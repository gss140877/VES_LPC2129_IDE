T19S15B8F — 9 Second Smooth Full-Scene Growth Startup
BASE: T19S15B8E, itself additive on hardware-validated T19S15B8D.

Startup changes only:
- duration changed from ~6.2 s to 9.0 s
- the COMPLETE startup scene scales as one unit from 34% to exactly 100%
- Ganapati, Vector artwork/logo, words/text, road, progress and all overlays remain together
- no independent image zoom
- final transform is exactly scale(1), avoiding end snap
- existing fade into IDE retained
- Esc skip retained

Validated IDE/ISP/flashing/Download HEX/CANLab/compiler/simulator implementation files are unchanged.

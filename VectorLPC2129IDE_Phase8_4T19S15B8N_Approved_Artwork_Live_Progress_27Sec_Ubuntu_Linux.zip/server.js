const express = require('express');
const fs = require('fs');
const path = require('path');
const os = require('os');
const child_process = require('child_process');

const app = express();
const PORT = process.env.PORT || 3000;
const root = __dirname;

app.use(express.json({limit:'10mb'}));
app.use(express.static(root));

function run(cmd, args, opts={}){
  return new Promise(resolve=>{
    child_process.execFile(cmd,args,{cwd:root,timeout:20000,...opts},(err,stdout,stderr)=>{
      resolve({ok:!err, output:[stdout,stderr,err?err.message:''].filter(Boolean).join('\n')});
    });
  });
}


/* T19S7 — deterministic four-node build in ONE HTTP transaction. */
async function t19s7BuildHex(code){
 const hdr=`typedef unsigned int uint32_t;
#define IO0PIN (*(volatile uint32_t*)0xE0028000u)
#define IO0SET (*(volatile uint32_t*)0xE0028004u)
#define IO0DIR (*(volatile uint32_t*)0xE0028008u)
#define IO0CLR (*(volatile uint32_t*)0xE002800Cu)
#define IO1PIN (*(volatile uint32_t*)0xE0028010u)
#define IO1SET (*(volatile uint32_t*)0xE0028014u)
#define IO1DIR (*(volatile uint32_t*)0xE0028018u)
#define IO1CLR (*(volatile uint32_t*)0xE002801Cu)
`;
 const d=fs.mkdtempSync(path.join(os.tmpdir(),'lpc2129-multi-'));
 const c=path.join(d,'main.c'),elf=path.join(d,'app.elf'),hex=path.join(d,'app.hex');
 fs.writeFileSync(c,hdr+'\n#line 1 "main.c"\n'+String(code||''));
 const args=['-mcpu=arm7tdmi','-marm','-O0','-g3','-ffreestanding','-nostdlib','-Wall','-Wextra','-T',
 path.join(root,'examples','linker_lpc2129.ld'),path.join(root,'examples','startup_lpc2129_minimal.s'),c,'-o',elf];
 const b=await run('arm-none-eabi-gcc',args,{timeout:20000});
 if(!b.ok)return {ok:false,output:b.output};
 const o=await run('arm-none-eabi-objcopy',['-O','ihex',elf,hex],{timeout:20000});
 if(!o.ok)return {ok:false,output:o.output};
 return {ok:true,hex:fs.readFileSync(hex,'utf8'),output:b.output+'\n'+o.output};
}
app.post('/api/build-hex-multinode',async(req,res)=>{
 try{
  const src=(req.body&&req.body.sources)||{},results={};
  for(const k of ['A','B','C','D']){
   results[k]=await t19s7BuildHex(src[k]);
   if(!results[k].ok)return res.json({ok:false,failedNode:k,results});
  }
  return res.json({ok:true,results});
 }catch(e){return res.json({ok:false,error:e.message||String(e),results:{}});}
});

app.post('/api/build-hex', async (req,res)=>{
  const userCode = String(req.body.code || '');
  const sourceTypeRaw = String(req.body.sourceType || req.body.lang || 'c').toLowerCase();
  const isAsm = ['asm','assembly','s','.s'].includes(sourceTypeRaw);

  const lpcHeader = `
/* Auto-injected LPC2129 register aliases for simulator C build */
typedef unsigned int uint32_t;
#define IO0PIN (*(volatile uint32_t *)0xE0028000u)
#define IO0SET (*(volatile uint32_t *)0xE0028004u)
#define IO0DIR (*(volatile uint32_t *)0xE0028008u)
#define IO0CLR (*(volatile uint32_t *)0xE002800Cu)
#define IO1PIN (*(volatile uint32_t *)0xE0028010u)
#define IO1SET (*(volatile uint32_t *)0xE0028014u)
#define IO1DIR (*(volatile uint32_t *)0xE0028018u)
#define IO1CLR (*(volatile uint32_t *)0xE002801Cu)
#define IOPIN IO0PIN
#define IOSET IO0SET
#define IODIR IO0DIR
#define IOCLR IO0CLR
`;

  /* C code receives the helper register aliases above. Assembly source must be
     written exactly as entered, otherwise GAS directives such as .syntax fail. */
  const code = isAsm ? userCode : (lpcHeader + '\n#line 1 \"main.c\"\n' + userCode);
  const work = fs.mkdtempSync(path.join(os.tmpdir(),'lpc2129-'));
  const src = path.join(work, isAsm ? 'main.s' : 'main.c');
  const startup = path.join(root,'examples','startup_lpc2129_minimal.s');
  const linker = path.join(root,'examples','linker_lpc2129.ld');
  const elf = path.join(work,'app.elf');
  const hex = path.join(work,'app.hex');
  fs.writeFileSync(src,code);

  const gccArgs = ['-mcpu=arm7tdmi','-marm','-O0','-g3','-ffreestanding','-nostdlib','-Wall','-Wextra','-T',linker,startup];
  if(isAsm) gccArgs.push('-x','assembler-with-cpp');
  gccArgs.push(src,'-o',elf);

  const build = await run('arm-none-eabi-gcc',gccArgs);
  if(!build.ok) return res.json({ok:false, sourceType:isAsm?'assembly':'c', output:'arm-none-eabi-gcc build failed.\nSource type: '+(isAsm?'Assembly (.s)':'C (.c)')+'\n'+build.output});
  const obj = await run('arm-none-eabi-objcopy',['-O','ihex',elf,hex]);
  if(!obj.ok) return res.json({ok:false, sourceType:isAsm?'assembly':'c', output:'objcopy failed.\n'+obj.output});
  const size = await run('arm-none-eabi-size',[elf]);
  const dbg = await run('arm-none-eabi-objdump',['-d','-S','-l',elf]);
  const hexText = fs.readFileSync(hex,'utf8');
  res.json({
    ok:true,
    sourceType:isAsm?'assembly':'c',
    hex:hexText,
    debugListing: dbg.output || '',
    output:'Build successful.\nSource type: '+(isAsm?'Assembly (.s)':'C (.c)')+'\nDebug symbols: enabled (-g3 -O0) for source-line stepping.\n'+build.output+'\n'+obj.output+'\n'+size.output
  });
});



/* Phase 8.0D: save editable source windows to a persistent project-local folder. */
app.post('/api/save-source', async (req,res)=>{
  try{
    const code = String(req.body.code || '');
    let fileName = String(req.body.fileName || '').trim();
    const sourceType = String(req.body.sourceType || 'c').toLowerCase();
    const ext = ['assembly','asm','s','.s'].includes(sourceType) ? '.s' : '.c';
    if(!fileName) fileName = 'main' + ext;
    fileName = path.basename(fileName).replace(/[^A-Za-z0-9_.-]/g,'_');
    if(!fileName.toLowerCase().endsWith(ext)) fileName += ext;
    const dir = path.join(root,'user_sources');
    fs.mkdirSync(dir,{recursive:true});
    const outPath = path.join(dir,fileName);
    fs.writeFileSync(outPath,code,'utf8');
    res.json({ok:true,fileName,path:outPath,output:'Source saved successfully.\n'+outPath});
  }catch(e){
    res.json({ok:false,output:'Save source failed.\n'+e.message});
  }
});

app.post('/api/save-hex', async (req,res)=>{
  try{
    const hexText = String(req.body.hex || '');
    let folderPath = String(req.body.folderPath || '').trim();
    let fileName = String(req.body.fileName || 'lpc2129_app.hex').trim();
    if(!hexText.trim()) return res.json({ok:false, output:'Missing HEX data. Build HEX first.'});
    if(!folderPath) return res.json({ok:false, output:'Missing folder path.'});
    fileName = fileName.replace(/[\\/:*?"<>|]/g,'_');
    if(!fileName.toLowerCase().endsWith('.hex')) fileName += '.hex';
    fs.mkdirSync(folderPath,{recursive:true});
    const outPath = path.join(folderPath,fileName);
    fs.writeFileSync(outPath,hexText,'utf8');
    res.json({ok:true, output:'HEX saved successfully.\n'+outPath, path:outPath});
  }catch(e){
    res.json({ok:false, output:'Save HEX failed.\n'+e.message+'\nTip: use a valid folder path such as /home/$USER/LPC2129_HEX'});
  }
});

app.get('/api/ports', async (req,res)=>{
  try{
    const { SerialPort } = require('serialport');
    const ports = await SerialPort.list();
    res.json({ok:true,ports});
  }catch(e){
    res.json({ok:false,ports:[],output:e.message});
  }
});

function normalizeComPort(port){
  // Flash Magic command files use numeric COM value: COM(3, 9600), not COM3.
  // Linux serial paths (/dev/ttyUSB0, /dev/ttyACM0, etc.) are returned unchanged.
  const p = String(port || '').trim();
  const m = p.match(/COM\s*(\d+)/i);
  return m ? m[1] : p;
}

function findFlashMagicExe(){
  const candidates = [];
  if(process.env.FLASHMAGIC_EXE) candidates.push(process.env.FLASHMAGIC_EXE);
  candidates.push('FlashMagic.exe','FM.exe','flashmagic.exe','fm.exe');
  if(process.platform === 'win32'){
    const bases = [process.env['ProgramFiles'], process.env['ProgramFiles(x86)'], 'C:\\Program Files', 'C:\\Program Files (x86)'].filter(Boolean);
    for(const base of bases){
      candidates.push(path.join(base,'Flash Magic','FlashMagic.exe'));
      candidates.push(path.join(base,'Flash Magic','FM.exe'));
      candidates.push(path.join(base,'FlashMagic','FlashMagic.exe'));
      candidates.push(path.join(base,'FlashMagic','FM.exe'));
    }
  }
  for(const c of candidates){
    try{ if(c && (c.includes(path.sep) || c.includes('\\')) && fs.existsSync(c)) return c; }catch{}
  }
  // Fall back to PATH lookup. execFile will resolve this if it exists in PATH.
  return process.platform === 'win32' ? 'FlashMagic.exe' : 'flashmagic';
}

app.post('/api/flash', async (req,res)=>{
  const port = String(req.body.port || '');
  const hexText = String(req.body.hex || '');
  const baud = String(req.body.baud || '9600');
  const oscMHz = String(req.body.oscMHz || '12.000');
  if(!port) return res.json({ok:false,output:'Missing serial port.'});
  if(!hexText.trim()) return res.json({ok:false,output:'Missing HEX data.'});

  const runtime = path.join(root,'runtime');
  fs.mkdirSync(runtime,{recursive:true});
  const hexFile = path.join(runtime,'lpc2129_app.hex');
  fs.writeFileSync(hexFile,hexText);

  if(process.platform !== 'win32'){
    // Native Ubuntu/Linux hardware flashing equivalent. The Phase 6.1A frontend
    // button is intentionally unchanged; this backend maps it to lpc21isp.
    const oscKHz = String(Math.round(parseFloat(oscMHz || '12') * 1000));
    const result = await run('lpc21isp',['-control','-verify',hexFile,port,baud,oscKHz],{timeout:120000});
    const missingHint = result.output.includes('ENOENT')
      ? '\nlpc21isp was not found. Install it with: sudo apt install lpc21isp\n'
      : '';
    return res.json({
      ok:result.ok,
      output:(result.ok?'LPC2129 ISP flashing completed with lpc21isp.\n':'LPC2129 ISP flashing failed.\n')+
             `Serial port: ${port}\nBaud: ${baud}\nOscillator: ${oscKHz} kHz\n`+
             result.output+missingHint
    });
  }

  const scriptFile = path.join(runtime,'flashmagic_lpc2129.fms');
  const quietFile = path.join(runtime,'flashmagic_output.txt');
  const comNo = normalizeComPort(port);
  const script = [
    '; Auto-generated by LPC2129 Simulator',
    '; Put LPC2129 in ISP mode before running this command.',
    `COM(${comNo}, ${baud})`,
    `DEVICE(LPC2129, ${oscMHz})`,
    'TIMEOUTS(10, 60)',
    `ERASEUSED(${hexFile}, PROTECTISP)`,
    `HEXFILE(${hexFile}, CHECKSUMS, NOFILL, PROTECTISP)`,
    `VERIFY(${hexFile})`,
    'EXECUTE(0, ARM)',
    ''
  ].join('\r\n');
  fs.writeFileSync(scriptFile,script);

  const fmExe = findFlashMagicExe();
  const result = await run(fmExe,[`@${scriptFile}`],{timeout:120000});
  let extra = '';
  try{ if(fs.existsSync(quietFile)) extra = '\n'+fs.readFileSync(quietFile,'utf8'); }catch{}
  const cmdShown = `Flash Magic command file: ${scriptFile}\nFlash Magic executable: ${fmExe}\n`;
  const missingHint = result.output.includes('ENOENT') ? '\nFlashMagic.exe was not found. Install Flash Magic or set FLASHMAGIC_EXE to the full exe path.\n' : '';
  res.json({ok:result.ok,output:(result.ok?'Flash Magic completed.\n':'Flash Magic command failed.\n')+cmdShown+result.output+extra+missingHint});
});


/* T19S15B1 additive detection-only native ISP. No flash writes. */
let vesSP=null;try{vesSP=require('serialport')}catch(_){}
async function vesPorts(){
 const found=new Map();
 try{if(vesSP){const S=vesSP.SerialPort||vesSP;const a=typeof S.list==='function'?await S.list():[];for(const p of a||[])if(p&&p.path)found.set(p.path,{path:p.path,manufacturer:p.manufacturer||'',source:'serialport'});}}catch(_){}
 if(process.platform==='linux'){
  try{for(const n of fs.readdirSync('/dev'))if(/^(ttyUSB\d+|ttyACM\d+|ttyAMA\d+|ttyS\d+)$/.test(n)){const p='/dev/'+n;if(!found.has(p))found.set(p,{path:p,manufacturer:'Linux serial device',source:'/dev'});}}catch(_){}
  for(const dir of ['/dev/serial/by-id','/dev/serial/by-path'])try{for(const n of fs.readdirSync(dir)){const p=path.join(dir,n);if(!found.has(p))found.set(p,{path:p,manufacturer:'Linux serial alias',source:dir});}}catch(_){}
 }
 return [...found.values()].sort((a,b)=>a.path.localeCompare(b.path));
}
app.get('/api/ves-isp/ports',async(req,res)=>{try{const p=await vesPorts();res.json({ok:true,ports:p.map(x=>({path:x.path,manufacturer:x.manufacturer||''}))})}catch(e){res.json({ok:false,error:e.message,ports:[]})}});
function vesDetect(pathName,xtal){
 return new Promise(resolve=>{
  if(!vesSP)return resolve({ok:false,error:'serialport module unavailable',log:[]});
  const S=vesSP.SerialPort||vesSP,log=[];let p,buf='',stage=0,done=false,timer;
  const finish=x=>{if(done)return;done=true;clearTimeout(timer);try{p.close()}catch(_){}resolve({...x,log})};
  const tx=x=>{log.push('TX '+JSON.stringify(x));p.write(x)};
  try{
   p=new S({path:pathName,baudRate:9600,autoOpen:false,lock:false});
   p.open(e=>{if(e)return finish({ok:false,error:e.message});log.push('OPEN '+pathName+' @ 9600');tx('?')});
   p.on('data',d=>{const x=d.toString('ascii');buf+=x;log.push('RX '+JSON.stringify(x));
    if(stage===0&&/Synchronized/i.test(buf)){buf='';stage=1;return tx('Synchronized\r\n')}
    if(stage===1&&/\bOK\b/i.test(buf)){buf='';stage=2;return tx(String(xtal)+'\r\n')}
    if(stage===2&&/\bOK\b/i.test(buf)){buf='';stage=3;return tx('J\r\n')}
    if(stage===3){const n=buf.match(/\b\d{4,10}\b/g);if(n&&n.length)return finish({ok:true,partId:n[n.length-1],xtalKHz:xtal,port:pathName})}
   });
   p.on('error',e=>finish({ok:false,error:e.message}));
  }catch(e){finish({ok:false,error:e.message})}
  timer=setTimeout(()=>finish({ok:false,error:'ISP detection timeout. Check manual ISP mode, UART0 wiring and port.'}),8000);
 });
}

app.post('/api/ves-isp/diagnose-port',async(req,res)=>{
 const p=String(req.body?.port||'');
 if(!p)return res.json({ok:false,error:'Serial port required'});
 const result={ok:true,path:p,exists:false,readable:false,writable:false,realPath:null,holders:[],advice:[]};
 try{result.exists=fs.existsSync(p);if(result.exists){result.realPath=fs.realpathSync(p);fs.accessSync(p,fs.constants.R_OK);result.readable=true;fs.accessSync(p,fs.constants.W_OK);result.writable=true;}}catch(e){result.accessError=e.message;}
 try{
  const cp=require('child_process');
  const a=cp.spawnSync('fuser',['-v',result.realPath||p],{encoding:'utf8',timeout:1500});
  const text=((a.stdout||'')+'\n'+(a.stderr||'')).trim();
  if(text)result.holders.push(text);
 }catch(_){}
 if(result.holders.length)result.advice.push('Another process appears to have the serial device open. Close that serial terminal/program first.');
 if(!result.writable)result.advice.push('Current VES process does not have read/write access to this device.');
 result.advice.push('Close Flash Magic, serial terminals, minicom/screen, Arduino Serial Monitor, and any other program using this port before Detect.');
 result.advice.push('On Ubuntu, ModemManager can probe USB serial adapters. If it owns the port, release/disable that service before ISP use.');
 res.json(result);
});
app.post('/api/ves-isp/detect',async(req,res)=>{
 const p=String(req.body?.port||''),x=Number(req.body?.xtalKHz||12000);
 if(!p)return res.json({ok:false,error:'Serial port required',log:[]});
 res.json(await vesDetect(p,x));
});


/* T19S15B7 — additive LPC2129 Linux ISP reference identification.
   Uses lpc21isp detect-only. Existing B3 VES Native ISP is untouched. */
app.post('/api/ves-isp/lpc21isp-identify',(req,res)=>{
 const cp=require('child_process');
 const port=String(req.body?.port||'');
 const baud=Number(req.body?.baud||9600);
 const xtal=Number(req.body?.xtalKHz||12000);
 if(!port)return res.json({ok:false,error:'Serial port required'});
 const args=['-PHILIPSARM','-detectonly',port,String(baud),String(xtal)];
 let r;
 try{r=cp.spawnSync('lpc21isp',args,{encoding:'utf8',timeout:20000});}
 catch(e){return res.json({ok:false,error:e.message,command:'lpc21isp '+args.join(' ')})}
 const text=((r.stdout||'')+'\n'+(r.stderr||'')).trim();
 const m=text.match(/Read part ID:\s*(LPC\d+),\s*(\d+)\s*kiB FLASH\s*\/\s*(\d+)\s*kiB SRAM\s*\((0x[0-9A-Fa-f]+)\)/i);
 const bv=text.match(/Read bootcode version:\s*(\d+)\s*[\r\n]+\s*(\d+)/i);
 if(!m)return res.json({ok:false,error:'lpc21isp did not identify an LPC device',output:text,exitCode:r.status});
 const device=m[1].toUpperCase(),partIdHex=m[4].toUpperCase().replace('0X','0x');
 const isLpc2129=(device==='LPC2129' && partIdHex.toUpperCase()==='0X0201FF13');
 res.json({ok:true,manufacturer:'NXP',device,flashKiB:Number(m[2]),sramKiB:Number(m[3]),
   partIdHex,bootRom:bv?(bv[1]+'.'+bv[2]):'n/a',port,baud,xtalKHz:xtal,
   lpc2129Verified:isLpc2129,programmingAllowed:false,mode:'detect-only',output:text});
});


/* T19S15B8 — additive Linux LPC2129 programmer + first-use installer.
   B7 identify remains the mandatory safety gate. */
function vesRun(cmd,args,timeout=120000){
 const cp=require('child_process');
 try{
  const r=cp.spawnSync(cmd,args,{encoding:'utf8',timeout});
  return {ok:r.status===0,status:r.status,output:((r.stdout||'')+'\n'+(r.stderr||'')).trim(),error:r.error?r.error.message:null};
 }catch(e){return {ok:false,status:null,output:'',error:e.message}}
}
app.get('/api/ves-isp/lpc21isp-status',(req,res)=>{
 const r=vesRun('sh',['-lc','command -v lpc21isp && lpc21isp 2>&1 | head -n 3'],5000);
 res.json({installed:!!(r.output&&/lpc21isp/i.test(r.output)),output:r.output,error:r.error});
});
app.post('/api/ves-isp/install-lpc21isp',(req,res)=>{
 /* Explicit user button only. Uses Ubuntu package manager; pkexec supplies normal desktop authorization UI. */
 const script='apt-get update && apt-get install -y lpc21isp';
 const r=vesRun('pkexec',['sh','-lc',script],180000);
 res.json({ok:r.ok,output:r.output,error:r.error,status:r.status});
});
app.post('/api/ves-isp/program-lpc2129',(req,res)=>{
 const port=String(req.body?.port||''),hex=String(req.body?.hex||''),xtal=Number(req.body?.xtalKHz||12000);
 if(!port||!hex)return res.json({ok:false,error:'Port and HEX are required'});
 /* Re-identify target immediately before any programming process. */
 const id=vesRun('lpc21isp',['-PHILIPSARM','-detectonly',port,'9600',String(xtal)],25000);
 const m=id.output.match(/Read part ID:\s*(LPC\d+),.*\((0x[0-9A-Fa-f]+)\)/i);
 if(!m || m[1].toUpperCase()!=='LPC2129' || m[2].toUpperCase()!=='0X0201FF13')
   return res.json({ok:false,blocked:true,error:'PROGRAM BLOCKED: live target is not verified LPC2129 (0x0201FF13).',identifyOutput:id.output});
 const os=require('os'),p=require('path'),tmp=p.join(os.tmpdir(),'ves_lpc2129_'+process.pid+'_'+Date.now()+'.hex');
 try{
  fs.writeFileSync(tmp,hex,'utf8');
  /* lpc21isp performs programming and its normal verification sequence. */
  const pr=vesRun('lpc21isp',['-PHILIPSARM',tmp,port,'9600',String(xtal)],120000);
  res.json({ok:pr.ok,blocked:false,output:pr.output,identifyOutput:id.output,status:pr.status});
 }finally{try{fs.unlinkSync(tmp)}catch(_){}}
});

app.listen(PORT,()=>console.log(`VECTOR LPC2129 IDE Phase 7.0A running at http://localhost:${PORT}`));

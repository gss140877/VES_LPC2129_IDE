T19S15B8D — Download HEX Native Save-As Fix
BASE: validated T19S15B8B.

Root cause of B8C:
The visible top-toolbar "Download HEX" button does NOT use phase84t19s15a_firmware_manager.js.
It calls saveHexPreferredFolder() in simulator.js. B8C changed the wrong download path.

B8D changes the actual toolbar function:
Download HEX -> native showSaveFilePicker() -> browse destination -> edit filename -> Save.
If the runtime does not expose showSaveFilePicker, it falls back to the normal browser download flow.

Removed behavior for this button:
- no manual text prompt asking for a server folder such as C:\LPC2129_HEX.

Validated B8B VES Native ISP / Browse HEX / Flash HEX & Verify remains byte-for-byte unchanged.
server.js and index.html remain byte-for-byte unchanged from B8B.

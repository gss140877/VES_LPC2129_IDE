T19S15B8N — Approved No-Static-Bar Artwork + Live Progress
BASE: B8L application baseline.

- Uses the newly approved startup artwork:
  "Launching Vector LPC2129 IDE ..." remains in the artwork.
  No static/baked progress bar is present.
- Adds exactly ONE live HTML/CSS progress track directly below that tagline.
- Live percentage aligned to the right of the bar.
- Progress 0 -> 100% synchronized to 27 seconds.
- Whole-scene smooth growth/fade and Esc skip retained.
- Validated IDE/ISP/flashing/Download HEX/CANLab/compiler/simulator core unchanged.

T19S15B8B — Working B8 ISP + Browse/Flash Runtime Fix

ROOT CAUSE OF B8A REGRESSION:
B8A attached vesIspHexFile.onchange at module-load time, before the ISP panel DOM existed.
That dereferenced a missing element and aborted the ISP JavaScript module, which also prevented
the original VES Native ISP launcher from appearing.

B8B starts again from the exact user-uploaded working B8.
- No new DOM access occurs during module load.
- Browse HEX event binding occurs only in B8's existing post-panel-creation binding block.
- index.html unchanged byte-for-byte.
- server.js unchanged byte-for-byte.
- Original working VES Native ISP launcher architecture untouched.
- Browse HEX + Flash HEX & Verify added.
- Existing live LPC2129 / 0x0201FF13 safety gate retained.

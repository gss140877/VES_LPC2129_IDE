T19S15B8L — Clean Lower Branding + Single Progress Presentation
Visual baseline: B8H (before B8I/B8J artwork inpainting).

Screenshot diagnosis:
- B8J/K artwork cleanup caused the hazy lower Vector branding.
- B8K then removed the live bar, exposing the damaged/static launch area.

B8L fix:
- Restores the complete B8H startup PNG byte-for-byte: no progress-bar inpainting and no lower-branding inpainting.
- Removes ONLY the duplicate HTML/CSS progress bar.
- Therefore the original artwork's single launch/progress presentation remains visible.
- Lower VECTOR INDIA branding is restored from the undamaged B8H artwork.
- 27-second smooth whole-scene growth, fade and Esc skip retained.
- Validated IDE/ISP/flashing/Download HEX/CANLab/compiler/simulator implementation unchanged.

T19S15B8 — Linux ISP Program/Verify + First-Use Installer
BASE: user-validated T19S15B7.

Added:
- Install/Check lpc21isp button.
- Installation is only initiated by explicit button press and uses pkexec:
  apt-get update && apt-get install -y lpc21isp
  Ubuntu displays its normal authorization dialog.
- Program & Verify Current HEX button.
- Button enables only after B7 verifies LPC2129 / 0x0201FF13.
- Server RE-IDENTIFIES the live target immediately before programming; UI state alone cannot bypass safety.
- If target is not LPC2129 / 0x0201FF13, programming is blocked.
- Uses exact current HEX from validated T19S15A Firmware Manager.
- Temporary HEX is deleted after lpc21isp completes.
- Complete lpc21isp output is shown in the monitor.

Existing B7 Identify, B3 Native Detect/Diagnostics, Flash Magic, HEX export,
simulator, CANLab, examples, canvas, wiring and peripherals are retained.

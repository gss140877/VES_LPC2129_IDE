T19S15B7 — LPC2129 Linux ISP Reference Identification

BASE: user-uploaded, real-hardware-validated T19S15B3.
Existing B3 VES Native ISP detection/diagnostics remain untouched.

NEW:
Linux LPC2129 Identify button invokes:
lpc21isp -PHILIPSARM -detectonly <port> 9600 12000

It reports the actual device, Part ID, boot ROM, Flash and SRAM.
For LPC2129 the safety verifier requires BOTH:
device = LPC2129
Part ID = 0x0201FF13

If another LPC device (e.g. LPC2148) is connected, it is identified but explicitly marked NOT LPC2129.
Programming remains disabled in B7 regardless of result.
No erase/program/write operation is invoked.

Flash Magic, HEX manager, simulator, CANLab, examples, canvas, wiring and peripherals are untouched.

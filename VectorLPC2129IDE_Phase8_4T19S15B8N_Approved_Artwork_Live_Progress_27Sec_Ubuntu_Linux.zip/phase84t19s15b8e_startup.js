(()=>{
 const splash=document.getElementById('vesStartupSplash');
 const fill=document.getElementById('vesStartupProgressFill');
 const pct=document.getElementById('vesStartupPercent');
 if(!splash)return;
 const total=27000,start=performance.now();
 function tick(now){
   const p=Math.min(100,Math.round(((now-start)/total)*100));
   if(fill)fill.style.width=p+'%';
   if(pct)pct.textContent=p+'%';
   if(p<100){requestAnimationFrame(tick);return}
   setTimeout(()=>{
     splash.classList.add('vesDone');
     setTimeout(()=>splash.remove(),750);
   },220);
 }
 requestAnimationFrame(tick);
 addEventListener('keydown',e=>{
   if(e.key==='Escape'&&splash.isConnected){
     splash.classList.add('vesDone');
     setTimeout(()=>splash.remove(),300);
   }
 },{once:true});
})();
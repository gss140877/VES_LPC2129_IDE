(()=>{'use strict';
const E=x=>document.getElementById(x),J=async(p,o)=>await(await fetch(p,o)).json();
async function ports(){const d=await J('/api/ves-isp/ports'),s=E('vesIspPort');s.innerHTML='';(d.ports||[]).forEach(p=>{let o=document.createElement('option');o.value=p.path;o.textContent=p.path+(p.manufacturer?' — '+p.manufacturer:'');s.appendChild(o)});E('vesIspStatus').textContent=d.ok?(d.ports.length?('PORTS READY • '+d.ports.length+' FOUND'):'NO PORTS ENUMERATED — USE MANUAL PATH'):'PORT LIST ERROR'}
async function diagnose(){
 const p=(E('vesIspManualPort').value.trim()||E('vesIspPort').value);
 const d=await J('/api/ves-isp/diagnose-port',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({port:p})});
 E('vesIspDiagOut').textContent='Port: '+(d.path||p)+'\nReal path: '+(d.realPath||'-')+'\nExists: '+!!d.exists+'\nReadable: '+!!d.readable+'\nWritable: '+!!d.writable+'\n\nPort holders:\n'+((d.holders||[]).join('\n')||'none reported')+'\n\n'+(d.advice||[]).join('\n');
}
async function detect(){E('vesIspStatus').textContent='DETECTING...';E('vesIspLog').textContent='';const d=await J('/api/ves-isp/detect',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({port:(E('vesIspManualPort').value.trim()||E('vesIspPort').value),xtalKHz:Number(E('vesIspXtal').value||12000)})});E('vesIspLog').textContent=(d.log||[]).join('\n');E('vesIspStatus').textContent=d.ok?'ISP READY':'DETECTION FAILED';E('vesIspDevice').textContent=d.ok?('Part ID: '+d.partId+'  Oscillator: '+d.xtalKHz+' kHz'):(d.error||'Unknown error')}
async function linuxIdentify(){
 const port=(E('vesIspManualPort').value.trim()||E('vesIspPort').value),xtal=Number(E('vesIspXtal').value||12000);
 E('vesIspStatus').textContent='LPC21ISP DETECT-ONLY...';E('vesIspLog').textContent='';
 const d=await J('/api/ves-isp/lpc21isp-identify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({port,baud:9600,xtalKHz:xtal})});
 E('vesIspLog').textContent=d.output||d.error||'';
 if(!d.ok){E('vesIspStatus').textContent='LINUX ISP IDENTIFICATION FAILED';E('vesIspDevice').textContent=d.error||'Unknown error';return}
 E('vesIspStatus').textContent=d.lpc2129Verified?'LPC2129 VERIFIED • PROGRAMMING ENABLED':'DEVICE IDENTIFIED • NOT LPC2129';E('vesIspProgram').disabled=!d.lpc2129Verified;
 E('vesIspDevice').textContent='Manufacturer: '+d.manufacturer+'  Device: '+d.device+'  Part ID: '+d.partIdHex+
 '  Boot ROM: '+d.bootRom+'  Flash: '+d.flashKiB+' KiB  SRAM: '+d.sramKiB+' KiB  Oscillator: '+d.xtalKHz+' kHz';
}
async function checkInstall(install=false){
 E('vesIspStatus').textContent=install?'INSTALLING LPC21ISP...':'CHECKING LPC21ISP...';
 const d=install?await J('/api/ves-isp/install-lpc21isp',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}):await J('/api/ves-isp/lpc21isp-status');
 E('vesIspLog').textContent=d.output||d.error||'';
 E('vesIspStatus').textContent=install?(d.ok?'LPC21ISP INSTALL COMPLETE':'LPC21ISP INSTALL FAILED'):(d.installed?'LPC21ISP INSTALLED':'LPC21ISP NOT INSTALLED');
}
let vesBrowsedHex=null;
function browseHex(){const x=E('vesIspHexFile');if(x)x.click()}
async function selectedHexChanged(ev){
 const f=ev.target.files&&ev.target.files[0];if(!f)return;
 const label=E('vesIspHexName');
 if(!/\.hex$/i.test(f.name)){vesBrowsedHex=null;if(label)label.textContent='Rejected: choose a .hex file';return}
 const text=await f.text(),records=text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 const valid=records.length>0&&records.every(x=>/^:[0-9A-Fa-f]+$/.test(x))&&records.some(x=>/^:..[0-9A-Fa-f]{4}00/i.test(x));
 if(!valid){vesBrowsedHex=null;if(label)label.textContent='Rejected: invalid Intel HEX';return}
 vesBrowsedHex={name:f.name,text,size:f.size};
 if(label)label.textContent='Selected: '+f.name+' ('+f.size+' bytes)';
}
async function programCurrent(){
 const fm=(window.VESFirmware&&window.VESFirmware.current&&window.VESFirmware.current.valid&&window.VESFirmware.current.hex)?{name:'Current Firmware Manager HEX',text:window.VESFirmware.current.hex}:null;
 const fw=vesBrowsedHex||fm;
 if(!fw){E('vesIspStatus').textContent='PROGRAM BLOCKED';E('vesIspDevice').textContent='Browse a valid Intel HEX file or compile/capture a valid current HEX first.';return}
 if(!confirm('Flash "'+fw.name+'" to the LIVE LPC2129 and verify it? The target will be re-identified before flashing.'))return;
 const port=(E('vesIspManualPort').value.trim()||E('vesIspPort').value),xtal=Number(E('vesIspXtal').value||12000);
 E('vesIspStatus').textContent='RE-IDENTIFYING TARGET...';E('vesIspLog').textContent='';
 const d=await J('/api/ves-isp/program-lpc2129',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({port,xtalKHz:xtal,hex:fw.text})});
 E('vesIspLog').textContent=((d.identifyOutput||'')+'\n\n'+(d.output||d.error||'')).trim();
 E('vesIspStatus').textContent=d.ok?'FLASH & VERIFY COMPLETE':(d.blocked?'PROGRAM BLOCKED':'FLASH/VERIFY FAILED');
}
function open(){let p=E('vesIspPanel');if(p){p.style.display='block';return}p=document.createElement('div');p.id='vesIspPanel';p.innerHTML=`<div class="vh"><b>VES Native ISP • LPC2129 Detection</b><button id="vesIspClose">×</button></div><div class="vb"><div class="notice">Detection only — erase/program/write are disabled.</div><label>Serial Port <select id="vesIspPort"></select></label><button id="vesIspRefresh">Refresh Ports</button><button id="vesIspDiag">Diagnose Port</button><label>Manual Linux Port <input id="vesIspManualPort" placeholder="/dev/ttyUSB0"></label><label>Oscillator <input id="vesIspXtal" value="12000" type="number"> kHz</label><p>Put the LPC2129 board in manual UART0 ISP mode, reset it, then press Detect.</p><button id="vesIspDetect">Detect LPC2129</button><button id="vesLpc21Identify">Linux LPC2129 Identify</button><button id="vesIspInstall">Install/Check lpc21isp</button><input id="vesIspHexFile" type="file" accept=".hex,text/plain" style="display:none"><button id="vesIspBrowseHex">Browse HEX...</button><span id="vesIspHexName">No HEX selected</span><button id="vesIspProgram" disabled>Flash HEX & Verify</button><div id="vesIspStatus">IDLE</div><div id="vesIspDevice">Device not detected</div><pre id="vesIspDiagOut"></pre><h4>ISP Protocol Monitor</h4><pre id="vesIspLog"></pre></div>`;document.body.appendChild(p);E('vesIspClose').onclick=()=>p.style.display='none';E('vesIspRefresh').onclick=ports;E('vesIspDiag').onclick=diagnose;E('vesIspDetect').onclick=detect;E('vesLpc21Identify').onclick=linuxIdentify;E('vesIspInstall').onclick=()=>checkInstall(true);E('vesIspBrowseHex').onclick=browseHex;E('vesIspHexFile').onchange=selectedHexChanged;E('vesIspProgram').onclick=programCurrent;ports()}
function add(){if(E('vesNativeIspBtn'))return;const fw=E('vesFirmwareBtn'),b=document.createElement('button');b.id='vesNativeIspBtn';b.textContent='VES Native ISP';b.onclick=open;if(fw&&fw.parentNode)fw.parentNode.insertBefore(b,fw.nextSibling);else document.body.appendChild(b)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',add);else add();setTimeout(add,700);
})();
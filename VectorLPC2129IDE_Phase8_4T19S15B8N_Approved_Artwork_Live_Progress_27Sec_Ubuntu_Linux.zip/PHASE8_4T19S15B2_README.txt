T19S15B2 — Linux Serial Port Discovery Fix
Protected base: T19S15B1.
Only native ISP serial discovery changed.
Adds Linux /dev ttyUSB*, ttyACM*, ttyAMA*, ttyS* discovery, /dev/serial aliases, and manual /dev/ttyUSB0 entry.
No erase/program/write support. Existing Flash Magic and validated IDE functions are untouched.

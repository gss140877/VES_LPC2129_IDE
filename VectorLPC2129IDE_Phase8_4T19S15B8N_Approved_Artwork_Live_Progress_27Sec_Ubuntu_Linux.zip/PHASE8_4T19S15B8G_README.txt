T19S15B8G — 27 Second Unclipped Vector Tagline Startup
BASE: T19S15B8F.

Startup-only changes:
- duration: 9 s -> 27 s
- full approved scene still grows smoothly from 34% to 100%
- startup artwork uses full-frame fit so top-right VECTOR INDIA is not cropped
- obsolete "Engineering Education for a Smarter Tomorrow" is visually covered
- exact replacement text: "Drives You To Industry....."
- replacement applied at both top-right and bottom Vector branding locations
- no new/regenerated artwork
- smooth fade to IDE and Esc skip retained

Validated B8D implementation files for ISP/flashing/Download HEX/CANLab/compiler/simulator remain unchanged.

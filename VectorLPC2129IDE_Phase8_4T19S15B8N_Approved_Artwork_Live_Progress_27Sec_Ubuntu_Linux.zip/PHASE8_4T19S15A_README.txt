T19S15A — Universal LPC2129 HEX Manager
Protected base: validated T19S14.
Additive Firmware menu. Existing compiler, simulator, peripheral/CAN engines, canvas, wiring and examples remain unchanged.
Export uses exact HEX already held by runtime; it does not recompile.
Includes Node A/B/C/D HEX export and all-node manifest.
ISP flashing is intentionally deferred.

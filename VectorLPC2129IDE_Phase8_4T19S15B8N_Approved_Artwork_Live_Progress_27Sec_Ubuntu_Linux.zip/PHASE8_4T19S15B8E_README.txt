T19S15B8E: additive 6.2s animated startup splash on validated B8D. Existing ISP, flashing, Download HEX, CANLab, compiler and simulator implementation files are unchanged.

T19S15B3 — Serial Lock Diagnostics
Base: validated T19S15B2 functionality retained.
Observed real CP2102 at /dev/ttyUSB0 but Detect returned: Resource temporarily unavailable / Cannot lock port.

ISP-only additive changes:
- SerialPort open requests lock:false.
- Diagnose Port button reports existence, resolved path, R/W access and fuser holders.
- Gives Ubuntu guidance for competing serial terminals / Flash Magic / ModemManager.
- No process is killed and no service/permission is modified automatically.
- Still detection-only: no erase/program/write commands.

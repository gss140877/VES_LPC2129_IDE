T19S15B1 — VES Native LPC2129 ISP Detection
Base: validated T19S15A. Existing Flash Magic ISP is untouched.
Additive detection path only: list serial ports, manual UART0 ISP synchronization, oscillator handshake, Read Part ID, protocol monitor.
No erase/program/write commands are implemented in this milestone.

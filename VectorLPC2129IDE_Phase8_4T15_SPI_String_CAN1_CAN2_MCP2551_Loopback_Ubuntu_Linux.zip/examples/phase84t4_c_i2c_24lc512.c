/* VECTOR LPC2129 — I2C + 24LC512 classroom example
   String: "Vector India Pvt Ltd" (20 bytes)

   Demonstrates BOTH complete paths:
   A) BYTE WRITE each character -> RANDOM READ each character -> LPC2129 RAM
   B) PAGE WRITE complete string -> SEQUENTIAL READ complete string -> LPC2129 RAM

   EEPROM:
     0x0100..0x0113 : byte-write copy
     0x0200..0x0213 : page-write copy
   RAM:
     byte_random_ram[] : random-read result
     page_seq_ram[]    : sequential-read result

   LPC2129 I2C pins: P0.2=SCL, P0.3=SDA
   24LC512 7-bit address: 0x50
*/
#define PINSEL0   (*(volatile unsigned long *)0xE002C000)
#define I2CONSET  (*(volatile unsigned long *)0xE001C000)
#define I2STAT    (*(volatile unsigned long *)0xE001C004)
#define I2DAT     (*(volatile unsigned long *)0xE001C008)
#define I2SCLH    (*(volatile unsigned long *)0xE001C010)
#define I2SCLL    (*(volatile unsigned long *)0xE001C014)
#define I2CONCLR  (*(volatile unsigned long *)0xE001C018)

#define I2_AA 0x04
#define I2_SI 0x08
#define I2_STO 0x10
#define I2_STA 0x20
#define I2_I2EN 0x40
#define TEXT_LEN 20

/* const -> Flash/ROM; volatile destination arrays -> SRAM */
static const unsigned char source_text[TEXT_LEN+1] = "Vector India Pvt Ltd";
volatile unsigned char byte_random_ram[TEXT_LEN+1];
volatile unsigned char page_seq_ram[TEXT_LEN+1];
volatile unsigned long i2c_demo_complete;

static void wait_si(void){while((I2CONSET&I2_SI)==0){}}
static int expect(unsigned long s){return (I2STAT&0xF8)==s;}

static void i2c_init(void){
    PINSEL0=(PINSEL0&~0xF0UL)|0x50UL; /* P0.2=SCL, P0.3=SDA */
    I2SCLH=75; I2SCLL=75;            /* ~100 kHz @ PCLK=15 MHz */
    I2CONCLR=I2_AA|I2_SI|I2_STA;
    I2CONSET=I2_I2EN;
}
static int i2c_start(void){
    I2CONSET=I2_STA; I2CONCLR=I2_SI; wait_si();
    return expect(0x08)||expect(0x10);
}
static void i2c_stop(void){I2CONSET=I2_STO;I2CONCLR=I2_SI;}
static int i2c_tx(unsigned char b,unsigned long expected){
    I2DAT=b;I2CONCLR=I2_STA|I2_SI;wait_si();return expect(expected);
}
static unsigned char i2c_rx_ack(void){
    I2CONSET=I2_AA;I2CONCLR=I2_SI;wait_si();return (unsigned char)I2DAT;
}
static unsigned char i2c_rx_nack(void){
    I2CONCLR=I2_AA|I2_SI;wait_si();return (unsigned char)I2DAT;
}
static int set_pointer(unsigned int a){
    if(!i2c_start())return 0;
    if(!i2c_tx(0xA0,0x18))return 0;
    if(!i2c_tx((unsigned char)(a>>8),0x28))return 0;
    if(!i2c_tx((unsigned char)a,0x28))return 0;
    return 1;
}
static int byte_write(unsigned int a,unsigned char d){
    if(!set_pointer(a))return 0;
    if(!i2c_tx(d,0x28))return 0;
    i2c_stop();return 1;
}
static unsigned char random_read(unsigned int a){
    unsigned char d=0;
    if(!set_pointer(a))return 0;
    if(!i2c_start())return 0;
    if(!i2c_tx(0xA1,0x40))return 0;
    d=i2c_rx_nack();i2c_stop();return d;
}
static int page_write(unsigned int a,const unsigned char *p,unsigned int n){
    unsigned int i;
    if(!set_pointer(a))return 0;
    for(i=0;i<n;i++)if(!i2c_tx(p[i],0x28))return 0;
    i2c_stop();return 1;
}
static int sequential_read(unsigned int a,volatile unsigned char *p,unsigned int n){
    unsigned int i;
    if(!n)return 1;
    if(!set_pointer(a))return 0;
    if(!i2c_start())return 0;
    if(!i2c_tx(0xA1,0x40))return 0;
    for(i=0;i<n-1;i++)p[i]=i2c_rx_ack();
    p[n-1]=i2c_rx_nack();i2c_stop();return 1;
}
int main(void){
    unsigned int i;
    i2c_init();

    /* A: BYTE WRITE entire string, one EEPROM transaction per character. */
    for(i=0;i<TEXT_LEN;i++)byte_write(0x0100+i,source_text[i]);

    /* RANDOM READ every byte into LPC2129 SRAM. */
    for(i=0;i<TEXT_LEN;i++)byte_random_ram[i]=random_read(0x0100+i);
    byte_random_ram[TEXT_LEN]=0;

    /* B: PAGE WRITE complete 20-byte string in one page transaction. */
    page_write(0x0200,source_text,TEXT_LEN);

    /* SEQUENTIAL READ complete page-written string into LPC2129 SRAM. */
    sequential_read(0x0200,page_seq_ram,TEXT_LEN);
    page_seq_ram[TEXT_LEN]=0;

    i2c_demo_complete=0x1234ABCD;
    while(1){}
}

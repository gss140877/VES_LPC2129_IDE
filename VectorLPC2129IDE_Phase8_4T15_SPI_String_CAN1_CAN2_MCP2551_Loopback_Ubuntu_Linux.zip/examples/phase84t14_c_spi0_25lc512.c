/* VECTOR LPC2129 — SPI0 + 25LC512 string EEPROM example
   String: "Vector India Pvt Ltd" (20 bytes)

   A) BYTE WRITE each character to 0x0100..0x0113
      then BYTE READ each character into spi_byte_ram[] in LPC2129 SRAM.

   B) PAGE WRITE the complete 20-byte string to 0x0200..0x0213
      then SEQUENTIAL READ the complete string into spi_seq_ram[] in SRAM.

   SPI0: P0.4=SCK0, P0.5=MISO0, P0.6=MOSI0
   CS:   P0.7 GPIO, active low
*/
#define PINSEL0  (*(volatile unsigned long *)0xE002C000)
#define IO0SET   (*(volatile unsigned long *)0xE0028004)
#define IO0DIR   (*(volatile unsigned long *)0xE0028008)
#define IO0CLR   (*(volatile unsigned long *)0xE002800C)

#define S0SPCR   (*(volatile unsigned long *)0xE0020000)
#define S0SPSR   (*(volatile unsigned long *)0xE0020004)
#define S0SPDR   (*(volatile unsigned long *)0xE0020008)
#define S0SPCCR  (*(volatile unsigned long *)0xE002000C)
#define S0SPINT  (*(volatile unsigned long *)0xE002001C)

#define SPIF     0x80
#define MSTR     0x20
#define CS       (1UL<<7)
#define TEXT_LEN 20

static const unsigned char source_text[TEXT_LEN+1] = "Vector India Pvt Ltd";
volatile unsigned char spi_byte_ram[TEXT_LEN+1];
volatile unsigned char spi_seq_ram[TEXT_LEN+1];
volatile unsigned long spi_demo_complete;

static void cs_high(void){IO0SET=CS;}
static void cs_low(void){IO0CLR=CS;}
static void spi0_init(void){
    PINSEL0=(PINSEL0&~0xFF00UL)|0x1500UL;
    IO0DIR|=CS; cs_high();
    S0SPCCR=8;
    S0SPCR=MSTR;       /* master, mode 0, MSB first */
    S0SPINT=1;
}
static unsigned char xfer(unsigned char d){
    S0SPDR=d;
    while((S0SPSR&SPIF)==0){}
    return (unsigned char)S0SPDR;
}
static void wren(void){cs_low();xfer(0x06);cs_high();}
static void byte_write(unsigned int a,unsigned char d){
    wren();cs_low();xfer(0x02);xfer((unsigned char)(a>>8));xfer((unsigned char)a);xfer(d);cs_high();
}
static unsigned char byte_read(unsigned int a){
    unsigned char d;cs_low();xfer(0x03);xfer((unsigned char)(a>>8));xfer((unsigned char)a);d=xfer(0xFF);cs_high();return d;
}
static void page_write(unsigned int a,const unsigned char *p,unsigned int n){
    unsigned int i;wren();cs_low();xfer(0x02);xfer((unsigned char)(a>>8));xfer((unsigned char)a);
    for(i=0;i<n;i++)xfer(p[i]);
    cs_high();
}
static void sequential_read(unsigned int a,volatile unsigned char *p,unsigned int n){
    unsigned int i;cs_low();xfer(0x03);xfer((unsigned char)(a>>8));xfer((unsigned char)a);
    for(i=0;i<n;i++)p[i]=xfer(0xFF);
    cs_high();
}
int main(void){
    unsigned int i;
    spi0_init();

    for(i=0;i<TEXT_LEN;i++) byte_write(0x0100+i,source_text[i]);
    for(i=0;i<TEXT_LEN;i++) spi_byte_ram[i]=byte_read(0x0100+i);
    spi_byte_ram[TEXT_LEN]=0;

    page_write(0x0200,source_text,TEXT_LEN);
    sequential_read(0x0200,spi_seq_ram,TEXT_LEN);
    spi_seq_ram[TEXT_LEN]=0;

    spi_demo_complete=0x25AC0512;
    while(1){}
}

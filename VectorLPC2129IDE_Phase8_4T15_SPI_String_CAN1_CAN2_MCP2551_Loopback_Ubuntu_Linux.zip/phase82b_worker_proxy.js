/* VECTOR LPC2129 IDE — Phase 8.2B
   Main-thread proxy for dedicated ARM7 worker.
*/
(function(){
'use strict';
if(window.__phase82bProxyInstalled)return;
window.__phase82bProxyInstalled=true;
let worker=null,workerRunning=false,lastState=null;
let pendingEepromConfig={present:true,a0:0,a1:0,a2:0};
let pendingSpiEepromConfig={present:true};
let pendingCanBusConfig={connected:true,term1:true,term2:true,mcp1:true,mcp2:true};
let memoryReqSeq=1;const memoryReqPending=new Map();
let pendingTerminal={0:'',1:''},terminalRAF=0;
let lastCanvasPins={p0:null,p1:null,d0:null,d1:null};

function logSafe(s){try{if(typeof log==='function')log(s)}catch(e){}}
function clock(){const c=window.LPC2129ClockConfig||{};return {cclkHz:Number(c.cclkHz)||60000000,pclkHz:Number(c.pclkHz)||15000000}}

function createMirror(st){
  if(!st)return null;
  const m=window.lpcArm7Emu||{};
  m.running=!!st.running;m.steps=st.steps||0;m.r=Uint32Array.from(st.r||[]);
  m.cpsr=st.cpsr||{};m.gpio=st.gpio||{};m.profiler=st.profiler||{};
  m.decodeStats=st.decodeStats||{ARM:{},THUMB:{}};m.disasm=st.disasm||'';m.lastError=st.lastError||'';
  m.unsupportedCount=st.unsupportedCount||0;m.lastUnsupported=st.lastUnsupported||null;
  m.gpioPinChangeCount=st.gpioPinChangeCount||0;m.lastGpioTransitionCycles=st.lastGpioTransitionCycles||0;
  m.uartWorkerState={0:st.uart0,1:st.uart1};m.adcWorkerState=st.adc||{};m.timerWorkerState={0:st.timer0||{},1:st.timer1||{}};m.pwmWorkerState=st.pwm||{};m.rtcWorkerState=st.rtc||{};m.i2cWorkerState=st.i2c||{};m.spiWorkerState={0:st.spi0||{},1:st.spi1||{}};m.canWorkerState={1:st.can1||{},2:st.can2||{},af:st.canAF||{},bus:st.canBus||{}};m.vic=st.vic||{};m.pinConnect=st.pinConnect||{};
  window.lpcAdc=st.adc||{};window.lpcTimers={0:st.timer0||{},1:st.timer1||{}};window.lpcPwm=st.pwm||{};window.lpcRtc=st.rtc||{};window.lpcI2C=st.i2c||{};window.lpcSPI={0:st.spi0||{},1:st.spi1||{}};window.lpcCAN={1:st.can1||{},2:st.can2||{},af:st.canAF||{},bus:st.canBus||{}};
  window.lpcArm7Emu=m;return m;
}
function applyCanvas(st){
  if(!st||!st.gpio)return;
  const g=st.gpio;
  window.lpcGpio=window.lpcGpio||{};
  const p0=window.lpcGpio.p0||(window.lpcGpio.p0={});
  const p1=window.lpcGpio.p1||(window.lpcGpio.p1={});
  p0.IOPIN=p0.pin=g.IO0PIN>>>0;p0.IODIR=p0.dir=g.IO0DIR>>>0;p0.IOSET=p0.set=g.IO0SET>>>0;p0.IOCLR=p0.clr=g.IO0CLR>>>0;
  p1.IOPIN=p1.pin=g.IO1PIN>>>0;p1.IODIR=p1.dir=g.IO1DIR>>>0;p1.IOSET=p1.set=g.IO1SET>>>0;p1.IOCLR=p1.clr=g.IO1CLR>>>0;
  window.lpcGpio.running=!!st.running;
  const changed=lastCanvasPins.p0!==p0.pin||lastCanvasPins.p1!==p1.pin||lastCanvasPins.d0!==p0.dir||lastCanvasPins.d1!==p1.dir;
  if(changed){
    lastCanvasPins={p0:p0.pin,p1:p1.pin,d0:p0.dir,d1:p1.dir};
    try{if(typeof updateLpcExternalLoads==='function')updateLpcExternalLoads()}catch(e){}
    try{if(typeof window.phase81RefreshCanvasOutputs==='function')window.phase81RefreshCanvasOutputs()}catch(e){}
    try{if(typeof renderLpcGpioMonitor==='function')renderLpcGpioMonitor()}catch(e){}
  }
  try{if(typeof window.phase83eRefreshBoardIO==='function')window.phase83eRefreshBoardIO()}catch(e){}
  try{if(typeof window.phase83gRefresh==='function')window.phase83gRefresh()}catch(e){}
}
function scheduleTerminalFlush(){
  if(terminalRAF)return;
  terminalRAF=requestAnimationFrame(()=>{
    terminalRAF=0;
    for(const p of [0,1]){
      if(pendingTerminal[p]){
        const s=pendingTerminal[p];pendingTerminal[p]='';
        try{if(typeof window.phase82AppendTerminalTx==='function')window.phase82AppendTerminalTx(p,s,lastState&&lastState['uart'+p])}catch(e){}
      }else{
        try{if(typeof window.phase82UpdateWorkerStatus==='function'&&lastState)window.phase82UpdateWorkerStatus(p,lastState['uart'+p])}catch(e){}
      }
    }
  });
}
function handleWorkerMessage(ev){
  const m=ev.data||{};
  if(m.type==='started'){
    logSafe('Phase 8.2B ARM7 worker started; HEX loaded: '+m.bytes+' bytes.');
    try{if(typeof window.phase83eSyncInput==='function')window.phase83eSyncInput()}catch(e){}
  }else if(m.type==='gpio-edge'){
    // Phase 8.4F: apply canonical physical-pin transitions immediately.
    // Debug/SFR windows remain snapshot-throttled; physical loads do not.
    const edgeState={running:workerRunning,gpio:m.gpio||{}};
    applyCanvas(edgeState);
    if(window.lpcArm7Emu){
      window.lpcArm7Emu.gpio={...(window.lpcArm7Emu.gpio||{}),...(m.gpio||{})};
      window.lpcArm7Emu.lastGpioTransitionCycles=Number(m.cycles)||0;
    }
  }else if(m.type==='snapshot'){
    lastState=m.state||null;const mirror=createMirror(lastState);applyCanvas(lastState);
    workerRunning=!!(lastState&&lastState.running);
    if(typeof setRunStopButtonState==='function')setRunStopButtonState(workerRunning);
    // Debug views are deliberately throttled to snapshots (~30 Hz) and rendered only if visible.
    try{
      const visible=document.querySelector('.debugFloatPanel:not(.hidden)');
      if(visible&&typeof window.phase5RefreshDebug==='function'&&mirror)window.phase5RefreshDebug(mirror,'worker runtime');
    }catch(e){}
    scheduleTerminalFlush();
  }else if(m.type==='memory-response'){
    const q=memoryReqPending.get(Number(m.reqId)||0);
    if(q){memoryReqPending.delete(Number(m.reqId)||0);q.resolve({kind:m.kind,base:Number(m.base)>>>0,bytes:Uint8Array.from(m.bytes||[])});}
  }else if(m.type==='uart-tx'){
    const p=Number(m.port)?1:0;
    let s='';for(const b of (m.bytes||[]))s+=String.fromCharCode(Number(b)&255);
    pendingTerminal[p]+=s;scheduleTerminalFlush();
  }else if(m.type==='activity'){
    try{if(typeof window.phase83BoardActivity==='function')window.phase83BoardActivity(m.kind,m.port,m.count||1)}catch(e){}
  }else if(m.type==='reset-state'){
    try{if(typeof window.phase83BoardResetState==='function')window.phase83BoardResetState(!!m.asserted)}catch(e){}
    if(!m.asserted)logSafe('On-board RESET released: LPC2129 restarted from reset vector 0x00000000.');
  }else if(m.type==='error'){
    logSafe('ARM7 worker stopped: '+m.text);workerRunning=false;if(typeof setRunStopButtonState==='function')setRunStopButtonState(false);
  }else if(m.type==='stopped'){
    workerRunning=false;if(window.lpcGpio)window.lpcGpio.running=false;
    if(window.lpcArm7Emu)window.lpcArm7Emu.running=false;
    if(typeof setRunStopButtonState==='function')setRunStopButtonState(false);
    logSafe('ARM7 worker stopped.');
  }
}
function ensureWorker(){
  if(worker)return worker;
  worker=new Worker('phase82b_arm7_worker.js');
  worker.onmessage=handleWorkerMessage;
  worker.onerror=e=>{logSafe('ARM7 worker error: '+(e.message||e.type));workerRunning=false};
  window.phase82bWorker=worker;return worker;
}
async function startWorkerRuntime(){
  if(!window.lastLpc2129Hex){
    logSafe('No HEX loaded. Building LPC2129 source first...');
    if(typeof window.compileLpc2129Hex==='function'){const ok=await window.compileLpc2129Hex();if(!ok)return false}
  }
  if(workerRunning)return true;
  ensureWorker().postMessage({type:'start',hex:window.lastLpc2129Hex,clock:clock()});
  ensureWorker().postMessage({type:'eeprom-config',...pendingEepromConfig});
  ensureWorker().postMessage({type:'spi-eeprom-config',...pendingSpiEepromConfig});
  ensureWorker().postMessage({type:'can-bus-config',...pendingCanBusConfig});
  workerRunning=true;
  window.lpcGpio=window.lpcGpio||{};window.lpcGpio.running=true;
  window.lpcArm7Emu={running:true,r:new Uint32Array(16),cpsr:{},gpio:{},profiler:{totalCycles:0,totalInstructions:0,families:{}},decodeStats:{ARM:{},THUMB:{}}};
  if(typeof setRunStopButtonState==='function')setRunStopButtonState(true);
  logSafe('Phase 8.2B: simulation delegated to dedicated ARM7 Web Worker.');
  return true;
}
function stopWorkerRuntime(){
  if(worker)worker.postMessage({type:'stop'});
  workerRunning=false;if(window.lpcGpio)window.lpcGpio.running=false;if(window.lpcArm7Emu)window.lpcArm7Emu.running=false;
  if(typeof setRunStopButtonState==='function')setRunStopButtonState(false);
}
window.phase82bStart=startWorkerRuntime;
window.phase82bStop=stopWorkerRuntime;
window.phase82bIsRunning=()=>workerRunning;
window.startLpc2129HexEmulator=startWorkerRuntime;
window.stopLpc2129HexEmulator=stopWorkerRuntime;
window.toggleRunStopSimulation=async()=>workerRunning?stopWorkerRuntime():startWorkerRuntime();

window.phase82bSendRx=function(port,text){
  if(!workerRunning||!worker){logSafe('UART'+port+' RX: run the LPC2129 program first.');return false}
  const bytes=[];for(const ch of String(text))bytes.push(ch.charCodeAt(0)&255);
  worker.postMessage({type:'rx',port:Number(port)?1:0,bytes});return true;
};
window.phase82bSetInput=function(port,pin,level){
  if(worker)worker.postMessage({type:'gpio-input',port:Number(port)?1:0,pin:Number(pin),level:!!level});
};
window.phase82bUpdateClock=function(){
  if(worker)worker.postMessage({type:'clock',...clock()});
};
window.phase83HardwareResetAssert=function(){
  if(workerRunning&&worker){worker.postMessage({type:'reset-assert'});return true}
  logSafe('RESET: run the LPC2129 program first.');return false;
};
window.phase83HardwareResetRelease=function(){
  if(workerRunning&&worker){worker.postMessage({type:'reset-release'});return true}
  return false;
};

window.addEventListener('load',()=>setTimeout(()=>{
  // Re-assert the worker runtime overrides after all legacy scripts have initialized.
  window.startLpc2129HexEmulator=startWorkerRuntime;
  window.stopLpc2129HexEmulator=stopWorkerRuntime;
  window.toggleRunStopSimulation=async()=>workerRunning?stopWorkerRuntime():startWorkerRuntime();
  logSafe('Phase 8.2B ready: ARM7 execution is off the browser UI thread; UART terminal TX is frame-batched.');
},1900));

window.phase84SetAdcInput=function(channel,raw){
  if(worker)worker.postMessage({type:'adc-input',channel:Number(channel),raw:Number(raw)});
};
window.phase84AdcTrigger=function(source,falling){
  if(worker)worker.postMessage({type:'adc-trigger',source:String(source||''),falling:!!falling});
};
window.phase84RequestSnapshot=function(){if(worker)worker.postMessage({type:'snapshot'})};
window.phase84tReadMemory=function(kind,base,length){
  return new Promise((resolve,reject)=>{
    if(!worker){reject(new Error('LPC2129 runtime is not loaded. Build and Run the program first.'));return;}
    const reqId=memoryReqSeq++;
    const timer=setTimeout(()=>{if(memoryReqPending.has(reqId)){memoryReqPending.delete(reqId);reject(new Error('Memory read timed out'));}},1200);
    memoryReqPending.set(reqId,{resolve:(v)=>{clearTimeout(timer);resolve(v)},reject});
    worker.postMessage({type:'memory-read',reqId,kind:String(kind||''),base:Number(base)>>>0,length:Math.max(1,Math.min(1024,Number(length)||256))});
  });
};
window.phase84t15ConfigureCanBus=function(cfg){pendingCanBusConfig={...pendingCanBusConfig,...(cfg||{})};if(worker)worker.postMessage({type:'can-bus-config',...pendingCanBusConfig});};
window.phase84t14ConfigureSpiEeprom=function(cfg){pendingSpiEepromConfig={present:cfg&&cfg.present!==false};if(worker)worker.postMessage({type:'spi-eeprom-config',...pendingSpiEepromConfig});};
window.phase84tConfigureEeprom=function(cfg){pendingEepromConfig={present:cfg&&cfg.present!==false,a0:cfg&&cfg.a0?1:0,a1:cfg&&cfg.a1?1:0,a2:cfg&&cfg.a2?1:0};if(worker)worker.postMessage({type:'eeprom-config',...pendingEepromConfig});};
window.phase84TimerEdge=function(timer,channel,rising){if(worker)worker.postMessage({type:'timer-edge',timer:Number(timer)?1:0,channel:Number(channel)||0,rising:!!rising})};
})();

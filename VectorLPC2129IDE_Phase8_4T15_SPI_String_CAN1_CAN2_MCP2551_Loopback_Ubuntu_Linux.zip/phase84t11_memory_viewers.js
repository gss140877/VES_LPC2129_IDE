/* VECTOR LPC2129 IDE — Phase 8.4T11 complete memory viewers
   Full address-space virtual scroll viewers:
   24LC512 0x0000..0xFFFF
   LPC2129 Flash 0x00000000..0x0003FFFF
   LPC2129 SRAM 0x40000000..0x40003FFF
*/
(function(){
'use strict';
if(window.__phase84t11MemoryViewers)return;
window.__phase84t11MemoryViewers=true;

const CFG={
 eeprom:{id:'p84t11Eeprom',title:'24LC512 EEPROM — Complete Memory',kind:'eeprom',start:0x0000,end:0xFFFF,digits:4,live:true,note:'64 KB I²C EEPROM • complete 0x0000–0xFFFF address space'},
 spieeprom:{id:'p84t14SpiEeprom',title:'25LC512 SPI EEPROM — Complete Memory',kind:'spieeprom',start:0x0000,end:0xFFFF,digits:4,live:true,note:'64 KB SPI EEPROM • complete 0x0000–0xFFFF address space'},
 flash:{id:'p84t11Flash',title:'LPC2129 ROM / Flash — Complete Memory',kind:'flash',start:0x00000000,end:0x0003FFFF,digits:8,live:false,note:'256 KB on-chip Flash • constants, code and .rodata are stored here'},
 ram:{id:'p84t11Ram',title:'LPC2129 SRAM — Complete Memory',kind:'ram',start:0x40000000,end:0x40003FFF,digits:8,live:true,note:'16 KB on-chip SRAM • .data, .bss, stack and runtime variables appear here'}
};
const ROW_BYTES=16, ROW_H=21, FETCH_ROWS=40;
const state={};

function hex(v,d){return '0x'+((Number(v)||0)>>>0).toString(16).toUpperCase().padStart(d,'0')}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function parseAddr(v,c){
  let s=String(v||'').trim();
  if(!s)return c.start;
  let n;
  if(/^0x/i.test(s))n=parseInt(s,16);
  else if(/^[0-9A-Fa-f]+$/.test(s))n=parseInt(s,16);
  else n=Number(s);
  if(!Number.isFinite(n))return c.start;
  return clamp(Math.floor(n),c.start,c.end)>>>0;
}
function esc(c){return c==='&'?'&amp;':c==='<'?'&lt;':c==='>'?'&gt;':c}

function makeDraggable(p,h){
 let on=false,ox=0,oy=0;
 h.addEventListener('mousedown',e=>{
   if(e.target.closest('button,input'))return;
   on=true;const r=p.getBoundingClientRect();ox=e.clientX-r.left;oy=e.clientY-r.top;
   p.style.zIndex='2147482001';e.preventDefault();
 });
 window.addEventListener('mousemove',e=>{
   if(!on)return;
   p.style.left=Math.max(0,Math.min(window.innerWidth-p.offsetWidth,e.clientX-ox))+'px';
   p.style.top=Math.max(58,Math.min(window.innerHeight-60,e.clientY-oy))+'px';
 });
 window.addEventListener('mouseup',()=>on=false);
}
function create(kind){
 const c=CFG[kind]; if(!c)return null;
 let p=document.getElementById(c.id); if(p)return p;
 p=document.createElement('div');p.id=c.id;p.className='p84t11-memory-window';
 p.innerHTML=`
  <div class="p84t11-head">
    <span>${c.title}</span>
    <div><button data-role="refresh" title="Refresh visible memory">↻</button><button data-role="close">×</button></div>
  </div>
  <div class="p84t11-controls">
    <label>Go to address</label>
    <input data-role="addr" spellcheck="false" value="${hex(c.start,c.digits)}">
    <button data-role="go">Go</button>
    <button data-role="top">Start</button>
    <button data-role="end">End</button>
    <span data-role="range">${hex(c.start,c.digits)} – ${hex(c.end,c.digits)}</span>
  </div>
  <div class="p84t11-note">${c.note}</div>
  <div class="p84t11-colhead"><b>ADDRESS</b><span>00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F</span><i>ASCII</i></div>
  <div class="p84t11-scroll" data-role="scroll"><div class="p84t11-spacer" data-role="spacer"></div><div class="p84t11-rows" data-role="rows"></div></div>
  <div class="p84t11-status"><span data-role="status">Ready</span><span>16 bytes/row</span></div>`;
 document.body.appendChild(p);
 const rows=Math.ceil((c.end-c.start+1)/ROW_BYTES);
 p.querySelector('[data-role=spacer]').style.height=(rows*ROW_H)+'px';
 makeDraggable(p,p.querySelector('.p84t11-head'));
 const st=state[kind]={panel:p,cfg:c,token:0,lastBase:null,open:true};
 const sc=p.querySelector('[data-role=scroll]');
 let scrollTimer=0;
 sc.addEventListener('scroll',()=>{clearTimeout(scrollTimer);scrollTimer=setTimeout(()=>refresh(kind,false),28)});
 p.querySelector('[data-role=go]').onclick=()=>go(kind);
 p.querySelector('[data-role=addr]').addEventListener('keydown',e=>{if(e.key==='Enter')go(kind)});
 p.querySelector('[data-role=top]').onclick=()=>gotoAddr(kind,c.start);
 p.querySelector('[data-role=end]').onclick=()=>gotoAddr(kind,c.end);
 p.querySelector('[data-role=refresh]').onclick=()=>refresh(kind,true);
 p.querySelector('[data-role=close]').onclick=()=>{p.style.display='none';st.open=false};
 return p;
}
function gotoAddr(kind,a){
 const st=state[kind]||{panel:create(kind),cfg:CFG[kind]};const c=st.cfg,p=st.panel;
 a=clamp(Number(a)>>>0,c.start,c.end);
 p.querySelector('[data-role=addr]').value=hex(a,c.digits);
 const row=Math.floor((a-c.start)/ROW_BYTES);
 p.querySelector('[data-role=scroll]').scrollTop=row*ROW_H;
 refresh(kind,true);
}
function go(kind){
 const st=state[kind]||{panel:create(kind),cfg:CFG[kind]};
 const inp=st.panel.querySelector('[data-role=addr]');
 gotoAddr(kind,parseAddr(inp.value,st.cfg));
}
async function refresh(kind,force){
 const st=state[kind];if(!st||!st.open||st.panel.style.display==='none')return;
 const c=st.cfg,p=st.panel,sc=p.querySelector('[data-role=scroll]');
 const totalRows=Math.ceil((c.end-c.start+1)/ROW_BYTES);
 const visibleRows=Math.ceil(sc.clientHeight/ROW_H)+4;
 let first=Math.floor(sc.scrollTop/ROW_H)-2; first=clamp(first,0,Math.max(0,totalRows-1));
 let count=Math.max(FETCH_ROWS,visibleRows);
 if(first+count>totalRows)first=Math.max(0,totalRows-count);
 const base=(c.start+first*ROW_BYTES)>>>0;
 const maxLen=(c.end-base+1)>>>0;
 const len=Math.min(count*ROW_BYTES,maxLen);
 if(!force&&st.lastBase===base&&kind==='flash')return;
 st.lastBase=base;
 const token=++st.token;
 p.querySelector('[data-role=status]').textContent='Reading '+hex(base,c.digits)+'…';
 let result;
 try{
   if(typeof window.phase84tReadMemory!=='function')throw new Error('Memory service unavailable');
   result=await window.phase84tReadMemory(c.kind,base,len);
 }catch(e){
   if(token!==st.token)return;
   const rowsEl=p.querySelector('[data-role=rows]');
   rowsEl.style.top=(first*ROW_H)+'px';
   let out='';
   const rowCount=Math.min(count,Math.ceil((c.end-base+1)/ROW_BYTES));
   for(let r=0;r<rowCount;r++){
     const addr=(base+r*ROW_BYTES)>>>0;
     let hs='',as='';
     for(let i=0;i<ROW_BYTES;i++){hs+='<span>--</span>';as+='.';}
     out+=`<div class="p84t11-row"><b>${hex(addr,c.digits)}</b><div>${hs}</div><em>${as}</em></div>`;
   }
   rowsEl.innerHTML=out;
   p.querySelector('[data-role=status]').textContent='Viewer ready — Build and Run to read live memory';
   return;
 }
 if(token!==st.token)return;
 const a=result.bytes||new Uint8Array(), rowsEl=p.querySelector('[data-role=rows]');
 rowsEl.style.top=(first*ROW_H)+'px';
 let out='';
 const rowCount=Math.ceil(a.length/ROW_BYTES);
 for(let r=0;r<rowCount;r++){
   const addr=(base+r*ROW_BYTES)>>>0;
   let hs='',as='';
   for(let i=0;i<ROW_BYTES;i++){
     const k=r*ROW_BYTES+i;
     if(k<a.length){
       const v=a[k]&255;
       hs+=`<span>${v.toString(16).toUpperCase().padStart(2,'0')}</span>`;
       as+=esc(v>=32&&v<=126?String.fromCharCode(v):'.');
     }else{hs+='<span>  </span>';as+=' ';}
   }
   out+=`<div class="p84t11-row"><b>${hex(addr,c.digits)}</b><div>${hs}</div><em>${as}</em></div>`;
 }
 rowsEl.innerHTML=out;
 p.querySelector('[data-role=status]').textContent=`Showing ${hex(base,c.digits)} – ${hex((base+a.length-1)>>>0,c.digits)}`;
}
function show(kind){
 let p=document.getElementById(CFG[kind].id)||create(kind);
 const st=state[kind];p.style.display='block';st.open=true;
 if(kind==='eeprom'||kind==='spieeprom'){p.style.left='420px';p.style.top='155px'}
 else if(kind==='flash'){p.style.left='300px';p.style.top='120px'}
 else {p.style.left='360px';p.style.top='145px'}
 refresh(kind,true);return p;
}

window.phase84t11ShowEepromMemory=()=>show('eeprom');
window.phase84t14ShowSpiEepromMemory=()=>show('spieeprom');
window.phase84t11ShowFlashMemory=()=>show('flash');
window.phase84t11ShowRamMemory=()=>show('ram');

/* Replace the old small 64-byte EEPROM observer with the complete viewer. */
window.phase84tShowEepromMemory=window.phase84t11ShowEepromMemory;

window.addEventListener('load',()=>{
 setTimeout(()=>{
   /* Re-assert after all earlier I2C modules have initialized. */
   window.phase84tShowEepromMemory=window.phase84t11ShowEepromMemory;
 },2100);
 setInterval(()=>{
   for(const k of ['eeprom','spieeprom','ram']){
     const st=state[k];
     if(st&&st.open&&st.panel.style.display!=='none')refresh(k,true);
   }
 },800);
});
})();
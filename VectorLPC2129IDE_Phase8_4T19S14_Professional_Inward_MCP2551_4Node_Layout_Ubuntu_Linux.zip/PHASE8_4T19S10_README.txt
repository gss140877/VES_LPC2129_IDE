Phase 8.4T19S10 — Compile Function Shadowing Fix

T19S9 proved the Compile button handler fires because COMPILE BUTTON RECEIVED appeared,
but A/B/C/D stayed IDLE. Therefore the failure was between the click handler and the intended
compile implementation.

This build removes ambiguity from repeated prior patches:
- all previous s4CompileNodes implementations are renamed OLD_DISABLED
- exactly ONE active s4CompileNodes() is defined
- its first synchronous action sets A/B/C/D to WAITING
- overall status then becomes COMPILER FUNCTION ENTERED
- only after those visible state changes does any backend request occur
- it then compiles A, B, C, D through the existing /api/build-hex path

Expected immediate click sequence:
COMPILE BUTTON RECEIVED
then COMPILER FUNCTION ENTERED
and A/B/C/D = WAITING
then A = COMPILING.

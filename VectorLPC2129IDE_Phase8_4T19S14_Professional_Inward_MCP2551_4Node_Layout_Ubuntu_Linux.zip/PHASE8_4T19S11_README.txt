T19S11
T19S10 proved the compile function is entered: A changed to WAITING.
This build makes the four status elements globally unique and scopes lookup to #t19lab.
A/B/C/D are explicitly initialized before any backend call.
Expected immediately after Compile: A/B/C/D WAITING, then A COMPILING.

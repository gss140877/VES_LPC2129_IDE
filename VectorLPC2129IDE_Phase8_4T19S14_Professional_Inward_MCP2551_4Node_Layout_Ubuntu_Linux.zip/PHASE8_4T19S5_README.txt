Phase 8.4T19S5 — Four-Node Compile/Run + Switch/LED Fix

Actual root cause:
The new 4-node example used window.electronAPI.compileArm7C(source).
That is not the compile path used by the working LPC2129 simulator build.

The proven 2-node example compiles through:
POST /api/build-hex
{ code: <source>, sourceType: "c" }

As a result, the 4-node workers could fail to receive HEX / start, so switch GPIO injection had no running Node A firmware to act on, and B/C/D LEDs could never respond.

Fix:
- s4CompileOne() now uses the same /api/build-hex backend as the proven 2-node example.
- Node A/B/C/D compile sequentially and store their own HEX.
- Run Nodes starts four independent workers only after valid HEX exists.
- Added visible 4-node run status: IDLE / COMPILING / RUNNING / FAILED / STOPPED.
- Switch log now explicitly reports if Node A is not running.
- Existing four-node CAN broadcast, gpio-edge LED update, wiring, source/UART windows and mode router retained.

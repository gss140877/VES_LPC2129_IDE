Phase 8.4T19S3 — Multi-Node Window Open Fix

Root cause:
T19S2 removed the shared drag() function while rebuilding the example router.
Both buildTwoNodeUI() and buildFourNodeUI() still called drag().
Therefore selecting Multi-Node CANLab raised:
ReferenceError: drag is not defined
before the window became visible.

Fix:
- Restored shared pointer-based drag() helper.
- Keeps T19S2 deterministic Example 1 / Example 2 router unchanged.
- Keeps 2-node and 4-node canvases/options unchanged.
- Added explicit launch error reporting instead of silent failure.

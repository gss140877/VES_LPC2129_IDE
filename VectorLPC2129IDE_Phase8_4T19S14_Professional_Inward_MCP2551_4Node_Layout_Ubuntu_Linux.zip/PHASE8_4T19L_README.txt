Phase 8.4T19L — Interactive Physical Wiring
Base: approved T19K canvas; component layout unchanged.

Wiring controls:
- Drag a visible wire to move its orthogonal route.
- Double-click a wire to delete it.
- Click one terminal, then another terminal, to add a wire.
- Restore Wiring restores the canonical 8-wire topology.
- Moving or zooming components redraws connected wiring.
- Canvas zoom remains separate from component zoom.

This milestone concentrates on wiring interaction. CAN electrical fault gating is the next stage after runtime confirmation of these interactions.

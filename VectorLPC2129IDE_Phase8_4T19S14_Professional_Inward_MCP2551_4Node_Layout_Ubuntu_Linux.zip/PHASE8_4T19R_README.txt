Phase 8.4T19R — Runtime CAN Bus Disconnect / Reconnect

Changes:
- Removed Trigger CAN.
- Added context-sensitive Disconnect CAN Bus / Reconnect CAN Bus control.
- Disconnect opens the shared CAN path while both ARM7/LPC2129 nodes keep running.
- Transmissions while disconnected receive NO ACK.
- Existing CAN controller model increments TEC and ACK error count, so repeated runtime attempts can show ERROR ACTIVE -> ERROR PASSIVE -> BUS OFF.
- Reconnect restores the path for later transmissions.
- Physical Layer window now shows runtime bus CONNECTED / DISCONNECTED.
- CANH/CANL rails visibly show a disconnected/open pattern.

Preserved from T19Q:
- CAN frame monitor
- TEC / REC
- BIT / STUFF / CRC / FORM / ACK injection
- ERROR ACTIVE / ERROR PASSIVE / BUS OFF
- switch -> CAN -> LED
- UART0 terminals
- editable sources
- draggable/zoomable components and canvas
- draggable/addable/deletable wiring
- Restore Wiring

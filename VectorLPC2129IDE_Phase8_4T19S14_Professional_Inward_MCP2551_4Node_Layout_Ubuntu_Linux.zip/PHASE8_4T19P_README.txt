Phase 8.4T19P — CAN TX Completion + Switch/LED Fix

Root cause fixed:
T19O was sending 'can-external-ack' after a transmitted CAN frame.
The canonical ARM7/LPC2129 worker does not implement that message.
It implements 'can-external-result', which calls CAN controller txDone().

Effect of the old bug:
1. Node A starts with switch released and sends initial DATA=00.
2. CAN TX buffer 1 becomes busy.
3. Host bus never returns the supported TX-completion message.
4. C1SR TBS1 never becomes ready again.
5. Node A firmware blocks in while((C1SR & 4)==0).
6. Later switch press/release changes are therefore never transmitted.
7. Node B LED never responds.

T19P correction:
- Bus completion now sends:
  type: can-external-result
  controller: actual controller
  buf: actual transmit buffer
  ack: true/false
- This allows WorkerCANController.txDone() to restore TBS and enables repeated CAN transmissions.
- Real-time gpio-edge handling is added so Node B LED updates immediately from actual P1.31 output state.
- Released P1.30 HIGH is re-applied shortly after Node A starts to avoid start/reset races.

Preserved unchanged from T19O/T19L/T19M:
- draggable/zoomable components
- canvas zoom
- draggable/addable/deletable wiring
- Restore Wiring
- physical-path gating
- Node A/B editable source windows
- Node A/B real UART0 terminals

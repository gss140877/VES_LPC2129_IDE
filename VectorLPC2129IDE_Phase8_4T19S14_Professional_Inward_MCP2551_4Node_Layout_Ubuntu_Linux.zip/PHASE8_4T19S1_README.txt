Phase 8.4T19S1 — True Example Switching / 4-Node UI

Fix:
Selecting Example 2 now reconstructs the SAME Multi-Node CANLab window.

Example 1:
- 2-node canvas
- Node A/B source and UART controls
- 2-node Physical Layer and CAN monitor

Example 2:
- 4-node canvas replaces the 2-node canvas
- Source A/B/C/D
- UART A/B/C/D
- Compile / Run / Stop Nodes
- Restore Wiring
- Disconnect / Reconnect CAN Bus
- Four-Node Physical Layer
- Four-Node CAN Bus Monitor
- dedicated 4-node toolbar layout

Switching back to Example 1 restores the original 2-node canvas/control layout.

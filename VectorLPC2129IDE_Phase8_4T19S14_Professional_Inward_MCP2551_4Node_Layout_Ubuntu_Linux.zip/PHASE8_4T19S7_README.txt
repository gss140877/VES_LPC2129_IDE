T19S7 — Server Batch Compile
Four browser-side compile requests have been removed.
The 4-node lab sends one request to /api/build-hex-multinode.
The server compiles A/B/C/D and returns four HEX images together.
The original /api/build-hex remains untouched for existing IDE examples.

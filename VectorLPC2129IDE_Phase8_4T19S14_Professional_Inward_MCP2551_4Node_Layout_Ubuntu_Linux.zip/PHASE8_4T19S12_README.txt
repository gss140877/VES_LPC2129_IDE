Phase 8.4T19S12 — Four-Node State Initialization Fix

Observed in T19S11:
COMPILE BUTTON RECEIVED
A/B/C/D -> WAITING
but A never became COMPILING.

Therefore execution stopped synchronously after status initialization and before the first backend call.
T19S12 explicitly creates/normalizes s4Node.A/B/C/D state objects before clearing HEX.
Only after that does Node A become COMPILING and call /api/build-hex.

Expected:
Compile -> A/B/C/D WAITING -> NODE STATES INITIALIZED -> A COMPILING.

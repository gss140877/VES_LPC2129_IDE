Phase 8.4T19S2 — Explicit Example Mode Router

T19S/S1 incremental DOM mutation was unreliable.
T19S2 uses deterministic full UI rebuilds:
- buildTwoNodeUI()
- buildFourNodeUI()

Selecting Example 2 completely replaces the toolbar and canvas in the SAME Multi-Node CANLab window.
Selecting Example 1 reconstructs the original 2-node toolbar/canvas.
No separate hidden 4-node window is used.

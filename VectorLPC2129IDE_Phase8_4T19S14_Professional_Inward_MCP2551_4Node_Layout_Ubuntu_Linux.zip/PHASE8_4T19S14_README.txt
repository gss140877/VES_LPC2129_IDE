Phase 8.4T19S14 — Professional Inward MCP2551 Four-Node Layout

BASE: confirmed-working T19S13.

Only Example-2 canvas geometry/default routing/CSS were changed.
No compiler, ARM7 worker, CAN engine, switch/LED firmware, bus error logic,
source/UART windows, or node runtime state was changed.

Topology:
- LPC2129 A/C on outer left.
- LPC2129 B/D on outer right.
- MCP2551 A/C immediately inside the left nodes, MCU side outward and CAN side inward.
- MCP2551 B/D immediately inside the right nodes, CAN side inward and MCU side outward.
- All four MCP2551 CAN sides face the central shared CANH/CANL backbone.
- TD1->TXD and RXD->RD1 remain local node links.
- CANH and CANL are visually separated differential rails.
- Two 120-ohm terminators remain at the physical bus ends.
- Default wire bends separate TX/RX and CANH/CANL routes.
- Existing component drag/zoom and wire add/delete/drag remain intact.

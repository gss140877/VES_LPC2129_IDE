Phase 8.4T19Q — CAN Error States + Injection Monitor

Base: fully working T19P. Existing canvas, wiring, switch/LED, UART and source windows preserved.

New CAN monitor:
- Frame table: time, source, destination, ID, DLC, data, ACK, physical-path state.
- Per-node TEC and REC.
- Error-state display:
  ERROR ACTIVE: TEC < 128 and REC < 128
  ERROR PASSIVE: TEC >= 128 or REC >= 128
  BUS OFF: TEC >= 256
- Error counters for five CAN protocol error categories:
  BIT, STUFF, CRC, FORM, ACK.
- Last error display.

Error injection:
- Select Node A or B.
- Select BIT / STUFF / CRC / FORM / ACK.
- Select TX-side (+8 TEC) or RX-side (+1 REC).
- Inject Error updates the canonical CAN controller.
- Clear Node Errors resets TEC/REC/error counters and recovers a bus-off node.
- Existing physical-wire NO-ACK testing remains active; repeated NO ACK increments TEC by 8.

Counter behavior:
- Successful TX decrements TEC toward zero.
- Successful RX decrements REC toward zero.
- No ACK increments transmitter TEC by 8 and records ACK error.
- TX-side injected protocol error increments TEC by 8.
- RX-side injected protocol error increments REC by 1.

The model is for training/diagnostic visualization while preserving LPC2129 SFR-driven firmware execution.

Phase 8.4T19S8 — Proven IDE Fetch / Per-Node Compile

T19S7's new batch endpoint could remain pending with only SERVER BUILD IN PROGRESS visible.

T19S8 removes the four-node batch endpoint from the UI path.
The 4-node CANLab now uses the IDE's existing vectorFetchJson() transport and the already-proven /api/build-hex endpoint.

Compilation is intentionally per-node:
A COMPILING -> A READY
B COMPILING -> B READY
C COMPILING -> C READY
D COMPILING -> D READY
then ALL 4 NODES COMPILED.

This makes the exact failing node visible and reuses the same backend route already used by the LPC2129 IDE.
The T19S7 server endpoint remains present but is no longer called by the 4-node UI.

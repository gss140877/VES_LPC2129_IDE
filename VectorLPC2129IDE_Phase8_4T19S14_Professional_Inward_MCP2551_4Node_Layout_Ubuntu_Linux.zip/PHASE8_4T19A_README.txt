Phase 8.4T19A — Two-Node ARM7/LPC2129 CANLab Foundation

- Node A and Node B each run an independent canonical ARM7/LPC2129 Web Worker.
- Each worker has its own CPU, Flash, SRAM, SFR and CAN controller state.
- Shared host-side CAN bus resolves simultaneous transmissions.
- Example uses CAN1 in both nodes: Node A ID 0x120, Node B ID 0x080.
- Both compiled firmwares wait on P0.10; Trigger Simultaneous TX releases both.
- Arbitration is compared bit-by-bit and monitor reports winner, loser, and bit index.
- Losing controller receives arbitration-lost notification and automatically retries.
- ACK is bus-level and independent of acceptance-filter delivery.

Open: Communication > CAN > Multi-Node ARM7/LPC2129 CANLab

T19A is a multi-CPU CAN foundation, not final ISO 11898 certification. Bit stuffing,
CRC-15, detailed error frames, exact TEC/REC transitions, bus-off recovery, complete AF,
extended-frame arbitration and MCP2551 physical timing remain later T19 increments.

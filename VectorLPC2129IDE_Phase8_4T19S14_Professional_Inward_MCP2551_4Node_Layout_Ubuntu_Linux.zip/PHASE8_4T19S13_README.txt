Phase 8.4T19S13 — Missing Four-Node Runtime State Declaration Fix

T19S12 still stopped after:
COMPILE BUTTON RECEIVED
A/B/C/D = WAITING

Exact root cause:
The file had no declaration for s4Node at all.
T19S12 added code that referenced s4Node[k], but referencing an undeclared s4Node itself raises ReferenceError immediately.

T19S13 adds the missing global runtime state object:
s4Node.A
s4Node.B
s4Node.C
s4Node.D

Each contains:
worker, running, hex, state

Expected compile progression now:
COMPILE BUTTON RECEIVED
A/B/C/D = WAITING
NODE STATE OBJECT READY
A = COMPILING
then A = READY, B = COMPILING, ...

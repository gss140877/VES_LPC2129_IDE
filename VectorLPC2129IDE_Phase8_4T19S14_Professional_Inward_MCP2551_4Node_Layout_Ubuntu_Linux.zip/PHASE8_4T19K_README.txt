T19K visual approval baseline built from T19A functional foundation and T15 approved MCP2551 styling. Fixed topology only; interactive wiring intentionally deferred.

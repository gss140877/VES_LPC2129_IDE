Phase 8.4T19S9 — Four-Node Button Event Binding Fix

Observed in T19S8:
A/B/C/D remained IDLE after Compile Nodes was pressed.
That means s4CompileNodes() was never entered; this is a UI event-binding failure, not compiler time.

Fix:
- Every Example-2 toolbar control now has a unique explicit DOM ID.
- Compile/Run/Stop/Source/UART/Wiring/Bus/Physical/Monitor handlers bind directly by ID after the four-node DOM is built.
- Compile button immediately changes the overall label to COMPILE BUTTON RECEIVED before any backend call.
- Then s4CompileNodes() changes A/B/C/D from IDLE to WAITING and begins Node A compilation.
- Existing compiler, four-node workers, CAN bus, switches/LEDs and circuit canvas retained.

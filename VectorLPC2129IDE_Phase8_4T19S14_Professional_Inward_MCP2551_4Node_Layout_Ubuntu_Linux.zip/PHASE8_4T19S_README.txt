Phase 8.4T19S — Four-Node CANLab Foundation

Existing T19R two-node example is preserved as Example 1.

New Example 2:
- 4 independent ARM7/LPC2129 workers: A, B, C, D
- 4 approved MCP2551 breakouts
- shared CANH/CANL bus
- only bus ends (A and D) conceptually terminated
- Node A:
  SW1 P1.28 -> ID 0x101 -> Node B LED P1.31
  SW2 P1.29 -> ID 0x102 -> Node C LED P1.31
  SW3 P1.30 -> ID 0x103 -> Node D LED P1.31
- Node B/C/D each have independent firmware and UART0.
- Node A/B/C/D each have editable source windows and UART terminals.
- Compile Nodes / Run Nodes / Stop Nodes work across all four workers.
- Existing wiring UX retained:
  component drag/zoom, canvas zoom, wire drag/add/delete, Restore Wiring.
- Runtime Disconnect/Reconnect CAN Bus included.
- Four-node Physical Layer window included.
- Four-node CAN monitor shows frames and per-node TEC/REC/error state.

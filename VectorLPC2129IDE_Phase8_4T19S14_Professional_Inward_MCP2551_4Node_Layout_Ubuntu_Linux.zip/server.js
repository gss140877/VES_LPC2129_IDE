const express = require('express');
const fs = require('fs');
const path = require('path');
const os = require('os');
const child_process = require('child_process');

const app = express();
const PORT = process.env.PORT || 3000;
const root = __dirname;

app.use(express.json({limit:'10mb'}));
app.use(express.static(root));

function run(cmd, args, opts={}){
  return new Promise(resolve=>{
    child_process.execFile(cmd,args,{cwd:root,timeout:20000,...opts},(err,stdout,stderr)=>{
      resolve({ok:!err, output:[stdout,stderr,err?err.message:''].filter(Boolean).join('\n')});
    });
  });
}


/* T19S7 — deterministic four-node build in ONE HTTP transaction. */
async function t19s7BuildHex(code){
 const hdr=`typedef unsigned int uint32_t;
#define IO0PIN (*(volatile uint32_t*)0xE0028000u)
#define IO0SET (*(volatile uint32_t*)0xE0028004u)
#define IO0DIR (*(volatile uint32_t*)0xE0028008u)
#define IO0CLR (*(volatile uint32_t*)0xE002800Cu)
#define IO1PIN (*(volatile uint32_t*)0xE0028010u)
#define IO1SET (*(volatile uint32_t*)0xE0028014u)
#define IO1DIR (*(volatile uint32_t*)0xE0028018u)
#define IO1CLR (*(volatile uint32_t*)0xE002801Cu)
`;
 const d=fs.mkdtempSync(path.join(os.tmpdir(),'lpc2129-multi-'));
 const c=path.join(d,'main.c'),elf=path.join(d,'app.elf'),hex=path.join(d,'app.hex');
 fs.writeFileSync(c,hdr+'\n#line 1 "main.c"\n'+String(code||''));
 const args=['-mcpu=arm7tdmi','-marm','-O0','-g3','-ffreestanding','-nostdlib','-Wall','-Wextra','-T',
 path.join(root,'examples','linker_lpc2129.ld'),path.join(root,'examples','startup_lpc2129_minimal.s'),c,'-o',elf];
 const b=await run('arm-none-eabi-gcc',args,{timeout:20000});
 if(!b.ok)return {ok:false,output:b.output};
 const o=await run('arm-none-eabi-objcopy',['-O','ihex',elf,hex],{timeout:20000});
 if(!o.ok)return {ok:false,output:o.output};
 return {ok:true,hex:fs.readFileSync(hex,'utf8'),output:b.output+'\n'+o.output};
}
app.post('/api/build-hex-multinode',async(req,res)=>{
 try{
  const src=(req.body&&req.body.sources)||{},results={};
  for(const k of ['A','B','C','D']){
   results[k]=await t19s7BuildHex(src[k]);
   if(!results[k].ok)return res.json({ok:false,failedNode:k,results});
  }
  return res.json({ok:true,results});
 }catch(e){return res.json({ok:false,error:e.message||String(e),results:{}});}
});

app.post('/api/build-hex', async (req,res)=>{
  const userCode = String(req.body.code || '');
  const sourceTypeRaw = String(req.body.sourceType || req.body.lang || 'c').toLowerCase();
  const isAsm = ['asm','assembly','s','.s'].includes(sourceTypeRaw);

  const lpcHeader = `
/* Auto-injected LPC2129 register aliases for simulator C build */
typedef unsigned int uint32_t;
#define IO0PIN (*(volatile uint32_t *)0xE0028000u)
#define IO0SET (*(volatile uint32_t *)0xE0028004u)
#define IO0DIR (*(volatile uint32_t *)0xE0028008u)
#define IO0CLR (*(volatile uint32_t *)0xE002800Cu)
#define IO1PIN (*(volatile uint32_t *)0xE0028010u)
#define IO1SET (*(volatile uint32_t *)0xE0028014u)
#define IO1DIR (*(volatile uint32_t *)0xE0028018u)
#define IO1CLR (*(volatile uint32_t *)0xE002801Cu)
#define IOPIN IO0PIN
#define IOSET IO0SET
#define IODIR IO0DIR
#define IOCLR IO0CLR
`;

  /* C code receives the helper register aliases above. Assembly source must be
     written exactly as entered, otherwise GAS directives such as .syntax fail. */
  const code = isAsm ? userCode : (lpcHeader + '\n#line 1 \"main.c\"\n' + userCode);
  const work = fs.mkdtempSync(path.join(os.tmpdir(),'lpc2129-'));
  const src = path.join(work, isAsm ? 'main.s' : 'main.c');
  const startup = path.join(root,'examples','startup_lpc2129_minimal.s');
  const linker = path.join(root,'examples','linker_lpc2129.ld');
  const elf = path.join(work,'app.elf');
  const hex = path.join(work,'app.hex');
  fs.writeFileSync(src,code);

  const gccArgs = ['-mcpu=arm7tdmi','-marm','-O0','-g3','-ffreestanding','-nostdlib','-Wall','-Wextra','-T',linker,startup];
  if(isAsm) gccArgs.push('-x','assembler-with-cpp');
  gccArgs.push(src,'-o',elf);

  const build = await run('arm-none-eabi-gcc',gccArgs);
  if(!build.ok) return res.json({ok:false, sourceType:isAsm?'assembly':'c', output:'arm-none-eabi-gcc build failed.\nSource type: '+(isAsm?'Assembly (.s)':'C (.c)')+'\n'+build.output});
  const obj = await run('arm-none-eabi-objcopy',['-O','ihex',elf,hex]);
  if(!obj.ok) return res.json({ok:false, sourceType:isAsm?'assembly':'c', output:'objcopy failed.\n'+obj.output});
  const size = await run('arm-none-eabi-size',[elf]);
  const dbg = await run('arm-none-eabi-objdump',['-d','-S','-l',elf]);
  const hexText = fs.readFileSync(hex,'utf8');
  res.json({
    ok:true,
    sourceType:isAsm?'assembly':'c',
    hex:hexText,
    debugListing: dbg.output || '',
    output:'Build successful.\nSource type: '+(isAsm?'Assembly (.s)':'C (.c)')+'\nDebug symbols: enabled (-g3 -O0) for source-line stepping.\n'+build.output+'\n'+obj.output+'\n'+size.output
  });
});



/* Phase 8.0D: save editable source windows to a persistent project-local folder. */
app.post('/api/save-source', async (req,res)=>{
  try{
    const code = String(req.body.code || '');
    let fileName = String(req.body.fileName || '').trim();
    const sourceType = String(req.body.sourceType || 'c').toLowerCase();
    const ext = ['assembly','asm','s','.s'].includes(sourceType) ? '.s' : '.c';
    if(!fileName) fileName = 'main' + ext;
    fileName = path.basename(fileName).replace(/[^A-Za-z0-9_.-]/g,'_');
    if(!fileName.toLowerCase().endsWith(ext)) fileName += ext;
    const dir = path.join(root,'user_sources');
    fs.mkdirSync(dir,{recursive:true});
    const outPath = path.join(dir,fileName);
    fs.writeFileSync(outPath,code,'utf8');
    res.json({ok:true,fileName,path:outPath,output:'Source saved successfully.\n'+outPath});
  }catch(e){
    res.json({ok:false,output:'Save source failed.\n'+e.message});
  }
});

app.post('/api/save-hex', async (req,res)=>{
  try{
    const hexText = String(req.body.hex || '');
    let folderPath = String(req.body.folderPath || '').trim();
    let fileName = String(req.body.fileName || 'lpc2129_app.hex').trim();
    if(!hexText.trim()) return res.json({ok:false, output:'Missing HEX data. Build HEX first.'});
    if(!folderPath) return res.json({ok:false, output:'Missing folder path.'});
    fileName = fileName.replace(/[\\/:*?"<>|]/g,'_');
    if(!fileName.toLowerCase().endsWith('.hex')) fileName += '.hex';
    fs.mkdirSync(folderPath,{recursive:true});
    const outPath = path.join(folderPath,fileName);
    fs.writeFileSync(outPath,hexText,'utf8');
    res.json({ok:true, output:'HEX saved successfully.\n'+outPath, path:outPath});
  }catch(e){
    res.json({ok:false, output:'Save HEX failed.\n'+e.message+'\nTip: use a valid folder path such as /home/$USER/LPC2129_HEX'});
  }
});

app.get('/api/ports', async (req,res)=>{
  try{
    const { SerialPort } = require('serialport');
    const ports = await SerialPort.list();
    res.json({ok:true,ports});
  }catch(e){
    res.json({ok:false,ports:[],output:e.message});
  }
});

function normalizeComPort(port){
  // Flash Magic command files use numeric COM value: COM(3, 9600), not COM3.
  // Linux serial paths (/dev/ttyUSB0, /dev/ttyACM0, etc.) are returned unchanged.
  const p = String(port || '').trim();
  const m = p.match(/COM\s*(\d+)/i);
  return m ? m[1] : p;
}

function findFlashMagicExe(){
  const candidates = [];
  if(process.env.FLASHMAGIC_EXE) candidates.push(process.env.FLASHMAGIC_EXE);
  candidates.push('FlashMagic.exe','FM.exe','flashmagic.exe','fm.exe');
  if(process.platform === 'win32'){
    const bases = [process.env['ProgramFiles'], process.env['ProgramFiles(x86)'], 'C:\\Program Files', 'C:\\Program Files (x86)'].filter(Boolean);
    for(const base of bases){
      candidates.push(path.join(base,'Flash Magic','FlashMagic.exe'));
      candidates.push(path.join(base,'Flash Magic','FM.exe'));
      candidates.push(path.join(base,'FlashMagic','FlashMagic.exe'));
      candidates.push(path.join(base,'FlashMagic','FM.exe'));
    }
  }
  for(const c of candidates){
    try{ if(c && (c.includes(path.sep) || c.includes('\\')) && fs.existsSync(c)) return c; }catch{}
  }
  // Fall back to PATH lookup. execFile will resolve this if it exists in PATH.
  return process.platform === 'win32' ? 'FlashMagic.exe' : 'flashmagic';
}

app.post('/api/flash', async (req,res)=>{
  const port = String(req.body.port || '');
  const hexText = String(req.body.hex || '');
  const baud = String(req.body.baud || '9600');
  const oscMHz = String(req.body.oscMHz || '12.000');
  if(!port) return res.json({ok:false,output:'Missing serial port.'});
  if(!hexText.trim()) return res.json({ok:false,output:'Missing HEX data.'});

  const runtime = path.join(root,'runtime');
  fs.mkdirSync(runtime,{recursive:true});
  const hexFile = path.join(runtime,'lpc2129_app.hex');
  fs.writeFileSync(hexFile,hexText);

  if(process.platform !== 'win32'){
    // Native Ubuntu/Linux hardware flashing equivalent. The Phase 6.1A frontend
    // button is intentionally unchanged; this backend maps it to lpc21isp.
    const oscKHz = String(Math.round(parseFloat(oscMHz || '12') * 1000));
    const result = await run('lpc21isp',['-control','-verify',hexFile,port,baud,oscKHz],{timeout:120000});
    const missingHint = result.output.includes('ENOENT')
      ? '\nlpc21isp was not found. Install it with: sudo apt install lpc21isp\n'
      : '';
    return res.json({
      ok:result.ok,
      output:(result.ok?'LPC2129 ISP flashing completed with lpc21isp.\n':'LPC2129 ISP flashing failed.\n')+
             `Serial port: ${port}\nBaud: ${baud}\nOscillator: ${oscKHz} kHz\n`+
             result.output+missingHint
    });
  }

  const scriptFile = path.join(runtime,'flashmagic_lpc2129.fms');
  const quietFile = path.join(runtime,'flashmagic_output.txt');
  const comNo = normalizeComPort(port);
  const script = [
    '; Auto-generated by LPC2129 Simulator',
    '; Put LPC2129 in ISP mode before running this command.',
    `COM(${comNo}, ${baud})`,
    `DEVICE(LPC2129, ${oscMHz})`,
    'TIMEOUTS(10, 60)',
    `ERASEUSED(${hexFile}, PROTECTISP)`,
    `HEXFILE(${hexFile}, CHECKSUMS, NOFILL, PROTECTISP)`,
    `VERIFY(${hexFile})`,
    'EXECUTE(0, ARM)',
    ''
  ].join('\r\n');
  fs.writeFileSync(scriptFile,script);

  const fmExe = findFlashMagicExe();
  const result = await run(fmExe,[`@${scriptFile}`],{timeout:120000});
  let extra = '';
  try{ if(fs.existsSync(quietFile)) extra = '\n'+fs.readFileSync(quietFile,'utf8'); }catch{}
  const cmdShown = `Flash Magic command file: ${scriptFile}\nFlash Magic executable: ${fmExe}\n`;
  const missingHint = result.output.includes('ENOENT') ? '\nFlashMagic.exe was not found. Install Flash Magic or set FLASHMAGIC_EXE to the full exe path.\n' : '';
  res.json({ok:result.ok,output:(result.ok?'Flash Magic completed.\n':'Flash Magic command failed.\n')+cmdShown+result.output+extra+missingHint});
});

app.listen(PORT,()=>console.log(`VECTOR LPC2129 IDE Phase 7.0A running at http://localhost:${PORT}`));

Phase 8.4T19O — Restored T19L UI + Real UART + Switch/LED

Base:
- T19M, which itself preserves the user-confirmed T19L interactive wiring.

Deliberately preserved:
- component dragging
- component wheel zoom
- canvas wheel zoom
- wire drag
- terminal-to-terminal wire add
- double-click wire delete
- Restore Wiring
- T19M physical-path gating

Added without replacing the canvas:
- Node A Source floating editable/zoomable window
- Node B Source floating editable/zoomable window
- Node A UART0 floating terminal
- Node B UART0 floating terminal
- UART terminals show only actual uart-tx bytes from each ARM7/LPC2129 worker
- Node A P1.30 active-low switch input
- CAN1 ID 0x101, data 01/00
- Node B active-low P1.31 LED follows actual Node B GPIO state

No synthetic serial/CAN mirroring is used.

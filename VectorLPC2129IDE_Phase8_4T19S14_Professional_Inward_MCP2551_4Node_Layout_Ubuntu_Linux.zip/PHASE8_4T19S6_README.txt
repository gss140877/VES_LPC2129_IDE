Phase 8.4T19S6 — Parallel Four-Node Compile + Live Status

Observed problem:
The status remained at "COMPILING A/B/C/D..." because the four builds were performed sequentially and the UI exposed no per-node progress. Each /api/build-hex request can take up to the server's GCC timeout, so four sequential requests can look like a hang.

Changes:
- A/B/C/D compile concurrently using Promise.all.
- Same proven /api/build-hex backend retained.
- 25-second browser-side timeout for each node.
- Visible A/B/C/D compile state:
  IDLE / QUEUED / COMPILING / READY / FAILED / TIMEOUT / BACKEND ERROR.
- Compiler failure text now reads server response 'output' (the actual field used by server.js), not only 'log'.
- Run Nodes automatically invokes Compile Nodes if any HEX is missing.
- Existing 4-node sources, workers, switches, LEDs, CAN bus, wiring and monitors are unchanged.

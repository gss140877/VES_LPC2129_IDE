Phase 8.4T19M — Electrically Meaningful CAN Wiring
Base: user-confirmed T19L interactive wiring. T19L canvas/layout/wire interaction retained.

New behavior:
- The visible wiring model now gates CAN frame delivery.
- Required physical paths:
  Node A TD1-TXD, RXD-RD1, CANH, CANL
  Node B TD1-TXD, RXD-RD1, CANH, CANL
- Delete any required link: transmitted frame receives ACK NO; receiver does not get the frame.
- CAN monitor reports PHYSICAL PATH OPEN and identifies missing connection(s).
- Restore Wiring restores all canonical links and communication can recover.
- Physical Layer window shows CONNECTED/OPEN state for all eight required links and READY/NO ACK status.

This stage does not change the confirmed T19L canvas geometry or interaction model.

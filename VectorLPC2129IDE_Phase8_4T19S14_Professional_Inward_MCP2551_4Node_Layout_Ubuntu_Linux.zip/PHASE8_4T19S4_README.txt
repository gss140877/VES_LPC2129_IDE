Phase 8.4T19S4 — Four-Node Switch/LED + CAN Broadcast Fix

Root corrections:
1. Four-node CAN is now modeled as a broadcast bus.
   A transmitted frame is delivered to every running, physically connected receiver node.
   B/C/D firmware itself decides whether ID 0x101/0x102/0x103 should operate its LED.
   This matches real CAN behavior better than host-side target-only delivery.

2. Node A P1.28/P1.29/P1.30 released HIGH inputs are applied at startup and re-applied after 25 ms.

3. gpio-edge events are handled for B/C/D, so LED visuals update immediately from actual P1.31 GPIO output.

4. Switch presses/releases continue to inject actual GPIO levels:
   SW1 P1.28 -> ID 0x101 -> B LED
   SW2 P1.29 -> ID 0x102 -> C LED
   SW3 P1.30 -> ID 0x103 -> D LED

5. Four-node CAN monitor now distinguishes expected target and actual bus listeners.

6. Four-node Disconnect/Reconnect button now correctly addresses the in-place #t19lab.s4Mode toolbar.

All S3 example routing, draggable/zoomable components, interactive wiring, sources, UARTs and monitors are retained.

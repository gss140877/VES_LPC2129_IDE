(function(){
'use strict';
const node={A:{worker:null,hex:'',state:null,running:false},B:{worker:null,hex:'',state:null,running:false}};
let pending=[],arbTimer=null,seq=0,events=[];
let qFrames=[],qErrors=[];
let qBusConnected=true;
const defaultA=`/* T19O NODE A - REAL-HARDWARE STYLE
   LPC2129 P1.30 switch -> CAN1 standard ID 0x101
   UART0 prints each transmitted frame.
*/
#define IO1PIN  (*(volatile unsigned long*)0xE0028010)
#define IO1DIR  (*(volatile unsigned long*)0xE0028018)
#define PINSEL0 (*(volatile unsigned long*)0xE002C000)
#define PINSEL1 (*(volatile unsigned long*)0xE002C004)

#define U0THR   (*(volatile unsigned long*)0xE000C000)
#define U0DLL   (*(volatile unsigned long*)0xE000C000)
#define U0DLM   (*(volatile unsigned long*)0xE000C004)
#define U0LCR   (*(volatile unsigned long*)0xE000C00C)
#define U0LSR   (*(volatile unsigned long*)0xE000C014)

#define C1MOD   (*(volatile unsigned long*)0xE0044000)
#define C1CMR   (*(volatile unsigned long*)0xE0044004)
#define C1BTR   (*(volatile unsigned long*)0xE0044014)
#define C1SR    (*(volatile unsigned long*)0xE004401C)
#define C1TFI1  (*(volatile unsigned long*)0xE0044030)
#define C1TID1  (*(volatile unsigned long*)0xE0044034)
#define C1TDA1  (*(volatile unsigned long*)0xE0044038)
#define AFMR    (*(volatile unsigned long*)0xE003C000)

#define SW (1UL<<30)

static void uart0_init(void){
    PINSEL0=(PINSEL0&~0x0FUL)|0x05UL;
    U0LCR=0x83; U0DLL=98; U0DLM=0; U0LCR=0x03;
}
static void uart0_putc(char c){while((U0LSR&0x20UL)==0){} U0THR=(unsigned long)c;}
static void uart0_puts(const char *s){while(*s)uart0_putc(*s++);}

static void can1_send(unsigned char state){
    while((C1SR&4UL)==0){}
    C1TFI1=(1UL<<16);
    C1TID1=0x101;
    C1TDA1=(unsigned long)state;
    C1CMR=0x21;
    if(state) uart0_puts("TX CAN1 ID=101 DATA=01\\r\\n");
    else      uart0_puts("TX CAN1 ID=101 DATA=00\\r\\n");
}

int main(void){
    unsigned long last=2, now;
    IO1DIR &= ~SW;
    uart0_init();

    /* CAN1: RD1=P0.25; TD1 is the dedicated CAN1 transmit pin. */
    PINSEL1=(PINSEL1&~(3UL<<18))|(1UL<<18);
    C1MOD=1; C1BTR=0x001C001D; AFMR=2; C1MOD=0;

    uart0_puts("NODE A READY\\r\\n");

    while(1){
        now=(IO1PIN&SW)?0:1;       /* active-low switch */
        if(now!=last){
            last=now;
            can1_send((unsigned char)now);
        }
    }
}`;
const defaultB=`/* T19O NODE B - REAL-HARDWARE STYLE
   CAN1 standard ID 0x101 -> active-low LED P1.31
   UART0 prints each received frame and LED action.
*/
#define IO1SET  (*(volatile unsigned long*)0xE0028014)
#define IO1DIR  (*(volatile unsigned long*)0xE0028018)
#define IO1CLR  (*(volatile unsigned long*)0xE002801C)
#define PINSEL0 (*(volatile unsigned long*)0xE002C000)
#define PINSEL1 (*(volatile unsigned long*)0xE002C004)

#define U0THR   (*(volatile unsigned long*)0xE000C000)
#define U0DLL   (*(volatile unsigned long*)0xE000C000)
#define U0DLM   (*(volatile unsigned long*)0xE000C004)
#define U0LCR   (*(volatile unsigned long*)0xE000C00C)
#define U0LSR   (*(volatile unsigned long*)0xE000C014)

#define C1MOD   (*(volatile unsigned long*)0xE0044000)
#define C1CMR   (*(volatile unsigned long*)0xE0044004)
#define C1GSR   (*(volatile unsigned long*)0xE0044008)
#define C1BTR   (*(volatile unsigned long*)0xE0044014)
#define C1RID   (*(volatile unsigned long*)0xE0044024)
#define C1RDA   (*(volatile unsigned long*)0xE0044028)
#define AFMR    (*(volatile unsigned long*)0xE003C000)

#define LED (1UL<<31)

static void uart0_init(void){
    PINSEL0=(PINSEL0&~0x0FUL)|0x05UL;
    U0LCR=0x83; U0DLL=98; U0DLM=0; U0LCR=0x03;
}
static void uart0_putc(char c){while((U0LSR&0x20UL)==0){} U0THR=(unsigned long)c;}
static void uart0_puts(const char *s){while(*s)uart0_putc(*s++);}

int main(void){
    unsigned long data;
    IO1DIR |= LED;
    IO1SET  = LED;                 /* LED OFF */
    uart0_init();

    PINSEL1=(PINSEL1&~(3UL<<18))|(1UL<<18);
    C1MOD=1; C1BTR=0x001C001D; AFMR=2; C1MOD=0;

    uart0_puts("NODE B READY\\r\\n");

    while(1){
        if(C1GSR&1UL){
            data=C1RDA;
            if((C1RID&0x7FFUL)==0x101){
                if(data&1UL){
                    IO1CLR=LED;
                    uart0_puts("RX CAN1 ID=101 DATA=01 -> LED ON\\r\\n");
                }else{
                    IO1SET=LED;
                    uart0_puts("RX CAN1 ID=101 DATA=00 -> LED OFF\\r\\n");
                }
            }
            C1CMR=0x04;
        }
    }
}`;

let kUartText={A:'',B:''};

function kAppendUart(k,bytes){
    let s='';
    for(const b of (bytes||[])) s+=String.fromCharCode(Number(b)&255);
    kUartText[k]+=s;
    if(kUartText[k].length>24000) kUartText[k]=kUartText[k].slice(-16000);
    kRenderUart(k);
}
function kOpenUart(k){
    let p=document.getElementById('kUart'+k);
    if(!p){
        p=document.createElement('div');
        p.id='kUart'+k;
        p.className='kFloat kUart';
        p.innerHTML=`<div class="kFloatHead"><b>Node ${k} UART0 Terminal</b><div><button data-clear>Clear</button><button data-close>×</button></div></div><pre></pre>`;
        document.body.appendChild(p);
        p.querySelector('[data-clear]').onclick=e=>{e.stopPropagation();kUartText[k]='';kRenderUart(k);};
        p.querySelector('[data-close]').onclick=e=>{e.stopPropagation();p.style.display='none';};
        drag(p,p.querySelector('.kFloatHead'));
    }
    p.style.display='block';
    kRenderUart(k);
}
function kRenderUart(k){
    const p=document.getElementById('kUart'+k);
    if(!p||p.style.display==='none')return;
    const pre=p.querySelector('pre');
    pre.textContent=kUartText[k];
    pre.scrollTop=pre.scrollHeight;
}

function kOpenSource(k){
    let p=document.getElementById('kSource'+k);
    if(!p){
        p=document.createElement('div');
        p.id='kSource'+k;
        p.className='kFloat kSource';
        p.innerHTML=`<div class="kFloatHead"><b>Node ${k} C Source</b><div><button data-minus>A−</button><span data-zoom>100%</span><button data-plus>A+</button><button data-close>×</button></div></div><textarea spellcheck="false"></textarea>`;
        document.body.appendChild(p);
        const ta=p.querySelector('textarea');
        ta.value=(k==='A'?defaultA:defaultB);
        let fs=12;
        const apply=()=>{ta.style.fontSize=fs+'px';p.querySelector('[data-zoom]').textContent=Math.round(fs/12*100)+'%';};
        p.querySelector('[data-minus]').onclick=e=>{e.stopPropagation();fs=Math.max(8,fs-1);apply();};
        p.querySelector('[data-plus]').onclick=e=>{e.stopPropagation();fs=Math.min(24,fs+1);apply();};
        p.querySelector('[data-close]').onclick=e=>{e.stopPropagation();p.style.display='none';};
        drag(p,p.querySelector('.kFloatHead'));
        apply();
    }
    p.style.display='block';
    p.querySelector('textarea').focus();
}
function log(s){events.push({n:++seq,s});if(events.length>200)events.shift();renderMonitor()}
async function compileOne(k){
 const ta=document.getElementById('t19src'+k),st=document.getElementById('t19status'+k);st.textContent='Compiling...';
 try{const r=await fetch('/api/build-hex',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:ta.value,sourceType:'c'})});const d=await r.json();if(!d.ok){st.textContent='Compile failed';log('Node '+k+' compile failed');return false}node[k].hex=d.hex||'';st.textContent='Compiled';log('Node '+k+' compiled');return true}catch(e){st.textContent='Backend error';log('Compile backend error: '+e.message);return false}
}
async function compileNodes(){
 const ea=document.getElementById('kSourceA'),eb=document.getElementById('kSourceB');
 const ha=document.getElementById('t19srcA'),hb=document.getElementById('t19srcB');
 if(ea&&ha)ha.value=ea.querySelector('textarea').value;
 if(eb&&hb)hb.value=eb.querySelector('textarea').value;
 const a=await compileOne('A'),b=await compileOne('B');return a&&b;
}
function stopNode(k){const n=node[k];if(n.worker){try{n.worker.postMessage({type:'stop'});n.worker.terminate()}catch(e){}n.worker=null}n.running=false}
function startNode(k){
 stopNode(k);const n=node[k];if(!n.hex)return false;
 const w=new Worker('phase82b_arm7_worker.js');n.worker=w;w.onmessage=e=>handle(k,e.data||{});
 w.postMessage({type:'start',hex:n.hex,clock:{cclkHz:60000000,pclkHz:15000000}});
 w.postMessage({type:'can-external-config',enabled:true,nodeId:k});
 w.postMessage({type:'can-bus-config',connected:qBusConnected,term1:true,term2:true,mcp1:true,mcp2:true});
 if(k==='A'){
   w.postMessage({type:'gpio-input',port:1,pin:30,level:true});
   setTimeout(()=>{if(node.A.worker)node.A.worker.postMessage({type:'gpio-input',port:1,pin:30,level:true})},25);
 }
 n.running=true;return true
}
function runNodes(){if(!node.A.hex||!node.B.hex){log('Compile both nodes first.');return}pending=[];startNode('A');startNode('B');log('Two independent ARM7/LPC2129 workers started; trigger held HIGH.')}
function stopNodes(){stopNode('A');stopNode('B');log('Both nodes stopped.')}
function handle(k,d){
 if(d.type==='snapshot'){
   const prev=((node[k].state||{}).can1)||{};
   node[k].state=d.state||null;
   const c=((node[k].state||{}).can1)||{};
   if(Number(c.txErr||0)!==Number(prev.txErr||0)||Number(c.rxErr||0)!==Number(prev.rxErr||0)||qState(c)!==qState(prev)){
     qErrors.push({time:new Date().toLocaleTimeString(),node:k,kind:c.lastError||'STATE',role:'AUTO',tec:Number(c.txErr||0),rec:Number(c.rxErr||0),state:qState(c)});
     if(qErrors.length>160)qErrors.shift();
   }
   renderNodes();return
 }
 if(d.type==='gpio-edge'){
   if(!node[k].state)node[k].state={};
   node[k].state.gpio=d.gpio||{};
   if(k==='B'){
     const led=document.getElementById('kLED'),g=d.gpio||{};
     if(led){
       const out=((Number(g.IO1DIR||0)>>>31)&1)!==0;
       const level=((Number(g.IO1PIN||0)>>>31)&1)!==0;
       led.classList.toggle('on',out&&!level);
     }
   }
   return
 }
 if(d.type==='started'){log('Node '+k+' ARM7 started');return}
 if(d.type==='can-external-tx'){pending.push({k,d});if(!arbTimer)arbTimer=setTimeout(resolveBus,3);return}
 if(d.type==='uart-tx'){if(Number(d.port)===0)kAppendUart(k,d.bytes||[]);return}
 if(d.type==='error')log('Node '+k+' error: '+d.text)
}
function bits(v,n){const a=[];for(let i=n-1;i>=0;i--)a.push((v>>>i)&1);return a}
function arbBits(f){return f.extended?[0,...bits((f.id>>>18)&0x7ff,11),1,1,...bits(f.id&0x3ffff,18),f.rtr?1:0,0,0]:[0,...bits(f.id&0x7ff,11),f.rtr?1:0,0,0]}
function compare(x,y){const a=arbBits(x),b=arbBits(y),n=Math.min(a.length,b.length);for(let i=0;i<n;i++)if(a[i]!==b[i])return {winner:a[i]===0?0:1,bit:i,a:a[i],b:b[i]};return {winner:0,bit:-1,a:0,b:0}}
function resolveBus(){
 arbTimer=null;if(!pending.length)return;const q=pending.splice(0);
 if(q.length===1){deliver(q[0]);return}
 const x=q[0],y=q[1],r=compare(x.d.frame,y.d.frame),win=r.winner===0?x:y,lose=r.winner===0?y:x;
 log(`ARBITRATION: Node ${win.k} ID 0x${win.d.frame.id.toString(16).toUpperCase()} wins; Node ${lose.k} loses at arbitration bit ${r.bit}.`);
 const lw=node[lose.k].worker;if(lw)lw.postMessage({type:'can-external-arbitration-lost',controller:lose.d.controller,buf:lose.d.frame.buf,bit:r.bit});
 deliver(win);
}
function deliver(x){
 const all=['A','B'].filter(k=>k!==x.k&&node[k].worker&&node[k].running);
 const ok=kBusPathOK();
 const peers=ok?all:[];
 const ack=ok&&peers.length>0;
 const f=x.d.frame||{};
 const id=Number(f.id||0),dlc=Number(f.dlc||0),data=Array.isArray(f.data)?f.data:[];
 const line=`ID 0x${id.toString(16).toUpperCase().padStart(3,'0')} DLC ${dlc} Data ${data.map(v=>Number(v).toString(16).padStart(2,'0').toUpperCase()).join(' ')} ACK ${ack?'YES':'NO'}`;
 qFrames.push({time:new Date().toLocaleTimeString(),from:x.k,to:peers.join(',')||'-',id,dlc,data:data.slice(0,dlc),ack,path:ok?'OK':'OPEN'});
 if(qFrames.length>160)qFrames.shift();
 if(ok){
   for(const k of peers)node[k].worker.postMessage({type:'can-external-rx',controller:Number(x.d.controller||1),frame:f});
   log(`Node ${x.k} TX → ${peers.join(',')||'-'} | ${line}`,'frame');
 }else{
   log(`Node ${x.k} TX | ${line} | PHYSICAL PATH OPEN: ${kPathReason()}`,'err');
 }
 if(node[x.k].worker)node[x.k].worker.postMessage({
   type:'can-external-result',
   controller:Number(x.d.controller||1),
   buf:Number((x.d.frame&&x.d.frame.buf)||1),
   ack
 });
}
function renderNodes(){
 for(const k of ['A','B']){
   const s=node[k].state||{},c=s.can1||{},e=document.getElementById('t19state'+k);
   if(e)e.innerHTML=`<b>Node ${k}</b> ARM steps ${s.steps||0}<br>CAN1 ${c.MOD&1?'RESET':'NORMAL'} TX ${c.txCount||0} RX ${c.rxCount||0}<br>TEC ${c.txErr||0} REC ${c.rxErr||0}<br>ICR 0x${Number(c.ICR||0).toString(16).toUpperCase().padStart(8,'0')}`;
 }
 const led=document.getElementById('kLED');
 const g=(node.B.state||{}).gpio||{};
 if(led){
   const out=((Number(g.IO1DIR||0)>>>31)&1)!==0;
   const level=((Number(g.IO1PIN||0)>>>31)&1)!==0;
   led.classList.toggle('on',out&&!level);
 }
 qRenderMonitor();
}
function renderMonitor(){const e=document.getElementById('t19events');if(e)e.innerHTML=events.slice().reverse().map(x=>`<div><span>#${x.n}</span> ${x.s}</div>`).join('')}


function qState(c){
 if(!c)return '—';
 if(c.busOff||Number(c.txErr||0)>=256)return 'BUS OFF';
 if(Number(c.txErr||0)>=128||Number(c.rxErr||0)>=128)return 'ERROR PASSIVE';
 return 'ERROR ACTIVE';
}
function qOpenMonitor(){
 let p=document.getElementById('qCanMonitor');
 if(!p){
  p=document.createElement('div');p.id='qCanMonitor';p.className='qCanMonitor';
  p.innerHTML=`<div class="qMonHead"><b>CAN Bus Monitor / Error-State Analyzer</b><button data-close>×</button></div>
  <div class="qMonControls">
   <label>Node <select data-node><option>A</option><option>B</option></select></label>
   <label>Error <select data-kind><option>BIT</option><option>STUFF</option><option>CRC</option><option>FORM</option><option>ACK</option></select></label>
   <label>Detected as <select data-role><option value="TX">TX error (+8 TEC)</option><option value="RX">RX error (+1 REC)</option></select></label>
   <button data-inject>Inject Error</button><button data-clearerr>Clear Node Errors</button><button data-clearlog>Clear Monitor</button>
  </div>
  <div class="qStates"><div data-state-a></div><div data-state-b></div></div>
  <div class="qTables">
    <div><h4>CAN Frames</h4><div class="qScroll"><table><thead><tr><th>Time</th><th>From</th><th>Target</th><th>Listeners</th><th>ID</th><th>DLC</th><th>Data</th><th>ACK</th><th>Path</th></tr></thead><tbody data-frames></tbody></table></div></div>
    <div><h4>Error / State Events</h4><div class="qScroll"><table><thead><tr><th>Time</th><th>Node</th><th>Error</th><th>Role</th><th>TEC</th><th>REC</th><th>State</th></tr></thead><tbody data-errors></tbody></table></div></div>
  </div>`;
  document.body.appendChild(p);
  p.querySelector('[data-close]').onclick=()=>p.style.display='none';
  p.querySelector('[data-inject]').onclick=()=>{
    const k=p.querySelector('[data-node]').value,kind=p.querySelector('[data-kind]').value,role=p.querySelector('[data-role]').value;
    if(node[k].worker)node[k].worker.postMessage({type:'can-error-inject',controller:1,kind,role});
    const c=(node[k].state||{}).can1||{};
    qErrors.push({time:new Date().toLocaleTimeString(),node:k,kind,role,tec:Number(c.txErr||0),rec:Number(c.rxErr||0),state:qState(c)});
    if(qErrors.length>160)qErrors.shift();
    log(`Injected ${kind} error on Node ${k} (${role}).`);
    setTimeout(qRenderMonitor,60);
  };
  p.querySelector('[data-clearerr]').onclick=()=>{
    const k=p.querySelector('[data-node]').value;
    if(node[k].worker)node[k].worker.postMessage({type:'can-error-clear',controller:1});
    qErrors.push({time:new Date().toLocaleTimeString(),node:k,kind:'CLEAR',role:'-',tec:0,rec:0,state:'ERROR ACTIVE'});
    log(`Node ${k} CAN error counters cleared / recovered.`);
    setTimeout(qRenderMonitor,60);
  };
  p.querySelector('[data-clearlog]').onclick=()=>{qFrames=[];qErrors=[];events=[];seq=0;renderMonitor();qRenderMonitor();};
  drag(p,p.querySelector('.qMonHead'));
 }
 p.style.display='block';qRenderMonitor();
}
function qStateCard(k){
 const c=(node[k].state||{}).can1||{},counts=c.errorCounts||{},state=qState(c),tec=Number(c.txErr||0),rec=Number(c.rxErr||0);
 return `<div class="qCard ${state.replace(/\s+/g,'-').toLowerCase()}">
 <b>NODE ${k} • CAN1</b><strong>${state}</strong>
 <span>TEC <em>${tec}</em></span><span>REC <em>${rec}</em></span>
 <span>Last error <em>${c.lastError||'NONE'}</em></span>
 <small>BIT ${counts.BIT||0} • STUFF ${counts.STUFF||0} • CRC ${counts.CRC||0} • FORM ${counts.FORM||0} • ACK ${counts.ACK||0}</small>
 </div>`;
}
function qRenderMonitor(){
 const p=document.getElementById('qCanMonitor');if(!p||p.style.display==='none')return;
 p.querySelector('[data-state-a]').innerHTML=qStateCard('A');
 p.querySelector('[data-state-b]').innerHTML=qStateCard('B');
 p.querySelector('[data-frames]').innerHTML=qFrames.slice().reverse().map(f=>`<tr><td>${f.time}</td><td>${f.from}</td><td>${f.to}</td><td>0x${Number(f.id).toString(16).toUpperCase().padStart(3,'0')}</td><td>${f.dlc}</td><td>${f.data.map(v=>Number(v).toString(16).toUpperCase().padStart(2,'0')).join(' ')}</td><td>${f.ack?'YES':'NO'}</td><td>${f.path}</td></tr>`).join('');
 p.querySelector('[data-errors]').innerHTML=qErrors.slice().reverse().map(e=>`<tr><td>${e.time}</td><td>${e.node}</td><td>${e.kind}</td><td>${e.role}</td><td>${e.tec}</td><td>${e.rec}</td><td>${e.state}</td></tr>`).join('');
}
function kMcp(id,rev){return `<div class="canPcb ${rev?'kRev':''}"><div class="canSilk"><b>VECTOR INDIA</b><span>MCP2551 • CAN1</span></div><div class="canMcu"><small>MCU SIDE</small><span id="${id}TX" class="pin canPin"><i></i><b>TXD</b><em>TD1</em></span><span id="${id}RX" class="pin canPin"><i></i><b>RXD</b><em>RD1</em></span></div><div class="canChip"><div class="legs">${'<i></i>'.repeat(4)}</div><div class="body"><i class="dot"></i><b>MCP2551</b><span>High-Speed CAN</span><em>SOIC-8</em></div><div class="legs">${'<i></i>'.repeat(4)}</div></div><div class="canPower"><span class="pin canPwr"><i></i><b>VCC</b></span><span class="pin canPwr"><i></i><b>GND</b></span></div><div class="canBusSide"><small>CAN BUS</small><span id="${id}H" class="pin canBusPin"><i></i><b>CANH</b></span><span id="${id}L" class="pin canBusPin"><i></i><b>CANL</b></span></div><div class="term">120Ω TERM <b>ON</b></div><div class="canFoot">MCP2551 transceiver breakout</div></div>`}
function kCanvas(){return `<div id="kScene"><svg id="kWire"></svg><div id="kBA" class="kPart kBoard" style="left:25px;top:35px" data-z=".68"><div class="kHead">NODE A • LPC2129 TRAINER</div><div class="kBody"><img src="assets/vector_lpc2129_board.png"><span id="ATD" class="kPin r t"><i></i>TD1</span><span id="ARD" class="kPin r d"><i></i>RD1</span><button id="kSW" class="kSW"><i></i></button><small class="kIO">SW • P1.30</small></div></div><div id="kMA" class="kPart kMcp" style="left:570px;top:120px" data-z="1"><div class="kHead">NODE A • MCP2551</div>${kMcp('MA',false)}</div><div id="kMB" class="kPart kMcp" style="left:930px;top:120px" data-z="1"><div class="kHead">NODE B • MCP2551</div>${kMcp('MB',true)}</div><div id="kBB" class="kPart kBoard" style="left:1210px;top:35px" data-z=".68"><div class="kHead">NODE B • LPC2129 TRAINER</div><div class="kBody"><img src="assets/vector_lpc2129_board.png"><span id="BTD" class="kPin l t"><i></i>TD1</span><span id="BRD" class="kPin l d"><i></i>RD1</span><i id="kLED" class="kLED"></i><small class="kIO">LED • P1.31</small></div></div><div id="kBus"><div class="rail h">CANH</div><div class="rail l">CANL</div><div class="tr le">120Ω<i></i></div><div class="tr ri">120Ω<i></i></div><span id="BAH" class="bp ah"></span><span id="BAL" class="bp al"></span><span id="BBH" class="bp bh"></span><span id="BBL" class="bp bl"></span><b>CAN BUS</b></div></div>`}

let kWires=[
 {id:'A_TX',f:'ATD',t:'MATX',c:'sig',bend:0},
 {id:'A_RX',f:'MARX',t:'ARD',c:'sig',bend:0},
 {id:'A_H',f:'MAH',t:'BAH',c:'ch',bend:0},
 {id:'A_L',f:'MAL',t:'BAL',c:'cl',bend:0},
 {id:'B_H',f:'BBH',t:'MBH',c:'ch',bend:0},
 {id:'B_L',f:'BBL',t:'MBL',c:'cl',bend:0},
 {id:'B_TX',f:'BTD',t:'MBTX',c:'sig',bend:0},
 {id:'B_RX',f:'MBRX',t:'BRD',c:'sig',bend:0}
];
const kDefaults=kWires.map(w=>({...w}));
let kScale=1,kDragWire=null,kConnect=null;

function kp(id){
 const s=document.getElementById('kScene'),e=document.getElementById(id);
 if(!s||!e)return null;
 const a=s.getBoundingClientRect(),b=e.getBoundingClientRect();
 return{x:((b.left+b.right)/2-a.left)/kScale,y:((b.top+b.bottom)/2-a.top)/kScale};
}
function kd(){
 const s=document.getElementById('kScene'),v=document.getElementById('kWire');
 if(!s||!v)return;
 v.setAttribute('viewBox',`0 0 ${s.clientWidth} ${s.clientHeight}`);
 let q='';
 for(const w of kWires){
   const a=kp(w.f),b=kp(w.t);if(!a||!b)continue;
   const m=(a.x+b.x)/2+(w.bend||0);
   const d=`M${a.x},${a.y} L${m},${a.y} L${m},${b.y} L${b.x},${b.y}`;
   q+=`<path class="khit" data-wire="${w.id}" d="${d}"/><path class="kvis ${w.c}" data-wire="${w.id}" d="${d}"/>`;
 }
 v.innerHTML=q;
}
function ki(p){
 let on=false,x=0,y=0,l=0,t=0,h=p.querySelector('.kHead');
 h.onpointerdown=e=>{on=true;x=e.clientX;y=e.clientY;l=parseFloat(p.style.left)||0;t=parseFloat(p.style.top)||0;try{h.setPointerCapture(e.pointerId)}catch(_){};e.preventDefault();e.stopPropagation()};
 h.onpointermove=e=>{if(on){p.style.left=(l+(e.clientX-x)/kScale)+'px';p.style.top=(t+(e.clientY-y)/kScale)+'px';kd()}};
 h.onpointerup=()=>on=false;h.onpointercancel=()=>on=false;
 p.onwheel=e=>{e.preventDefault();e.stopPropagation();let z=parseFloat(p.dataset.z||1);z=Math.max(.5,Math.min(1.7,z+(e.deltaY<0?.1:-.1)));p.dataset.z=z;p.style.setProperty('--z',z);kd()};
 p.style.setProperty('--z',p.dataset.z||1);
}
function kTerminalTarget(el){
 if(!el)return null;
 if(el.id && ['ATD','ARD','MATX','MARX','MAH','MAL','BAH','BAL','BBH','BBL','MBH','MBL','MBTX','MBRX','BTD','BRD'].includes(el.id))return el;
 const p=el.closest('[id]');
 return p&&['ATD','ARD','MATX','MARX','MAH','MAL','BAH','BAL','BBH','BBL','MBH','MBL','MBTX','MBRX','BTD','BRD'].includes(p.id)?p:null;
}
function kInstall(){
 document.querySelectorAll('#kScene .kPart').forEach(ki);
 const s=document.getElementById('kScene'),v=document.getElementById('kWire');

 /* Wire drag and delete use SVG event delegation, so redraws do not destroy handlers. */
 v.addEventListener('pointerdown',e=>{
   const p=e.target.closest('path[data-wire]');if(!p)return;
   const w=kWires.find(x=>x.id===p.dataset.wire);if(!w)return;
   kDragWire={id:w.id,x:e.clientX,b:w.bend||0};
   e.preventDefault();e.stopPropagation();
 });
 v.addEventListener('dblclick',e=>{
   const p=e.target.closest('path[data-wire]');if(!p)return;
   const i=kWires.findIndex(x=>x.id===p.dataset.wire);
   if(i>=0){kWires.splice(i,1);kd();}
   e.preventDefault();e.stopPropagation();
 });
 document.addEventListener('pointermove',e=>{
   if(!kDragWire)return;
   const w=kWires.find(x=>x.id===kDragWire.id);if(!w)return;
   w.bend=kDragWire.b+(e.clientX-kDragWire.x)/kScale;kd();
 });
 document.addEventListener('pointerup',()=>kDragWire=null);
 document.addEventListener('pointercancel',()=>kDragWire=null);

 /* Click any real terminal, then a second terminal, to create a new physical wire. */
 s.addEventListener('click',e=>{
   const t=kTerminalTarget(e.target);if(!t)return;
   e.stopPropagation();
   if(!kConnect){kConnect=t;t.classList.add('karmed');return;}
   if(kConnect===t){t.classList.remove('karmed');kConnect=null;return;}
   kWires.push({id:'USER_'+Date.now(),f:kConnect.id,t:t.id,c:'user',bend:0});
   kConnect.classList.remove('karmed');kConnect=null;kd();
 });

 s.onwheel=e=>{
   if(e.target.closest('.kPart'))return;
   e.preventDefault();
   kScale=Math.max(.55,Math.min(1.8,kScale+(e.deltaY<0?.1:-.1)));
   s.style.setProperty('--sz',kScale);kd()
 };
 const sw=document.getElementById('kSW');
 if(sw){
   const release=()=>{
     sw.classList.remove('pressed');
     if(node.A.worker)node.A.worker.postMessage({type:'gpio-input',port:1,pin:30,level:true});
   };
   sw.onpointerdown=e=>{
     e.preventDefault();e.stopPropagation();
     sw.classList.add('pressed');
     if(node.A.worker)node.A.worker.postMessage({type:'gpio-input',port:1,pin:30,level:false});
   };
   sw.onpointerup=release;
   sw.onpointercancel=release;
 }
 setTimeout(kd,100);
}
function kRestore(){kWires=kDefaults.map(w=>({...w}));if(kConnect){kConnect.classList.remove('karmed');kConnect=null}kd();}

function kHas(f,t){
 return kWires.some(w=>(w.f===f&&w.t===t)||(w.f===t&&w.t===f));
}
function kNodePath(n){
 if(n==='A')return kHas('ATD','MATX')&&kHas('MARX','ARD')&&kHas('MAH','BAH')&&kHas('MAL','BAL');
 return kHas('BTD','MBTX')&&kHas('MBRX','BRD')&&kHas('BBH','MBH')&&kHas('BBL','MBL');
}
function kBusPathOK(){return qBusConnected&&kNodePath('A')&&kNodePath('B');}
function kPathReason(){
 const miss=[];
 if(!qBusConnected)miss.push('CAN BUS DISCONNECTED');
 if(!kHas('ATD','MATX'))miss.push('A TD1-TXD');
 if(!kHas('MARX','ARD'))miss.push('A RXD-RD1');
 if(!kHas('MAH','BAH'))miss.push('A CANH');
 if(!kHas('MAL','BAL'))miss.push('A CANL');
 if(!kHas('BTD','MBTX'))miss.push('B TD1-TXD');
 if(!kHas('MBRX','BRD'))miss.push('B RXD-RD1');
 if(!kHas('BBH','MBH'))miss.push('B CANH');
 if(!kHas('BBL','MBL'))miss.push('B CANL');
 return miss.join(', ');
}



function qSetBusConnected(v){
 qBusConnected=!!v;
 const btn=document.querySelector('#t19lab [data-bus]');
 if(btn)btn.textContent=qBusConnected?'Disconnect CAN Bus':'Reconnect CAN Bus';
 const bus=document.getElementById('kBus');
 if(bus)bus.classList.toggle('qDisconnected',!qBusConnected);
 for(const k of ['A','B']){
   if(node[k].worker){
     node[k].worker.postMessage({type:'can-bus-config',connected:qBusConnected,term1:true,term2:true,mcp1:true,mcp2:true});
   }
 }
 log(qBusConnected
   ? 'CAN BUS RECONNECTED — communication path restored.'
   : 'CAN BUS DISCONNECTED — subsequent transmissions produce NO ACK / TEC growth.');
 qErrors.push({time:new Date().toLocaleTimeString(),node:'BUS',kind:qBusConnected?'RECONNECT':'DISCONNECT',role:'PHYSICAL',tec:'-',rec:'-',state:qBusConnected?'CONNECTED':'OPEN'});
 if(qErrors.length>160)qErrors.shift();
 kRenderPhysical();
 qRenderMonitor();
}
function qToggleBus(){qSetBusConnected(!qBusConnected);}
function kOpenPhysical(){
 let p=document.getElementById('kPhysical');
 if(!p){
  p=document.createElement('div');p.id='kPhysical';p.className='kPhysical';
  p.innerHTML='<div class="kPhysHead"><b>CAN Physical Layer / Wiring Status</b><button>×</button></div><pre></pre>';
  document.body.appendChild(p);p.querySelector('button').onclick=()=>p.style.display='none';
  drag(p,p.querySelector('.kPhysHead'));
 }
 p.style.display='block';kRenderPhysical();
}
function kRenderPhysical(){
 const p=document.getElementById('kPhysical');if(!p)return;
 const rows=[
  ['Node A TD1 → MCP2551 TXD',kHas('ATD','MATX')],
  ['Node A MCP2551 RXD → RD1',kHas('MARX','ARD')],
  ['Node A CANH',kHas('MAH','BAH')],['Node A CANL',kHas('MAL','BAL')],
  ['Node B CANH',kHas('BBH','MBH')],['Node B CANL',kHas('BBL','MBL')],
  ['Node B TD1 → MCP2551 TXD',kHas('BTD','MBTX')],
  ['Node B MCP2551 RXD → RD1',kHas('MBRX','BRD')]
 ];
 p.querySelector('pre').textContent=
 'RUNTIME CAN BUS: '+(qBusConnected?'CONNECTED':'DISCONNECTED')+'\n\n'+
 rows.map(r=>(r[1]?'CONNECTED  ':'OPEN       ')+r[0]).join('\n')+
 '\n\nCAN PHYSICAL PATH: '+(kBusPathOK()?'READY / ACK POSSIBLE':'OPEN / NO ACK')+
 (kBusPathOK()?'':'\nReason: '+kPathReason());
}






function commonHeaderHtml(title){
 return `<div class="t19head"><b>${title}</b><button data-close>×</button></div>`;
}
function buildTwoNodeUI(p){
 p.className='t19lab';
 p.innerHTML=commonHeaderHtml('Phase 8.4T19S2 • Example 1 — Two-Node Switch → LED')+
 `<div class="kbar">
   <select data-example>
    <option value="2" selected>Example 1 • Two-Node Switch → LED</option>
    <option value="4">Example 2 • Four-Node 3-Switch → 3-LED</option>
   </select>
   <button data-a>Node A Source</button><button data-b>Node B Source</button>
   <button data-ua>Node A UART0</button><button data-ub>Node B UART0</button>
   <button data-c>Compile Nodes</button><button data-r>Run Nodes</button><button data-s>Stop Nodes</button>
   <button data-w>Restore Wiring</button><button data-bus>Disconnect CAN Bus</button>
   <button data-p>Physical Layer</button><button data-q>CAN Bus Monitor</button>
 </div>
 <div class="kview">${kCanvas()}</div>
 <textarea id="t19srcA" hidden></textarea><textarea id="t19srcB" hidden></textarea>
 <span id="t19statusA" hidden></span><span id="t19statusB" hidden></span>`;

 p.querySelector('[data-close]').onclick=()=>p.style.display='none';
 p.querySelector('[data-example]').onchange=e=>{if(e.target.value==='4')s4Open();};
 p.querySelector('#t19srcA').value=defaultA;
 p.querySelector('#t19srcB').value=defaultB;
 p.querySelector('[data-a]').onclick=()=>kOpenSource('A');
 p.querySelector('[data-b]').onclick=()=>kOpenSource('B');
 p.querySelector('[data-ua]').onclick=()=>kOpenUart('A');
 p.querySelector('[data-ub]').onclick=()=>kOpenUart('B');
 p.querySelector('[data-c]').onclick=compileNodes;
 p.querySelector('[data-r]').onclick=runNodes;
 p.querySelector('[data-s]').onclick=stopNodes;
 p.querySelector('[data-w]').onclick=kRestore;
 p.querySelector('[data-bus]').onclick=qToggleBus;
 p.querySelector('[data-p]').onclick=kOpenPhysical;
 p.querySelector('[data-q]').onclick=qOpenMonitor;
 drag(p,p.querySelector('.t19head'));
}
function buildFourNodeUI(p){
 p.className='t19lab s4Mode';
 p.innerHTML=commonHeaderHtml('Phase 8.4T19S2 • Example 2 — Four-Node 3-Switch → 3-LED')+
 `<div class="kbar s4Toolbar">
   <select data-example>
    <option value="2">Example 1 • Two-Node Switch → LED</option>
    <option value="4" selected>Example 2 • Four-Node 3-Switch → 3-LED</option>
   </select>
   <button id="s4BtnSourceA">Source A</button><button id="s4BtnSourceB">Source B</button><button id="s4BtnSourceC">Source C</button><button id="s4BtnSourceD">Source D</button>
   <button id="s4BtnUartA">UART A</button><button id="s4BtnUartB">UART B</button><button id="s4BtnUartC">UART C</button><button id="s4BtnUartD">UART D</button>
   <button id="s4BtnCompile">Compile Nodes</button><button id="s4BtnRun">Run Nodes</button><button id="s4BtnStop">Stop Nodes</button>
   <button id="s4BtnWiring">Restore Wiring</button><button id="s4BtnBus">Disconnect CAN Bus</button>
   <button id="s4BtnPhysical">Physical Layer</button><button id="s4BtnMonitor">CAN Bus Monitor</button>
 <span class="s4NodeStatus">A:<b id="t19s11StatusA">IDLE</b></span>
 <span class="s4NodeStatus">B:<b id="t19s11StatusB">IDLE</b></span>
 <span class="s4NodeStatus">C:<b id="t19s11StatusC">IDLE</b></span>
 <span class="s4NodeStatus">D:<b id="t19s11StatusD">IDLE</b></span>
 <span id="s4RunStatus">IDLE</span>
 </div>
 <div class="kview">${s4Canvas()}</div>`;

 p.querySelector('[data-close]').onclick=()=>p.style.display='none';
 p.querySelector('[data-example]').onchange=e=>{if(e.target.value==='2')open();};

 document.getElementById('s4BtnSourceA').onclick=()=>s4OpenSource('A');
 document.getElementById('s4BtnSourceB').onclick=()=>s4OpenSource('B');
 document.getElementById('s4BtnSourceC').onclick=()=>s4OpenSource('C');
 document.getElementById('s4BtnSourceD').onclick=()=>s4OpenSource('D');

 document.getElementById('s4BtnUartA').onclick=()=>s4OpenUart('A');
 document.getElementById('s4BtnUartB').onclick=()=>s4OpenUart('B');
 document.getElementById('s4BtnUartC').onclick=()=>s4OpenUart('C');
 document.getElementById('s4BtnUartD').onclick=()=>s4OpenUart('D');

 document.getElementById('s4BtnCompile').onclick=async()=>{
   const overall=document.getElementById('s4RunStatus');
   if(overall)overall.textContent='COMPILE BUTTON RECEIVED';
   await s4CompileNodes();
 };
 document.getElementById('s4BtnRun').onclick=async()=>{await s4RunNodes();};
 document.getElementById('s4BtnStop').onclick=()=>s4StopNodes();
 document.getElementById('s4BtnWiring').onclick=()=>s4Restore();
 document.getElementById('s4BtnBus').onclick=()=>s4ToggleBus();
 document.getElementById('s4BtnPhysical').onclick=()=>s4OpenPhysical();
 document.getElementById('s4BtnMonitor').onclick=()=>s4OpenMonitor();

 drag(p,p.querySelector('.t19head'));
}
function open(){
 let p=document.getElementById('t19lab');
 if(!p){
   p=document.createElement('div');
   p.id='t19lab';
   p.className='t19lab';
   document.body.appendChild(p);
 }
 buildTwoNodeUI(p);
 p.style.display='block';
 requestAnimationFrame(()=>{kInstall();kd();});
};
let s4Node={
 A:{worker:null,running:false,hex:null,state:null},
 B:{worker:null,running:false,hex:null,state:null},
 C:{worker:null,running:false,hex:null,state:null},
 D:{worker:null,running:false,hex:null,state:null}
};
let s4Pending=[],s4ArbTimer=null,s4Seq=0,s4Events=[],s4Frames=[],s4Errors=[];
let s4BusConnected=true,s4Scale=1,s4DragWire=null,s4Connect=null;

const s4SourceA=`/* NODE A — 3 switches -> three CAN IDs */
#define IO1PIN  (*(volatile unsigned long*)0xE0028010)
#define IO1DIR  (*(volatile unsigned long*)0xE0028018)
#define PINSEL0 (*(volatile unsigned long*)0xE002C000)
#define PINSEL1 (*(volatile unsigned long*)0xE002C004)
#define U0THR   (*(volatile unsigned long*)0xE000C000)
#define U0DLL   (*(volatile unsigned long*)0xE000C000)
#define U0DLM   (*(volatile unsigned long*)0xE000C004)
#define U0LCR   (*(volatile unsigned long*)0xE000C00C)
#define U0LSR   (*(volatile unsigned long*)0xE000C014)
#define C1MOD   (*(volatile unsigned long*)0xE0044000)
#define C1CMR   (*(volatile unsigned long*)0xE0044004)
#define C1BTR   (*(volatile unsigned long*)0xE0044014)
#define C1SR    (*(volatile unsigned long*)0xE004401C)
#define C1TFI1  (*(volatile unsigned long*)0xE0044030)
#define C1TID1  (*(volatile unsigned long*)0xE0044034)
#define C1TDA1  (*(volatile unsigned long*)0xE0044038)
#define AFMR    (*(volatile unsigned long*)0xE003C000)
#define SW1 (1UL<<28)
#define SW2 (1UL<<29)
#define SW3 (1UL<<30)

static void u0_init(void){PINSEL0=(PINSEL0&~0x0FUL)|0x05UL;U0LCR=0x83;U0DLL=98;U0DLM=0;U0LCR=0x03;}
static void u0c(char c){while((U0LSR&0x20UL)==0){}U0THR=(unsigned long)c;}
static void u0s(const char*s){while(*s)u0c(*s++);}
static void can1_send(unsigned short id,unsigned char v){
 while((C1SR&4UL)==0){}
 C1TFI1=(1UL<<16);C1TID1=id;C1TDA1=v;C1CMR=0x21;
 if(id==0x101)u0s(v?"TX 101 01\\r\\n":"TX 101 00\\r\\n");
 if(id==0x102)u0s(v?"TX 102 01\\r\\n":"TX 102 00\\r\\n");
 if(id==0x103)u0s(v?"TX 103 01\\r\\n":"TX 103 00\\r\\n");
}
int main(void){
 unsigned long a=2,b=2,c=2,na,nb,nc;
 IO1DIR&=~(SW1|SW2|SW3);u0_init();
 PINSEL1=(PINSEL1&~(3UL<<18))|(1UL<<18);
 C1MOD=1;C1BTR=0x001C001D;AFMR=2;C1MOD=0;
 u0s("NODE A READY\\r\\n");
 while(1){
   na=(IO1PIN&SW1)?0:1;nb=(IO1PIN&SW2)?0:1;nc=(IO1PIN&SW3)?0:1;
   if(na!=a){a=na;can1_send(0x101,(unsigned char)na);}
   if(nb!=b){b=nb;can1_send(0x102,(unsigned char)nb);}
   if(nc!=c){c=nc;can1_send(0x103,(unsigned char)nc);}
 }
}`;

function s4ReceiverSource(id){
 return `/* Receiver Node — CAN ID 0x${id.toString(16).toUpperCase()} -> P1.31 LED */
#define IO1SET (*(volatile unsigned long*)0xE0028014)
#define IO1DIR (*(volatile unsigned long*)0xE0028018)
#define IO1CLR (*(volatile unsigned long*)0xE002801C)
#define PINSEL0 (*(volatile unsigned long*)0xE002C000)
#define PINSEL1 (*(volatile unsigned long*)0xE002C004)
#define U0THR (*(volatile unsigned long*)0xE000C000)
#define U0DLL (*(volatile unsigned long*)0xE000C000)
#define U0DLM (*(volatile unsigned long*)0xE000C004)
#define U0LCR (*(volatile unsigned long*)0xE000C00C)
#define U0LSR (*(volatile unsigned long*)0xE000C014)
#define C1MOD (*(volatile unsigned long*)0xE0044000)
#define C1CMR (*(volatile unsigned long*)0xE0044004)
#define C1GSR (*(volatile unsigned long*)0xE0044008)
#define C1BTR (*(volatile unsigned long*)0xE0044014)
#define C1RID (*(volatile unsigned long*)0xE0044024)
#define C1RDA (*(volatile unsigned long*)0xE0044028)
#define AFMR (*(volatile unsigned long*)0xE003C000)
#define LED (1UL<<31)
static void u0_init(void){PINSEL0=(PINSEL0&~0x0FUL)|0x05UL;U0LCR=0x83;U0DLL=98;U0DLM=0;U0LCR=0x03;}
static void u0c(char c){while((U0LSR&0x20UL)==0){}U0THR=(unsigned long)c;}
static void u0s(const char*s){while(*s)u0c(*s++);}
int main(void){unsigned long d;IO1DIR|=LED;IO1SET=LED;u0_init();PINSEL1=(PINSEL1&~(3UL<<18))|(1UL<<18);C1MOD=1;C1BTR=0x001C001D;AFMR=2;C1MOD=0;u0s("NODE READY\\r\\n");while(1){if(C1GSR&1UL){d=C1RDA;if((C1RID&0x7FFUL)==0x${id.toString(16).toUpperCase()}){if(d&1UL){IO1CLR=LED;u0s("RX -> LED ON\\r\\n");}else{IO1SET=LED;u0s("RX -> LED OFF\\r\\n");}}C1CMR=0x04;}}}`;
}
const s4SourceB=s4ReceiverSource(0x101);
const s4SourceC=s4ReceiverSource(0x102);
const s4SourceD=s4ReceiverSource(0x103);

let s4Uart={A:'',B:'',C:'',D:''};

function s4Mcp(id,nodeName,reverse){
 return `<div class="canPcb ${reverse?'s4Rev':''}">
 <div class="canSilk"><b>VECTOR INDIA</b><span>MCP2551 • CAN1</span></div>
 <div class="canMcu"><small>MCU SIDE</small>
 <span id="${id}TX" class="pin canPin s4Conn"><i></i><b>TXD</b><em>TD1</em></span>
 <span id="${id}RX" class="pin canPin s4Conn"><i></i><b>RXD</b><em>RD1</em></span></div>
 <div class="canChip"><div class="legs">${'<i></i>'.repeat(4)}</div><div class="body"><i class="dot"></i><b>MCP2551</b><span>High-Speed CAN</span><em>SOIC-8</em></div><div class="legs">${'<i></i>'.repeat(4)}</div></div>
 <div class="canPower"><span class="pin canPwr"><i></i><b>VCC</b></span><span class="pin canPwr"><i></i><b>GND</b></span></div>
 <div class="canBusSide"><small>CAN BUS</small><span id="${id}H" class="pin canBusPin s4Conn"><i></i><b>CANH</b></span><span id="${id}L" class="pin canBusPin s4Conn"><i></i><b>CANL</b></span></div>
 <div class="term">120Ω TERM <b>${nodeName==='A'||nodeName==='D'?'ON':'OFF'}</b></div>
 <div class="canFoot">MCP2551 transceiver breakout • NODE ${nodeName}</div></div>`;
}

function s4Board(node,inputs){
 const left=node==='A';
 const io=left
   ? `<button id="S4SW1" class="s4Sw one"><i></i></button><button id="S4SW2" class="s4Sw two"><i></i></button><button id="S4SW3" class="s4Sw three"><i></i></button><small class="s4IoLabel">SW1 P1.28 • SW2 P1.29 • SW3 P1.30</small>`
   : `<i id="S4LED${node}" class="s4Led"></i><small class="s4IoLabel">LED P1.31</small>`;
 return `<div class="s4BoardBody"><img src="assets/vector_lpc2129_board.png">
 <span id="S4${node}TD" class="s4BoardPin td"><i></i><b>TD1</b></span>
 <span id="S4${node}RD" class="s4BoardPin rd"><i></i><b>RD1</b></span>${io}</div>`;
}

function s4Canvas(){
 return `<div id="s4Scene" class="s4Professional">
 <svg id="s4Wire"></svg>

 <!-- OUTER LEFT NODES -->
 <div id="s4BA" class="s4Part s4Board" style="left:15px;top:28px" data-z=".48">
  <div class="s4Head">NODE A • LPC2129</div>${s4Board('A',true)}
 </div>
 <div id="s4BC" class="s4Part s4Board" style="left:15px;top:405px" data-z=".48">
  <div class="s4Head">NODE C • LPC2129</div>${s4Board('C',false)}
 </div>

 <!-- INWARD-FACING LEFT TRANSCEIVERS: MCU side faces left LPC2129, CAN side faces center -->
 <div id="s4MA" class="s4Part s4Mcp" style="left:410px;top:105px" data-z=".82">
  <div class="s4Head">NODE A • MCP2551</div>${s4Mcp('S4MA','A',false)}
 </div>
 <div id="s4MC" class="s4Part s4Mcp" style="left:410px;top:482px" data-z=".82">
  <div class="s4Head">NODE C • MCP2551</div>${s4Mcp('S4MC','C',false)}
 </div>

 <!-- INWARD-FACING RIGHT TRANSCEIVERS: CAN side faces center, MCU side faces right LPC2129 -->
 <div id="s4MB" class="s4Part s4Mcp" style="left:808px;top:105px" data-z=".82">
  <div class="s4Head">NODE B • MCP2551</div>${s4Mcp('S4MB','B',true)}
 </div>
 <div id="s4MD" class="s4Part s4Mcp" style="left:808px;top:482px" data-z=".82">
  <div class="s4Head">NODE D • MCP2551</div>${s4Mcp('S4MD','D',true)}
 </div>

 <!-- OUTER RIGHT NODES -->
 <div id="s4BB" class="s4Part s4Board s4RightBoard" style="left:1045px;top:28px" data-z=".48">
  <div class="s4Head">NODE B • LPC2129</div>${s4Board('B',false)}
 </div>
 <div id="s4BD" class="s4Part s4Board s4RightBoard" style="left:1045px;top:405px" data-z=".48">
  <div class="s4Head">NODE D • LPC2129</div>${s4Board('D',false)}
 </div>

 <!-- CENTRAL SHARED DIFFERENTIAL BUS -->
 <div id="s4Bus">
  <div class="rail h">CANH</div><div class="rail l">CANL</div>
  <div class="s4Term left">120Ω<i></i></div><div class="s4Term right">120Ω<i></i></div>
  <span id="S4AH" class="s4BusPin a h"></span><span id="S4AL" class="s4BusPin a l"></span>
  <span id="S4BH" class="s4BusPin b h"></span><span id="S4BL" class="s4BusPin b l"></span>
  <span id="S4CH" class="s4BusPin c h"></span><span id="S4CL" class="s4BusPin c l"></span>
  <span id="S4DH" class="s4BusPin d h"></span><span id="S4DL" class="s4BusPin d l"></span>
  <b>CANH / CANL • FOUR-NODE BACKBONE</b>
 </div>

 <div class="s4Legend">
  <b>LOCAL TRANSCEIVER LINKS</b>
  <span>TD1 → TXD</span><span>RXD → RD1</span>
  <b>SHARED BUS</b><span>CANH → CANH</span><span>CANL → CANL</span>
 </div>
 </div>`;
}
let s4Wires=[
 {id:'A_TX',f:'S4ATD',t:'S4MATX',c:'sig tx',bend:-10},{id:'A_RX',f:'S4MARX',t:'S4ARD',c:'sig rx',bend:10},
 {id:'B_TX',f:'S4BTD',t:'S4MBTX',c:'sig tx',bend:10},{id:'B_RX',f:'S4MBRX',t:'S4BRD',c:'sig rx',bend:-10},
 {id:'C_TX',f:'S4CTD',t:'S4MCTX',c:'sig tx',bend:-10},{id:'C_RX',f:'S4MCRX',t:'S4CRD',c:'sig rx',bend:10},
 {id:'D_TX',f:'S4DTD',t:'S4MDTX',c:'sig tx',bend:10},{id:'D_RX',f:'S4MDRX',t:'S4DRD',c:'sig rx',bend:-10},
 {id:'AH',f:'S4MAH',t:'S4AH',c:'ch',bend:-12},{id:'AL',f:'S4MAL',t:'S4AL',c:'cl',bend:12},
 {id:'BH',f:'S4BH',t:'S4MBH',c:'ch',bend:12},{id:'BL',f:'S4BL',t:'S4MBL',c:'cl',bend:-12},
 {id:'CH',f:'S4MCH',t:'S4CH',c:'ch',bend:-12},{id:'CL',f:'S4MCL',t:'S4CL',c:'cl',bend:12},
 {id:'DH',f:'S4DH',t:'S4MDH',c:'ch',bend:12},{id:'DL',f:'S4DL',t:'S4MDL',c:'cl',bend:-12}
];
const s4Defaults=s4Wires.map(w=>({...w}));

function s4Has(f,t){return s4Wires.some(w=>(w.f===f&&w.t===t)||(w.f===t&&w.t===f));}
function s4NodePath(k){
 if(k==='A')return s4Has('S4ATD','S4MATX')&&s4Has('S4MARX','S4ARD')&&s4Has('S4MAH','S4AH')&&s4Has('S4MAL','S4AL');
 if(k==='B')return s4Has('S4BTD','S4MBTX')&&s4Has('S4MBRX','S4BRD')&&s4Has('S4BH','S4MBH')&&s4Has('S4BL','S4MBL');
 if(k==='C')return s4Has('S4CTD','S4MCTX')&&s4Has('S4MCRX','S4CRD')&&s4Has('S4MCH','S4CH')&&s4Has('S4MCL','S4CL');
 return s4Has('S4DTD','S4MDTX')&&s4Has('S4MDRX','S4DRD')&&s4Has('S4DH','S4MDH')&&s4Has('S4DL','S4MDL');
}
function s4Point(id){const s=document.getElementById('s4Scene'),e=document.getElementById(id);if(!s||!e)return null;const a=s.getBoundingClientRect(),b=e.getBoundingClientRect();return{x:((b.left+b.right)/2-a.left)/s4Scale,y:((b.top+b.bottom)/2-a.top)/s4Scale};}
function s4Draw(){const s=document.getElementById('s4Scene'),v=document.getElementById('s4Wire');if(!s||!v)return;v.setAttribute('viewBox',`0 0 ${s.clientWidth} ${s.clientHeight}`);let q='';for(const w of s4Wires){const a=s4Point(w.f),b=s4Point(w.t);if(!a||!b)continue;const m=(a.x+b.x)/2+(w.bend||0),d=`M${a.x},${a.y} L${m},${a.y} L${m},${b.y} L${b.x},${b.y}`;q+=`<path class="hit" data-wire="${w.id}" d="${d}"/><path class="vis ${w.c}" data-wire="${w.id}" d="${d}"/>`;}v.innerHTML=q;s4RenderPhysical();}
function s4Part(p){let on=false,x=0,y=0,l=0,t=0,h=p.querySelector('.s4Head');h.onpointerdown=e=>{on=true;x=e.clientX;y=e.clientY;l=parseFloat(p.style.left)||0;t=parseFloat(p.style.top)||0;try{h.setPointerCapture(e.pointerId)}catch(_){};e.preventDefault();e.stopPropagation()};h.onpointermove=e=>{if(on){p.style.left=(l+(e.clientX-x)/s4Scale)+'px';p.style.top=(t+(e.clientY-y)/s4Scale)+'px';s4Draw()}};h.onpointerup=()=>on=false;h.onpointercancel=()=>on=false;p.onwheel=e=>{e.preventDefault();e.stopPropagation();let z=parseFloat(p.dataset.z||1);z=Math.max(.45,Math.min(1.6,z+(e.deltaY<0?.1:-.1)));p.dataset.z=z;p.style.setProperty('--z',z);s4Draw()};p.style.setProperty('--z',p.dataset.z||1);}
function s4TerminalTarget(el){if(!el)return null;const p=el.closest('[id]');if(!p)return null;return /^S4/.test(p.id)?p:null;}
function s4Install(){
 document.querySelectorAll('#s4Scene .s4Part').forEach(s4Part);
 const s=document.getElementById('s4Scene'),v=document.getElementById('s4Wire');
 v.addEventListener('pointerdown',e=>{const p=e.target.closest('path[data-wire]');if(!p)return;const w=s4Wires.find(x=>x.id===p.dataset.wire);if(!w)return;s4DragWire={id:w.id,x:e.clientX,b:w.bend||0};e.preventDefault();e.stopPropagation();});
 v.addEventListener('dblclick',e=>{const p=e.target.closest('path[data-wire]');if(!p)return;const i=s4Wires.findIndex(x=>x.id===p.dataset.wire);if(i>=0){s4Wires.splice(i,1);s4Draw()}e.preventDefault();e.stopPropagation();});
 document.addEventListener('pointermove',e=>{if(!s4DragWire)return;const w=s4Wires.find(x=>x.id===s4DragWire.id);if(!w)return;w.bend=s4DragWire.b+(e.clientX-s4DragWire.x)/s4Scale;s4Draw();});
 document.addEventListener('pointerup',()=>s4DragWire=null);
 s.addEventListener('click',e=>{const t=s4TerminalTarget(e.target);if(!t||!/(TD|RD|TX|RX|H|L)$/.test(t.id))return;if(!s4Connect){s4Connect=t;t.classList.add('s4Armed');return;}if(s4Connect===t){t.classList.remove('s4Armed');s4Connect=null;return;}s4Wires.push({id:'USER_'+Date.now(),f:s4Connect.id,t:t.id,c:'user',bend:0});s4Connect.classList.remove('s4Armed');s4Connect=null;s4Draw();});
 s.onwheel=e=>{if(e.target.closest('.s4Part'))return;e.preventDefault();s4Scale=Math.max(.5,Math.min(1.6,s4Scale+(e.deltaY<0?.1:-.1)));s.style.setProperty('--sz',s4Scale);s4Draw();};

 const swmap=[['S4SW1',28],['S4SW2',29],['S4SW3',30]];
 for(const [id,pin] of swmap){
  const sw=document.getElementById(id);if(!sw)continue;
  const rel=()=>{
    sw.classList.remove('pressed');
    if(s4Node.A.worker){
      s4Node.A.worker.postMessage({type:'gpio-input',port:1,pin,level:true});
      s4Log(`${id} RELEASED (P1.${pin}=1)`);
    }else{
      s4Log(`${id} RELEASED but Node A is NOT RUNNING`);
    }
  };
  sw.onpointerdown=e=>{
    e.preventDefault();e.stopPropagation();
    sw.classList.add('pressed');
    if(s4Node.A.worker){
      s4Node.A.worker.postMessage({type:'gpio-input',port:1,pin,level:false});
      s4Log(`${id} PRESSED (P1.${pin}=0)`);
    }else{
      s4Log(`${id} PRESSED but Node A is NOT RUNNING`);
    }
  };
  sw.onpointerup=rel;sw.onpointercancel=rel;
 }
 setTimeout(s4Draw,100);
}
function s4Restore(){s4Wires=s4Defaults.map(w=>({...w}));s4Draw();}
function s4Log(s){s4Events.push({n:++s4Seq,s});if(s4Events.length>180)s4Events.shift();s4RenderMonitor();}
function s4AppendUart(k,bytes){let s='';for(const b of (bytes||[]))s+=String.fromCharCode(Number(b)&255);s4Uart[k]+=s;if(s4Uart[k].length>22000)s4Uart[k]=s4Uart[k].slice(-15000);s4RenderUart(k);}
function s4OpenUart(k){let p=document.getElementById('s4Uart'+k);if(!p){p=document.createElement('div');p.id='s4Uart'+k;p.className='kFloat kUart';p.innerHTML=`<div class="kFloatHead"><b>Node ${k} UART0</b><div><button data-clear>Clear</button><button data-close>×</button></div></div><pre></pre>`;document.body.appendChild(p);p.querySelector('[data-clear]').onclick=()=>{s4Uart[k]='';s4RenderUart(k)};p.querySelector('[data-close]').onclick=()=>p.style.display='none';drag(p,p.querySelector('.kFloatHead'));}p.style.display='block';s4RenderUart(k);}
function s4RenderUart(k){const p=document.getElementById('s4Uart'+k);if(!p||p.style.display==='none')return;const pre=p.querySelector('pre');pre.textContent=s4Uart[k];pre.scrollTop=pre.scrollHeight;}
function s4OpenSource(k){let p=document.getElementById('s4Source'+k);if(!p){p=document.createElement('div');p.id='s4Source'+k;p.className='kFloat kSource';p.innerHTML=`<div class="kFloatHead"><b>Node ${k} C Source</b><div><button data-close>×</button></div></div><textarea spellcheck="false"></textarea>`;document.body.appendChild(p);p.querySelector('textarea').value=({A:s4SourceA,B:s4SourceB,C:s4SourceC,D:s4SourceD})[k];p.querySelector('[data-close]').onclick=()=>p.style.display='none';drag(p,p.querySelector('.kFloatHead'));}p.style.display='block';}

async function s4CompileOne(k){
 const panel=document.getElementById('s4Source'+k);
 const source=panel
   ? panel.querySelector('textarea').value
   : ({A:s4SourceA,B:s4SourceB,C:s4SourceC,D:s4SourceD})[k];

 const st=document.getElementById('s4Status'+k);
 if(st)st.textContent='COMPILING';

 const ctl=new AbortController();
 const timer=setTimeout(()=>ctl.abort(),25000);

 try{
   const r=await fetch('/api/build-hex',{
     method:'POST',
     headers:{'Content-Type':'application/json'},
     body:JSON.stringify({code:source,sourceType:'c'}),
     signal:ctl.signal
   });
   clearTimeout(timer);

   if(!r.ok)throw new Error('HTTP '+r.status);

   const d=await r.json();

   if(!d||!d.ok){
     s4Node[k].hex=null;
     if(st)st.textContent='FAILED';
     s4Log('Node '+k+' COMPILE FAILED: '+((d&&(d.output||d.log))||'unknown compiler error'));
     return false;
   }

   s4Node[k].hex=d.hex||'';
   if(st)st.textContent=s4Node[k].hex?'READY':'NO HEX';
   s4Log('Node '+k+' COMPILED OK');
   return !!s4Node[k].hex;
 }catch(e){
   clearTimeout(timer);
   s4Node[k].hex=null;
   if(st)st.textContent=e&&e.name==='AbortError'?'TIMEOUT':'BACKEND ERROR';
   s4Log('Node '+k+' COMPILE ERROR: '+(e&&e.message?e.message:e));
   return false;
 }
}
async function s4CompileNodes_OLD_DISABLED(){
 const overall=document.getElementById('s4RunStatus');
 const fallbackFetch=async(path,opt)=>{
   const r=await fetch(path,opt);
   const text=await r.text();
   try{return JSON.parse(text)}catch(_){return {ok:false,output:text||'Non-JSON response'};}
 };
 if(!s4Node.A||!s4Node.B||!s4Node.C||!s4Node.D){
   if(overall)overall.textContent='NODE STATE INIT FAILED';
   return false;
 }

 const api=(typeof window.vectorFetchJson==='function')?window.vectorFetchJson:fallbackFetch;

 for(const k of ['A','B','C','D']){
   s4Node[k].hex=null;
   const e=document.getElementById('s4Status'+k);
   if(e)e.textContent='WAITING';
 }
 if(overall)overall.textContent='READY TO COMPILE';

 for(const k of ['A','B','C','D']){
   const e=document.getElementById('s4Status'+k);
   if(e)e.textContent='COMPILING';
   if(overall)overall.textContent='COMPILING NODE '+k+'...';

   const p=document.getElementById('s4Source'+k);
   const source=p?p.querySelector('textarea').value:({A:s4SourceA,B:s4SourceB,C:s4SourceC,D:s4SourceD})[k];

   let d;
   try{
     d=await api('/api/build-hex',{
       method:'POST',
       headers:{'Content-Type':'application/json'},
       body:JSON.stringify({code:source,sourceType:'c'})
     });
   }catch(err){
     if(e)e.textContent='BACKEND ERROR';
     if(overall)overall.textContent='BACKEND ERROR AT NODE '+k;
     s4Log('Node '+k+' backend error: '+(err&&err.message?err.message:err));
     return false;
   }

   if(!d||!d.ok||!d.hex){
     if(e)e.textContent='FAILED';
     if(overall)overall.textContent='COMPILE FAILED AT NODE '+k;
     s4Log('Node '+k+' compile failed: '+((d&&(d.output||d.error))||'unknown compiler error'));
     return false;
   }

   s4Node[k].hex=d.hex;
   if(e)e.textContent='READY';
   s4Log('Node '+k+' COMPILED OK');
 }

 if(overall)overall.textContent='ALL 4 NODES COMPILED';
 return true;
}
function s4StopNode(k){const n=s4Node[k];if(n.worker){try{n.worker.postMessage({type:'stop'})}catch(_){}try{n.worker.terminate()}catch(_){}}n.worker=null;n.running=false;}
function s4StopNodes(){
 for(const k of ['A','B','C','D'])s4StopNode(k);
 const st=document.getElementById('s4RunStatus');if(st)st.textContent='STOPPED';
 s4Log('All four nodes stopped.');
}
async function s4StartNode(k){
 const n=s4Node[k];if(!n.hex)return false;
 s4StopNode(k);const w=new Worker('phase82b_arm7_worker.js');n.worker=w;n.running=true;
 w.onmessage=e=>s4Handle(k,e.data||{});
 w.postMessage({type:'start',hex:n.hex,clock:{cclkHz:60000000,pclkHz:15000000}});
 w.postMessage({type:'can-external-config',enabled:true,nodeId:k});
 w.postMessage({type:'can-bus-config',connected:s4BusConnected,term1:true,term2:true,mcp1:true,mcp2:true});
 if(k==='A'){
   for(const pin of [28,29,30])w.postMessage({type:'gpio-input',port:1,pin,level:true});
   setTimeout(()=>{
     if(s4Node.A.worker)for(const pin of [28,29,30])s4Node.A.worker.postMessage({type:'gpio-input',port:1,pin,level:true});
   },25);
 }
 return true;
}

function s4StatusEl(k){
 const lab=document.getElementById('t19lab');
 return lab ? lab.querySelector('#t19s11Status'+k) : null;
}
async function s4CompileNodes(){
 const overall=document.getElementById('s4RunStatus');
 const keys=['A','B','C','D'];

 for(const k of keys){
   const e=s4StatusEl(k);
   if(e)e.textContent='WAITING';
 }

 /* T19S12: do not assume every node-state object already exists. */
 for(const k of keys){
   if(!s4Node[k])s4Node[k]={worker:null,running:false,hex:null,state:null,uart:[]};
   s4Node[k].hex=null;
 }

 if(overall)overall.textContent='NODE STATE OBJECT READY';

 const api=(typeof window.vectorFetchJson==='function')
   ? window.vectorFetchJson
   : async(path,opt)=>{
       const r=await fetch(path,opt);
       const t=await r.text();
       try{return JSON.parse(t)}catch(_){return {ok:false,output:t||('HTTP '+r.status)};}
     };

 for(const k of keys){
   const e=s4StatusEl(k);
   if(e)e.textContent='COMPILING';
   if(overall)overall.textContent='COMPILING NODE '+k;

   const p=document.getElementById('s4Source'+k);
   const source=p?p.querySelector('textarea').value:
     ({A:s4SourceA,B:s4SourceB,C:s4SourceC,D:s4SourceD})[k];

   let d;
   try{
     d=await api('/api/build-hex',{
       method:'POST',
       headers:{'Content-Type':'application/json'},
       body:JSON.stringify({code:source,sourceType:'c'})
     });
   }catch(err){
     if(e)e.textContent='BACKEND ERROR';
     if(overall)overall.textContent='BACKEND ERROR AT '+k;
     s4Log('Node '+k+' backend error: '+(err&&err.message?err.message:err));
     return false;
   }

   if(!d||!d.ok||!d.hex){
     if(e)e.textContent='FAILED';
     if(overall)overall.textContent='COMPILE FAILED AT '+k;
     s4Log('Node '+k+' compile failed: '+((d&&(d.output||d.error))||'unknown compiler error'));
     return false;
   }

   s4Node[k].hex=d.hex;
   if(e)e.textContent='READY';
 }
 if(overall)overall.textContent='ALL 4 NODES COMPILED';
 return true;
}
async function s4RunNodes(){
 const st=document.getElementById('s4RunStatus');

 if(['A','B','C','D'].some(k=>!s4Node[k].hex)){
   if(st)st.textContent='HEX MISSING — COMPILING FIRST...';
   if(!(await s4CompileNodes()))return;
 }

 if(st)st.textContent='STARTING A/B/C/D...';

 for(const k of ['A','B','C','D']){
   if(!(await s4StartNode(k))){
     if(st)st.textContent='START FAILED AT NODE '+k;
     return;
   }
 }

 if(st)st.textContent='RUNNING • A/B/C/D';
 s4Log('Four-node network running.');
}
function s4Handle(k,d){
 if(d.type==='snapshot'){s4Node[k].state=d.state||null;s4RenderNodes();s4RenderMonitor();return;}
 if(d.type==='gpio-edge'){
   if(!s4Node[k].state)s4Node[k].state={};
   s4Node[k].state.gpio=d.gpio||{};
   s4RenderNodes();
   return;
 }
 if(d.type==='uart-tx'){if(Number(d.port)===0)s4AppendUart(k,d.bytes||[]);return;}
 if(d.type==='can-external-tx'){s4Pending.push({k,d});if(!s4ArbTimer)s4ArbTimer=setTimeout(s4ResolveBus,3);return;}
 if(d.type==='error')s4Log('Node '+k+' error: '+(d.text||'unknown'));
}
function s4Bits(x){const f=x.d.frame||{},id=Number(f.id||0);return id&0x7ff;}
function s4ResolveBus(){
 s4ArbTimer=null;if(!s4Pending.length)return;
 const batch=s4Pending.splice(0),sorted=batch.slice().sort((a,b)=>s4Bits(a)-s4Bits(b));
 const win=sorted[0];
 for(const x of sorted.slice(1)){if(s4Node[x.k].worker)s4Node[x.k].worker.postMessage({type:'can-external-arbitration-lost',controller:Number(x.d.controller||1),buf:Number((x.d.frame&&x.d.frame.buf)||1),bit:0});}
 s4Deliver(win);
}
function s4TargetForId(id){return id===0x101?'B':id===0x102?'C':id===0x103?'D':'-';}
function s4Deliver(x){
 const f=x.d.frame||{},id=Number(f.id||0),data=Array.isArray(f.data)?f.data:[],dlc=Number(f.dlc||0);
 const expected=s4TargetForId(id);

 const sourceOK=s4NodePath(x.k);
 const receivers=['A','B','C','D'].filter(k=>
   k!==x.k &&
   s4Node[k] &&
   s4Node[k].worker &&
   s4Node[k].running &&
   s4NodePath(k)
 );

 const busOK=s4BusConnected&&sourceOK;
 const delivered=busOK?receivers:[];
 const ack=delivered.length>0;

 if(busOK){
   for(const k of delivered){
     s4Node[k].worker.postMessage({type:'can-external-rx',controller:1,frame:f});
   }
 }

 if(s4Node[x.k].worker){
   s4Node[x.k].worker.postMessage({
     type:'can-external-result',
     controller:Number(x.d.controller||1),
     buf:Number(f.buf||1),
     ack
   });
 }

 s4Frames.push({
   time:new Date().toLocaleTimeString(),
   from:x.k,
   to:expected,
   listeners:delivered.join(','),
   id,dlc,
   data:data.slice(0,dlc),
   ack
 });
 if(s4Frames.length>180)s4Frames.shift();

 s4Log(`Node ${x.k} broadcast ID 0x${id.toString(16).toUpperCase()} -> listeners [${delivered.join(',')||'-'}], target ${expected}, DATA ${data.slice(0,dlc).map(v=>Number(v).toString(16).padStart(2,'0').toUpperCase()).join(' ')} ACK ${ack?'YES':'NO'}`);
}
function s4RenderNodes(){
 for(const k of ['B','C','D']){
  const led=document.getElementById('S4LED'+k),g=(s4Node[k].state||{}).gpio||{};
  if(led){const out=((Number(g.IO1DIR||0)>>>31)&1)!==0,level=((Number(g.IO1PIN||0)>>>31)&1)!==0;led.classList.toggle('on',out&&!level);}
 }
}
function s4ToggleBus(){s4BusConnected=!s4BusConnected;const b=document.getElementById('s4BtnBus');if(b)b.textContent=s4BusConnected?'Disconnect CAN Bus':'Reconnect CAN Bus';const bus=document.getElementById('s4Bus');if(bus)bus.classList.toggle('disconnected',!s4BusConnected);for(const k of ['A','B','C','D'])if(s4Node[k].worker)s4Node[k].worker.postMessage({type:'can-bus-config',connected:s4BusConnected,term1:true,term2:true,mcp1:true,mcp2:true});s4Log(s4BusConnected?'CAN bus reconnected.':'CAN bus disconnected.');s4RenderPhysical();}
function s4OpenPhysical(){let p=document.getElementById('s4Physical');if(!p){p=document.createElement('div');p.id='s4Physical';p.className='kPhysical';p.innerHTML='<div class="kPhysHead"><b>Four-Node Physical Layer</b><button>×</button></div><pre></pre>';document.body.appendChild(p);p.querySelector('button').onclick=()=>p.style.display='none';drag(p,p.querySelector('.kPhysHead'));}p.style.display='block';s4RenderPhysical();}
function s4RenderPhysical(){const p=document.getElementById('s4Physical');if(!p)return;const rows=['A','B','C','D'].map(k=>`${k}: ${s4NodePath(k)?'CONNECTED':'OPEN'}`);p.querySelector('pre').textContent=`RUNTIME BUS: ${s4BusConnected?'CONNECTED':'DISCONNECTED'}\n\n${rows.join('\n')}`;}
function s4OpenMonitor(){let p=document.getElementById('s4Monitor');if(!p){p=document.createElement('div');p.id='s4Monitor';p.className='qCanMonitor';p.innerHTML=`<div class="qMonHead"><b>Four-Node CAN Bus Monitor</b><button data-close>×</button></div><div class="qStates"><div data-a></div><div data-b></div><div data-c></div><div data-d></div></div><div class="qTables s4Tables"><div><h4>CAN Frames</h4><div class="qScroll"><table><thead><tr><th>Time</th><th>From</th><th>To</th><th>ID</th><th>DLC</th><th>Data</th><th>ACK</th></tr></thead><tbody data-frames></tbody></table></div></div></div>`;document.body.appendChild(p);p.querySelector('[data-close]').onclick=()=>p.style.display='none';drag(p,p.querySelector('.qMonHead'));}p.style.display='block';s4RenderMonitor();}
function s4Card(k){const c=(s4Node[k].state||{}).can1||{};const tec=Number(c.txErr||0),rec=Number(c.rxErr||0),state=c.busOff?'BUS OFF':(tec>=128||rec>=128?'ERROR PASSIVE':'ERROR ACTIVE');return `<div class="qCard ${state.replace(/\s+/g,'-').toLowerCase()}"><b>NODE ${k}</b><strong>${state}</strong><span>TEC <em>${tec}</em></span><span>REC <em>${rec}</em></span></div>`;}
function s4RenderMonitor(){const p=document.getElementById('s4Monitor');if(!p||p.style.display==='none')return;for(const k of ['A','B','C','D'])p.querySelector('[data-'+k.toLowerCase()+']').innerHTML=s4Card(k);p.querySelector('[data-frames]').innerHTML=s4Frames.slice().reverse().map(f=>`<tr><td>${f.time}</td><td>${f.from}</td><td>${f.to}</td><td>${f.listeners||'-'}</td><td>0x${f.id.toString(16).toUpperCase()}</td><td>${f.dlc}</td><td>${f.data.map(v=>Number(v).toString(16).padStart(2,'0').toUpperCase()).join(' ')}</td><td>${f.ack?'YES':'NO'}</td></tr>`).join('');}

function s4Open(){
 let p=document.getElementById('t19lab');
 if(!p){
   p=document.createElement('div');
   p.id='t19lab';
   p.className='t19lab';
   document.body.appendChild(p);
 }
 buildFourNodeUI(p);
 p.style.display='block';
 requestAnimationFrame(()=>{s4Install();s4Draw();});
}


function drag(p,h){
 let on=false,ox=0,oy=0;
 h.addEventListener('pointerdown',e=>{
   if(e.target.closest('button,select,input,textarea'))return;
   on=true;
   ox=e.clientX-p.offsetLeft;
   oy=e.clientY-p.offsetTop;
   try{h.setPointerCapture(e.pointerId)}catch(_){}
   e.preventDefault();
 });
 h.addEventListener('pointermove',e=>{
   if(!on)return;
   p.style.left=Math.max(0,e.clientX-ox)+'px';
   p.style.top=Math.max(45,e.clientY-oy)+'px';
 });
 h.addEventListener('pointerup',()=>on=false);
 h.addEventListener('pointercancel',()=>on=false);
}

window.phase84t19aOpenMultiNodeCANLab=function(){
 try{open();}
 catch(e){
   console.error('T19S3 Multi-Node CANLab launch failed',e);
   alert('Multi-Node CANLab launch error: '+(e&&e.message?e.message:e));
 }
};
window.phase84t19sOpenFourNodeCANLab=s4Open;
})();
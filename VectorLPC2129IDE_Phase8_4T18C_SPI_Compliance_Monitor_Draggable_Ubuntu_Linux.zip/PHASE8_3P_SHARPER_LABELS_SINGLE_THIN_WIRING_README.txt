VECTOR LPC2129 IDE — Phase 8.3P
Sharper Labels + Single Thin Wiring

Changes from Phase 8.3O:
1. UART/AUX LED bank title, TX0/RX0/TX1/RX1 labels and selector text are sharper,
   higher contrast and slightly larger.
2. ONBOARD SWITCH / LED trainer text is sharper and easier to read while the
   block remains centred below the LPC2129 package.
3. Board-to-Berg electrical connections are now rendered only once. The common
   canvas SVG copy is suppressed for UART/AUX and SW/LED onboard connections;
   the editable orthogonal board-route layer remains the sole visible route.
4. Visible board wiring is thinner (2.2 px conductor) with a narrow highlight.
5. Ordinary/off-board wire strokes are also reduced to 2.2 px.
6. Electrical connectivity remains project.wires; no source/parser shortcut and
   no duplicate electrical model was introduced.
7. Approved LPC2129 board PNG is unchanged.

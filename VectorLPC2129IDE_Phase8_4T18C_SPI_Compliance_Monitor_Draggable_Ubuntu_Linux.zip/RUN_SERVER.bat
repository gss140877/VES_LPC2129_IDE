@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title LPC2129 Simulator Server

echo ===============================================
echo   LPC2129 Simulator - Phase 5 Debug Perspective
echo ===============================================
echo.

echo Checking / installing ARM GNU toolchain...
call "%~dp0CHECK_INSTALL_ARM_TOOLCHAIN.bat"
if errorlevel 1 (
  echo.
  echo ERROR: ARM toolchain setup failed.
  echo HEX generation requires arm-none-eabi-gcc and arm-none-eabi-objcopy.
  pause
  exit /b 1
)

echo.
echo Checking Node.js...
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed or not in PATH.
  echo Install Node.js LTS, then run this file again.
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm is not installed or not in PATH.
  echo Reinstall Node.js LTS with npm option enabled.
  pause
  exit /b 1
)

if not exist "%~dp0node_modules" (
  echo Installing required Node packages...
  call npm install
  if errorlevel 1 (
    echo.
    echo ERROR: npm install failed.
    pause
    exit /b 1
  )
) else (
  echo Node packages already installed.
)

echo.
echo Opening frontend at http://localhost:3000
start "" "http://localhost:3000"
echo.
echo Starting server... Keep this window open while using simulator.
echo Press Ctrl+C to stop.
echo.
npm start

echo.
echo Server stopped.
pause

Vector LPC2129 Simulator – Phase 5.7 Professional QFP64 Component

Changes:
- Replaced the PCB bitmap component with a vector/CSS LPC2129FBD64 LQFP64 package.
- Displays all 64 physical package pins based on the NXP LPC2109/2119/2129 datasheet.
- GPIO pins retain the existing simulator data-node names and remain wireable.
- Pin numbers are circular, aligned to package leads, and scale together during canvas/component zoom.
- Power, ground, clock, reset, and special pins use distinct marker colors.
- Hover tooltips show physical pin number, signal name, and principal alternate functions.
- Existing C/Assembly build, HEX execution, debugger, single-step, and source arrow features are retained.

Run RUN_SERVER.bat and test zoom, wiring, GPIO monitor, Run and Single Step.

/* VECTOR LPC2129 IDE — Phase 8.3Q
   Defensive cleanup of stale pre-image-board / UNO/QFP visual artifacts.
   Does NOT touch canonical p74f GPIO hit boxes, UART/SW/LED Berg nodes,
   component pins, project.wires, or the approved LPC2129 PNG. */
(function(){'use strict';
if(window.__phase83qLegacyCleanupInstalled)return; window.__phase83qLegacyCleanupInstalled=true;
const legacySelectors=[
  '.qfp-lead','.qfp-label','.qfp-pin1-mark','.qfp-body','.qfp-chip','.qfp64-shell',
  '.p73-pcb','.p73-hole2','.p73-hole3','.p73-title','.p73-header','.p73-cpu',
  '.p73-smallmod','.p73-power','.p73-silk','.uno-img'
];
function clean(){
 const b=document.getElementById('uno'); if(!b||!b.classList.contains('p74f-image-board'))return;
 legacySelectors.forEach(sel=>b.querySelectorAll(sel).forEach(el=>el.remove()));
 // The image-backed board owns exactly one stage. Any direct legacy visual
 // child left beside that stage is stale bootstrap artwork and is removed.
 [...b.children].forEach(el=>{if(!el.classList.contains('p74f-board-stage'))el.remove()});
}
function install(){clean();const b=document.getElementById('uno');if(!b)return false;
 const mo=new MutationObserver(()=>clean());mo.observe(b,{childList:true,subtree:true});
 // Re-clean after old delayed phase installers have had a chance to run.
 [50,250,900,1400,2200].forEach(ms=>setTimeout(clean,ms));return true;
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
window.addEventListener('load',install,{once:true});
})();

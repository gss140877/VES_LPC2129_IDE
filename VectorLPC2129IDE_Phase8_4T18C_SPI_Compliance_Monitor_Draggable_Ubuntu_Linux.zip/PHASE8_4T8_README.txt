Phase 8.4T8
Communication menu overlay fix:
- Root cause: final .topbar.appToolbar CSS uses overflow-y:hidden, clipping child dropdowns.
- Communication popup now uses position:fixed and is positioned under its toolbar button at runtime.
- z-index 60000 places it above canvas, bottom dock, and normal floating panels.
- Horizontal toolbar scrolling behavior is unchanged.

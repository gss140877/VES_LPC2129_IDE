(function(){'use strict';
function install(){
 const btn=document.getElementById('communicationBtn');
 const menu=document.querySelector('#communicationToolbarGroup .commMenu');
 if(!btn||!menu||btn.dataset.overlayReady)return;
 btn.dataset.overlayReady='1';
 function position(){
   const r=btn.getBoundingClientRect();
   let left=r.left, top=r.bottom+2;
   const mw=Math.max(menu.offsetWidth||178,178);
   if(left+mw>window.innerWidth-8) left=Math.max(8,window.innerWidth-mw-8);
   menu.style.left=Math.round(left)+'px';
   menu.style.top=Math.round(top)+'px';
 }
 function open(){position();menu.classList.add('commOpen');}
 function close(){menu.classList.remove('commOpen');}
 btn.addEventListener('mouseenter',open);
 btn.addEventListener('focus',open);
 btn.addEventListener('click',function(e){e.preventDefault();e.stopPropagation(); if(menu.classList.contains('commOpen'))close();else open();});
 menu.addEventListener('mouseenter',open);
 const group=document.getElementById('communicationToolbarGroup');
 group.addEventListener('mouseleave',()=>setTimeout(()=>{if(!menu.matches(':hover'))close()},120));
 document.addEventListener('click',e=>{if(!group.contains(e.target)&&!menu.contains(e.target))close()});
 window.addEventListener('resize',()=>{if(menu.classList.contains('commOpen'))position()});
 window.addEventListener('scroll',()=>{if(menu.classList.contains('commOpen'))position()},true);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install);else install();
window.addEventListener('load',install);
})();
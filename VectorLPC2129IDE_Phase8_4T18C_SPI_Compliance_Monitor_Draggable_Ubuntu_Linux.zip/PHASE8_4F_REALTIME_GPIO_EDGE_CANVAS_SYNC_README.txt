VECTOR LPC2129 IDE — Phase 8.4F
Real-time GPIO edge / canvas synchronization

Purpose
-------
Fix visible latency between Timer0/Timer1 IRQ-driven GPIO toggles and the Circuit Canvas/on-board LED.

Architecture
------------
* ARM7 worker remains the source of truth.
* Timer0/1 continue to advance from simulated CPU/PCLK cycles.
* Whenever firmware changes a canonical GPIO physical output, the worker now emits a compact gpio-edge event immediately.
* The main thread applies that edge directly to window.lpcGpio and refreshes canvas loads/on-board I/O.
* The ~33 ms full snapshot path remains only for debugger/SFR/GPR/profiler state.
* No source parsing or example-specific LED shortcut is used.

Timing meaning
--------------
For the Phase 8.4D/E direct ADC example, ADC decimal 100..1000 is the TOGGLE interval in milliseconds.
Example: ADC=500 changes LED state every ~500 ms; a complete ON->OFF->ON cycle is ~1000 ms.

The timer simulation quantum remains 250 us, so timer quantization is <=0.25 ms plus instruction execution, while visible GPIO updates no longer wait for a 33 ms debug snapshot.

/* VECTOR LPC2129 IDE Phase 7.2A - Floating Circuit Canvas + Component Selection */
(function(){'use strict';
if(window.__phase72CanvasInstalled)return;window.__phase72CanvasInstalled=true;
const $=id=>document.getElementById(id);let zoom=1.0;
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function applyZoom(next){zoom=clamp(next,0.40,2.00);const scene=$('scene');if(scene){scene.style.transform='scale('+zoom+')';scene.dataset.p72Zoom=String(zoom)}const t=$('p72ZoomText');if(t)t.textContent=Math.round(zoom*100)+'%';try{if(typeof redrawWires==='function')setTimeout(redrawWires,0)}catch(e){}}
window.phase72CanvasZoomIn=()=>applyZoom(zoom+0.10);
window.phase72CanvasZoomOut=()=>applyZoom(zoom-0.10);
window.phase72CanvasZoomReset=()=>applyZoom(1.0);
window.phase72ShowCanvas=function(){const p=$('p72CanvasWindow');if(p){p.style.display='block';if(typeof p72Bring==='function')p72Bring(p);else p.style.zIndex='65000';}}
function addViewItem(){document.querySelectorAll('.ide-menu').forEach(m=>{if(!(m.firstChild&&m.firstChild.nodeValue&&m.firstChild.nodeValue.trim()==='View'))return;const pop=m.querySelector('.ide-menu-pop');if(!pop||pop.querySelector('[data-p72-canvas]'))return;const b=document.createElement('button');b.textContent='Circuit Canvas + Components';b.dataset.p72Canvas='1';b.onclick=e=>{e.stopPropagation();phase72ShowCanvas()};pop.insertBefore(b,pop.firstChild);});}
function install(){const ws=document.querySelector('.workspace'), bar=ws&&ws.querySelector('.canvasbar'), canvas=$('canvas');if(!ws||!bar||!canvas)return;
 const p=document.createElement('div');p.id='p72CanvasWindow';p.className='p71-window';Object.assign(p.style,{left:'300px',top:'92px',width:'calc(100vw - 330px)',height:'calc(100vh - 120px)',zIndex:'5400'});
 p.innerHTML='<div class="p71-head"><span class="p72-canvas-title">LPC2129 Circuit Canvas + Component Selection</span><div class="p72-zoombar"><button type="button" title="Zoom out" onclick="phase72CanvasZoomOut()">−</button><span id="p72ZoomText" class="p72-zoomtext">100%</span><button type="button" title="Zoom in" onclick="phase72CanvasZoomIn()">+</button><button type="button" title="Reset zoom" onclick="phase72CanvasZoomReset()">1:1</button></div><button class="p71-close" title="Close">×</button></div><div class="p71-body"><div id="p72CanvasHost"></div></div>';
 document.body.appendChild(p);const host=$('p72CanvasHost');host.appendChild(bar);host.appendChild(canvas);ws.classList.add('p72-canvas-detached');
 p.querySelector('.p71-close').onclick=()=>p.style.display='none';
 if(typeof behavior==='function')behavior(p);else{ // independent fallback drag/resize
   const head=p.querySelector('.p71-head');let z=5500;const bring=q=>q.style.zIndex=String(++z);window.p72Bring=bring;
   head.addEventListener('mousedown',e=>{if(e.button!==0||e.target.closest('button'))return;bring(p);const r=p.getBoundingClientRect(),sx=e.clientX,sy=e.clientY;function mv(ev){p.style.left=Math.max(4,r.left+ev.clientX-sx)+'px';p.style.top=Math.max(62,r.top+ev.clientY-sy)+'px'}function up(){removeEventListener('mousemove',mv,true);removeEventListener('mouseup',up,true)}addEventListener('mousemove',mv,true);addEventListener('mouseup',up,true)});
   const rh=document.createElement('div');rh.className='phase71ResizeHandle';p.appendChild(rh);rh.addEventListener('mousedown',e=>{const r=p.getBoundingClientRect(),sx=e.clientX,sy=e.clientY;function mv(ev){p.style.width=Math.max(520,r.width+ev.clientX-sx)+'px';p.style.height=Math.max(360,r.height+ev.clientY-sy)+'px'}function up(){removeEventListener('mousemove',mv,true);removeEventListener('mouseup',up,true)}addEventListener('mousemove',mv,true);addEventListener('mouseup',up,true);e.preventDefault();e.stopPropagation()});p.addEventListener('mousedown',()=>bring(p),true);
 }
 // phase71's behavior is private; emulate bring-to-front safely even when it handled dragging.
 let localZ=60000;p.addEventListener('mousedown',()=>p.style.zIndex=String(++localZ),true);
 applyZoom(1.0);addViewItem();
 try{if(typeof log==='function')log('Phase 7.2A loaded: floating/resizable/zoomable Circuit Canvas + Component Selection window active.')}catch(e){}
}
window.addEventListener('load',()=>setTimeout(install,650));
})();

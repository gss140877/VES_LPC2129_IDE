VECTOR LPC2129 IDE — Phase 8.4T4
24LC512 SMD Breakout + Communication Menu

Protected baseline: Phase 8.4S.

Changes in this I2C-only stage:
- One LPC2129 on-chip I2C peripheral only.
- Correct LPC2129 pins: P0.2=SCL, P0.3=SDA.
- EEPROM upgraded to 24LC512 (64 KByte / 512 Kbit), 7-bit address 0x50.
- Canvas uses the existing LPC2129 board; no fake/overlay LPC2129 block is drawn.
- Professional green breakout PCB with SOIC-8 24LC512, 1x4 Berg header, 4.7 kOhm SCL/SDA pull-ups, 100 nF decoupling, and A0/A1/A2 straps.
- Routed wires originate from the real board header nodes: P0.2, P0.3, 3.3V and GND.
- I2C debug windows do not auto-open on example selection.
- New IDE Communication dropdown:
    Communication > UART > UART0 Terminal / UART1 Terminal
    Communication > I2C > LPC2129 I2C SFR / Protocol Analyzer / 24LC512 Memory
- Existing UART terminal engine remains unchanged; only its duplicate toolbar buttons are hidden when the unified Communication menu installs.

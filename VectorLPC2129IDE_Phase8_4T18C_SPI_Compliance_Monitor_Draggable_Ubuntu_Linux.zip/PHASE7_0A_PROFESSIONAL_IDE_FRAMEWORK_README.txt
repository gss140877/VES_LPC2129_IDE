VECTOR LPC2129 IDE - PHASE 7.0A
Professional IDE Framework for LPC2129 only

Foundation: Phase 6.1A Professional CPU Component (preserved)

NEW IN 7.0A
- LPC2129-only desktop IDE identity and menu system
- Project Explorer with Target 1 / Source Group 1
- Source/startup/linker project navigation
- Build Target, Rebuild All and Clean Target commands
- F7 Build, F5 Run, F11 Single Step shortcuts
- Dedicated debug toolbar: Run, Stop, Reset, Step Into, Run to Cursor
- Disassembly window using ELF/DWARF/objdump mixed listing
- Memory window for emulator memory inspection
- Watch 1 window for ARM registers and LPC2129 GPIO SFR expressions
- Target Options window for LPC2129 memory/core/clock/toolchain configuration
- Existing CPU Registers, Peripheral Registers, Trace, Coverage and Clock panels retained
- Existing Professional QFP64 CPU component and circuit canvas retained
- Ubuntu/Linux launcher and lpc21isp support retained
- IDE status bar with target/core and source line/column

IMPORTANT
This is a Keil-like LPC2129 development environment, not a copy of proprietary Keil software.
The compiler remains GNU Arm Embedded (arm-none-eabi-gcc) and debug execution uses the VECTOR LPC2129 ARM7TDMI-S simulator.

RUN ON UBUNTU
1. chmod +x *.sh
2. ./INSTALL_UBUNTU_DEPENDENCIES.sh
3. ./START_APP_WINDOW_NO_URL_BAR.sh

Or: ./START_LPC2129_SIMULATOR.sh

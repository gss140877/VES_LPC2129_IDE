VECTOR LPC2129 IDE — Phase 8.3N

Changes from confirmed-working Phase 8.3M baseline:

1. Legacy JTAG artwork is visually removed from the trainer board area by a PCB-colored board-stage mask. The original approved PNG asset is not regenerated or replaced.
2. UART/AUX LED bank is repositioned wholly inside the former JTAG region with clean separation.
3. Reusable onboard SW/LED trainer is centered directly below the LPC2129 IC lower edge and above the lower GPIO label band.
4. Onboard jumper deletion fixed: double-click a wire segment or bend to delete the actual project.wires connection.
5. Drag/bend routing, Berg endpoints, UART/AUX selectors, reusable SW/LED Berg nodes, worker runtime, GPIO/UART/VIC paths and canonical physical-pin rule are retained.

Runtime visual/interaction confirmation is still required on the target Ubuntu/Electron environment.

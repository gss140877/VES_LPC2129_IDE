VECTOR LPC2129 IDE / Simulator - Phase 8.4I
Glassy / Transparent External LED + Color Selection

Baseline:
- Built from user-confirmed Phase 8.4H canonical CPU/peripheral timing build.
- Timer/ADC/VIC/ARM7TDMI-S timing engine is intentionally unchanged.
- Approved LPC2129 board image is unchanged.

External LED visual changes:
- Transparent/glassy LED lens with highlights, internal emitter core and metallic leads.
- Selected external LED displays a compact COLOR selector.
- Available colors: Red, Green, Yellow, Amber, Blue and White.
- OFF state remains visibly transparent/tinted.
- ON state uses the selected emission color and an immediate full-brightness glow.
- Core LED visual transition is disabled so 100 ms GPIO activity is not visually averaged by CSS fading.

Usage:
1. Add an LED from Components or use the existing external LED.
2. Click the LED to select it.
3. Use the COLOR selector shown below the selected LED.
4. Wire A/K normally; color selection is visual only and does not bypass the canonical electrical/GPIO path.

Canonical rule retained:
HEX -> ARM7TDMI-S CPU -> LPC2129 peripheral/GPIO engine -> physical GPIO -> project wiring -> external LED.

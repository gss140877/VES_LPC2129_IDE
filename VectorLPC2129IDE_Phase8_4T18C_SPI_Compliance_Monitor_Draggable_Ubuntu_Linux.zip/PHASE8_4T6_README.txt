Phase 8.4T6
- Protected 8.4S-derived I2C/24LC512 branch.
- VCC and GND are two vertically stacked Berg/header sockets on the LEFT edge.
- SCL and SDA remain on the RIGHT edge.
- 24LC512 is redrawn as a professional SOIC-8 SMD package with 8 gull-wing leads, pin-1 dot/notch and package markings.
- A0/A1/A2 remain configurable; component remains addable/draggable/zoomable/deletable.
- Communication is now a guaranteed visible toolbar dropdown, independent of the older menu constructor:
  Communication > UART > UART0 Terminal / UART1 Terminal
  Communication > I2C > LPC2129 I2C SFR / Protocol Analyzer / 24LC512 Memory

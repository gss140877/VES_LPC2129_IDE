Phase 5.1 - ARM7TDMI-S CPU Core Self Tests
==========================================

What is added:
1. CPU Self Test dropdown in the top toolbar.
2. Load Test button.
3. Four assembly test programs:
   - ARM Data Processing
   - ARM Barrel Shifter
   - ARM Branch / Flags
   - THUMB Basic
4. Test source files are also included inside examples/.

How to test:
1. Run RUN_SERVER.bat.
2. Open simulator.
3. Select one item from CPU Self Test.
4. Click Load Test.
5. Click Build HEX.
6. Click Run Simulation.
7. Open Debug View if hidden.

Expected PASS patterns:
- ARM Data Processing: IO0SET = 0x000000AA, IO1SET = 0x00000055
- ARM Barrel Shifter: IO0SET = 0x00000F0F
- ARM Branch / Flags: IO0SET = 0x0000F000
- THUMB Basic: IO0SET = 0x00000033 and profiler THUMB instruction count > 0

Purpose:
These tests help verify ARM7TDMI-S instruction family behavior before moving to
Timer, UART, LCD, and full peripheral simulation.

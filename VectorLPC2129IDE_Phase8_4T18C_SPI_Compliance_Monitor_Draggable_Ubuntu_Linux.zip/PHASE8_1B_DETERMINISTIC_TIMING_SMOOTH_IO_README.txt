VECTOR LPC2129 IDE — Phase 8.1B

Deterministic Timing + Smooth I/O Synchronization

Core changes:
1. ARM7 execution now advances in fixed 250 us simulation quanta.
2. Host/browser frame timing determines only how many simulation quanta are processed.
3. Simulated time is derived from ARM7 accumulated cycles / configured CCLK.
4. GPIO transitions are timestamped in emulated cycle time.
5. External input changes are latched and applied at deterministic boundaries/CPU reads.
6. Removed the periodic 100 ms switch polling loop from Phase 8.1A.
7. Canvas refresh targets 60 FPS and updates only changed visual state.
8. LED DOM is not rebuilt during GPIO changes.
9. LED/button transitions use short CSS visual interpolation only; electrical GPIO state remains immediate.
10. Existing example/project workspace behavior is preserved.

Execution rule remains:
.c/.s source -> ARM GCC/GAS -> ELF/HEX -> ARM7TDMI-S instruction execution
-> LPC2129 GPIO SFRs -> physical GPIO state -> Circuit Canvas.

Timing status:
This build is deterministic relative to the engine's current ARM7 instruction-cycle estimator.
It is not yet certified as cycle-perfect ARM7TDMI-S timing for every instruction/peripheral.

VECTOR LPC2129 IDE — Phase 7.4B Compact UNO-Style Board Refinement

Changes from Phase 7.4A:
- Reduced the LPC2129 UNO-style board footprint.
- Top and lower header rows now use the same socket/hit-box geometry.
- Lower-row hit boxes directly overlap their visible header sockets and highlight on hover like the top row.
- Adjacent hit boxes remain separated to avoid accidental neighboring-pin selection.
- Added clear physical LPC2129 pin-number badges next to each signal label.
- Improved GPIO/JTAG signal-label readability.
- Moved "VECTOR LPC2129 UNO" to a horizontal PCB silkscreen position above RESET/JTAG.
- Preserved all 46 existing connectable data-node identities and the existing wiring engine.

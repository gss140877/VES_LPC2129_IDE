VECTOR LPC2129 IDE — Phase 8.3L
CLEAN ONBOARD I/O LAYOUT

Based directly on Phase 8.3K working functionality.

Screenshot-driven artwork cleanup only:
1. UART/AUX LED bank moved left/up and made shorter so its border is clearly separated from the external POWER block and the P1.30/P1.31 trainer.
2. Four channels remain TX0/RX0/TX1/RX1 with the same OFF/UART/AUX behavior.
3. AUX targets are now only small Berg-strip sockets. No A0-A3 labels, no visible AUX pads, and no oversized generic yellow/green pin rectangles.
4. Hover/source/target indication is confined to a thin glow around the Berg socket itself.
5. P1.30/P1.31 trainer moved upward to restore clear space above the printed P1.27-P1.31 label/number band.
6. Phase 8.3J draggable orthogonal onboard wiring remains unchanged and still terminates above the physical header/socket artwork.
7. Electrical connectivity remains project.wires; visual route editing does not alter the canonical net.
8. Approved vector_lpc2129_board.png is unchanged.

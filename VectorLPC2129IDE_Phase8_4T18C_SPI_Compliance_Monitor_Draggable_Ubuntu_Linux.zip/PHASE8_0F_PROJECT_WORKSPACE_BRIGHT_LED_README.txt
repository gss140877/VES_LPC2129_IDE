VECTOR LPC2129 IDE — Phase 8.0F

Requested workflow correction:
1. Selecting a C/ASM example NO LONGER opens a new source window automatically.
2. The selected .c/.s is added under PROJECT -> Source Group 1.
3. The selected example becomes the active build source.
4. Its relevant Circuit Canvas is configured and brought to front automatically.
5. Click the .c/.s item in PROJECT when you want to open the editable/saveable source window.
6. Build HEX uses the active project source. Edited source invalidates stale HEX.
7. LED ON visualization has been substantially strengthened with a bright core and multi-stage glow/halo.

Simulation rule remains:
source -> ARM GCC/GAS -> ELF/HEX -> ARM7TDMI-S -> LPC2129 GPIO -> Circuit Canvas.

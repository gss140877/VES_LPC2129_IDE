/* Phase 8.4T5 — 24LC512 as a first-class Circuit Canvas component.
   Uses the existing project.parts / project.wires engine so drag, wheel zoom,
   double-click delete, save/load and manual rewiring remain canonical. */
(function(){'use strict';
if(window.__phase84t5I2CComponentInstalled)return;window.__phase84t5I2CComponentInstalled=true;
const TYPE='eeprom24lc512';
function prj(){try{return project}catch(e){return window.project}}
function part(){const p=prj();return p&&Array.isArray(p.parts)?p.parts.find(x=>x&&x.type===TYPE):null}
function addr(p){return 0x50|((p.a0?1:0)<<0)|((p.a1?1:0)<<1)|((p.a2?1:0)<<2)}
function sync(){const p=part();try{window.phase84tConfigureEeprom&&window.phase84tConfigureEeprom({present:!!p,a0:p&&p.a0?1:0,a1:p&&p.a1?1:0,a2:p&&p.a2?1:0})}catch(e){}}
function uniqueId(){const p=prj();let n=1,id='eeprom'+n;while(p.parts.some(x=>x.id===id)){n++;id='eeprom'+n}return id}
function wireExists(a,b){const p=prj();return p.wires.some(w=>(w.from===a&&w.to===b)||(w.from===b&&w.to===a))}
function addDefaultWires(ep){const pairs=[['uno.3V3',ep.id+'.VCC'],['uno.GND',ep.id+'.GND'],['uno.P0_2',ep.id+'.SCL'],['uno.P0_3',ep.id+'.SDA']];pairs.forEach(([a,b])=>{try{if(!wireExists(a,b)&&typeof addWire==='function')addWire(a,b)}catch(e){}})}
function addEeprom(opt={}){const p=prj();if(!p||!Array.isArray(p.parts))return null;let ep=part();if(ep){try{selectedId=ep.id;render()}catch(e){};sync();return ep}ep={id:uniqueId(),type:TYPE,x:opt.x??830,y:opt.y??145,scale:opt.scale??1,state:0,a0:0,a1:0,a2:0};p.parts.push(ep);try{selectedId=ep.id;render();addDefaultWires(ep);render()}catch(e){}sync();return ep}
window.phase84t5Add24LC512FromPalette=function(){addEeprom({x:820,y:150});const pal=document.getElementById('componentPalette');if(pal)pal.style.display='none';try{log('24LC512 EEPROM breakout added. Drag, wheel-zoom, configure A0/A1/A2, or double-click to delete.')}catch(e){}};
function boardHTML(p){const a=addr(p);return `<div class="e512pcb">
 <div class="e512silk"><b>VECTOR INDIA</b><span>24LC512 I²C EEPROM</span></div>
 <div class="e512power">
   <div class="e512sideLabel">POWER</div>
   <span class="pin e512sidepin" data-node="${p.id}.VCC" data-tip="VCC — 3.3 V"><i></i><b>VCC</b></span>
   <span class="pin e512sidepin" data-node="${p.id}.GND" data-tip="GND"><i></i><b>GND</b></span>
 </div>
 <div class="e512ref">U1</div>
 <div class="e512chipPro">
   <div class="e512pins left">${[1,2,3,4].map(n=>`<i></i>`).join('')}</div>
   <div class="e512body"><i class="dot"></i><i class="notch"></i><b>24LC512</b><span>Microchip</span><em>SOIC-8</em></div>
   <div class="e512pins right">${[8,7,6,5].map(n=>`<i></i>`).join('')}</div>
 </div>
 <div class="e512pull r1"><i></i><b>R1</b><span>4K7</span></div><div class="e512pull r2"><i></i><b>R2</b><span>4K7</span></div>
 <div class="e512cap"><i></i><b>C1</b><span>100n</span></div>
 <div class="e512addrtitle">ADDRESS <b>0x${a.toString(16).toUpperCase().padStart(2,'0')}</b></div>
 <div class="e512cfg">${[0,1,2].map(n=>`<button type="button" data-bit="${n}" class="${p['a'+n]?'hi':'lo'}"><span>A${n}</span><i>${p['a'+n]?'1':'0'}</i></button>`).join('')}</div>
 <div class="e512berglabel">I²C HEADER</div><div class="e512berg">
  <span class="pin e512pin" data-node="${p.id}.SCL" data-tip="SCL — onboard 4.7 kΩ pull-up"><i></i><b>SCL</b></span>
  <span class="pin e512pin" data-node="${p.id}.SDA" data-tip="SDA — onboard 4.7 kΩ pull-up"><i></i><b>SDA</b></span>
 </div>
 <div class="e512legend">3V3 • 4K7 SDA/SCL PULL-UPS • A0/A1/A2 CONFIGURABLE</div>
 </div>`}
function decorate(){const p=prj();if(!p||!Array.isArray(p.parts))return;p.parts.filter(x=>x&&x.type===TYPE).forEach(ep=>{const el=document.getElementById(ep.id);if(!el)return;el.classList.add('e512part');el.innerHTML=boardHTML(ep);el.querySelectorAll('.e512cfg button').forEach(b=>{b.onmousedown=e=>e.stopPropagation();b.ondblclick=e=>e.stopPropagation();b.onclick=e=>{e.preventDefault();e.stopPropagation();const bit=Number(b.dataset.bit);ep['a'+bit]=ep['a'+bit]?0:1;try{selectedId=ep.id;render()}catch(_){}sync();try{log('24LC512 address changed to 0x'+addr(ep).toString(16).toUpperCase())}catch(_){}}})})}
const oldRender=window.render||((typeof render==='function')?render:null);if(oldRender){window.render=render=function(){const r=oldRender.apply(this,arguments);decorate();try{drawWires()}catch(e){};setTimeout(sync,0);return r};decorate()}
const oldShow=window.phase84tShowI2CEepromLab;window.phase84tShowI2CEepromLab=function(){const ep=addEeprom({x:825,y:145});if(ep)addDefaultWires(ep);try{if(typeof window.phase72ShowCanvas==='function')window.phase72ShowCanvas()}catch(e){};sync();return ep};
window.phase84tHideI2CEepromLab=function(){/* component remains user-owned; examples must not delete user hardware */};
window.phase84t5GetEepromAddress=function(){const p=part();return p?addr(p):null};
setInterval(sync,350);
window.addEventListener('load',()=>setTimeout(()=>{decorate();sync()},500));
})();

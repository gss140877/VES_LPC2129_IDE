Vector LPC2129 Simulator – Phase 6.0A
Clock, PLL, VPB and MAM Timing Foundation

This build upgrades the uploaded Phase 5.7 package while retaining:
- Professional LPC2129FBD64 64-pin LQFP component
- Circular physical pin numbers and aligned scalable pin labels
- Existing wiring and component canvas
- Embedded C and Assembly source build
- Intel HEX ARM7TDMI-S execution
- Run, stop, single-step, source arrow and debug panels
- LPC2129 GPIO register monitoring

New in Phase 6.0A:
- Dedicated draggable Clock / Timing panel in the main toolbar
- Configurable oscillator frequency
- PLL enable, M multiplier and P divider settings
- Live CCLK calculation
- Live PLL CCO frequency calculation and 156–320 MHz validity indication
- Configurable VPB divider with live PCLK calculation
- Configurable MAM mode and MAMTIM cycles
- CPU and peripheral cycle period display
- Emulator elapsed-time calculation based on selected CCLK
- CPU Profiler timing now uses the configured CCLK instead of fixed 60 MHz

Default LPC2129 classroom profile:
- Oscillator: 12 MHz
- PLL: enabled
- M = 5
- P = 2
- CCLK = 60 MHz
- FCCO = 240 MHz
- VPB divider = 4
- PCLK = 15 MHz
- MAM fully enabled
- MAMTIM = 3

Test:
1. Run START_LPC2129_SIMULATOR.bat.
2. Click Clock / Timing.
3. Confirm 60 MHz CCLK and 15 MHz PCLK defaults.
4. Build the default GPIO example.
5. Run or single-step and observe elapsed time changing with profiler cycles.
6. Change oscillator/PLL/VPB values and confirm timing updates immediately.

VECTOR LPC2129 IDE — Phase 8.2B
Worker-Based ARM7 Runtime + Low-Latency UART/UI

Architecture:
- The canonical LPC2129 ARM7TDMI-S CPU decoder/executor is extracted from simulator.js
  and executes compiled Intel HEX inside phase82b_arm7_worker.js.
- The browser main thread no longer runs the ARM instruction loop.
- GPIO/UART peripheral accesses remain memory-mapped from the worker CPU engine.
- UART0/UART1 TX serialization remains cycle/baud timed in the worker.
- Transmitted bytes are delivered to the UI in batches and painted once per animation frame.
- UART RX terminal input is posted to the worker RX FIFO.
- CPU/GPIO/UART snapshots are posted about every 33 ms.
- Debug panels are updated only from snapshots and only while a debug window is visible.
- Floating window dragging/resizing stays on the main UI thread.

Canonical execution rule:
.c/.s -> arm-none-eabi GCC/GAS -> ELF/HEX -> worker ARM7TDMI-S CPU
-> memory-mapped LPC2129 GPIO/UART SFRs -> peripheral engine -> UI snapshot/terminal.

Timing:
- CPU scheduler uses the Phase 8.1B fixed 250 us simulation quantum.
- UART frame completion uses emulated CPU cycles, PCLK divisor/fractional baud,
  configured frame size and CCLK.
- Browser paint timing does not determine UART electrical timing.

Validation boundary:
This phase targets UI responsiveness and low-latency I/O while preserving the existing CPU path.
Static syntax/integration checks are performed here. Full Electron/Ubuntu runtime performance must
be confirmed on the target system.

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "================================================"
echo " Vector LPC2129 Simulator - Ubuntu Setup"
echo "================================================"

if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Node.js/npm not found. Installing Ubuntu packages..."
  if [ "${EUID:-$(id -u)}" -eq 0 ]; then
    apt-get update && apt-get install -y nodejs npm
  elif command -v sudo >/dev/null 2>&1; then
    sudo apt-get update && sudo apt-get install -y nodejs npm
  else
    echo "ERROR: sudo unavailable. Install Node.js LTS and npm manually."
    exit 1
  fi
fi

./CHECK_INSTALL_ARM_TOOLCHAIN.sh

if command -v lpc21isp >/dev/null 2>&1; then
  echo "lpc21isp is already available."
elif command -v apt-get >/dev/null 2>&1 && apt-cache show lpc21isp >/dev/null 2>&1; then
  echo "Installing optional LPC21xx ISP utility (lpc21isp)..."
  if [ "${EUID:-$(id -u)}" -eq 0 ]; then
    apt-get install -y lpc21isp || true
  elif command -v sudo >/dev/null 2>&1; then
    sudo apt-get install -y lpc21isp || true
  fi
else
  echo "Optional: install lpc21isp if you want native LPC2129 hardware flashing on Linux."
fi

if [ ! -d node_modules ]; then
  echo "Installing Node.js packages..."
  npm install
else
  echo "Node.js packages already installed."
fi

echo
echo "Ubuntu setup complete."

/* VECTOR LPC2129 IDE Phase 7.3A - floating Log window */
(function(){'use strict';
function show(){ if(typeof window.phase71BuildOutput==='function'){window.phase71BuildOutput(); const w=document.getElementById('p71BuildOutput'); if(w){const t=w.querySelector('.p71-title');if(t)t.textContent='Compiler / Log';} return;} }
window.phase73ShowLog=show;
window.addEventListener('load',()=>setTimeout(()=>{
  // Existing toolbar Log button calls this legacy function: redirect it to the floating window manager.
  window.toggleCompilerWindow=show;
  const b=document.querySelector('button[onclick="toggleCompilerWindow()"]'); if(b)b.title='Open floating Compiler / Log window';
  try{if(typeof window.log==='function')window.log('Phase 7.3A: Compiler / Log is now openable, closeable, draggable and resizable.');}catch(e){}
},650));
})();

VECTOR LPC2129 IDE - Phase 7.2A Floating Canvas Window

Added:
- LPC2129 Circuit Canvas + Component Selection is now an independent IDE floating window.
- Open/reopen from View -> Circuit Canvas + Components.
- Close with the title-bar X.
- Drag from the title bar.
- Resize from the bottom-right resize grip.
- Bring to front on click.
- Independent canvas zoom: -, +, and 1:1 reset (40% to 200%).
- Existing component palette, CPU graphic, wiring scene and simulator behavior are preserved inside the floating window.

This milestone changes window management only; the LPC2129 simulation core is not replaced.

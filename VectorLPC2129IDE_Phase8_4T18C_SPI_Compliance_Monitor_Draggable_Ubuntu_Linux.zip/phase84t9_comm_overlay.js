(function(){
'use strict';
function byId(id){return document.getElementById(id)}
function callFirst(names,arg){
  for(const n of names){
    try{
      const f=window[n];
      if(typeof f==='function'){ return arguments.length>1 ? f(arg) : f(); }
    }catch(e){console.error(e);}
  }
}
function place(){
  const b=byId('communicationBtn'), m=byId('communicationMenu');
  if(!b||!m)return;
  const r=b.getBoundingClientRect();
  m.style.left=Math.max(4,Math.min(r.left,window.innerWidth-m.offsetWidth-6))+'px';
  m.style.top=(r.bottom+2)+'px';
}
function openMenu(){
  const m=byId('communicationMenu'),b=byId('communicationBtn');
  if(!m||!b)return;
  m.classList.add('commOpen'); b.setAttribute('aria-expanded','true');
  requestAnimationFrame(place);
}
function closeMenu(){
  const m=byId('communicationMenu'),b=byId('communicationBtn');
  if(m)m.classList.remove('commOpen');
  if(b)b.setAttribute('aria-expanded','false');
}
function toggle(e){
  e.preventDefault();e.stopPropagation();
  const m=byId('communicationMenu');
  if(m && m.classList.contains('commOpen')) closeMenu(); else openMenu();
}
function action(name){
  switch(name){
    case 'uart0':
      callFirst(['phase82ShowTerminal','showUartTerminal'],0); break;
    case 'uart1':
      callFirst(['phase82ShowTerminal','showUartTerminal'],1); break;
    case 'i2c-sfr':
      callFirst(['phase84tShowI2CSfr','phase84tShowI2CSFR']); break;
    case 'i2c-analyzer':
      callFirst(['phase84tShowI2CAnalyzer','phase84tShowAnalyzer']); break;
    case 'i2c-memory':
      callFirst(['phase84tShowEepromMemory','phase84tShowEEPROMMemory']); break;
    case 'i2c-compliance':
      callFirst(['phase84t16ShowI2CCompliance']); break;
    case 'spi0-sfr':
      callFirst(['phase84t14ShowSPI0Sfr']); break;
    case 'spi1-sfr':
      callFirst(['phase84t14ShowSPI1Sfr']); break;
    case 'spi-analyzer':
      callFirst(['phase84t14ShowSPIAnalyzer']); break;
    case 'spi-memory':
      callFirst(['phase84t14ShowSpiEepromMemory']); break;
    case 'spi-compliance':
      callFirst(['phase84t17ShowSPICompliance']); break;
    case 'can1-sfr':
      callFirst(['phase84t15ShowCAN1Sfr']); break;
    case 'can2-sfr':
      callFirst(['phase84t15ShowCAN2Sfr']); break;
    case 'can-af':
      callFirst(['phase84t15ShowCANAF']); break;
    case 'can-monitor':
      callFirst(['phase84t15ShowCANMonitor']); break;
    case 'can-diag':
      callFirst(['phase84t15ShowCANDiagnostics']); break;
  }
  closeMenu();
}
function install(){
  const b=byId('communicationBtn'),m=byId('communicationMenu');
  if(!b||!m)return;
  b.addEventListener('click',toggle);
  m.addEventListener('click',function(e){
    const t=e.target.closest('[data-comm-action]');
    if(!t)return;
    e.preventDefault();e.stopPropagation();action(t.dataset.commAction);
  });
  document.addEventListener('click',function(e){
    if(!e.target.closest('#communicationToolbarGroup') && !e.target.closest('#communicationMenu')) closeMenu();
  });
  window.addEventListener('resize',function(){if(m.classList.contains('commOpen'))place()});
  window.addEventListener('scroll',function(){if(m.classList.contains('commOpen'))place()},true);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install);
else install();
})();
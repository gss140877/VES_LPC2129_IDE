VECTOR LPC2129 IDE — Phase 8.3A
VIC + UART IRQ + Board PWR/TX/RX LEDs + Functional Hardware RESET

New board diagnostics:
- PWR red SMD indicator: continuously on while board UI is present.
- TX green SMD indicator: activity pulse generated only after UART serializer completes TX byte(s).
- RX yellow SMD indicator: activity pulse generated only when bytes are accepted into UART RX FIFO.
- On-board RESET is pointer-press/hold/release driven.
- RESET assertion pauses CPU execution; release resets CPU/GPIO/UART/VIC state while preserving emulated flash,
  then execution restarts at address 0x00000000. No recompile/page reload is performed.

VIC engine:
- VICIRQStatus, VICFIQStatus, VICRawIntr
- VICIntSelect, VICIntEnable, VICIntEnClr
- VICSoftInt / VICSoftIntClear
- VICProtection
- VICVectAddr / VICDefVectAddr
- VICVectAddr0..15
- VICVectCntl0..15
- UART0 source 6, UART1 source 7
- vectored slot priority 0..15
- VICVectAddr write used as end-of-interrupt acknowledgement

ARM7 IRQ path:
UART condition -> VIC raw IRQ -> enabled IRQ -> ARM IRQ exception -> vector 0x18
-> LDR PC from VICVectAddr -> firmware ISR -> VIC EOI -> SUBS PC,LR,#4 return.
CPSR I/F bits and SPSR_irq/IRQ LR/SP foundation are modeled for this path.

Examples:
C: UART0 RX Interrupt Echo, UART1 RX Interrupt Echo
ASM: UART0 RX Interrupt Echo, UART1 RX Interrupt Echo

Validation boundary:
Static JS syntax/integration tests are performed in the build environment.
The user's Ubuntu runtime remains authoritative for GUI/worker behavior and real-time responsiveness.
This is a focused UART/VIC IRQ implementation, not yet a full certification of every LPC2129 VIC/FIQ corner case.

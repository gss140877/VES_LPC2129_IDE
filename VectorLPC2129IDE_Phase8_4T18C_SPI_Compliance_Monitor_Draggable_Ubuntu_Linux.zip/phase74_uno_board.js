/* VECTOR LPC2129 IDE Phase 7.4H
   NXP-canonical 46 GPIO board mapping:
   P0.0..P0.25, P0.27..P0.30, P1.16..P1.31
   P0.26 and P0.31 are not exposed because they are not available on LPC2129. */
(function(){'use strict';
if(window.__phase74UnoBoardInstalled)return;
window.__phase74UnoBoardInstalled=true;

function esc(s){
  return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

const CANONICAL_GPIO_LABELS = [
  ...Array.from({length:26},(_,i)=>`P0.${i}`),
  ...Array.from({length:4}, (_,i)=>`P0.${i+27}`),
  ...Array.from({length:16},(_,i)=>`P1.${i+16}`)
];

function nodeForLabel(label){
  return 'uno.' + label.replace('.','_');
}

function ioHit(label,n,row,index){
  const x=267 + (1328-267)*(index/22);
  const y=row==='top'?51:948;
  const node=nodeForLabel(label);
  return `<span class="pin lpc-pin p74f-hit p74f-${row}"
      style="--px:${x};--py:${y}"
      data-io="${n}"
      data-node="${esc(node)}"
      data-pinlabel="${esc(label)}"
      data-tip="I/O ${n} • ${esc(label)}"
      title="I/O ${n} • ${esc(label)}"></span>`;
}

function install(){
  const board=document.getElementById('uno');
  if(!board||board.dataset.p74hImage==='1')return;

  if(CANONICAL_GPIO_LABELS.length!==46 ||
     CANONICAL_GPIO_LABELS.includes('P0.26') ||
     CANONICAL_GPIO_LABELS.includes('P0.31')){
    console.error('Phase 7.4H canonical LPC2129 GPIO map validation failed.');
    return;
  }

  board.dataset.p74Uno='1';
  board.dataset.p74hImage='1';
  board.className='uno lpc-board p74f-image-board';

  let hits='';
  CANONICAL_GPIO_LABELS.slice(0,23).forEach((label,i)=>hits+=ioHit(label,i+1,'top',i));
  CANONICAL_GPIO_LABELS.slice(23).forEach((label,i)=>hits+=ioHit(label,i+24,'bottom',i));

  board.innerHTML=`<div class="p74f-board-stage">
    <img class="p74f-board-image"
         src="assets/vector_lpc2129_board.png"
         alt="VECTOR INDIA LPC2129 development board — NXP canonical 46 GPIO">
    <div class="p74f-hit-layer">
      ${hits}
      <span class="pin p74f-powerhit"
            style="--px:1400;--py:410;--ph:102"
            data-node="uno.5V" data-tip="5V" title="5V"></span>
      <span class="pin p74f-powerhit"
            style="--px:1400;--py:538;--ph:102"
            data-node="uno.3V3" data-tip="3.3V" title="3.3V"></span>
      <span class="pin p74f-powerhit"
            style="--px:1400;--py:665;--ph:102"
            data-node="uno.GND" data-tip="GND" title="GND"></span>
    </div>
  </div>`;

  try{if(typeof window.bindPinEvents==='function')window.bindPinEvents();}catch(e){}
  try{if(typeof window.installPinHandlers==='function')window.installPinHandlers();}catch(e){}
  try{if(typeof window.renderWires==='function')window.renderWires();}catch(e){}
  try{
    if(typeof window.log==='function')
      window.log('Phase 7.4H: NXP-canonical LPC2129 46-GPIO map active; P0.26/P0.31 removed.');
  }catch(e){}
}

window.LPC2129_CANONICAL_GPIO_LABELS = CANONICAL_GPIO_LABELS.slice();
// Phase 8.3O: install immediately so the legacy bootstrap board never flashes.
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',install,{once:true});
else install();
window.addEventListener('load',install,{once:true});
})();
Phase 4C - ARM7TDMI-S Live Instruction Profiler

Base: Phase 4B Instruction Coverage + Unsupported Opcode Report

Added in this version:
1. Live instruction profiling panel.
2. Total instruction count.
3. ARM instruction count.
4. THUMB instruction count.
5. Estimated cycle count.
6. Estimated elapsed execution time at 60 MHz CCLK.
7. Average CPI.
8. Last executed mode, PC, opcode, and instruction family.
9. Coverage matrix now shows per-family decode count, execute count, cycles, and last PC/opcode.
10. Unsupported opcode report retained.
11. C source and Assembly source build support retained.
12. LPC2129 GPIO Digital Monitor retained.

How to test:
1. Run RUN_SERVER.bat.
2. Select C Source or Assembly Source.
3. Build HEX.
4. Run Simulation.
5. Open/add LPC2129 Digital Monitor if needed.
6. Watch the ARM7TDMI-S panel update with live instruction/cycle statistics.

Note:
Cycle count is currently an educational estimate, not cycle-accurate ARM7TDMI timing.

/* VECTOR LPC2129 IDE — Phase 8.3N
   Four-channel UART/AUX SMD LED bank.
   Physical sources: P0.0/TXD0, P0.1/RXD0, P0.8/TXD1, P0.9/RXD1.
   Each channel selector cycles OFF -> UART -> AUX.
   AUX is a real Circuit Canvas node and must be wired visibly to a canonical MCU pin.
   No source parsing; no example-specific LED shortcut.
*/
(function(){
'use strict';
if(window.__phase83gInstalled)return; window.__phase83gInstalled=true;
const ch=[
 {id:0,name:'TX0',node:'uno.P0_0',port:0,pin:0,kind:'tx'},
 {id:1,name:'RX0',node:'uno.P0_1',port:0,pin:1,kind:'rx'},
 {id:2,name:'TX1',node:'uno.P0_8',port:0,pin:8,kind:'tx'},
 {id:3,name:'RX1',node:'uno.P0_9',port:0,pin:9,kind:'rx'}
];
const state={mode:['UART','UART','UART','UART'],pulse:[0,0,0,0]};
function q(id){return document.getElementById(id)}
function prj(){try{if(typeof project!=='undefined'&&project)return project}catch(e){} return window.project||null}
function logSafe(s){try{if(typeof log==='function')log(s)}catch(e){}}
function pinLevel(node){
 const m=/^uno\.P([01])_(\d+)$/.exec(String(node||'')); if(!m)return null;
 const po=window.lpcGpio&&window.lpcGpio['p'+m[1]]; if(!po)return null;
 return ((po.IOPIN>>>Number(m[2]))&1);
}
function auxSource(i){
 const p=prj(); if(!p||!Array.isArray(p.wires))return null;
 const aux='p83g.AUX'+i;
 for(const w of p.wires){
  let other=null; if(w.from===aux)other=w.to; else if(w.to===aux)other=w.from;
  if(other&&/^uno\.P[01]_\d+$/.test(other))return other;
 }
 return null;
}
function setMode(i,mode){state.mode[i]=mode; const b=q('p83gSel'+i); if(b){b.dataset.mode=mode;b.textContent=mode==='OFF'?'O':mode==='UART'?'U':'A';b.title=ch[i].name+' source: '+mode+' (click: OFF / UART / AUX)'} refresh();}
function refresh(){
 const now=performance.now();
 ch.forEach((c,i)=>{
  const mode=state.mode[i]; const led=q('p83gLed'+i), pad=q('p83gAux'+i), src=q('p83gSrc'+i);
  let on=false,label='';
  if(mode==='OFF'){label='OPEN';}
  else if(mode==='AUX'){
   const n=auxSource(i); const lv=n?pinLevel(n):null; on=lv===1; label=n?n.replace('uno.','')+'='+lv:'AUX open';
  }else{
   // Dedicated physical pin. GPIO/static level is visible; UART transfers use the
   // hardware activity detector pulse supplied by the UART peripheral engine.
   const lv=pinLevel(c.node); on=(state.pulse[i]>now)||(lv===1 && !uartMuxSelected(c));
   label=c.node.replace('uno.','')+(uartMuxSelected(c)?' / UART':' / GPIO='+lv);
  }
  if(led){led.classList.toggle('on',!!on);led.classList.toggle('offsel',mode==='OFF')}
  if(pad)pad.classList.toggle('active',mode==='AUX');
  if(src)src.textContent=label;
 });
}
function uartMuxSelected(c){
 const ps=window.lpcArm7Emu&&window.lpcArm7Emu.pinConnect ? (window.lpcArm7Emu.pinConnect.PINSEL0>>>0) : 0;
 if(c.pin===0||c.pin===1)return (ps&0xF)===0x5;
 return ((ps>>>16)&0xF)===0x5;
}
function pulseChannel(kind,port,count){
 const i=(Number(port)?2:0)+(kind==='rx'?1:0); if(i<0||i>3)return;
 state.pulse[i]=performance.now()+70; refresh(); setTimeout(refresh,78);
 // Physical-line visual observer: external canvas LED directly connected to the same
 // UART pin receives the same activity pulse. This is hardware-engine derived.
 pulseExternalLed(ch[i].node,70);
}
function connected(node){const p=prj(),out=[]; if(!p||!Array.isArray(p.wires))return out; p.wires.forEach(w=>{if(w.from===node)out.push(w.to); if(w.to===node)out.push(w.from)}); return out}
function isGnd(n){return /(?:^uno\.GND$|\.G$|GND)/i.test(n||'')}
function isVcc(n){return /(?:^uno\.(?:5V|3V3)$|VCC|3V3|5V)/i.test(n||'')}
function pulseExternalLed(pinNode,ms){
 const p=prj(); if(!p||!Array.isArray(p.parts))return;
 p.parts.filter(x=>x.type==='led').forEach(part=>{
  const a=connected(part.id+'.A'),k=connected(part.id+'.K');
  const touches=(a.includes(pinNode)&&k.some(isGnd))||(k.includes(pinNode)&&a.some(isVcc));
  if(!touches)return;
  const bulb=document.querySelector('#'+CSS.escape(part.id)+' .ledBulb'); if(bulb){bulb.classList.add('on');setTimeout(()=>{try{if(typeof window.phase81RefreshCanvasOutputs==='function')window.phase81RefreshCanvasOutputs();else bulb.classList.remove('on')}catch(e){bulb.classList.remove('on')}},ms)}
 });
}
function stageLocalPoint(el,stage){
 if(!el||!stage)return null;
 const er=el.getBoundingClientRect(), sr=stage.getBoundingClientRect();
 if(!sr.width||!sr.height)return null;
 return {x:((er.left+er.width/2)-sr.left)*(768/sr.width),y:((er.top+er.height/2)-sr.top)*(512/sr.height)};
}
function boardWireColor(w){
 try{if(typeof colorForWire==='function')return colorForWire(w)}catch(e){}
 return '#ff9800';
}
function ensureBoardWireLayer(stage){
 let svg=q('p83hBoardWires');
 if(svg&&svg.parentElement!==stage){svg.remove();svg=null}
 if(!svg){
  svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
  svg.id='p83hBoardWires';svg.setAttribute('class','p83h-board-wire-layer');svg.setAttribute('viewBox','0 0 768 512');
  stage.appendChild(svg);
 }
 return svg;
}
function drawBoardJumpers(){
 const stage=document.querySelector('#uno .p74f-board-stage'), p=prj(); if(!stage||!p||!Array.isArray(p.wires))return;
 const svg=ensureBoardWireLayer(stage); svg.innerHTML='';
 p.wires.forEach((w,idx)=>{
  const fa=/^p83g\.AUX([0-3])$/.exec(String(w.from||'')), ta=/^p83g\.AUX([0-3])$/.exec(String(w.to||''));
  const aux=fa?w.from:(ta?w.to:null); const pin=fa?w.to:(ta?w.from:null);
  if(!aux||!/^uno\.P[01]_\d+$/.test(String(pin||'')))return;
  const ae=stage.querySelector('[data-node="'+CSS.escape(aux)+'"]');
  const pe=stage.querySelector('[data-node="'+CSS.escape(pin)+'"]');
  const a=stageLocalPoint(pe,stage), b=stageLocalPoint(ae,stage); if(!a||!b)return;
  // Compact PCB/jumper-like route: leave the MCU header vertically first, then
  // route across the board and enter the selected AUX Berg pin from below/side.
  const midY=(a.y<b.y)?Math.min(b.y-11,a.y+18):Math.max(b.y+11,a.y-18);
  const pts=`${a.x.toFixed(1)},${a.y.toFixed(1)} ${a.x.toFixed(1)},${midY.toFixed(1)} ${b.x.toFixed(1)},${midY.toFixed(1)} ${b.x.toFixed(1)},${b.y.toFixed(1)}`;
  const g=document.createElementNS('http://www.w3.org/2000/svg','g');g.dataset.vectorWireIndex=String(idx);g.setAttribute('title','Board jumper: '+pin.replace('uno.','')+' → '+aux.replace('p83g.',''));
  const sh=document.createElementNS('http://www.w3.org/2000/svg','polyline');sh.setAttribute('class','p83h-wire-shadow');sh.setAttribute('points',pts);
  const ln=document.createElementNS('http://www.w3.org/2000/svg','polyline');ln.setAttribute('class','p83h-wire');ln.setAttribute('points',pts);ln.setAttribute('stroke',boardWireColor(w));
  g.append(sh,ln);
  g.addEventListener('dblclick',e=>{e.preventDefault();e.stopPropagation();const pp=prj();if(!pp||!Array.isArray(pp.wires))return;const wi=Number(g.dataset.vectorWireIndex);if(wi>=0&&wi<pp.wires.length){pp.wires.splice(wi,1);try{window.project=pp}catch(_){};try{if(typeof drawWires==='function')drawWires()}catch(_){};drawBoardJumpers();logSafe('Board jumper deleted')}});
  svg.appendChild(g);
 });
}
function wrapWireRenderer(){
 if(window.__phase83hWireRendererWrapped)return; window.__phase83hWireRendererWrapped=true;
 try{
  if(typeof drawWires==='function'){
   const old=drawWires; window.drawWires=drawWires=function(){const r=old.apply(this,arguments);setTimeout(drawBoardJumpers,0);return r};
  }
 }catch(e){}
 window.addEventListener('resize',()=>setTimeout(drawBoardJumpers,0));
}
function install(){
 const stage=document.querySelector('#uno .p74f-board-stage'); if(!stage)return false; if(q('p83gBank'))return true;
 // Retire the former shared TX/RX pair. PWR and physical RESET remain untouched.
 q('p83TxWrap')?.classList.add('p83g-retired'); q('p83RxWrap')?.classList.add('p83g-retired');
 const mask=document.createElement('div');mask.id='p83nJtagMask';mask.className='p83n-jtag-mask';mask.setAttribute('aria-hidden','true');stage.appendChild(mask);
 const bank=document.createElement('div');bank.id='p83gBank';bank.className='p83g-bank';
 bank.innerHTML=`<div class="p83g-title">UART / AUX LED BANK <span>O/U/A</span></div><div class="p83g-grid">${ch.map((c,i)=>`
 <div class="p83g-ch" title="${c.name}: OFF / dedicated ${c.node.replace('uno.','')} UART pin / AUX jumper">
  <b>${c.name}</b><i id="p83gLed${i}" class="p83g-led ${c.kind}"></i>
  <button id="p83gSel${i}" class="p83g-sel" type="button" data-mode="UART">U</button>
  <span id="p83gAux${i}" class="pin p83g-aux" data-node="p83g.AUX${i}" data-tip="Berg/header AUX input • ${c.name} • wire from any LPC2129 physical I/O header" title="Berg/header AUX input — ${c.name}"></span>
  <small id="p83gSrc${i}"></small>
 </div>`).join('')}</div>`;
 stage.appendChild(bank);
 ch.forEach((c,i)=>q('p83gSel'+i).addEventListener('click',e=>{e.preventDefault();const a=['OFF','UART','AUX'],n=a[(a.indexOf(state.mode[i])+1)%3];setMode(i,n);logSafe(c.name+' onboard LED selector -> '+n)}));
 try{if(typeof window.installPinHandlers==='function')window.installPinHandlers()}catch(e){}
 try{if(typeof window.bindPinEvents==='function')window.bindPinEvents()}catch(e){}
 wrapWireRenderer();
 try{if(typeof window.drawWires==='function')window.drawWires()}catch(e){}
 setTimeout(drawBoardJumpers,20);
 refresh(); return true;
}
window.phase83gRefresh=()=>{install();refresh();drawBoardJumpers()};
window.phase83gBoardActivity=(kind,port,count)=>{install();pulseChannel(kind,port,count)};
window.phase83gState=state;
window.addEventListener('load',()=>setTimeout(install,1750));
setInterval(()=>{if(q('p83gBank'))refresh()},80);
})();

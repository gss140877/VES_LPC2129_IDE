VECTOR LPC2129 IDE — Phase 8.3D
Physical RESET Button Movement

Changes:
- Existing approved board PNG remains byte-for-byte unchanged.
- RESET functional overlay remains exactly over the board's existing RESET switch.
- A small translucent cap overlay now visually depresses by 3 px while RESET is asserted.
- On pointer release it springs back to the released position.
- The movement is tied to the same hardware-reset press/release events.
- Keyboard Space/Enter activation also shows the same press/release animation.
- PWR/TX/RX LED positions and all Phase 8.3C VIC/UART IRQ functionality are unchanged.

Phase 8.4T12 — Direct main-toolbar memory access

Correction:
T11 created the ROM/RAM viewers but exposed them only through the secondary IDE
View/debug controls. This did not make them reliably available in the user's normal
main toolbar.

T12 adds an always-visible Memory dropdown directly beside Communication:
Memory >
  24LC512 EEPROM Memory
  ROM / Flash Memory
  RAM Memory

Viewer ranges:
- 24LC512: 0x0000 - 0xFFFF
- LPC2129 Flash: 0x00000000 - 0x0003FFFF
- LPC2129 SRAM: 0x40000000 - 0x40003FFF

Each viewer:
- opens even before Run
- complete virtual scroll address space
- Go To Address
- 16 hex bytes per row
- ASCII column
- live worker reads while simulation is running

Also removed stale phase84t8_comm_overlay.js from index.html.

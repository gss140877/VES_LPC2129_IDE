Phase 4B Update - ARM7TDMI-S Instruction Coverage + Unsupported Opcode Report

What is added:
1. Runtime Instruction Coverage Matrix inside the LPC2129 Digital Monitor / CPU panel.
2. Unsupported opcode detector for ARM and THUMB mode.
3. Clear report with Mode, PC, Opcode, Family, and Detail when the emulator reaches an instruction not yet executable.
4. Existing C source and Assembly source build support is preserved.
5. Existing GPIO memory-mapped execution and Digital Monitor update behavior is preserved.

How to test:
1. Run RUN_SERVER.bat.
2. Open the project in browser.
3. Select C Source or Assembly Source.
4. Build HEX.
5. Add/open LPC2129 Digital Monitor.
6. Click Run Simulation.
7. Observe the ARM7TDMI-S CPU panel and Instruction Coverage Matrix.

Important:
This update does not claim full ARM7TDMI-S validation yet. It makes coverage visible and makes unsupported opcodes explicit. The next updates should implement/test missing instruction families one by one until all matrix rows are fully validated.

VECTOR LPC2129 IDE — Phase 8.3Q

Purpose
- Remove the four stray light-gray square artifacts seen over the approved LPC2129 PCB.
- These are treated as stale legacy bootstrap/QFP/UNO-derived visual DOM, not valid LPC2129 board nodes.

Preserved
- Approved vector_lpc2129_board.png unchanged.
- Canonical 46 LPC2129 GPIO hit boxes.
- UART/AUX LED bank and reusable SW/LED Berg headers.
- Thin single onboard/off-board wiring and route editor.
- project.wires electrical connectivity and ARM7/UART/GPIO runtime.

Implementation
- Adds a scoped cleanup guard active only when #uno is the p74f image-backed LPC2129 board.
- Removes legacy QFP/p73/UNO-image visual descendants and any stale direct bootstrap child beside the canonical board stage.
- MutationObserver plus delayed cleanup protects against older delayed installers repainting artifacts.
- Does not globally hide .pin elements, so real GPIO/Berg/component connection targets remain functional.

VECTOR LPC2129 IDE — Phase 8.4H
Canonical CPU + Peripheral Timebase / Timer Blink Timing Fix

Purpose
-------
Fix the remaining ADC-controlled Timer0/Timer1 blink timing mismatch without adding
any source-code, Timer-to-LED, or UI timing shortcut.

Canonical execution path remains:
C/ASM -> GNU ARM toolchain -> HEX -> ARM7TDMI-S executor -> LPC2129 SFR/peripheral
engine -> VIC -> compiled ISR -> GPIO SFR -> physical GPIO -> Circuit Canvas.

Timing architecture
-------------------
The LPC2129 hardware clock is now the owner of peripheral time:
12 MHz crystal -> PLL/CCLK 60 MHz -> VPB/PCLK 15 MHz -> Timer/ADC/UART.
A 1 ms hardware quantum advances exactly 60,000 CCLK clocks and 15,000 PCLK clocks.
Timer0/1 PR/PC/TC and MR match logic are advanced from this canonical PCLK domain.
UART and ADC timing now use the same LPC2129 hardware clock rather than ARM
interpreter throughput.

The ARM7TDMI-S engine continues executing the actual compiled ARM/THUMB instructions.
VIC IRQ is sampled before each executed instruction. A Timer match only asserts the
Timer interrupt; the real compiled ISR must execute and write IO0SET/IO0CLR before
P0.10 and the LED can change.

ADC-direct blink example
------------------------
With PCLK=15 MHz and PR=14999:
  TC increments once per 1 ms.
Therefore MR0=100 gives a 100 ms toggle interval, MR0=500 gives 500 ms, and
MR0=1000 gives 1000 ms. A complete ON->OFF->ON period is twice the toggle interval.

Validation performed
--------------------
- JavaScript syntax check passed.
- Timer0/1 still derive only from PCLK.
- ADC/UART due-time references moved to the canonical LPC clock.
- No Timer-to-LED direct path was introduced.
- Approved board artwork was not modified.

Note
----
This is a high-fidelity functional/register model, not a transistor-level or
cycle-perfect silicon certification model. Runtime timing must still be verified on
the target Ubuntu machine.

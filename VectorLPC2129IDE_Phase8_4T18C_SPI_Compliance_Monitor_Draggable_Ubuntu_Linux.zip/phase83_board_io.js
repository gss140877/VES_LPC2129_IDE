/* VECTOR LPC2129 Phase 8.3B
   Precise interactive overlays on the existing approved board image.
   No board-image regeneration or replacement.
*/
(function(){
'use strict';
if(window.__phase83bBoardInstalled)return;
window.__phase83bBoardInstalled=true;

let txTimer=null, rxTimer=null;

function q(id){ return document.getElementById(id); }

function install(){
  const stage=document.querySelector('#uno .p74f-board-stage');
  if(!stage) return false;
  if(q('p83bOverlayLayer')) return true;

  const layer=document.createElement('div');
  layer.id='p83bOverlayLayer';
  layer.className='p83b-overlay-layer';

  /*
    Source board PNG: 1536 x 1024.
    Display stage:     768 x  512 (exactly 0.5 scale).

    Placement in source-image coordinates:
      RESET : center over existing physical RESET switch ~ (120, 708)
      PWR   : centered above VECTOR diagrammatic logo   ~ (124, 258)
      TX    : vertically aligned below P0.0 header      ~ (267, 250)
      RX    : vertically aligned below P0.1 header      ~ (315, 250)
  */
  layer.innerHTML=`
    <div id="p83PwrWrap" class="p83b-led-wrap p83b-pwr"
         style="--px:124;--py:258"
         title="Board Power">
      <i id="p83PwrLed" class="p83b-smd pwr on"></i>
      <span>PWR</span>
    </div>

    <div id="p83TxWrap" class="p83b-led-wrap p83b-tx"
         style="--px:267;--py:250"
         title="UART TX activity">
      <i id="p83TxLed" class="p83b-smd tx"></i>
      <span>TX</span>
    </div>

    <div id="p83RxWrap" class="p83b-led-wrap p83b-rx"
         style="--px:315;--py:250"
         title="UART RX activity">
      <i id="p83RxLed" class="p83b-smd rx"></i>
      <span>RX</span>
    </div>

    <button id="p83ResetButton"
            class="p83b-reset-hit"
            style="--px:120;--py:708;--pw:112;--ph:104"
            type="button"
            aria-label="LPC2129 hardware reset"
            title="LPC2129 hardware RESET — press/hold to assert, release to restart"></button>
  `;

  stage.appendChild(layer);

  const rb=q('p83ResetButton');
  const down=(e)=>{
    e.preventDefault();
    rb.classList.add('pressed');
    try{ rb.setPointerCapture(e.pointerId); }catch(_){}
    if(typeof window.phase83HardwareResetAssert==='function')
      window.phase83HardwareResetAssert();
  };
  const up=(e)=>{
    e.preventDefault();
    if(!rb.classList.contains('pressed')) return;
    rb.classList.remove('pressed');
    if(typeof window.phase83HardwareResetRelease==='function')
      window.phase83HardwareResetRelease();
  };

  rb.addEventListener('pointerdown',down);
  rb.addEventListener('pointerup',up);
  rb.addEventListener('pointercancel',up);
  rb.addEventListener('lostpointercapture',up);

  /* Keyboard activation mirrors the physical press/release animation. */
  rb.addEventListener('keydown',e=>{
    if((e.key===' '||e.key==='Enter')&&!rb.classList.contains('pressed')){
      e.preventDefault();
      rb.classList.add('pressed');
      if(typeof window.phase83HardwareResetAssert==='function')
        window.phase83HardwareResetAssert();
    }
  });
  rb.addEventListener('keyup',e=>{
    if((e.key===' '||e.key==='Enter')&&rb.classList.contains('pressed')){
      e.preventDefault();
      rb.classList.remove('pressed');
      if(typeof window.phase83HardwareResetRelease==='function')
        window.phase83HardwareResetRelease();
    }
  });

  return true;
}

window.phase83BoardActivity=function(kind,port,count){
  install();
  try{if(typeof window.phase83gBoardActivity==='function')window.phase83gBoardActivity(kind,port,count)}catch(e){}

  const isTx=kind==='tx';
  const el=q(isTx?'p83TxLed':'p83RxLed');
  const wrap=q(isTx?'p83TxWrap':'p83RxWrap');
  if(!el) return;

  const uart='UART'+(Number(port)?1:0);
  el.classList.add('on');
  if(wrap) wrap.title=(isTx?'TX':'RX')+' activity — '+uart+
      (count>1?' — '+count+' bytes':'');

  if(isTx){
    clearTimeout(txTimer);
    txTimer=setTimeout(()=>el.classList.remove('on'),65);
  }else{
    clearTimeout(rxTimer);
    rxTimer=setTimeout(()=>el.classList.remove('on'),65);
  }
};

window.phase83BoardResetState=function(asserted){
  install();
  const rb=q('p83ResetButton');
  if(rb) rb.classList.toggle('pressed',!!asserted);

  if(asserted){
    q('p83TxLed')?.classList.remove('on');
    q('p83RxLed')?.classList.remove('on');
  }
};

window.addEventListener('load',()=>setTimeout(install,1450));
})();

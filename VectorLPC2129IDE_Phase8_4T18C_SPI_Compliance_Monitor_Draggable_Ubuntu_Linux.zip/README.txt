LPC2129 Simulator - Phase 3B True ARM7TDMI HEX Emulator Foundation

Run:
  run_server.bat
  open http://localhost:3000

What changed in Phase 3B:
  - Arduino/AVR monitor/runtime is not used.
  - Build HEX uses arm-none-eabi-gcc for LPC2129 ARM mode.
  - The simulator now loads the Intel HEX file into emulated flash memory.
  - Run Simulation starts a true ARM7TDMI instruction execution loop.
  - GPIO monitor updates from memory-mapped LPC2129 registers:
      IO0PIN 0xE0028000
      IO0SET 0xE0028004
      IO0DIR 0xE0028008
      IO0CLR 0xE002800C
      IO1PIN 0xE0028010
      IO1SET 0xE0028014
      IO1DIR 0xE0028018
      IO1CLR 0xE002801C
  - Flash Magic ISP support is retained.
  - Download HEX to preferred folder is retained.

Supported ARM7TDMI core subset in this first true-emulator phase:
  - ARM state execution from address 0x00000000
  - B / BL / BX
  - Data processing instructions used by common GCC GPIO examples
  - LDR / STR word and byte transfers
  - STM / LDM stack prologue/epilogue instructions
  - Basic CPSR N/Z/C/V condition handling
  - RAM stack at 0x40000000 - 0x40003FFF

Classroom test:
  1. Keep default P0.10 LED blink code.
  2. Click Build HEX.
  3. Click Run Simulation.
  4. Watch the LPC2129 Digital I/O Monitor and the LED state.

Note:
  Phase 3B is the emulator foundation, not a complete ARM architecture simulator yet.
  More instructions, timer/interrupt model, and peripheral accuracy should be added in future phases.


Phase 3C update:
- Real HEX-first ARM7TDMI emulator path retained.
- GPIO pin changes are paced so P0/P1 monitor toggling is visible.
- Added fuller condition-code support and improved CMP/SUB/ADD flags.
- GPIO write trace shows IO0DIR/IO0SET/IO0CLR/IO1DIR/IO1SET/IO1CLR writes.


Phase 3F Fix:
- Corrected LPC2129 Port 1 GPIO register addresses to 0xE002C000..0xE002C00C.
- Fixed GPIO address decoder to treat P0 and P1 as separate address windows.
- P1.16-P1.31 monitor now updates from IOSET1/IOCLR1 HEX execution.

PHASE 4A UPDATE - ARM7TDMI-S ARM/THUMB DECODER
----------------------------------------------
This build upgrades the HEX emulator engine with a broader ARM7TDMI-S machine-code decoder.
It supports ARM state and THUMB state instruction-class decoding for ARMv4T/ARM7TDMI-S.
Core integer, branch, load/store, stack, block-transfer, multiply, multiply-long, halfword,
signed load, BX mode switch, and common THUMB instruction formats are functionally executed.
SWI, coprocessor and undefined instruction classes are decoded and handled safely for classroom
simulation rather than crashing the UI.

Use this build as the base before adding Timer/UART/LCD peripheral timing.

Phase 8.4A addition: LPC2129 four-channel 10-bit on-chip ADC worker engine, four professional
Circuit Canvas trimpots on AIN0..AIN3, and UART0 decimal/voltage examples. See
PHASE8_4A_ONCHIP_ADC_4CHANNEL_TRIPOTS_UART0_README.txt.

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

./CHECK_INSTALL_ARM_TOOLCHAIN.sh
command -v node >/dev/null 2>&1 || { echo "ERROR: Node.js is not installed. Run ./INSTALL_UBUNTU_DEPENDENCIES.sh"; exit 1; }
command -v npm >/dev/null 2>&1 || { echo "ERROR: npm is not installed. Run ./INSTALL_UBUNTU_DEPENDENCIES.sh"; exit 1; }

if [ ! -d node_modules ]; then npm install; fi

node server.js > /tmp/vector_lpc2129_server.log 2>&1 &
SERVER_PID=$!
cleanup(){ kill "$SERVER_PID" 2>/dev/null || true; }
trap cleanup EXIT INT TERM

for _ in $(seq 1 40); do
  if curl -fsS http://127.0.0.1:3000/ >/dev/null 2>&1; then break; fi
  sleep 0.25
done

APPURL="http://localhost:3000"
BROWSER=""
for b in chromium chromium-browser google-chrome google-chrome-stable microsoft-edge microsoft-edge-stable; do
  if command -v "$b" >/dev/null 2>&1; then BROWSER="$(command -v "$b")"; break; fi
done

if [ -n "$BROWSER" ]; then
  "$BROWSER" --app="$APPURL" --window-size=1500,900 >/dev/null 2>&1 || true
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$APPURL" >/dev/null 2>&1 || true
  echo "No Chromium-family browser found; opened the simulator in the default browser."
else
  echo "Open $APPURL in your browser."
fi

wait "$SERVER_PID"

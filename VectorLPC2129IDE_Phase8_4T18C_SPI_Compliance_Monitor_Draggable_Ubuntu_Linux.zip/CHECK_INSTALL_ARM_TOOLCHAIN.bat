@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title ARM GNU Toolchain Check / Install

echo ===============================================
echo   ARM GNU Toolchain Check / Install
echo ===============================================
echo.

call :CheckTools
if "%TOOLS_OK%"=="1" (
  echo ARM GNU toolchain is already installed and available in PATH.
  echo.
  arm-none-eabi-gcc --version | more /E +0
  exit /b 0
)

echo ARM GNU toolchain was NOT found in PATH.
echo Required tools:
echo   arm-none-eabi-gcc
echo   arm-none-eabi-objcopy
echo   arm-none-eabi-size
echo.

echo Searching common installation folders...
call :FindInstalledToolchain
call :CheckTools
if "%TOOLS_OK%"=="1" (
  echo Found ARM GNU toolchain in an installed folder.
  echo Temporarily added to PATH for this session:
  echo   %ARM_TOOLCHAIN_BIN%
  echo.
  arm-none-eabi-gcc --version | more /E +0
  exit /b 0
)

echo Trying automatic installation using Windows Package Manager ^(winget^) ...
where winget >nul 2>nul
if errorlevel 1 (
  echo.
  echo ERROR: winget is not available on this system.
  echo Please install ARM GNU Toolchain manually from Arm Developer,
  echo then make sure the bin folder is added to PATH.
  echo.
  pause
  exit /b 1
)

echo.
echo Installing package: Arm.GnuArmEmbeddedToolchain
echo This may need internet access and Windows permission approval.
echo.
winget install -e --id Arm.GnuArmEmbeddedToolchain --source winget --accept-package-agreements --accept-source-agreements
if errorlevel 1 (
  echo.
  echo First winget install attempt failed.
  echo Trying winget search/install by package name...
  winget install "GNU Arm Embedded Toolchain" --source winget --accept-package-agreements --accept-source-agreements
)

echo.
echo Re-checking ARM GNU toolchain...
call :FindInstalledToolchain
call :CheckTools
if "%TOOLS_OK%"=="1" (
  echo.
  echo SUCCESS: ARM GNU toolchain is ready.
  echo.
  arm-none-eabi-gcc --version | more /E +0
  exit /b 0
)

echo.
echo ERROR: ARM GNU toolchain still not found after install attempt.
echo Please close this terminal and run RUN_SERVER.bat again.
echo If it still fails, manually add the ARM toolchain bin folder to PATH.
echo Common bin folder examples:
echo   C:\Program Files ^(x86^)\GNU Arm Embedded Toolchain\10 2021.10\bin
echo   C:\Program Files\Arm GNU Toolchain\*\bin
echo.
pause
exit /b 1

:CheckTools
set "TOOLS_OK=0"
where arm-none-eabi-gcc >nul 2>nul || exit /b 0
where arm-none-eabi-objcopy >nul 2>nul || exit /b 0
where arm-none-eabi-size >nul 2>nul || exit /b 0
set "TOOLS_OK=1"
exit /b 0

:FindInstalledToolchain
set "ARM_TOOLCHAIN_BIN="
for /f "delims=" %%D in ('dir /b /s /ad "C:\Program Files\Arm GNU Toolchain" 2^>nul') do (
  if exist "%%D\bin\arm-none-eabi-gcc.exe" set "ARM_TOOLCHAIN_BIN=%%D\bin"
)
for /f "delims=" %%D in ('dir /b /s /ad "C:\Program Files (x86)\GNU Arm Embedded Toolchain" 2^>nul') do (
  if exist "%%D\bin\arm-none-eabi-gcc.exe" set "ARM_TOOLCHAIN_BIN=%%D\bin"
)
for /f "delims=" %%D in ('dir /b /s /ad "C:\Program Files (x86)\Arm GNU Toolchain" 2^>nul') do (
  if exist "%%D\bin\arm-none-eabi-gcc.exe" set "ARM_TOOLCHAIN_BIN=%%D\bin"
)
if not "%ARM_TOOLCHAIN_BIN%"=="" (
  set "PATH=%ARM_TOOLCHAIN_BIN%;%PATH%"
)
exit /b 0

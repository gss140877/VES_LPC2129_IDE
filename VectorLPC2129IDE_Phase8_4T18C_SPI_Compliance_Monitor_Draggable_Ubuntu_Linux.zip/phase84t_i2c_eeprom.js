/* Phase 8.4T4 — LPC2129 single I2C + 24LC512 breakout visual + observer diagnostics.
   The worker owns I2C/EEPROM behavior. This file only renders the circuit and diagnostics. */
(function(){'use strict';
let z=69000,lastSig='',wireRAF=0;
const $=id=>document.getElementById(id);
const hex=(v,n=2)=>'0x'+Number(v||0).toString(16).toUpperCase().padStart(n,'0');
function scene(){return $('scene')||$('canvas')||$('p72CanvasHost')}
function currentState(){return window.lpcI2C||window.i2cWorkerState||{}}
function dragResize(p){
 const h=p.querySelector('.p84t-panel-head');let drag=false,ox=0,oy=0;
 h.addEventListener('mousedown',e=>{if(e.button!==0||e.target.closest('button'))return;drag=true;const r=p.getBoundingClientRect();ox=e.clientX-r.left;oy=e.clientY-r.top;p.style.zIndex=String(++z);e.preventDefault()});
 addEventListener('mousemove',e=>{if(drag){p.style.left=Math.max(4,e.clientX-ox)+'px';p.style.top=Math.max(62,e.clientY-oy)+'px';p.style.right='auto';p.style.bottom='auto'}});addEventListener('mouseup',()=>drag=false);
 const rh=document.createElement('div');rh.className='p84t-resize';p.appendChild(rh);rh.addEventListener('mousedown',e=>{const r=p.getBoundingClientRect(),sx=e.clientX,sy=e.clientY;function mv(ev){p.style.width=Math.max(330,r.width+ev.clientX-sx)+'px';p.style.height=Math.max(220,r.height+ev.clientY-sy)+'px'}function up(){removeEventListener('mousemove',mv,true);removeEventListener('mouseup',up,true)}addEventListener('mousemove',mv,true);addEventListener('mouseup',up,true);e.preventDefault();e.stopPropagation()});p.addEventListener('mousedown',()=>p.style.zIndex=String(++z),true);
}
function panel(id,title,x,y,w,h,klass){let p=$(id);if(p)return p;p=document.createElement('div');p.id=id;p.className='p84t-panel';Object.assign(p.style,{left:x+'px',top:y+'px',width:w+'px',height:h+'px',display:'none'});p.innerHTML='<div class="p84t-panel-head"><span>'+title+'</span><button title="Close">×</button></div><div class="p84t-panel-body '+(klass||'')+'"></div>';document.body.appendChild(p);p.querySelector('button').onclick=()=>p.style.display='none';dragResize(p);return p}
function ensurePanels(){
 panel('p84tI2CSfr','Communication / I²C / LPC2129 SFR',330,105,390,355,'sfr');
 panel('p84tI2CAnalyzer','Communication / I²C / Protocol Analyzer',735,105,455,355,'analyzer');
 panel('p84tEepromMemory','Communication / I²C / 24LC512 Memory',515,475,610,330,'memory');
}
function openPanel(id){ensurePanels();const p=$(id);if(p){p.style.display='block';p.style.zIndex=String(++z);paint(true)}}
function boardMarkup(){return `
 <div class="p84t-brd-silk top">VECTOR INDIA · I²C EEPROM BREAKOUT</div>
 <div class="p84t-brd-title">24LC512</div><div class="p84t-brd-sub">512-Kbit Serial EEPROM · 64 KByte · 0x50</div>
 <div class="p84t-soic8"><i class="dot"></i><span>24LC512</span><small>SOIC-8</small><b class="p1"></b><b class="p2"></b><b class="p3"></b><b class="p4"></b><b class="p5"></b><b class="p6"></b><b class="p7"></b><b class="p8"></b></div>
 <div class="p84t-r r1"><i></i><span>R1<br>4K7</span></div><div class="p84t-r r2"><i></i><span>R2<br>4K7</span></div>
 <div class="p84t-cap"><i></i><span>C1<br>100n</span></div>
 <div class="p84t-addr"><span>A0</span><span>A1</span><span>A2</span><b>0</b><b>0</b><b>0</b></div>
 <div class="p84t-berg-label">J1 · BERG HEADER</div>
 <div class="p84t-berg"><span class="pin p84t-bergpin vcc" data-node="p84t512.VCC" data-tip="24LC512 VCC — 3.3 V"><i></i><em>VCC</em></span><span class="pin p84t-bergpin gnd" data-node="p84t512.GND" data-tip="24LC512 GND"><i></i><em>GND</em></span><span class="pin p84t-bergpin scl" data-node="p84t512.SCL" data-tip="24LC512 SCL"><i></i><em>SCL</em></span><span class="pin p84t-bergpin sda" data-node="p84t512.SDA" data-tip="24LC512 SDA"><i></i><em>SDA</em></span></div>
 <div class="p84t-trace t-vcc"></div><div class="p84t-trace t-scl"></div><div class="p84t-trace t-sda"></div>
 <div class="p84t-busled"><i id="p84tI2CLed"></i><span>I²C ACT</span></div>
 <div class="p84t-note">SCL/SDA pulled up on breakout</div>`}
function ensureCanvas(){let b=$('p84t512Breakout');if(b)return b;const h=scene();if(!h)return null;
 b=document.createElement('div');b.id='p84t512Breakout';b.className='p84t-eeprom-breakout';b.innerHTML=boardMarkup();h.appendChild(b);
 let svg=$('p84tI2CWires');if(!svg){svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('id','p84tI2CWires');svg.setAttribute('class','p84t-i2c-wires');svg.innerHTML='<path id="p84tWireVCC" class="p84t-wire vcc"/><path id="p84tWireGND" class="p84t-wire gnd"/><path id="p84tWireSCL" class="p84t-wire scl"/><path id="p84tWireSDA" class="p84t-wire sda"/><circle id="p84tDotSCL" class="p84t-dot scl" r="4"/><circle id="p84tDotSDA" class="p84t-dot sda" r="4"/>';h.appendChild(svg)}
 requestWireUpdate();return b}
function qNode(n){const h=scene();return h&&h.querySelector('[data-node="'+n+'"]')}
function point(el){const h=scene();if(!h||!el)return null;const hr=h.getBoundingClientRect(),r=el.getBoundingClientRect();const sx=hr.width/(h.offsetWidth||hr.width||1),sy=hr.height/(h.offsetHeight||hr.height||1);return{x:(r.left+r.width/2-hr.left)/sx,y:(r.top+r.height/2-hr.top)/sy}}
function route(a,b){if(!a||!b)return'';const bend=Math.max(a.x+34,Math.min(b.x-28,a.x+(b.x-a.x)*.48));return `M ${a.x.toFixed(1)} ${a.y.toFixed(1)} H ${bend.toFixed(1)} V ${b.y.toFixed(1)} H ${b.x.toFixed(1)}`}
function updateWires(){wireRAF=0;const h=scene(),svg=$('p84tI2CWires');if(!h||!svg||svg.style.display==='none')return;svg.setAttribute('viewBox',`0 0 ${h.offsetWidth||1200} ${h.offsetHeight||700}`);
 const pairs=[['p84tWireVCC','uno.3V3','p84t512.VCC'],['p84tWireGND','uno.GND','p84t512.GND'],['p84tWireSCL','uno.P0_2','p84t512.SCL'],['p84tWireSDA','uno.P0_3','p84t512.SDA']];
 for(const [id,a,b] of pairs){const p1=point(qNode(a)),p2=point(qNode(b)),path=$(id);if(path)path.setAttribute('d',route(p1,p2))}
 const s1=point(qNode('p84t512.SCL')),s2=point(qNode('p84t512.SDA'));if(s1){$('p84tDotSCL').setAttribute('cx',s1.x);$('p84tDotSCL').setAttribute('cy',s1.y)}if(s2){$('p84tDotSDA').setAttribute('cx',s2.x);$('p84tDotSDA').setAttribute('cy',s2.y)}}
function requestWireUpdate(){if(!wireRAF)wireRAF=requestAnimationFrame(updateWires)}
function show(){const b=ensureCanvas();if(b)b.style.display='block';const s=$('p84tI2CWires');if(s)s.style.display='block';try{window.phase72ShowCanvas&&window.phase72ShowCanvas()}catch(e){};setTimeout(requestWireUpdate,30);setTimeout(requestWireUpdate,250)}
function hide(){const b=$('p84t512Breakout'),s=$('p84tI2CWires');if(b)b.style.display='none';if(s)s.style.display='none'}
function statusName(st){const m={0x08:'START transmitted',0x10:'Repeated START transmitted',0x18:'SLA+W transmitted — ACK',0x20:'SLA+W transmitted — NACK',0x28:'Data transmitted — ACK',0x30:'Data transmitted — NACK',0x40:'SLA+R transmitted — ACK',0x48:'SLA+R transmitted — NACK',0x50:'Data received — ACK returned',0x58:'Data received — NACK returned',0xF8:'Idle / no relevant state'};return m[st&0xF8]||'I²C state'}
function renderSfr(s){const p=$('p84tI2CSfr');if(!p||p.style.display==='none')return;const ok=!!s.pinsConfigured;p.querySelector('.p84t-panel-body').innerHTML=`<div class="p84t-kpi"><span class="${ok?'good':'warn'}">${ok?'P0.2=SCL · P0.3=SDA':'PINSEL0 not configured for I²C'}</span><span>${s.active?'BUS ACTIVE':'BUS IDLE'}</span></div><table><thead><tr><th>SFR</th><th>Address</th><th>Value</th></tr></thead><tbody><tr><td>I2CONSET</td><td>0xE001C000</td><td>${hex(s.CONSET,2)}</td></tr><tr class="focus"><td>I2STAT</td><td>0xE001C004</td><td>${hex(s.STAT,2)}</td></tr><tr><td>I2DAT</td><td>0xE001C008</td><td>${hex(s.DAT,2)}</td></tr><tr><td>I2ADR</td><td>0xE001C00C</td><td>${hex(s.ADR,2)}</td></tr><tr><td>I2SCLH</td><td>0xE001C010</td><td>${hex(s.SCLH,4)}</td></tr><tr><td>I2SCLL</td><td>0xE001C014</td><td>${hex(s.SCLL,4)}</td></tr><tr><td>I2CONCLR</td><td>0xE001C018</td><td>write-only</td></tr></tbody></table><div class="p84t-state"><b>${hex(s.STAT,2)}</b><span>${statusName(Number(s.STAT||0))}</span></div>`}
function renderAnalyzer(s){const p=$('p84tI2CAnalyzer');if(!p||p.style.display==='none')return;const ev=s.events||[];let html='<div class="p84t-an-head"><span>TIME µs</span><span>TYPE</span><span>DETAIL</span></div>';for(const e of ev.slice(-20)){const k=String(e.kind||''),d=Number(e.data||0);let text=hex(d,2);if(k==='ADDR')text=hex(d,2)+' → '+hex((d>>1)&0x7f,2)+(d&1?' READ':' WRITE');else if(k==='STAT')text=statusName(d);else if(k==='STOP')text='STOP condition';html+=`<div class="p84t-an-row ${k.toLowerCase()}"><span>${Number(e.t||0).toFixed(0)}</span><b>${k}</b><span>${text}</span></div>`}if(!ev.length)html+='<div class="p84t-empty">Build and run the 24LC512 example to capture bus transactions.</div>';p.querySelector('.p84t-panel-body').innerHTML=html}
function renderMemory(s){const p=$('p84tEepromMemory');if(!p||p.style.display==='none')return;const e=s.eeprom||{},a=e.window||[],base=Number(e.windowBase||0);let rows='';for(let r=0;r<4;r++){let bytes='',ascii='';for(let c=0;c<16;c++){const v=Number(a[r*16+c]||0)&255;bytes+='<span>'+v.toString(16).toUpperCase().padStart(2,'0')+'</span>';ascii+=(v>=32&&v<=126)?String.fromCharCode(v):'.'}rows+=`<div class="p84t-mem-row"><b>${(base+r*16).toString(16).toUpperCase().padStart(4,'0')}</b><div>${bytes}</div><em>${ascii}</em></div>`}p.querySelector('.p84t-panel-body').innerHTML=`<div class="p84t-mem-kpi"><span>24LC512 <b>${hex(e.address===undefined?0x50:e.address,2)}</b></span><span>Pointer <b>${hex(e.pointer,4)}</b></span><span>Writes <b>${e.writeCount||0}</b></span><span>Reads <b>${e.readCount||0}</b></span></div><div class="p84t-mem-head"><b>ADDR</b><span>00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F</span><i>ASCII</i></div>${rows}`}
function paint(force){const s=currentState(),e=s.eeprom||{};const sig=[s.CONSET,s.STAT,s.DAT,s.ADR,s.SCLH,s.SCLL,s.active,s.pinsConfigured,e.pointer,e.writeCount,e.readCount,(s.events||[]).length,(e.window||[]).join(',')].join('|');if(!force&&sig===lastSig)return;lastSig=sig;const led=$('p84tI2CLed');if(led)led.classList.toggle('on',!!s.active);renderSfr(s);renderAnalyzer(s);renderMemory(s)}
window.phase84tShowI2CEepromLab=show;window.phase84tHideI2CEepromLab=hide;
window.phase84tShowI2CSfr=()=>openPanel('p84tI2CSfr');window.phase84tShowI2CAnalyzer=()=>openPanel('p84tI2CAnalyzer');window.phase84tShowEepromMemory=()=>openPanel('p84tEepromMemory');
window.addEventListener('resize',requestWireUpdate);window.addEventListener('load',()=>setTimeout(()=>{ensurePanels();setInterval(()=>{paint(false);requestWireUpdate()},220)},1600));
})();

/* Phase 8.4T5 override: breakout is now a canonical project.parts component; legacy overlay renderer is disabled. */

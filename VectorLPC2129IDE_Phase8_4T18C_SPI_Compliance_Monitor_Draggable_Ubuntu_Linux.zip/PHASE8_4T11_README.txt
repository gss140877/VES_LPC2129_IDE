Phase 8.4T11 — Complete EEPROM / ROM / RAM Memory Viewers

Added without changing LPC2129 execution/peripheral timing:
1. 24LC512 complete memory viewer
   Address range 0x0000–0xFFFF (64 KB)
   Scrollable complete address space
   Go To Address box
   16 bytes/row + ASCII
   Live visible-region refresh

2. LPC2129 ROM / Flash complete viewer
   Address range 0x00000000–0x0003FFFF (256 KB)
   Scrollable complete address space
   Go To Address box
   16 bytes/row + ASCII
   Reads actual worker Flash bytes
   Intended for code, constants and .rodata inspection

3. LPC2129 SRAM complete viewer
   Address range 0x40000000–0x40003FFF (16 KB)
   Scrollable complete address space
   Go To Address box
   16 bytes/row + ASCII
   Live visible-region refresh
   Intended for .data, .bss, stack and runtime-variable inspection

Access:
- Communication > 24LC512 Memory opens the enhanced full EEPROM viewer.
- IDE View > ROM / Flash Memory
- IDE View > RAM Memory
- Debug toolbar also has ROM and RAM buttons.

Implementation:
Memory viewers are virtualized. The scrollbar represents the complete physical address
range, while only the visible rows are fetched from the ARM7 worker. This avoids freezing
the browser while still exposing every address.

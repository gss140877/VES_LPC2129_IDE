VECTOR LPC2129 IDE — Phase 7.4F

- Uses the previously approved/generated VECTOR LPC2129 board PNG directly as the board component image.
- No replacement board artwork was generated for this build.
- 46 existing LPC2129 electrical node IDs are preserved.
- I/O 1..23 overlays the 23 visible top header sockets.
- I/O 24..46 overlays the 23 visible bottom header sockets.
- Hit boxes are positioned from normalized source-image socket-center coordinates, so canvas scaling/zoom keeps them registered with the image.
- 5V, 3.3V and GND remain connectable power nodes and overlay their visible right-side power sockets.
- The image itself contains the corrected 10-pin JTAG header.

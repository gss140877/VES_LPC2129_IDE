(function(){
'use strict';let z=61000;
function st(n){return (window.lpcSPI&&window.lpcSPI[n])||{}}
function panel(id,title,x,y,w,h){
 let p=document.getElementById(id);if(p)return p;p=document.createElement('div');p.id=id;p.className='spiDbg';
 p.style.cssText=`left:${x}px;top:${y}px;width:${w}px;height:${h}px`;
 p.innerHTML=`<div class="spiDbgHead"><b>${title}</b><button>×</button></div><div class="spiDbgBody"></div>`;
 document.body.appendChild(p);p.querySelector('button').onclick=()=>p.style.display='none';
 let on=false,ox=0,oy=0,hdr=p.querySelector('.spiDbgHead');hdr.onmousedown=e=>{on=true;ox=e.clientX-p.offsetLeft;oy=e.clientY-p.offsetTop;p.style.zIndex=++z};
 window.addEventListener('mousemove',e=>{if(on){p.style.left=Math.max(0,e.clientX-ox)+'px';p.style.top=Math.max(55,e.clientY-oy)+'px'}});window.addEventListener('mouseup',()=>on=false);return p;
}
function hx(v,d=8){return '0x'+(Number(v||0)>>>0).toString(16).toUpperCase().padStart(d,'0')}
function showSfr(n){const p=panel('spiSfr'+n,'Communication / SPI / SPI'+n+' SFR',360+n*35,145+n*25,440,300);p.style.display='block';renderSfr(n)}
function renderSfr(n){const p=document.getElementById('spiSfr'+n);if(!p||p.style.display==='none')return;const s=st(n),base=n?0xE0030000:0xE0020000;
 const rows=[['S'+n+'SPCR',base,s.SPCR],['S'+n+'SPSR',base+4,s.SPSR],['S'+n+'SPDR',base+8,s.SPDR],['S'+n+'SPCCR',base+0xC,s.SPCCR],['S'+n+'SPINT',base+0x1C,s.SPINT]];
 p.querySelector('.spiDbgBody').innerHTML=`<div class="spiKpi"><span>${s.master?'MASTER':'SLAVE'}</span><span>Pins ${s.pinsConfigured?'OK':'NOT CONFIGURED'}</span><span>Transfers ${s.transfers||0}</span></div>`+rows.map(r=>`<div class="spiReg"><b>${r[0]}</b><span>${hx(r[1])}</span><em>${hx(r[2])}</em></div>`).join('')+`<div class="spiBits">SPSR: SPIF=${!!(s.SPSR&0x80)} WCOL=${!!(s.SPSR&0x40)} ROVR=${!!(s.SPSR&0x20)} MODF=${!!(s.SPSR&0x10)} ABRT=${!!(s.SPSR&0x08)}</div>`;
}
function showAnalyzer(){const p=panel('spiAnalyzer','Communication / SPI / Protocol Analyzer',500,175,560,340);p.style.display='block';renderAnalyzer()}
function renderAnalyzer(){const p=document.getElementById('spiAnalyzer');if(!p||p.style.display==='none')return;const s=st(0),ev=s.events||[],ee=(s.eeprom||{}).events||[];
 let a=ev.slice(-24).map(e=>`<div class="spiEv"><span>${Number(e.t||0).toFixed(0)} µs</span><b>${e.kind}</b><em>${e.kind==='XFER'?'TX '+hx((e.data>>8)&255,2)+' / RX '+hx(e.data&255,2):hx(e.data,4)}</em></div>`).join('');
 let b=ee.slice(-16).map(e=>`<div class="spiEv dev"><span>${Number(e.t||0).toFixed(0)} µs</span><b>25LC512 ${e.kind}</b><em>${hx(e.data,e.kind==='ADDR'?4:2)}</em></div>`).join('');
 p.querySelector('.spiDbgBody').innerHTML=a+b||'<div class="spiEmpty">Run the SPI0 + 25LC512 example to capture transactions.</div>';
}
window.phase84t14ShowSPI0Sfr=()=>showSfr(0);window.phase84t14ShowSPI1Sfr=()=>showSfr(1);window.phase84t14ShowSPIAnalyzer=showAnalyzer;
setInterval(()=>{renderSfr(0);renderSfr(1);renderAnalyzer()},300);
})();
Phase 8.4T10
Toolbar restoration fix.

Root cause in T9:
Two extra closing </div> tags immediately after the Communication toolbar group
prematurely closed the main .topbar.

Fix:
Only those two erroneous closing tags were removed.

Expected topbar controls are restored:
- C Examples
- ASM Examples
- Communication
- New
- Save Project
- Load Project
- Build HEX
- Run Simulation
- Download HEX
- Log
- Debug panel selector
- Show Debug
- Clock / Timing
- Refresh COM
- COM selector
- Flash Magic ISP
- Serial
- Baud selector

Communication popup remains the flat overlay with:
- UART0 Terminal
- UART1 Terminal
- LPC2129 I2C SFR
- Protocol Analyzer
- 24LC512 Memory

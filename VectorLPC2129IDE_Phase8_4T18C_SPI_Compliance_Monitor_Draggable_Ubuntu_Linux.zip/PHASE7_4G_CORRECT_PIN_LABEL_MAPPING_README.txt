VECTOR LPC2129 IDE — Phase 7.4G

Fix:
- Corrected the hover/popup pin labels so they exactly match the labels printed on the integrated board image.
- I/O 1..23  -> P0.0 .. P0.22
- I/O 24..32 -> P0.23 .. P0.31
- I/O 33..46 -> P1.16 .. P1.29
- Pin numbers, image alignment, hit boxes, and existing electrical node IDs are preserved.
- 5V / 3.3V / GND hover labels remain unchanged.

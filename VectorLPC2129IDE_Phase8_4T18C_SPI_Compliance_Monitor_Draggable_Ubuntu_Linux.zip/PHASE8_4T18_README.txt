Phase 8.4T18 — Debug Clear + Complete CAN SFR Visibility

Built on user-validated T17.

Changes:
- Added Clear buttons to I2C, SPI and CAN monitor/debug windows.
- Clear removes previous observation logs/counters without erasing EEPROM/Flash/RAM or rewriting live SFR values.
- Added Clear to all complete memory viewers; it clears the displayed observation only. Use Refresh to read physical simulated memory again.
- CAN1/CAN2 SFR windows expanded and made vertically scrollable.
- CAN SFR display now includes the complete controller/receive set plus all three transmit buffers:
  MOD, CMR(write-only), GSR, ICR, IER, BTR, EWL, SR, RFS, RID, RDA, RDB,
  TFI1/TID1/TDA1/TDB1, TFI2/TID2/TDA2/TDB2, TFI3/TID3/TDA3/TDB3.
- C1TDA/C1TDB and corresponding CAN2/transmit-buffer registers are now directly visible.

No protocol-engine redesign was performed in this patch; T16/T17 compliance behavior is preserved.

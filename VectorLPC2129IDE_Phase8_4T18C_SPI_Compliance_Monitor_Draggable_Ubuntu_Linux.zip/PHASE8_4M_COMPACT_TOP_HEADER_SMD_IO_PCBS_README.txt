VECTOR LPC2129 IDE — Phase 8.4M
Compact Top-Header SMD I/O PCBs

Changes from 8.4L:
- LED Output PCB and Switch Input PCB reduced in form factor while preserving existing label/font sizes.
- All eight signal Berg/header pads moved close to the upper PCB edge and kept fully inside the board outline.
- Signal headers remain outward/upward facing for easy canvas wiring.
- 3.3V and GND Berg/header pads moved to the upper-left side of each PCB.
- Internal component spacing tightened without changing electrical behavior.
- Existing ARM7TDMI-S + LPC2129 canonical CPU/peripheral/GPIO architecture is unchanged.
- Phase 8.4H timing behavior remains untouched.

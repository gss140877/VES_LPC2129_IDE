VECTOR LPC2129 IDE — Phase 8.3M

- Based on confirmed-working Phase 8.3L functionality.
- UART/AUX four-LED bank relocated over former JTAG artwork region.
- Reusable onboard switch/LED trainer centered below LPC2129 package.
- SW and LED each expose a Berg-header node that can be visibly wired to any canonical LPC2129 GPIO pin.
- AL/AH switch polarity and AL/AH LED polarity retained.
- Existing four P1.30/P1.31 C examples automatically create visible P1.30->SW and P1.31->LED jumpers.
- Phase 8.3J orthogonal draggable board-wire editor extended to SW/LED Berg nodes.
- Electrical behavior remains project.wires + canonical GPIO; no source-parser shortcut.
- Approved vector_lpc2129_board.png bytes are unchanged; the UART bank overlay masks the JTAG artwork region at runtime.

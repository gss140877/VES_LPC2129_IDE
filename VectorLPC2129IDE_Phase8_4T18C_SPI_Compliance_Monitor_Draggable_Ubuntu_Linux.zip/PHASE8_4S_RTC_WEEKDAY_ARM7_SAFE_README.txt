VECTOR LPC2129 IDE Phase 8.4S
RTC weekday UART example ARM7-safe formatting fix

Observed Phase 8.4R symptom: output stopped at 07/09/202 and firmware restarted.
Root cause: weekday switch could compile to a jump-table/control-flow sequence not safely handled by the current ARM execution path.
Fix: replace weekday switch with simple if/return comparisons; retain subtraction-only decimal formatting.
Expected: 07/09/2026,Mon  16:07:00
RTC 32.768 kHz engine and Phase 8.4H canonical timing are unchanged.

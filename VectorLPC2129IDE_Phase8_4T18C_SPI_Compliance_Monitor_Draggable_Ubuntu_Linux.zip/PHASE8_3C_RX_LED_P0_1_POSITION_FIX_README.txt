Phase 8.3C positional correction only.

RX yellow SMD activity LED moved from the P0.2 alignment to the P0.1 alignment.
No board image was changed.
RESET, PWR, TX, VIC, UART IRQ, worker runtime and hardware-reset behavior are unchanged.

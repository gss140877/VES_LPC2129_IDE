VECTOR LPC2129 IDE — Phase 8.4A
ON-CHIP ADC + 4-CHANNEL TRIMPOT CANVAS + UART0 EXAMPLES

Baseline
--------
Built directly from the user-confirmed Phase 8.3Q baseline.
The approved LPC2129 board image is not replaced or regenerated.

ADC hardware model
------------------
Target: LPC2129 64-pin, four physical 10-bit ADC inputs:
  AIN0 = P0.27
  AIN1 = P0.28
  AIN2 = P0.29
  AIN3 = P0.30

Implemented worker-side memory mapped ADC engine:
  ADCR    0xE0034000
  ADGDR   0xE0034004
  ADINTEN 0xE003400C
  ADDR0   0xE0034010
  ADDR1   0xE0034014
  ADDR2   0xE0034018
  ADDR3   0xE003401C
  ADDR4-7 register-compatible storage is present but LPC2129 64-pin exposes only AIN0-3.
  ADSTAT  0xE0034030

Mode/timing behavior:
  - SEL channel selection
  - CLKDIV and ADC clock calculation from PCLK
  - PDN operational/power-down behavior
  - software START=001 conversion
  - BURST scan sequencing
  - CLKS burst accuracy 10-bit down to 3-bit
  - conversion completion after the selected ADC clock count
  - ADGDR RESULT/CHN/DONE/OVERRUN
  - channel ADDRn RESULT/DONE/OVERRUN
  - ADSTAT DONE/OVERRUN/ADINT aggregation
  - ADINTEN channel/global interrupt enable
  - VIC source 18 ADC end-of-conversion integration
  - START 010..111 hardware-trigger arm/edge hooks for P0.16, P0.22 and MAT sources.

The ADC engine is inside the ARM7 worker. Firmware must access the actual LPC2129
memory-mapped registers. There is no C-source parser or example-specific ADC shortcut.

Canonical analog path
---------------------
Circuit Canvas trimpot -> physical wire graph -> LPC2129 P0.27..P0.30/AIN0..AIN3
-> worker analog input -> ADC sample/convert -> ADGDR/ADDRn -> ARM7 firmware -> UART0.

A trimpot is considered electrically active only when:
  terminal 1 is actually wired to board 3.3V,
  terminal 3 is actually wired to board GND, and
  its wiper is actually wired to the corresponding physical ADC pin.
Disconnecting/re-wiring the Circuit Canvas therefore changes the ADC input without
source-code shortcuts.

Circuit Canvas
--------------
The ADC examples automatically create four compact professional-style 10 k trimpots.
Each contains:
  - multi-turn trimmer-style body/screw artwork
  - 0..1023 interactive adjustment
  - live raw code and 0.000..3.300 V indication
  - three Berg-style terminals: 3.3V, WIPER, GND

The four wipers are wired to P0.27, P0.28, P0.29 and P0.30 respectively.
All four are also visibly wired to the board 3.3V and GND terminals.

C examples
----------
1. phase84_c_adc0_uart0.c
   Single AIN0 software-trigger conversion with UART0 output.

2. phase84_c_adc4_uart0.c
   Sequential software-trigger polling of all four channels.
   UART0 output format includes both the 10-bit decimal code and voltage equivalent.

3. phase84_c_adc4_burst_uart0.c
   Four-channel BURST scan using ADDR0..ADDR3 dedicated result registers.

Example serial format
---------------------
AIN0  DEC=128  FLOAT=0.413 V
AIN1  DEC=384  FLOAT=1.239 V
AIN2  DEC=640  FLOAT=2.065 V
AIN3  DEC=896  FLOAT=2.891 V

Note on "FLOAT"
---------------
The displayed value is the voltage-equivalent decimal value to three fractional digits.
The examples intentionally use an integer/fixed-point formatter because this IDE builds
freestanding C with -nostdlib; therefore the example does not depend on printf() or a C
floating-point formatting library. The ADC conversion itself is still the LPC2129 10-bit
result (0..1023) referenced to 3.3 V.

Accuracy statement
------------------
This build aims for register-accurate LPC2129 ADC teaching/simulation behavior based on
NXP UM10114. It is not a silicon-certified electrical SPICE/noise/non-linearity model.
Analog noise, source impedance acquisition error, INL/DNL, VDDA ripple and temperature
characteristics are intentionally not synthesized unless explicitly added later.

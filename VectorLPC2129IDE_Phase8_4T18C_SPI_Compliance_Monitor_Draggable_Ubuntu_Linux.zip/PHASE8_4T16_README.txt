Phase 8.4T16 — LPC2129 I2C + 24LC512 Compliance Engine

This is the first compliance-phase build. T15 remains the functional baseline.

Implemented in T16:
- LPC2129 I2CONSET/I2STAT/I2DAT/I2ADR/I2SCLH/I2SCLL/I2CONCLR behavior.
- Master START and repeated START states.
- SLA+W ACK/NACK, data TX ACK/NACK, SLA+R ACK/NACK, RX ACK/NACK.
- Arbitration-lost state 0x38 injection path.
- Bus-error state 0x00 injection/path.
- SI-driven firmware state progression.
- SCL rate and byte-time derived from SCLH/SCLL and PCLK model.
- Clock-stretch delay model and SCL/SDA external fault state.
- Timestamped protocol state transitions.

24LC512:
- Erased state 0xFF.
- 64 KB address space and 16-bit word address.
- 128-byte page buffer with physical page-wrap semantics.
- Writes committed on STOP rather than immediately.
- Configurable 5 ms internal write-cycle busy period.
- Address NACK while internal write cycle is busy.
- ACK-polling compatible behavior.
- WP state blocks write programming.
- Sequential current-address read.

Example:
- "Vector India Pvt Ltd".
- Byte Write + ACK Polling + Random Read into LPC2129 RAM.
- Page Write + ACK Polling + Sequential Read into LPC2129 RAM.

New debug:
Communication > I2C > I2C / 24LC512 Compliance Monitor
- I2STAT decode
- SCL frequency / byte time
- EEPROM busy/write-cycle state
- page size and WP state
- timestamped I2C state timeline
- arbitration-lost injection
- clock-stretch injection
- WP control

Important scope statement:
T16 materially increases I2C/24LC512 fidelity, but it is not labelled final 100% compliance yet.
Remaining work before final compliance includes full LPC2129 slave-mode state coverage,
multi-master bit-level SDA arbitration against another active master, full VIC timing validation,
and automated conformance/regression vectors for every documented state.

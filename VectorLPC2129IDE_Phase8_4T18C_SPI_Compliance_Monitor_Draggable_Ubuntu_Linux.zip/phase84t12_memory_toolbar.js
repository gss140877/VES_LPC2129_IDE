(function(){
'use strict';
if(window.__phase84t12MemoryToolbar)return;
window.__phase84t12MemoryToolbar=true;

function id(x){return document.getElementById(x)}
function place(){
  const b=id('memoryBtn'),m=id('memoryMenu');
  if(!b||!m)return;
  const r=b.getBoundingClientRect();
  const width=m.offsetWidth||238;
  m.style.left=Math.max(4,Math.min(r.left,window.innerWidth-width-6))+'px';
  m.style.top=(r.bottom+2)+'px';
}
function openMenu(){
  const m=id('memoryMenu'),b=id('memoryBtn');
  if(!m||!b)return;
  m.classList.add('memoryOpen');
  b.setAttribute('aria-expanded','true');
  requestAnimationFrame(place);
}
function closeMenu(){
  const m=id('memoryMenu'),b=id('memoryBtn');
  if(m)m.classList.remove('memoryOpen');
  if(b)b.setAttribute('aria-expanded','false');
}
function show(action){
  let fn=null;
  if(action==='eeprom')fn=window.phase84t11ShowEepromMemory||window.phase84tShowEepromMemory;
  else if(action==='spieeprom')fn=window.phase84t14ShowSpiEepromMemory;
  else if(action==='flash')fn=window.phase84t11ShowFlashMemory;
  else if(action==='ram')fn=window.phase84t11ShowRamMemory;
  if(typeof fn==='function'){
    fn();
  }else{
    console.error('Memory viewer function unavailable:',action);
    alert('Memory viewer is not loaded: '+action);
  }
  closeMenu();
}
function install(){
  const b=id('memoryBtn'),m=id('memoryMenu');
  if(!b||!m)return;
  b.addEventListener('click',e=>{
    e.preventDefault();e.stopPropagation();
    if(m.classList.contains('memoryOpen'))closeMenu(); else openMenu();
  });
  m.addEventListener('click',e=>{
    const t=e.target.closest('[data-memory-action]');
    if(!t)return;
    e.preventDefault();e.stopPropagation();
    show(t.dataset.memoryAction);
  });
  document.addEventListener('click',e=>{
    if(!e.target.closest('#memoryToolbarGroup')&&!e.target.closest('#memoryMenu'))closeMenu();
  });
  window.addEventListener('resize',()=>{if(m.classList.contains('memoryOpen'))place()});
  window.addEventListener('scroll',()=>{if(m.classList.contains('memoryOpen'))place()},true);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install);
else install();
})();
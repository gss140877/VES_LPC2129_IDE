VECTOR LPC2129 IDE — Phase 8.4T
Protected base: Phase 8.4S RTC Weekday ARM7 Safe

ADDED ONLY:
- LPC2129 on-chip I2C SFR engine at 0xE001C000..0xE001C018
- SCL=P0.2 / SDA=P0.3 function validation through PINSEL0
- 24LC256 EEPROM device model, 7-bit address 0x50, 32 KiB memory
- Separate Embedded C example: phase84t_c_i2c_24lc256.c
- Professional green breakout PCB observer with standard DIP-8 IC representation
- Lightweight I2C protocol monitor (120 ms differential refresh; bounded event history)

EXAMPLE FLOW:
Byte Write 0x5A @ 0x0123 -> Random Read -> Page Write 8 bytes @ 0x0200 -> Sequential Read 8 bytes.
Inspect eeprom_byte_readback and eeprom_page_readback in the debugger/source runtime state.

PRESERVATION RULE:
No existing component/device source file was replaced. Only minimal dispatcher/menu/index hooks were made in existing files.
Phase 8.4H timebase, RTC 32.768 kHz path, PWM, ADC, Timers, GPIO, UART, VIC and trainer logic remain on their existing paths.

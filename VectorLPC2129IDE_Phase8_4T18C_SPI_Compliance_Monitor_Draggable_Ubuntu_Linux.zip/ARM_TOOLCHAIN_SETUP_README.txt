ARM GNU Toolchain Auto Check / Install
=====================================

Use RUN_SERVER.bat to start the simulator.

What RUN_SERVER.bat now does:
1. Checks for arm-none-eabi-gcc, arm-none-eabi-objcopy, and arm-none-eabi-size.
2. Searches common ARM toolchain installation folders.
3. If not found, tries to install using Windows Package Manager:

   winget install -e --id Arm.GnuArmEmbeddedToolchain --source winget

4. Starts the Node.js simulator server.
5. Opens the frontend at http://localhost:3000.

Manual test commands:

   arm-none-eabi-gcc --version
   arm-none-eabi-objcopy --version
   arm-none-eabi-size --version

If winget installation succeeds but the tools are still not detected, close the terminal
and run RUN_SERVER.bat again so Windows PATH refreshes.

Assembly source support added
-----------------------------
The web editor now has a Source type selector:
  - C Source: saved as main.c and compiled with the injected LPC2129 C register aliases.
  - Assembly Source: saved as main.s and assembled as GNU ARM assembly using -x assembler-with-cpp.

Use GNU ARM syntax for assembly, not Keil ARMASM syntax. Example directives:
  .syntax unified
  .cpu arm7tdmi
  .arm
  .global main

Keil directives like AREA, ENTRY, EXPORT and END are not accepted by arm-none-eabi-gcc unless converted to GNU syntax.

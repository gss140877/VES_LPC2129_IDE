(function(){
'use strict';
const T1='mcp2551can1',T2='mcp2551can2';
function P(){return typeof project!=='undefined'?project:null}
function find(t){const p=P();return p&&p.parts&&p.parts.find(x=>x.type===t)}
function addWireSafe(a,b){const p=P();if(!p)return;if(!p.wires.some(w=>(w.from===a&&w.to===b)||(w.from===b&&w.to===a)))try{addWire(a,b)}catch(e){}}
function add(type,opt={}){
 const p=P();if(!p)return null;let q=find(type);
 if(!q){const n=type===T1?1:2;q={id:'mcp2551_can'+n,type,x:opt.x??(n===1?770:1040),y:opt.y??285,scale:opt.scale??1};p.parts.push(q)}
 try{selectedId=q.id;render()}catch(e){}
 return q;
}
function connect(){
 const a=find(T1),b=find(T2);if(!a||!b)return;
 addWireSafe('uno.3V3',a.id+'.VCC');addWireSafe('uno.GND',a.id+'.GND');
 addWireSafe('uno.3V3',b.id+'.VCC');addWireSafe('uno.GND',b.id+'.GND');
 addWireSafe('uno.P0_25',a.id+'.RXD');
 addWireSafe('uno.P0_23',b.id+'.RXD');addWireSafe('uno.P0_24',b.id+'.TXD');
 addWireSafe(a.id+'.CANH',b.id+'.CANH');addWireSafe(a.id+'.CANL',b.id+'.CANL');
}
function card(q,n){return `<div class="canPcb">
 <div class="canSilk"><b>VECTOR INDIA</b><span>MCP2551 • CAN${n}</span></div>
 <div class="canMcu"><small>MCU SIDE</small>
   <span class="pin canPin" data-node="${q.id}.TXD"><i></i><b>TXD</b><em>${n===1?'TD1 dedicated':'P0.24/TD2'}</em></span>
   <span class="pin canPin" data-node="${q.id}.RXD"><i></i><b>RXD</b><em>${n===1?'P0.25/RD1':'P0.23/RD2'}</em></span>
 </div>
 <div class="canChip"><div class="legs">${'<i></i>'.repeat(4)}</div><div class="body"><i class="dot"></i><b>MCP2551</b><span>High-Speed CAN</span><em>SOIC-8</em></div><div class="legs">${'<i></i>'.repeat(4)}</div></div>
 <div class="canPower"><span class="pin canPwr" data-node="${q.id}.VCC"><i></i><b>VCC</b></span><span class="pin canPwr" data-node="${q.id}.GND"><i></i><b>GND</b></span></div>
 <div class="canBusSide"><small>CAN BUS</small><span class="pin canBusPin" data-node="${q.id}.CANH"><i></i><b>CANH</b></span><span class="pin canBusPin" data-node="${q.id}.CANL"><i></i><b>CANL</b></span></div>
 <div class="term">120Ω TERM <b>ON</b></div><div class="canFoot">MCP2551 transceiver breakout • ${n===1?'CAN1':'CAN2'}</div></div>`}
function decorate(){const p=P();if(!p)return;p.parts.forEach(q=>{let n=q.type===T1?1:q.type===T2?2:0;if(!n)return;const e=document.getElementById(q.id);if(e){e.classList.add('mcp2551part');e.innerHTML=card(q,n)}})}
const old=window.render;if(typeof old==='function'&&!window.__can15wrap){window.__can15wrap=1;window.render=function(){const r=old.apply(this,arguments);try{decorate();installPinHandlers();drawWires()}catch(e){}return r}}
window.phase84t15AddMCP2551CAN1=()=>{const q=add(T1);connect();try{render()}catch(e){};return q};
window.phase84t15AddMCP2551CAN2=()=>{const q=add(T2);connect();try{render()}catch(e){};return q};
window.phase84t15ShowCanLoopLab=()=>{const a=add(T1),b=add(T2);connect();try{render();window.phase72ShowCanvas&&window.phase72ShowCanvas()}catch(e){};window.phase84t15ConfigureCanBus&&window.phase84t15ConfigureCanBus({connected:true,term1:true,term2:true,mcp1:true,mcp2:true});return [a,b]};
window.addEventListener('load',()=>setTimeout(decorate,1100));
})();
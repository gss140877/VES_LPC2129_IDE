VECTOR LPC2129 IDE — Phase 7.4D
Vertical Header Alignment Refinement

Changes from Phase 7.4C:
- All 46 external I/O positions retain sequential numbering 1..46.
- Removed angled/rotated header text.
- Every header uses a strict common vertical centreline:
  visible socket -> connection hit box -> I/O number -> LPC2129 signal label.
- Top-row labels stack inward below the socket.
- Bottom-row labels stack inward above the socket.
- Hit boxes remain directly centred over the visible sockets.
- Existing electrical data-node IDs and simulator wiring behaviour are unchanged.

VECTOR LPC2129 IDE — Phase 8.0D

Corrections requested:
- C Source / ASM Source selector removed from toolbar.
- CPU Self Test selector and Load Test button removed from toolbar.
- C Examples and ASM Examples remain as the example entry points.
- Selecting an example opens its actual named .c or .s file in a dedicated floating source window.
- Every example source window is editable, draggable, resizable, closeable, reopenable.
- Each source window has Save Source.
- Save Source persists edited source under ./user_sources/<example filename> on the local simulator server.
- The active example source window is synchronized into the compiler input immediately.
- Build HEX compiles the active window content, not stale generic editor content.
- Editing invalidates the previously generated HEX.
- Selecting an example also loads its matching Circuit Canvas wiring.

Rule preserved:
.c/.s -> arm-none-eabi-gcc/GAS -> ELF/HEX -> ARM7TDMI-S -> LPC2129 GPIO -> circuit wiring -> components.

Phase 8.4T9 Communication menu correction
- Replaces hover/nested submenu behavior with one stable fixed overlay.
- Communication dropdown always contains:
  UART0 Terminal
  UART1 Terminal
  LPC2129 I2C SFR
  Protocol Analyzer
  24LC512 Memory
- Menu opens on click and stays open until an item or outside area is clicked.
- Overlay uses viewport-fixed positioning and maximum z-index so canvas cannot hide it.

Phase 8.4T7
1. 24LC512 breakout reduced from 286x174 to 232x138 px.
2. VCC/GND remain vertically stacked on left; SCL/SDA remain on right.
3. Pin/config hit areas are deliberately smaller and hover outlines removed.
4. Communication dropdown is no longer injected by JavaScript.
   It is physically present in index.html inside the main .topbar immediately
   after C Examples / ASM Examples.
5. Communication menu:
   UART -> UART0 Terminal / UART1 Terminal
   I2C  -> LPC2129 I2C SFR / Protocol Analyzer / 24LC512 Memory
6. Existing UART/I2C engines remain the action targets.

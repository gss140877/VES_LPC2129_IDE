VECTOR LPC2129 IDE — Phase 8.4N

LED breakout refinement:
- Removed the separate 8-way LED colour simulation panel.
- Added two compact simulation-only dropdowns in the unused left area of the LED PCB, below the 3V3/GND Berg headers.
- Dropdown 1 selects LED 1..8.
- Dropdown 2 selects the emission colour for the selected LED.
- Colour selection does not alter the electrical model and is not part of the simulated hardware circuit.
- Existing AH/AL DIP selection, 330R channels, top-edge Berg headers, GPIO wiring, ARM7TDMI-S engine and LPC2129 peripheral timing are unchanged.

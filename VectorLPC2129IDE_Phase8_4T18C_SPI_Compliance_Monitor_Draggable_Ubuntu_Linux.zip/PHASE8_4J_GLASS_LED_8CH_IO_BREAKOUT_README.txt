VECTOR LPC2129 IDE — Phase 8.4J

Baseline: user-confirmed Phase 8.4H timing architecture, plus Phase 8.4I LED colour work.

Changes:
1. Standalone external LED casing is neutral clear/glassy when OFF. The selected colour is the emitter colour, not a permanently tinted red casing.
2. Standalone LED repaint is now attached after the canonical LPC2129 GPIO output bridge, so ON brightness is applied on every actual GPIO edge rather than only at initial render.
3. New Components item: "8-CH LED + Switch Breakout".
4. Breakout board has shared 3V3/GND header, 8 SMD LED channels and 8 SMD switch channels.
5. Every LED channel has AH/AL polarity selection, independent colour selection, and an aligned Berg signal pin L1..L8.
6. Every switch channel has AH/AL polarity selection, latching SMD switch, and an aligned Berg signal pin S1..S8.
7. AH LED: GPIO HIGH = LED ON. AL LED: GPIO LOW = LED ON.
8. AH switch: switch ON drives HIGH, OFF drives LOW. AL switch: switch ON drives LOW, OFF drives HIGH.
9. Switch levels are delivered to the ARM7 worker through the existing external GPIO-input path. A release message removes stale drive when board power/wiring is removed.
10. No Timer/LED or source-parser shortcut was added. GPIO output still follows ARM7TDMI-S execution -> LPC2129 GPIO -> project wiring -> component.

Power the breakout by wiring its 3V3 and GND headers to the LPC2129 board supplies before using the 16 channels.

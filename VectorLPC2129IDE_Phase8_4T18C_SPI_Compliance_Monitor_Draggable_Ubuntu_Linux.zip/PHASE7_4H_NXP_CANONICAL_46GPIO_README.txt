VECTOR LPC2129 IDE — Phase 7.4H
NXP-CANONICAL 46-GPIO CORRECTION

Authoritative GPIO set:
- P0.0 through P0.25
- P0.27 through P0.30
- P1.16 through P1.31
Total: 46 GPIO

Not available on LPC2129:
- P0.26
- P0.31

Header mapping:
- I/O 1..23  = P0.0..P0.22
- I/O 24     = P0.23
- I/O 25     = P0.24
- I/O 26     = P0.25
- I/O 27..30 = P0.27..P0.30
- I/O 31..46 = P1.16..P1.31

This build updates:
1. Board-image lower silkscreen labels
2. Hover/popup labels
3. Electrical node IDs attached to each header
4. LPC2129 GPIO monitor availability model
5. Board-definition JSON
6. Canonical GPIO manifest for future builds

The 10-pin JTAG and right-side 5V/3.3V/GND power connectors are retained.

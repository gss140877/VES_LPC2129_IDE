VECTOR LPC2129 IDE — Phase 8.0C

Root cause fixed:
Phase 8.0B looked for .toolbar, but the application toolbar is .topbar.appToolbar.
Therefore no example controls were injected.

Phase 8.0C correction:
- C Examples ▼ and ASM Examples ▼ are now STATIC HTML controls in the real top toolbar.
- They are present immediately at page load; no delayed DOM insertion is required.
- Popup menus are appended to BODY with position:fixed, so the top toolbar's overflow-x/overflow-y rules cannot clip them.
- C dropdown: LED Blink P0.10; Switch P0.14 -> LED P0.10.
- ASM dropdown: LED Blink P0.10; Switch P0.14 -> LED P0.10.
- Example loading still clears previous HEX and preserves the execution rule:
  source -> ARM GCC/GAS -> HEX -> ARM7TDMI-S -> LPC2129 GPIO -> Circuit Canvas.

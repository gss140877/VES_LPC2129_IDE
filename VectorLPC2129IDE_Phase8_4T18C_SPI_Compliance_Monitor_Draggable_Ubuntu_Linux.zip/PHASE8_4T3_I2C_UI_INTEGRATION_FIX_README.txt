VECTOR LPC2129 IDE — Phase 8.4T3
I2C + 24LC256 Circuit Canvas / Debug Panel Integration Fix

Base: protected Phase 8.4S branch plus Phase 8.4T EEPROM engine.

Confirmed issue in previous 8.4T2:
- The I2C canvas/debug implementation existed in phase84t_i2c_eeprom.js.
- The Examples toolbar invoked the local loadExample() function inside phase80_core_examples.js.
- 8.4T2 wrapped window.phase80LoadExample instead, so selecting the I2C example never called the I2C lab show routine.
- The custom I2C circuit was also attached to the detached canvas host rather than directly to the scene.

Fix in 8.4T3:
1. The actual local loadExample() now has an explicit i2cLab='24lc256' branch.
2. Selecting "I2C — 24LC256 EEPROM" calls phase84tShowI2CEepromLab() directly.
3. The I2C circuit is inserted into #scene so it is visibly part of the Circuit Canvas.
4. SFR Debug, Protocol Analyzer and EEPROM Memory windows open with the example.
5. Selecting a non-I2C example hides the I2C circuit and its three diagnostic windows.
6. Existing tested Phase 8.4S functionality is otherwise untouched by this UI integration fix.

Hardware mapping:
- LPC2129: one on-chip I2C peripheral
- P0.2 = SCL
- P0.3 = SDA
- 24LC256 7-bit slave address = 0x50

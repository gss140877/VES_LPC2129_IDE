VECTOR LPC2129 IDE — Phase 8.4D
ADC-direct 100..1000 ms Timer0/Timer1 onboard LED toggle

Change from Phase 8.4C:
- AIN0 10-bit decimal value is no longer remapped.
- ADC raw values 100..1000 are used directly as the timer match interval in milliseconds.
- Example: ADC=100 -> toggle every 100 ms; ADC=500 -> toggle every 500 ms; ADC=1000 -> toggle every 1000 ms.
- ADC values 0..99 or 1001..1023 stop the timer and force the onboard LED OFF.
- Both Timer0 and Timer1 examples use the same direct rule.
- Existing ADC engine, timer engines, UART0 reporting, circuit canvas, trimpot drag behavior, reusable onboard LED wiring and board artwork are retained.

This keeps the demonstration deliberately simple: ADC decimal -> validity check -> timer MR0 -> GPIO toggle.

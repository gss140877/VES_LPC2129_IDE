Phase 8.4T18B — Editable Memory Debugger

Built on the T18 branch while retaining validated T17 I2C/SPI behavior and CAN debug improvements.

Memory windows affected:
- LPC2129 ROM/Flash 0x00000000–0x0003FFFF
- LPC2129 SRAM 0x40000000–0x40003FFF
- 24LC512 I2C EEPROM 0x0000–0xFFFF
- 25LC512 SPI EEPROM 0x0000–0xFFFF

Debug features:
1. Double-click any visible byte to edit it (00–FF).
2. Fill Range writes a selected address range with any byte 00–FF.
3. Clear fills the COMPLETE selected memory space with 0x00 and refreshes the view.
4. Existing Go To / Start / End / Refresh remain.
5. All edits modify the backing simulator memory, not just the displayed text.

Important hardware note:
Direct editing/filling of LPC2129 Flash and EEPROM is a debugger/simulator convenience. It does not emulate the real IAP Flash programming sequence or serial EEPROM write-cycle protocol. Normal firmware accesses still use the existing hardware engines.

VECTOR LPC2129 IDE — Phase 8.3B
Precise On-Board PWR/TX/RX LED and RESET Overlays

The approved assets/vector_lpc2129_board.png is unchanged.

Overlay positions are referenced to the original 1536x1024 board image:
- RESET functional hit-area: centered at source coordinate (120, 708), directly over the existing board reset switch.
- PWR red SMD LED: (124, 258), centered above the VECTOR diagrammatic logo.
- TX green SMD LED: (267, 250), vertically aligned below P0.0.
- RX yellow SMD LED: (315, 250), vertically aligned below P0.1.

The board component is rendered at exactly 0.5 scale (768x512), so all overlays use
source-image coordinates multiplied by 0.5 in CSS.

Functional behavior retained from Phase 8.3A:
- PWR LED remains on.
- TX LED pulses from completed UART serializer events.
- RX LED pulses when UART RX FIFO accepts data.
- RESET press asserts hardware reset in the ARM7 worker.
- RESET release preserves flash and restarts CPU/peripherals from reset vector 0x00000000.
- VIC/UART interrupt implementation and IRQ examples are retained.

VECTOR LPC2129 IDE — Phase 8.4E
VIC vector-address decode correction for Timer/UART IRQ execution

Fix:
- VICVectAddr0..15 are decoded at the LPC2129 addresses 0xFFFFFF00..0xFFFFFF3C.
- VICVectCntl0..15 remain at 0xFFFFF200..0xFFFFF23C.
- VIC peripheral ownership now includes the separate 0xFFFFFF00 vector-address window.
- Firmware writes to VICVectAddr0 now reach the canonical VIC vectAddr[] table used by vectorForIRQ().

Why this matters:
Timer0 source 4 / Timer1 source 5 and UART0 source 6 / UART1 source 7 can now resolve their installed ISR addresses through the VIC slot table rather than falling through with an empty vector slot.

The Phase 8.4D ADC-direct examples are intentionally retained unchanged:
- AIN0 raw decimal 100..1000 = timer toggle interval in ms
- outside that range = timer stopped, onboard LED forced OFF
- P0.10 LED path remains canonical through physical GPIO/canvas wiring.

VECTOR LPC2129 IDE — Phase 8.1A

Core timing/input correction.

1. Removed the old fixed ~220 ms pause whenever GPIO changed.
2. ARM7 execution is now paced from profiler totalCycles against configured LPC2129 CCLK.
3. CPU execution and canvas rendering are decoupled. The UI yields once per display frame.
4. GPIO UI synchronization occurs on physical pin/direction changes, not on every repeated IOSET/IOCLR write.
5. Full Circuit Canvas render() is no longer performed for each GPIO write.
   This prevents a held push-button DOM element from being destroyed/recreated.
6. Push-button now uses pointer capture:
   pointer-down = pressed, pointer-up/cancel = released.
   Moving the mouse slightly away no longer creates a false release.
7. A button transition is sampled immediately into IO0PIN/IO1PIN.
   The 20 ms input polling path was replaced by a low-impact 100 ms safety resync.
8. LED visual state is updated in place by class switching; no complete canvas rebuild is required.
9. Example/project workflow from Phase 8.0F is preserved.

RULE:
.c/.s -> arm-none-eabi-gcc/GAS -> ELF/HEX -> ARM7TDMI-S executed instructions
-> LPC2129 memory mapped GPIO -> canonical physical pins -> canvas components.

Timing note:
The engine uses its current instruction-family cycle estimator. It is now cycle-paced,
but this is not yet a cycle-perfect ARM7TDMI-S timing certification.

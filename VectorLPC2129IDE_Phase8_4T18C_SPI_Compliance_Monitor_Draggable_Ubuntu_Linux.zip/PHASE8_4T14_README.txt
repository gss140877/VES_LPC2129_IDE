Phase 8.4T14

I2C classroom example update
- Uses string "Vector India Pvt Ltd" (20 bytes).
- 0x0100..0x0113: each character written with BYTE WRITE.
- Each character is read back with RANDOM READ into byte_random_ram[] in LPC2129 SRAM.
- 0x0200..0x0213: complete string written with PAGE WRITE.
- Complete string read back with SEQUENTIAL READ into page_seq_ram[] in LPC2129 SRAM.
- source_text[] is const so it can be inspected in LPC2129 Flash/ROM viewer.

LPC2129 SPI subsystem
- SPI0 register block: S0SPCR/S0SPSR/S0SPDR/S0SPCCR/S0SPINT.
- SPI1 register block: S1SPCR/S1SPSR/S1SPDR/S1SPCCR/S1SPINT.
- Master/Slave control, CPHA/CPOL/LSBF/SPIE bits retained in SPCR.
- SPIF/MODF/ABRT status behavior and interrupt flag path represented.
- Legal SPI master clock counter checking.
- SPI0 pin mux: P0.4 SCK0, P0.5 MISO0, P0.6 MOSI0.
- SPI1 pin mux recognition: P0.17 SCK1, P0.18 MISO1, P0.19 MOSI1.
- Example uses P0.7 GPIO as active-low CS for the external EEPROM.

25LC512 SPI EEPROM
- 64 KB 0x0000..0xFFFF memory.
- WREN, WRDI, RDSR, WRSR, READ and WRITE command handling.
- 16-bit address.
- 128-byte write-page wrap behavior.
- WEL behavior.
- Professional draggable/zoomable/deletable Circuit Canvas breakout.
- Default wires: P0.4 SCK, P0.5 SO/MISO, P0.6 SI/MOSI, P0.7 CS, 3V3, GND.
- WP and HOLD shown pulled high on breakout.
- Full scrollable 25LC512 memory window with Go To Address.
- SPI0 SFR, SPI1 SFR and SPI Protocol Analyzer debug windows.
- C Example: SPI0 — 25LC512 Byte Write/Read.

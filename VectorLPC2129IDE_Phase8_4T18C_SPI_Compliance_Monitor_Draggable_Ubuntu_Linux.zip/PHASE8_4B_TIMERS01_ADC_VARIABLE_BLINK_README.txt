VECTOR LPC2129 IDE / Simulator — Phase 8.4B
Timer/Counter0 + Timer/Counter1 + ADC-controlled variable blink

Base: confirmed-working Phase 8.4A ADC build.

NEW
1. Trimpot direct drag
   - Hold the left mouse button on the trimpot screw/body and drag.
   - Horizontal/upward drag increases the wiper value; left/down decreases it.
   - The screw rotation, 0..1023 decimal reading, voltage reading and ADC input update live.
   - The original range control remains available.

2. Timer/Counter0 and Timer/Counter1 worker engines
   Register maps:
   Timer0 base 0xE0004000
   Timer1 base 0xE0008000

   Modeled registers:
   IR, TCR, TC, PR, PC, MCR, MR0..MR3,
   CCR, CR0..CR3, EMR and CTCR.

   Implemented digital behavior:
   - PCLK timer mode with prescale counter.
   - 32-bit timer counter operation.
   - Four match channels.
   - Match interrupt/reset/stop actions.
   - External-match set/clear/toggle state.
   - Four capture channels with rising/falling edge selection.
   - Capture interrupts.
   - Counter mode on selected CAP channel: rising/falling/both edges.
   - Timer0 VIC source 4 and Timer1 VIC source 5.
   - Timer MAT edge hook to ADC hardware-trigger model.
   - Timer state included in worker snapshots as window.lpcTimers.
   - Hardware RESET reconstructs Timer/UART/ADC/VIC peripheral engines.

3. New C examples
   - Timer0 + AIN0 Variable Blink
   - Timer1 + AIN0 Variable Blink

   Circuit Canvas:
   - One professional 10 kOhm trimpot wired to P0.27/AIN0, 3.3 V and GND.
   - Reusable onboard LED Berg header wired to P0.10.
   - Onboard LED is set to active-high mode for these examples.
   - AIN0 value maps linearly to 100..1000 ms timer interval.
   - UART0 reports AIN0 raw value and selected interval whenever it changes.

   Example timing assumes the standard project clock configuration:
   CCLK = 60 MHz, PCLK = 15 MHz, Timer PR = 14999 => TC increments every 1 ms.

CANONICAL RULE
Source -> GNU ARM compiler -> ELF/HEX -> ARM7TDMI-S worker -> LPC2129 ADC/Timer/GPIO/VIC -> canonical physical pin/wiring -> onboard LED / Circuit Canvas.
No source parser or timer/LED UI shortcut is used.

VALIDATION PERFORMED
- Node syntax checks passed.
- Worker Timer0 100 ms match/reset smoke test passed.
- Worker Timer1 match/reset smoke test passed.
- Capture rising-edge + interrupt smoke test passed.
- ZIP integrity checked.

NOTE
This is a register-complete digital simulation model intended for LPC2129 training and firmware execution. It is not a transistor-level/SPICE or silicon-certified timing model.

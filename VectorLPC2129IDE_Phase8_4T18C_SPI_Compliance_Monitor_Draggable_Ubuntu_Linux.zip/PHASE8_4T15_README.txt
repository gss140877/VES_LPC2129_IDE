Phase 8.4T15

SPI string demo
- "Vector India Pvt Ltd" stored in const Flash.
- BYTE WRITE to 25LC512 0x0100..0x0113, BYTE READ into spi_byte_ram[].
- PAGE WRITE to 0x0200..0x0213, SEQUENTIAL READ into spi_seq_ram[].
- Both readback arrays live in LPC2129 SRAM for ROM/RAM comparison.

LPC2129 CAN subsystem
- CAN1 controller base 0xE0044000; CAN2 controller base 0xE0048000.
- Programmer-visible MOD, CMR, GSR, ICR, IER, BTR, EWL, SR, RX registers,
  and all three TX-buffer register sets implemented.
- CAN acceptance-filter registers at 0xE003C000..0xE003C01C.
- 2 KB acceptance-filter RAM at 0xE0038000.
- CAN central status registers at 0xE0040000..0xE0040008.
- Normal/reset modes, three TX buffers, RX buffer/release, standard and extended
  ID packing, RTR/DLC/data, filter bypass and standard individual filtering,
  ACK/no-ACK path, TEC error growth, bus state, status and interrupt-capture flags.
- CAN1 RX pin recognition P0.25/RD1; CAN1 TX is LPC2129 dedicated TD1.
- CAN2 P0.23/RD2 and P0.24/TD2 pin recognition.

MCP2551 / CAN bus
- Two professional draggable/zoomable/deletable MCP2551 breakout boards.
- CANH-to-CANH and CANL-to-CANL bus wiring.
- Two 120-ohm termination states.
- Connected/disconnected bus fault injection.
- CAN1/CAN2 transceiver-presence engine.

Example
- CAN1 -> CAN2 -> CAN1 round trip for "Vector India Pvt Ltd".
- String is divided into 8+8+4-byte CAN frames.
- CAN1->CAN2 IDs 0x120,0x121,0x122.
- CAN2->CAN1 IDs 0x220,0x221,0x222.
- can2_rx_ram[] and can1_return_ram[] expose both received copies in SRAM.

Debug / monitor
Communication > CAN:
- LPC2129 CAN1 SFR
- LPC2129 CAN2 SFR
- CAN Acceptance Filter
- CAN Bus Monitor
- CAN Diagnostics / bus disconnect and termination controls

Phase 5.3R Clean Application UI

Updates:
- Removed duplicate/floating debug selector bar.
- Kept one clean Debug Panel selector in the top toolbar.
- Debug panels open only when selected from the dropdown.
- Debug panels remain draggable and resizable.
- Added application-style title bar and grouped toolbar sections.
- Toolbar uses horizontal scrolling instead of overlapping buttons on smaller screens.
- Added START_APP_WINDOW_NO_URL_BAR.bat to open Edge/Chrome app mode without browser address bar.

Recommended run:
  START_APP_WINDOW_NO_URL_BAR.bat

Normal browser mode:
  RUN_SERVER.bat

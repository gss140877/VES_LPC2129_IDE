/* VECTOR LPC2129 IDE Phase 8.4A — physical ADC canvas bridge.
   The worker ADC does not read UI sliders directly. This bridge resolves the
   actual circuit graph: powered trimpot -> wiper wire -> P0.27..P0.30/AIN0..3.
*/
(function(){
'use strict';
if(window.__phase84AdcBridgeInstalled)return;window.__phase84AdcBridgeInstalled=true;
const CHANNEL_PINS=['uno.P0_27','uno.P0_28','uno.P0_29','uno.P0_30'];
function connected(a,b){
  const ws=(window.project&&Array.isArray(project.wires))?project.wires:[];
  return ws.some(w=>(w.from===a&&w.to===b)||(w.from===b&&w.to===a));
}
function potForChannel(ch){
  const parts=(window.project&&Array.isArray(project.parts))?project.parts:[];
  const pin=CHANNEL_PINS[ch];
  for(const p of parts){
    if(p.type!=='pot')continue;
    if(!connected(pin,p.id+'.OUT'))continue;
    if(!connected('uno.3V3',p.id+'.VCC'))continue;
    if(!connected('uno.GND',p.id+'.GND'))continue;
    return p;
  }
  return null;
}
window.phase84SyncAdcCanvas=function(){
  for(let ch=0;ch<4;ch++){
    const p=potForChannel(ch);const raw=p?Math.max(0,Math.min(1023,Number(p.value)||0)):0;
    try{if(typeof window.phase84SetAdcInput==='function')window.phase84SetAdcInput(ch,raw)}catch(e){}
  }
};
window.phase84AdcCanvasState=function(){return CHANNEL_PINS.map((pin,ch)=>{const p=potForChannel(ch);return {channel:ch,pin,pot:p&&p.id||null,raw:p?Number(p.value)||0:0}})};
setInterval(()=>{try{window.phase84SyncAdcCanvas()}catch(e){}},120);
window.addEventListener('load',()=>setTimeout(()=>{try{window.phase84SyncAdcCanvas()}catch(e){}},1800));
})();

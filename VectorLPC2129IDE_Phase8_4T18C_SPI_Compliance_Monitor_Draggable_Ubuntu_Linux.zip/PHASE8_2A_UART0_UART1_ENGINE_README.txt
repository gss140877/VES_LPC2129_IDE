VECTOR LPC2129 IDE — Phase 8.2A
UART0 + UART1 Memory-Mapped Engines and Simulated Serial Terminals

Reference basis: NXP UM10114, Chapters 10 and 11.

Implemented UART0:
- U0RBR/U0THR/DLL aliasing via DLAB
- U0DLM/U0IER aliasing via DLAB
- U0IIR/U0FCR, U0LCR, U0LSR, U0SCR, U0ACR, U0FDR, U0TER
- 16-byte FIFO mode, RX trigger levels, RX overrun status
- THRE/TEMT/DR status
- baud derived from PCLK, divisor and fractional divider
- character timing based on emulated CCLK cycles
- UART0 TXD0/RXD0 pin mux validation through PINSEL0
- simulated UART0 serial terminal with RX injection

Implemented UART1:
- UART0-equivalent core registers
- U1MCR/U1MSR modem/loopback foundation
- UART1 TXD1/RXD1 pin mux validation through PINSEL0
- simulated UART1 serial terminal with RX injection

Important official GPIO correction included:
- IO1PIN  = 0xE0028010
- IO1SET  = 0xE0028014
- IO1DIR  = 0xE0028018
- IO1CLR  = 0xE002801C
This frees 0xE002C000/004 for PINSEL0/PINSEL1 as specified by UM10114.

Examples:
C Examples:
- UART0 TX/RX Echo
- UART1 TX/RX Echo
ASM Examples:
- UART0 TX/RX Echo
- UART1 TX/RX Echo

Canonical rule is preserved:
source -> ARM GCC/GAS -> ELF/HEX -> ARM7TDMI-S CPU -> memory bus
-> LPC2129 UART SFRs -> UART engine -> simulated serial terminal.

Validation boundary:
Register/FIFO/baud/polling/terminal behavior is implemented for classroom and simulator testing.
UART interrupt identification is modeled in IIR, but end-to-end CPU IRQ delivery through a fully validated VIC
and complete auto-baud edge-measurement behavior are not yet certified as 100% silicon-equivalent.

/* Phase 8.4O visualization: brightness comes only from worker PWM2 register state. */
(function(){'use strict';
function wired(){try{return project&&project.wires&&project.wires.some(w=>(w.from==='uno.P0_7'&&w.to==='p83e.LED')||(w.to==='uno.P0_7'&&w.from==='p83e.LED'))}catch(e){return false}}
function paint(){const el=document.getElementById('p83eUserLed'),p=window.lpcPwm;if(!el||!p||!wired())return;const d=Number(p.duty&&p.duty[2])||0;el.classList.toggle('on',d>0.002);el.style.opacity=String(0.18+0.82*d);el.style.filter='brightness('+(0.45+1.8*d).toFixed(2)+')';el.style.boxShadow=d>0.01?'0 0 '+Math.round(4+18*d)+'px rgba(255,40,20,'+(0.25+0.7*d).toFixed(2)+')':'none';el.title='PWM2 duty '+Math.round(d*100)+'%';}
setInterval(paint,40);window.phase84oRefresh=paint;
})();

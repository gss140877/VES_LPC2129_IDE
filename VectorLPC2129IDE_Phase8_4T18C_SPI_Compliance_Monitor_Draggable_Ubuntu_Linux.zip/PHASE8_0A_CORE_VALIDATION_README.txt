VECTOR LPC2129 IDE — Phase 8.0A
CORE VALIDATION: LED + SWITCH, EMBEDDED C + GNU ARM ASSEMBLY

Canonical execution rule:
  .c/.s source
     -> arm-none-eabi-gcc / GNU assembler
     -> ELF with debug information
     -> Intel HEX
     -> ARM7TDMI-S CPU engine executes actual instructions
     -> memory-mapped LPC2129 IO0PIN/IO0SET/IO0DIR/IO0CLR
     -> canonical 46-pin physical GPIO model
     -> circuit-canvas wire
     -> LED / push-button component behavior

There are NO example-specific direct LED toggles.
The example loader only:
  1) loads source text,
  2) places/wires components,
  3) clears any previously built HEX.

Examples:
  Embedded C — LED Blink, P0.10
  GNU ARM Assembly — LED Blink, P0.10
  Embedded C — P0.14 button controls P0.10 LED
  GNU ARM Assembly — P0.14 button controls P0.10 LED

Switch model:
  P0.14 is an input.
  Button released: input HIGH (GPIO pull-up model).
  Button pressed: input LOW through GND.
  The button changes only the physical input state. Firmware must read IO0PIN.

Phase 8.0A additionally fixes the CPU GPIO read path so external circuit inputs
are sampled when firmware reads IO0PIN/IO1PIN, and replaces the legacy P0-only
LED bridge with a P0/P1-aware GPIO-state-driven circuit bridge.

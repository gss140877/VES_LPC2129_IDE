VECTOR LPC2129 IDE — Phase 8.4T5

Protected base: Phase 8.4S.

Changes:
- 24LC512 EEPROM is now a first-class Circuit Canvas component in project.parts.
- Add from + Component → I²C 24LC512 EEPROM Breakout.
- Drag with mouse, wheel-zoom over component, double-click delete.
- Standard 1x4 Berg strip: VCC, GND, SCL, SDA.
- Onboard 4.7 kΩ SCL/SDA pull-ups and 100 nF decoupling shown.
- A0/A1/A2 are clickable hardware address straps; simulated slave address updates from 0x50 through 0x57.
- EEPROM presence/address is sent to the ARM7 worker; deleting the breakout removes its ACK response.
- Communication menu is inserted directly by the Phase 7 IDE menu constructor so it cannot be missed by load-order timing.
  Communication → UART → UART0/UART1 Terminal
  Communication → I²C → LPC2129 I²C SFR / Protocol Analyzer / 24LC512 Memory
- Debug windows remain observer-only and do not drive protocol behavior.

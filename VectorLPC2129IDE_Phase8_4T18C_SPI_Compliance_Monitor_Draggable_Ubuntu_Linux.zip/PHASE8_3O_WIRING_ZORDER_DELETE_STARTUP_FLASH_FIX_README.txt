VECTOR LPC2129 IDE — Phase 8.3O
Wiring Z-Order + Reliable Onboard Delete + Startup Flash Fix

Changes from Phase 8.3N:
1. Common/off-board wiring is rendered above the physical board/header/Berg-strip artwork so wire endpoints remain visibly on top of the connector face.
2. Onboard routed-wire double-click deletion no longer depends on browser dblclick surviving an SVG rerender. A same-wire second pointer-down within 380 ms deletes the real project.wires entry; existing dblclick handlers remain as fallback.
3. The legacy bootstrap QFP/green LPC2129 board is hidden before first paint and the approved vector_lpc2129_board.png stage is installed immediately at DOM ready, eliminating the startup glimpse/flash.
4. Existing Phase 8.3N placement, UART/AUX bank, reusable SW/LED trainer, draggable orthogonal routes and canonical physical-pin architecture are preserved.

Approved board PNG itself is unchanged.

VECTOR LPC2129 IDE — Phase 8.3G
UART / AUX Four-SMD-LED Bank

Built on Phase 8.3F. Approved vector_lpc2129_board.png is unchanged.

Board changes
- Former shared TX/RX indicators are retired.
- Four compact SMD indicators: TX0, RX0, TX1, RX1.
- Dedicated physical pin associations:
    TX0 = P0.0 / TXD0
    RX0 = P0.1 / RXD0
    TX1 = P0.8 / TXD1
    RX1 = P0.9 / RXD1
- Each channel has a three-state selector: O=OFF, U=UART/dedicated pin, A=AUX.
- Each channel exposes a real Circuit Canvas AUX node A0..A3.
- AUX nodes are wired using the existing canvas wire engine; no virtual pin dropdown.
- AUX mode follows the canonical physical GPIO IOPIN state of the visibly wired MCU pin.
- UART mode activity comes from the actual UART peripheral engine after compiled firmware executes.
- External canvas LED directly wired to the corresponding UART physical pin receives the same hardware-engine-derived visual activity pulse.
- No source parsing or example-specific direct LED drive is added.

Existing Phase 8.3F P1.30 switch / P1.31 LED trainer is preserved.
Existing reset, power LED, worker runtime, UART/VIC examples and canonical Port 1 addresses are preserved.

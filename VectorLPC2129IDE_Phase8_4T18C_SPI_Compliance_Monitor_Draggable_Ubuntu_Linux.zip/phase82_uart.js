/* VECTOR LPC2129 IDE — Phase 8.2A
   UART0/UART1 peripheral engines + simulated serial terminals.
   Based on NXP UM10114 UART0/UART1 register maps.
*/
(function(){
'use strict';
if(window.__phase82UartInstalled)return;
window.__phase82UartInstalled=true;

const UART0_BASE=0xE000C000>>>0;
const UART1_BASE=0xE0010000>>>0;
const PINSEL0=0xE002C000>>>0, PINSEL1=0xE002C004>>>0, PINSEL2=0xE002C014>>>0;

const terminalBuffers={0:'',1:''};
const termWindows={};
let z=62000;

function logSafe(s){try{if(typeof log==='function')log(s)}catch(e){}}
function pclk(){return Math.max(1,Number((window.LPC2129ClockConfig&&window.LPC2129ClockConfig.pclkHz)||15000000))}
function cclk(){return Math.max(1,Number((window.LPC2129ClockConfig&&window.LPC2129ClockConfig.cclkHz)||60000000))}
function printableByte(b){return String.fromCharCode(b&255)}
function escText(s){return String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))}

class LPC2129UART{
  constructor(port,emu){this.port=port;this.emu=emu;this.base=port?UART1_BASE:UART0_BASE;this.reset()}
  reset(){
    this.DLL=0x01;this.DLM=0x00;this.IER=0x00;this.FCR=0x00;this.LCR=0x00;
    this.LSR=0x60;this.SCR=0x00;this.ACR=0x00;this.FDR=0x10;this.TER=0x80;
    this.MCR=0x00;this.MSR=0x00;
    this.rx=[];this.tx=[];this.activeTx=null;this.txDueCycles=0;
    this.rxErrors=[];this.txCount=0;this.rxCount=0;this.overrunCount=0;
    this.lastTxCycle=0;this.lastRxCycle=0;this.lastIIR=0x01;
  }
  dlab(){return !!(this.LCR&0x80)}
  fifoEnabled(){return !!(this.FCR&1)}
  fifoCapacity(){return this.fifoEnabled()?16:1}
  rxTrigger(){return [1,4,8,14][(this.FCR>>>6)&3]}
  wordBits(){return 5+(this.LCR&3)}
  frameBits(){
    const stop=(this.LCR&4)?(this.wordBits()===5?1.5:2):1;
    const parity=(this.LCR&8)?1:0;
    return 1+this.wordBits()+parity+stop;
  }
  divisor(){const d=((this.DLM<<8)|this.DLL)&0xFFFF;return d||1}
  baud(){
    const mul=(this.FDR>>>4)&0x0F, add=this.FDR&0x0F;
    const m=mul||1;
    const frac=1+(add/m);
    return pclk()/(16*this.divisor()*frac);
  }
  frameCycles(){return Math.max(1,Math.round((this.frameBits()/Math.max(1,this.baud()))*cclk()))}
  pinsConfigured(){
    const ps=(this.emu&&this.emu.pinConnect&&this.emu.pinConnect.PINSEL0)>>>0;
    if(this.port===0)return ((ps&0xF)===0x5); // P0.0 TXD0=01, P0.1 RXD0=01
    return (((ps>>>16)&0xF)===0x5);           // P0.8 TXD1=01, P0.9 RXD1=01
  }
  updateLSR(){
    if(this.rx.length)this.LSR|=0x01;else this.LSR&=~0x01;
    if(this.tx.length===0)this.LSR|=0x20;else this.LSR&=~0x20;
    if(this.tx.length===0&&!this.activeTx)this.LSR|=0x40;else this.LSR&=~0x40;
    if(this.rxErrors.length)this.LSR|=0x80;else this.LSR&=~0x80;
  }
  interruptIIR(){
    const fifo=this.fifoEnabled()?0xC0:0;
    if((this.IER&0x04)&&(this.LSR&0x1E))return fifo|0x06;
    if((this.IER&0x01)&&this.rx.length>=this.rxTrigger())return fifo|0x04;
    if((this.IER&0x02)&&(this.LSR&0x20))return fifo|0x02;
    if(this.port===1&&(this.IER&0x08)&&(this.MSR&0x0F))return fifo|0x00;
    return fifo|0x01;
  }
  read(off){
    off&=0xFC;
    this.tick(this.emu&&this.emu.profiler?this.emu.profiler.totalCycles:0);
    switch(off){
      case 0x00:
        if(this.dlab())return this.DLL;
        if(!this.rx.length){this.updateLSR();return 0}
        {
          const b=this.rx.shift()&255;
          const err=this.rxErrors.shift()||0;
          this.LSR=(this.LSR&~0x1E)|(err&0x1E);
          this.rxCount++;this.lastRxCycle=this.emu.profiler.totalCycles||0;
          this.updateLSR();refreshStatus(this.port);return b;
        }
      case 0x04:return this.dlab()?this.DLM:this.IER;
      case 0x08:this.lastIIR=this.interruptIIR();return this.lastIIR;
      case 0x0C:return this.LCR;
      case 0x10:return this.port===1?this.MCR:0;
      case 0x14:{
        this.updateLSR();const v=this.LSR&0xFF;
        // Reading LSR clears OE/PE/FE/BI sticky indicators, while DR/THRE/TEMT are live.
        this.LSR&=~0x1E;this.updateLSR();return v;
      }
      case 0x18:
        if(this.port!==1)return 0;
        {const v=this.MSR&0xFF;this.MSR&=0xF0;return v}
      case 0x1C:return this.SCR;
      case 0x20:return this.ACR;
      case 0x28:return this.FDR;
      case 0x30:return this.TER;
      default:return 0;
    }
  }
  write(off,val){
    off&=0xFC;val>>>=0;
    switch(off){
      case 0x00:
        if(this.dlab()){this.DLL=val&0xFF;refreshStatus(this.port);break}
        this.writeTHR(val&0xFF);break;
      case 0x04:
        if(this.dlab())this.DLM=val&0xFF;
        else this.IER=val&(this.port?0x30F:0x307);
        refreshStatus(this.port);break;
      case 0x08:
        this.FCR=val&0xC7;
        if(val&0x02){this.rx=[];this.rxErrors=[];this.LSR&=~0x1F}
        if(val&0x04){this.tx=[];this.activeTx=null;this.LSR|=0x60}
        this.updateLSR();refreshStatus(this.port);break;
      case 0x0C:this.LCR=val&0xFF;refreshStatus(this.port);break;
      case 0x10:if(this.port===1){this.MCR=val&0xF3;this.applyLoopbackModem();refreshStatus(this.port)}break;
      case 0x1C:this.SCR=val&0xFF;break;
      case 0x20:
        // Auto-baud control bits are stored; end/timeout clear bits are write-one actions.
        this.ACR=val&0x07;
        if(val&0x100)this.ACR&=~1;
        if(val&0x200)this.ACR&=~1;
        refreshStatus(this.port);break;
      case 0x28:this.FDR=val&0xFF;refreshStatus(this.port);break;
      case 0x30:this.TER=val&0x80;this.tick(this.emu.profiler.totalCycles||0);refreshStatus(this.port);break;
    }
  }
  writeTHR(b){
    if(!(this.TER&0x80))return;
    const cap=this.fifoCapacity();
    if(this.tx.length>=cap)return;
    this.tx.push(b&255);
    this.LSR&=~0x60;
    this.tick(this.emu.profiler.totalCycles||0);
    refreshStatus(this.port);
  }
  startNext(now){
    if(this.activeTx!==null||!this.tx.length||!(this.TER&0x80))return;
    this.activeTx=this.tx.shift()&255;
    this.txDueCycles=(now+this.frameCycles())>>>0;
    if(this.tx.length===0)this.LSR|=0x20;else this.LSR&=~0x20;
    this.LSR&=~0x40;
  }
  tick(cycles){
    cycles=Number(cycles||0);
    this.startNext(cycles);
    let guard=0;
    while(this.activeTx!==null && cycles>=this.txDueCycles && guard++<64){
      const b=this.activeTx&255;
      this.activeTx=null;this.txCount++;this.lastTxCycle=this.txDueCycles;
      if(this.pinsConfigured()){
        if(this.port===1&&(this.MCR&0x10)){ // UART1 loopback
          this.injectRxByte(b,0,true);
        }else{
          emitTx(this.port,b,this);
        }
      }else{
        logSafe('UART'+this.port+' TX blocked: PINSEL0 has not selected TXD'+this.port+'/RXD'+this.port+'.');
      }
      const nextStart=this.txDueCycles;
      this.startNext(nextStart);
    }
    this.updateLSR();refreshStatus(this.port);
  }
  injectRxByte(b,errorBits=0,internal=false){
    if(!internal&&!this.pinsConfigured()){
      logSafe('UART'+this.port+' RX ignored: PINSEL0 has not selected UART pins.');
      return false;
    }
    const cap=this.fifoCapacity();
    if(this.rx.length>=cap){
      this.LSR|=0x02;this.overrunCount++;refreshStatus(this.port);return false;
    }
    const mask=(1<<this.wordBits())-1;
    this.rx.push((b&mask)&255);
    this.rxErrors.push(errorBits&0x1E);
    this.LSR|=0x01;
    if(errorBits&0x1E)this.LSR|=(errorBits&0x1E)|0x80;
    refreshStatus(this.port);
    return true;
  }
  applyLoopbackModem(){
    if(this.port!==1)return;
    if(this.MCR&0x10){
      const old=(this.MSR>>>4)&0x0F;
      // Loopback: RTS->CTS, DTR->DSR, OUT1->RI, OUT2->DCD
      const now=((this.MCR&0x02)?1:0)|((this.MCR&0x01)?2:0)|((this.MCR&0x04)?4:0)|((this.MCR&0x08)?8:0);
      const delta=(old^now)&0x0F;
      this.MSR=((now&0x0F)<<4)|delta;
    }
  }
}

function ensure(emu){
  if(!emu)return null;
  if(!emu.pinConnect)emu.pinConnect={PINSEL0:0,PINSEL1:0,PINSEL2:0x0000000C};
  if(!emu.uartEngines)emu.uartEngines={0:new LPC2129UART(0,emu),1:new LPC2129UART(1,emu)};
  return emu.uartEngines;
}

function isUartAddr(a){
  a>>>=0;
  return (a>=UART0_BASE&&a<=UART0_BASE+0x30)||(a>=UART1_BASE&&a<=UART1_BASE+0x30);
}
function isPinAddr(a){
  a>>>=0;return a===PINSEL0||a===PINSEL1||a===PINSEL2;
}
window.phase82IsPeripheralAddress=a=>isUartAddr(a)||isPinAddr(a);

window.phase82PeripheralRead=function(emu,a,width){
  a>>>=0;ensure(emu);
  if(isPinAddr(a)){
    if(a===PINSEL0)return emu.pinConnect.PINSEL0>>>0;
    if(a===PINSEL1)return emu.pinConnect.PINSEL1>>>0;
    if(a===PINSEL2)return emu.pinConnect.PINSEL2>>>0;
  }
  const port=a>=UART1_BASE?1:0, base=port?UART1_BASE:UART0_BASE;
  return emu.uartEngines[port].read((a-base)>>>0)>>>0;
};

window.phase82PeripheralWrite=function(emu,a,v,width){
  a>>>=0;v>>>=0;ensure(emu);
  if(isPinAddr(a)){
    if(a===PINSEL0)emu.pinConnect.PINSEL0=v>>>0;
    else if(a===PINSEL1)emu.pinConnect.PINSEL1=v>>>0;
    else if(a===PINSEL2)emu.pinConnect.PINSEL2=v>>>0;
    refreshStatus(0);refreshStatus(1);return;
  }
  const port=a>=UART1_BASE?1:0, base=port?UART1_BASE:UART0_BASE;
  emu.uartEngines[port].write((a-base)>>>0,v);
};

window.phase82TickUarts=function(emu){
  const us=ensure(emu);if(!us)return;
  const cy=emu.profiler?emu.profiler.totalCycles:0;
  us[0].tick(cy);us[1].tick(cy);
};

window.phase82InjectRx=function(port,text){
  port=Number(port)?1:0;
  if(typeof window.phase82bIsRunning==='function'&&window.phase82bIsRunning()&&typeof window.phase82bSendRx==='function'){
    return window.phase82bSendRx(port,text);
  }
  const emu=window.lpcArm7Emu;
  if(!emu){logSafe('UART'+port+' RX: run the LPC2129 program first.');return false}
  const us=ensure(emu),u=us[port];
  for(const ch of String(text))u.injectRxByte(ch.charCodeAt(0),0,false);
  return true;
};

function emitTx(port,b,u){
  const ch=printableByte(b);
  terminalBuffers[port]=(terminalBuffers[port]+ch).slice(-50000);
  const tw=termWindows[port];
  if(tw&&tw.out){tw.out.textContent=terminalBuffers[port];tw.out.scrollTop=tw.out.scrollHeight}
  refreshStatus(port);
}

function makeTerminal(port){
  if(termWindows[port])return termWindows[port];
  const w=document.createElement('div');
  w.className='p82-uart-window';
  w.id='p82Uart'+port+'Terminal';
  w.style.left=(port?650:280)+'px';w.style.top=(port?210:170)+'px';
  w.innerHTML=`
    <div class="p82-uart-head"><span>UART${port} Simulated Serial Terminal</span><div>
      <button data-clear>Clear</button><button data-close>×</button></div>
    </div>
    <div class="p82-uart-status" data-status>UART${port}: waiting for engine</div>
    <pre class="p82-uart-output" data-output></pre>
    <div class="p82-uart-rx">
      <input data-input type="text" placeholder="Type RX data for UART${port}">
      <button data-send>Send → RXD${port}</button>
      <button data-crlf>Send + CR/LF</button>
    </div>`;
  document.body.appendChild(w);
  const out=w.querySelector('[data-output]'),inp=w.querySelector('[data-input]'),status=w.querySelector('[data-status]');
  out.textContent=terminalBuffers[port];
  const send=crlf=>{const s=inp.value+(crlf?'\r\n':'');if(s){window.phase82InjectRx(port,s);inp.value='';inp.focus()}};
  w.querySelector('[data-send]').onclick=()=>send(false);
  w.querySelector('[data-crlf]').onclick=()=>send(true);
  inp.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();send(false)}};
  w.querySelector('[data-clear]').onclick=()=>{terminalBuffers[port]='';out.textContent=''};
  w.querySelector('[data-close]').onclick=()=>w.style.display='none';
  const head=w.querySelector('.p82-uart-head');
  head.onmousedown=e=>{
    if(e.target.tagName==='BUTTON')return;
    w.style.zIndex=String(++z);
    const r=w.getBoundingClientRect(),dx=e.clientX-r.left,dy=e.clientY-r.top;
    const move=ev=>{w.style.left=Math.max(0,ev.clientX-dx)+'px';w.style.top=Math.max(70,ev.clientY-dy)+'px'};
    const up=()=>{document.removeEventListener('mousemove',move);document.removeEventListener('mouseup',up)};
    document.addEventListener('mousemove',move);document.addEventListener('mouseup',up);e.preventDefault();
  };
  w.onmousedown=()=>w.style.zIndex=String(++z);
  termWindows[port]={w,out,inp,status};refreshStatus(port);return termWindows[port];
}
window.phase82ShowTerminal=function(port){
  port=Number(port)?1:0;const t=makeTerminal(port);t.w.style.display='flex';t.w.style.zIndex=String(++z);refreshStatus(port);return t.w;
};
window.phase82ClearTerminal=function(port){port=Number(port)?1:0;terminalBuffers[port]='';const t=termWindows[port];if(t)t.out.textContent=''};

function refreshStatus(port){
  const t=termWindows[port];if(!t)return;
  const emu=window.lpcArm7Emu;
  if(!emu){t.status.textContent='UART'+port+': waiting for running LPC2129 HEX';return}
  const us=ensure(emu),u=us[port];
  u.updateLSR();
  const pins=u.pinsConfigured()?'pins OK':'PINSEL not UART';
  const fmt=u.wordBits()+'-'+((u.LCR&8)?'P':'N')+'-'+((u.LCR&4)?'2':'1');
  t.status.textContent=
    `UART${port} | ${u.baud().toFixed(1)} baud | ${fmt} | ${pins} | `+
    `LSR=0x${u.LSR.toString(16).toUpperCase().padStart(2,'0')} `+
    `IIR=0x${u.interruptIIR().toString(16).toUpperCase().padStart(2,'0')} | `+
    `TX ${u.txCount} RX ${u.rxCount} | FIFO ${u.fifoEnabled()?'16':'OFF/1'}`;
}


window.phase82AppendTerminalTx=function(port,text,workerState){
  port=Number(port)?1:0;
  terminalBuffers[port]=(terminalBuffers[port]+String(text||'')).slice(-50000);
  const t=termWindows[port];
  if(t&&t.out){
    // One textContent update per animation frame, independent of UART byte timing.
    t.out.textContent=terminalBuffers[port];
    t.out.scrollTop=t.out.scrollHeight;
  }
  if(workerState)window.phase82UpdateWorkerStatus(port,workerState);
};
window.phase82UpdateWorkerStatus=function(port,s){
  port=Number(port)?1:0;const t=termWindows[port];if(!t||!s)return;
  const fmt=(s.wordBits||8)+'-'+((s.LCR&8)?'P':'N')+'-'+((s.LCR&4)?'2':'1');
  t.status.textContent=`UART${port} | ${Number(s.baud||0).toFixed(1)} baud | ${fmt} | ${s.pinsConfigured?'pins OK':'PINSEL not UART'} | `+
    `LSR=0x${Number(s.LSR||0).toString(16).toUpperCase().padStart(2,'0')} IIR=0x${Number(s.IIR||1).toString(16).toUpperCase().padStart(2,'0')} | `+
    `TX ${s.txCount||0} RX ${s.rxCount||0} | FIFO ${s.fifo?'16':'OFF/1'}`;
};
function addToolbarButtons(){
  const bar=document.querySelector('.topbar.appToolbar');if(!bar||document.getElementById('p82UartToolbar'))return;
  const g=document.createElement('div');g.id='p82UartToolbar';g.className='toolbarGroup';
  g.innerHTML='<button type="button" id="p82Uart0Btn">UART0 Terminal</button><button type="button" id="p82Uart1Btn">UART1 Terminal</button>';
  const first=bar.querySelector('.toolbarGroup');if(first&&first.nextSibling)bar.insertBefore(g,first.nextSibling);else bar.appendChild(g);
  g.querySelector('#p82Uart0Btn').onclick=()=>window.phase82ShowTerminal(0);
  g.querySelector('#p82Uart1Btn').onclick=()=>window.phase82ShowTerminal(1);
}

window.phase82UartState=function(port){
  const emu=window.lpcArm7Emu;if(!emu)return null;return ensure(emu)[Number(port)?1:0];
};

window.addEventListener('load',()=>setTimeout(()=>{
  addToolbarButtons();
  logSafe('Phase 8.2A UART0/UART1 engines loaded: DLAB/FIFO/baud/LSR/IIR/pin-mux/serial terminals enabled.');
},1700));

})();

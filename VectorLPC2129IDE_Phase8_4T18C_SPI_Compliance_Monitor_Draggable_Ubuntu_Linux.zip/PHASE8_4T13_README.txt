Phase 8.4T13
- Memory and Communication buttons are now in the SAME main-toolbar group.
- Memory is intentionally placed first, immediately beside Communication.
- This prevents Memory from being pushed into a separate horizontally clipped toolbar group.
- Memory menu still exposes 24LC512 EEPROM, LPC2129 ROM/Flash, and LPC2129 RAM viewers.

VECTOR LPC2129 IDE — Phase 8.3I
Aligned UART/AUX LED Headers

Based directly on the confirmed-working Phase 8.3H build.

CHANGE IN THIS BUILD
- Corrected the visible alignment of every UART/AUX bank channel.
- TX0 LED -> selector -> A0 Berg header now share one fixed grid column.
- RX0 LED -> selector -> A1 Berg header share one fixed grid column.
- TX1 LED -> selector -> A2 Berg header share one fixed grid column.
- RX1 LED -> selector -> A3 Berg header share one fixed grid column.
- Removed independent absolute AUX-header positioning that could visually offset the Berg header from its LED.
- Retains Phase 8.3H UART/AUX bank position, distinct border, Berg/header appearance, over-board jumper-wire visualization, and corrected board terminal hit areas.
- No UART/GPIO/VIC/worker/canonical physical-pin behavior changed.
- Approved board PNG is unchanged.

CANONICAL RULE RETAINED
Firmware -> ARM7 CPU -> LPC2129 peripheral/GPIO -> canonical physical pin -> circuit wire / onboard AUX selector -> LED.
No source-parser or example-specific LED shortcut is introduced.

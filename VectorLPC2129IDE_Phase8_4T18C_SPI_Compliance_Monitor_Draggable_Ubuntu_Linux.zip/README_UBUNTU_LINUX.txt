VECTOR LPC2129 Simulator - Phase 6.1A Professional CPU Component
Ubuntu Linux Build
================================================================

This Ubuntu package preserves the Phase 6.1A simulator frontend, LPC2129 CPU
component, ARM7TDMI-S simulation, examples, debugger panels, and build flow.
Only operating-system integration has been added/adapted for Ubuntu Linux.

FIRST RUN
---------
1. Extract the ZIP.
2. Open Terminal inside the extracted folder.
3. Run:
     chmod +x *.sh
     ./INSTALL_UBUNTU_DEPENDENCIES.sh
4. Start in application-window mode:
     ./START_APP_WINDOW_NO_URL_BAR.sh

Alternative browser mode:
     ./START_LPC2129_SIMULATOR.sh

REQUIRED
--------
- Ubuntu Linux
- Node.js + npm
- Arm GNU Embedded Toolchain:
    arm-none-eabi-gcc
    arm-none-eabi-objcopy
    arm-none-eabi-size
    arm-none-eabi-objdump

The setup script attempts to install the Ubuntu ARM packages automatically.

REAL LPC2129 FLASHING ON LINUX
------------------------------
Flash Magic is a Windows application. On Ubuntu, the backend can use the
native lpc21isp command when it is installed. The existing frontend button is
kept unchanged to preserve the Phase 6.1A UI.

Typical serial devices on Ubuntu are /dev/ttyUSB0 or /dev/ttyACM0.
If access is denied, add your user to the dialout group:
    sudo usermod -aG dialout "$USER"
Then sign out and back in.

NOT CHANGED
-----------
- index.html UI/layout
- style.css appearance
- simulator.js emulator/debugger logic
- professional LPC2129 CPU/QFP component assets
- examples and linker/startup files
- build endpoint behavior and compiler flags

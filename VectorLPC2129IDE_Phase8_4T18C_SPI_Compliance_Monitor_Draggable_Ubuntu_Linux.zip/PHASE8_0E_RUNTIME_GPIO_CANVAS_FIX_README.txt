VECTOR LPC2129 IDE — Phase 8.0E
Runtime GPIO ↔ Circuit Canvas fix

Root cause fixed:
  The Phase 8.0D bridge incorrectly checked window.project.
  The simulator declares its canonical project state with top-level `let project`,
  therefore it is not a property of window. The bridge returned before doing work.

Effects of the bug:
  - P0.10 GPIO changes did not reach the LED visual.
  - P0.14 push-button state did not reach the ARM7 GPIO input read path.
  - Example circuit rebuilding could also return early.

Phase 8.0E uses the existing canonical `project` state directly.
No duplicate canvas/circuit state and no example-specific LED shortcut is introduced.

Rule remains:
  editable .c/.s -> arm-none-eabi-gcc/as -> ELF/HEX -> ARM7TDMI-S CPU
  -> LPC2129 GPIO SFR -> canonical circuit project/wires -> LED/switch.

VECTOR LPC2129 IDE — Phase 8.4C

Timer0/Timer1 ADC-controlled LED blink rate correction.

Fixes:
- AIN0 now maps to the COMPLETE LED blink period 100..1000 ms.
- MR0 receives half of that period because the IRQ toggles the LED on every match.
- Whenever AIN0 changes, TCR reset is asserted, pending IR flags are cleared, MR0 is updated, then the timer is restarted. This makes the new rate take effect immediately rather than retaining the old timer phase.
- UART0 reports ADC raw value, complete blink period, and actual MR0 half-period.

Canonical path remains: compiled ARM firmware -> ADC SFRs -> Timer0/1 SFRs -> VIC IRQ -> GPIO P0.10 -> physical wiring -> onboard LED.

VECTOR LPC2129 IDE — Phase 7.4E

Changes:
- Removed the words VECTOR and UNO from the PCB board-name text.
- Replaced them with a compact VECTOR-style geometric logo mark followed by LPC2129.
- Added a dedicated right-side vertical POWER header: 5V, 3.3V, GND.
- Power header sockets are connectable through the existing wiring engine using uno.5V, uno.3V3 and uno.GND.
- Power sockets are separate from the sequential I/O 1..46 numbering.
- Preserved Phase 7.4D vertical I/O header alignment and existing 46 LPC2129 signal node IDs.

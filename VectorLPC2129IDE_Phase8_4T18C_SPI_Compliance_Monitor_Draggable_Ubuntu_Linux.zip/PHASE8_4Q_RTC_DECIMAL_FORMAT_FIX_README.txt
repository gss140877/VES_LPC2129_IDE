VECTOR LPC2129 IDE Phase 8.4Q
RTC UART calendar formatting fix

Observed symptom: RTC heading was correct but numeric date/time fields printed corrupted characters.
Root cause isolated to the example's generated integer division/modulo path, not the RTC 32.768 kHz calendar engine or UART byte path.
Fix: RTC example decimal formatting now uses bounded subtraction digit conversion and no / or % operators.
DOY is intentionally rendered as 3 digits (001..366).
No changes to Phase 8.4H canonical timing architecture, RTC crystal domain, PWM engine, ADC engine, GPIO engine, or board artwork.

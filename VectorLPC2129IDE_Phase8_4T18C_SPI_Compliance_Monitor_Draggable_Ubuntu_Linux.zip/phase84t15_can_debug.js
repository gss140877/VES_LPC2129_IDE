(function(){
'use strict';let zz=62000;
function C(n){return (window.lpcCAN&&window.lpcCAN[n])||{}}
function B(){return (window.lpcCAN&&window.lpcCAN.bus)||{}}
function A(){return (window.lpcCAN&&window.lpcCAN.af)||{}}
function hx(v,d=8){return '0x'+(Number(v||0)>>>0).toString(16).toUpperCase().padStart(d,'0')}
function win(id,title,x,y,w,h){let p=document.getElementById(id);if(p)return p;p=document.createElement('div');p.id=id;p.className='canDbg';p.style.cssText=`left:${x}px;top:${y}px;width:${w}px;height:${h}px`;p.innerHTML=`<div class="canDbgHead"><b>${title}</b><button>×</button></div><div class="canDbgBody"></div>`;document.body.appendChild(p);p.querySelector('button').onclick=()=>p.style.display='none';let on=0,ox,oy;p.querySelector('.canDbgHead').onmousedown=e=>{on=1;ox=e.clientX-p.offsetLeft;oy=e.clientY-p.offsetTop;p.style.zIndex=++zz};addEventListener('mousemove',e=>{if(on){p.style.left=Math.max(0,e.clientX-ox)+'px';p.style.top=Math.max(55,e.clientY-oy)+'px'}});addEventListener('mouseup',()=>on=0);return p}
const coreRegs=[
 ['MOD',0x00,'MOD'],['CMR',0x04,null],['GSR',0x08,'GSR'],['ICR',0x0C,'ICR'],['IER',0x10,'IER'],['BTR',0x14,'BTR'],['EWL',0x18,'EWL'],['SR',0x1C,'SR'],
 ['RFS',0x20,'RFS'],['RID',0x24,'RID'],['RDA',0x28,'RDA'],['RDB',0x2C,'RDB']
];
function renderSfr(n){
 const p=document.getElementById('canSfr'+n);if(!p||p.style.display==='none')return;
 const s=C(n),base=n===1?0xE0044000:0xE0048000,tx=s.tx||[];
 let rows='<div class="canSection">Controller / Receive Registers</div>';
 rows+=coreRegs.map(r=>`<div class="canReg"><b>C${n}${r[0]}</b><span>${hx(base+r[1])}</span><em>${r[2]?hx(s[r[2]]):'WRITE-ONLY'}</em></div>`).join('');
 for(let b=1;b<=3;b++){
   const t=tx[b-1]||{},q=0x30+(b-1)*0x10;
   rows+=`<div class="canSection">Transmit Buffer ${b}</div>`+
    [[`TFI${b}`,q,'TFI'],[`TID${b}`,q+4,'TID'],[`TDA${b}`,q+8,'TDA'],[`TDB${b}`,q+12,'TDB']].map(r=>`<div class="canReg"><b>C${n}${r[0]}</b><span>${hx(base+r[1])}</span><em>${hx(t[r[2]])}</em></div>`).join('');
 }
 rows+=`<div class="canKpi"><span>${s.MOD&1?'RESET':'NORMAL'}</span><span>Pins ${s.pinsConfigured?'OK':'NOT CONFIGURED'}</span><span>TX ${s.txCount||0}</span><span>RX ${s.rxCount||0}</span><span>TEC ${s.txErr||0}</span><span>REC ${s.rxErr||0}</span></div>`;
 p.querySelector('.canDbgBody').innerHTML=rows;
}
function showSfr(n){const p=win('canSfr'+n,'Communication / CAN / CAN'+n+' Complete SFR',260+n*35,85+n*20,620,590);p.style.display='block';renderSfr(n)}
function renderAF(){const p=document.getElementById('canAF');if(!p||p.style.display==='none')return;const a=A();p.querySelector('.canDbgBody').innerHTML=[['AFMR',0xE003C000,a.AFMR],['SFF_sa',0xE003C004,a.SFF_sa],['SFF_GRP_sa',0xE003C008,a.SFF_GRP_sa],['EFF_sa',0xE003C00C,a.EFF_sa],['EFF_GRP_sa',0xE003C010,a.EFF_GRP_sa],['ENDofTable',0xE003C014,a.ENDofTable],['LUTerrAd',0xE003C018,a.LUTerrAd],['LUTerr',0xE003C01C,a.LUTerr]].map(r=>`<div class="canReg"><b>${r[0]}</b><span>${hx(r[1])}</span><em>${hx(r[2])}</em></div>`).join('')+`<div class="canNote">AFMR=${a.AFMR===2?'Bypass — accept all':a.AFMR===1?'Off':'Filter table enabled'}</div>`}
function showAF(){const p=win('canAF','Communication / CAN / Acceptance Filter',430,155,480,360);p.style.display='block';renderAF()}
function renderMon(){const p=document.getElementById('canMonitor');if(!p||p.style.display==='none')return;const b=B(),fs=b.frames||[];p.querySelector('.canDbgBody').innerHTML=`<div class="canBusState"><span>BUS ${b.healthy?'HEALTHY':'FAULT'}</span><span>LINK ${b.connected?'CONNECTED':'OPEN'}</span><span>TERM-A ${b.term1?'120Ω':'OFF'}</span><span>TERM-B ${b.term2?'120Ω':'OFF'}</span></div>`+fs.slice().reverse().map(f=>`<div class="canFrame"><span>#${f.seq} ${Number(f.t||0).toFixed(0)}µs</span><b>CAN${f.src} → CAN${f.dst}</b><em>ID ${hx(f.id,f.extended?8:3)} DLC ${f.dlc}</em><code>${(f.data||[]).map(x=>Number(x).toString(16).toUpperCase().padStart(2,'0')).join(' ')}</code><strong>${f.ack?'ACK':'NO ACK'}</strong></div>`).join('')}
function showMon(){const p=win('canMonitor','CAN Bus Monitor — CAN1 ⇄ CAN2 via MCP2551',520,135,650,430);p.style.display='block';renderMon()}
function renderDiag(){const p=document.getElementById('canDiag');if(!p||p.style.display==='none')return;const b=B(),c1=C(1),c2=C(2);p.querySelector('.canDbgBody').innerHTML=`<div class="canDiagGrid"><b>CAN1</b><span>${c1.MOD&1?'Reset':'Normal'}</span><span>TX ${c1.txCount||0} / RX ${c1.rxCount||0}</span><span>TEC ${c1.txErr||0} REC ${c1.rxErr||0}</span><b>CAN2</b><span>${c2.MOD&1?'Reset':'Normal'}</span><span>TX ${c2.txCount||0} / RX ${c2.rxCount||0}</span><span>TEC ${c2.txErr||0} REC ${c2.rxErr||0}</span></div><div class="canControls"><button data-k="connected">${b.connected?'Disconnect Bus':'Reconnect Bus'}</button><button data-k="term1">Term A ${b.term1?'OFF':'ON'}</button><button data-k="term2">Term B ${b.term2?'OFF':'ON'}</button></div><div class="canNote">Loop example requires both MCP2551 engines, connected CANH/CANL and both 120Ω terminations.</div>`;p.querySelectorAll('[data-k]').forEach(x=>x.onclick=()=>{let q={};q[x.dataset.k]=!b[x.dataset.k];window.phase84t15ConfigureCanBus&&window.phase84t15ConfigureCanBus(q)})}
function showDiag(){const p=win('canDiag','CAN Diagnostics / Bus Fault Injection',465,190,520,310);p.style.display='block';renderDiag()}
window.phase84t15ShowCAN1Sfr=()=>showSfr(1);window.phase84t15ShowCAN2Sfr=()=>showSfr(2);window.phase84t15ShowCANAF=showAF;window.phase84t15ShowCANMonitor=showMon;window.phase84t15ShowCANDiagnostics=showDiag;
setInterval(()=>{renderSfr(1);renderSfr(2);renderAF();renderMon();renderDiag()},300);
})();
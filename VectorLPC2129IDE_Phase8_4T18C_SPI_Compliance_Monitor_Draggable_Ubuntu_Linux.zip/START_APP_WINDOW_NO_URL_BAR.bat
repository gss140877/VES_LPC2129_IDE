@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title LPC2129 Simulator App Window

echo ===============================================
echo   Vector LPC2129 Simulator - App Window Mode
echo ===============================================
echo.

echo Checking / installing ARM GNU toolchain...
call "%~dp0CHECK_INSTALL_ARM_TOOLCHAIN.bat"
if errorlevel 1 (
  echo ERROR: ARM toolchain setup failed.
  pause
  exit /b 1
)

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed or not in PATH.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm is not installed or not in PATH.
  pause
  exit /b 1
)

if not exist "%~dp0node_modules" (
  echo Installing required Node packages...
  call npm install
  if errorlevel 1 (
    echo ERROR: npm install failed.
    pause
    exit /b 1
  )
)

echo Starting local server in separate window...
start "LPC2129 Simulator Server" /min cmd /c "cd /d ""%~dp0"" && npm start"

echo Opening frontend in app mode without browser address bar...
timeout /t 2 /nobreak >nul

set APPURL=http://localhost:3000
set EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe
set EDGE64=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe
set CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe
set CHROME86=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe

if exist "%EDGE%" start "" "%EDGE%" --app=%APPURL% --window-size=1500,900 & exit /b 0
if exist "%EDGE64%" start "" "%EDGE64%" --app=%APPURL% --window-size=1500,900 & exit /b 0
if exist "%CHROME%" start "" "%CHROME%" --app=%APPURL% --window-size=1500,900 & exit /b 0
if exist "%CHROME86%" start "" "%CHROME86%" --app=%APPURL% --window-size=1500,900 & exit /b 0

start "" "%APPURL%"

Phase 8.4T17 — SPI0/SPI1 + 25LC512 compliance-stage upgrade
Built on user-validated T16.

Adds:
- PCLK/SPCCR-derived SCK and 8-bit timing.
- CPOL/CPHA/LSBF edge trace (16 edges per byte).
- SPIF completion timestamp, ROVR, MODF and ABRT paths; existing SPI interrupt path retained.
- 25LC512 WIP/WEL, RDSR polling, 5 ms write cycle, 128-byte page buffering/wrap, WP and HOLD.
- "Vector India Pvt Ltd" byte-write/read and page-write/sequential-read example now polls WIP.
- Communication > SPI > SPI0/SPI1 + 25LC512 Compliance Monitor.

Not yet labelled 100% silicon equivalence: asynchronous ARM instruction stalling across every SCK edge,
complete external SPI slave co-simulation, exact slave/SSEL corner cases, VIC timing certification,
and exhaustive datasheet regression vectors remain.

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "================================================"
echo " Vector LPC2129 Simulator - Ubuntu Linux"
echo " Phase 6.1A Professional CPU Component"
echo "================================================"

./CHECK_INSTALL_ARM_TOOLCHAIN.sh

command -v node >/dev/null 2>&1 || { echo "ERROR: Node.js is not installed. Run ./INSTALL_UBUNTU_DEPENDENCIES.sh"; exit 1; }
command -v npm >/dev/null 2>&1 || { echo "ERROR: npm is not installed. Run ./INSTALL_UBUNTU_DEPENDENCIES.sh"; exit 1; }

if [ ! -d node_modules ]; then
  echo "Installing required Node packages..."
  npm install
fi

cleanup(){
  if [ -n "${SERVER_PID:-}" ] && kill -0 "$SERVER_PID" 2>/dev/null; then
    kill "$SERVER_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT INT TERM

node server.js &
SERVER_PID=$!

for _ in $(seq 1 40); do
  if curl -fsS http://127.0.0.1:3000/ >/dev/null 2>&1; then break; fi
  sleep 0.25
done

echo "Simulator running at http://localhost:3000"
if command -v xdg-open >/dev/null 2>&1; then
  xdg-open http://localhost:3000 >/dev/null 2>&1 || true
fi

echo "Press Ctrl+C to stop."
wait "$SERVER_PID"

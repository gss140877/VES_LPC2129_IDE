VECTOR LPC2129 SIMULATOR - PHASE 6.1A
PROFESSIONAL CPU COMPONENT

Changes in this source update:
1. The previous CSS-drawn LPC2129 package has been removed from view.
2. The supplied LPC2129FBD64 LQFP-64 PNG is now the only visible CPU component.
3. Pin numbers and pin labels are taken only from the supplied artwork, preserving their alignment.
4. Existing pin elements are retained invisibly as wiring anchors to minimize impact on current simulator logic.
5. No emulator, clock, build, flash, monitor or peripheral-engine changes were made.

This package is supplied as a source update for user-side testing.

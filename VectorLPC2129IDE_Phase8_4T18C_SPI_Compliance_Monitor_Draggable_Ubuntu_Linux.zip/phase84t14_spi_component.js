(function(){
'use strict';
const TYPE='eeprom25lc512';
function prj(){return (typeof project!=='undefined')?project:null}
function part(){const p=prj();return p&&p.parts&&p.parts.find(x=>x.type===TYPE)}
function uid(){let n=1,id='spiEeprom'+n,p=prj();while(p.parts.some(x=>x.id===id)){n++;id='spiEeprom'+n}return id}
function sync(){try{window.phase84t14ConfigureSpiEeprom&&window.phase84t14ConfigureSpiEeprom({present:!!part()})}catch(e){}}
function wires(ep){
 const p=prj();if(!p)return;
 const add=(a,b)=>{if(!p.wires.some(w=>(w.from===a&&w.to===b)||(w.from===b&&w.to===a)))try{addWire(a,b)}catch(e){}};
 add('uno.3V3',ep.id+'.VCC');add('uno.GND',ep.id+'.GND');
 add('uno.P0_4',ep.id+'.SCK');add('uno.P0_5',ep.id+'.SO');add('uno.P0_6',ep.id+'.SI');add('uno.P0_7',ep.id+'.CS');
}
function add(opt={}){
 const p=prj();if(!p||!Array.isArray(p.parts))return null;let ep=part();
 if(!ep){ep={id:uid(),type:TYPE,x:opt.x??825,y:opt.y??160,scale:opt.scale??1,state:0};p.parts.push(ep)}
 try{selectedId=ep.id;render();wires(ep);render()}catch(e){}sync();return ep;
}
window.phase84t14Add25LC512FromPalette=function(){add();const q=document.getElementById('componentPalette');if(q)q.style.display='none'};
window.phase84t14ShowSpiEepromLab=function(){const ep=add({x:825,y:160});wires(ep);try{window.phase72ShowCanvas&&window.phase72ShowCanvas()}catch(e){};return ep};
function html(p){return `<div class="spi512pcb">
 <div class="spi512silk"><b>VECTOR INDIA</b><span>25LC512 SPI EEPROM</span></div>
 <div class="spi512power"><small>POWER</small><span class="pin spi512lp" data-node="${p.id}.VCC"><i></i><b>VCC</b></span><span class="pin spi512lp" data-node="${p.id}.GND"><i></i><b>GND</b></span></div>
 <div class="spi512u">U1</div><div class="spi512chip"><div class="legs">${'<i></i>'.repeat(4)}</div><div class="body"><i class="dot"></i><i class="notch"></i><b>25LC512</b><span>Microchip</span><em>SOIC-8</em></div><div class="legs">${'<i></i>'.repeat(4)}</div></div>
 <div class="spi512aux"><span>WP</span><b>10K ↑</b><span>HOLD</span><b>10K ↑</b></div>
 <div class="spi512hdr">
  <span class="pin spi512rp" data-node="${p.id}.CS"><i></i><b>CS</b></span>
  <span class="pin spi512rp" data-node="${p.id}.SCK"><i></i><b>SCK</b></span>
  <span class="pin spi512rp" data-node="${p.id}.SO"><i></i><b>SO</b></span>
  <span class="pin spi512rp" data-node="${p.id}.SI"><i></i><b>SI</b></span>
 </div><div class="spi512foot">64 KB • 128-BYTE PAGE • WP/HOLD PULLED HIGH</div></div>`}
function decorate(){const p=prj();if(!p||!p.parts)return;p.parts.filter(x=>x.type===TYPE).forEach(ep=>{const e=document.getElementById(ep.id);if(!e)return;e.classList.add('spi512part');e.innerHTML=html(ep)})}
const oldRender=window.render; if(typeof oldRender==='function'&&!window.__spi512RenderWrap){window.__spi512RenderWrap=true;window.render=function(){const r=oldRender.apply(this,arguments);try{decorate();installPinHandlers();drawWires()}catch(e){}return r}}
window.addEventListener('load',()=>{setTimeout(()=>{decorate();sync()},1200);setInterval(sync,900)});
})();
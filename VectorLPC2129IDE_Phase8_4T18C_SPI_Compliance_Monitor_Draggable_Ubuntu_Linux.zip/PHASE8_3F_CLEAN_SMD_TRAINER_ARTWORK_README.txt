VECTOR LPC2129 IDE — Phase 8.3F
Clean SMD Trainer Artwork

Baseline:
- Built directly from working Phase 8.3E.
- Functional P1.30/P1.31 logic is unchanged.
- Approved assets/vector_lpc2129_board.png is byte-for-byte unchanged.

Artwork correction:
- Removed the tall P1.30/P1.31 overlay columns that covered the printed lower I/O labels.
- Added one compact two-section SMD trainer card in the open lower-right PCB area ABOVE the printed I/O label band.
- P1.30 section contains:
  * AL/AH SMD DIP selector
  * Active-low SMD pushbutton
  * Active-high SMD pushbutton
  * visible miniature 10 kΩ pull-up and pull-down SMD resistors
- P1.31 section contains:
  * AL/AH SMD DIP selector
  * active-low SMD LED
  * active-high SMD LED
  * individual miniature 330 Ω SMD resistors
- Thin P1.30/P1.31 alignment leaders stop before the printed label/number band.
- Existing I/O numbers, P1.30/P1.31 labels and bottom header remain fully visible.

Canonical execution rule remains:
C source -> ARM GCC -> ELF/HEX -> ARM7 worker -> official LPC2129 P1 GPIO
-> P1.30 board input circuit -> firmware -> P1.31 board output circuit.

The four C combinations from Phase 8.3E are retained unchanged.

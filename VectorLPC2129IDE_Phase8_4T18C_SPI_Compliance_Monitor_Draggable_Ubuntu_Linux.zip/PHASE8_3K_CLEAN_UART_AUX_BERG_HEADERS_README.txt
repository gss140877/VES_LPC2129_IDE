VECTOR LPC2129 IDE — Phase 8.3K
Clean UART/AUX Berg Headers

Based directly on confirmed-working Phase 8.3J.

Artwork-only refinement requested by user:
- Removed visible A0, A1, A2 and A3 labels from the UART/AUX SMD LED bank.
- Kept only the four physical-looking Berg/header sockets.
- No extra AUX pad graphics were added.
- Internal AUX0..AUX3 electrical node IDs are retained so wiring behavior is unchanged.
- Tooltips remain descriptive but no A0..A3 text is printed on the board.
- Draggable/bendable over-board wiring from Phase 8.3J is retained.
- Approved LPC2129 board PNG is unchanged.

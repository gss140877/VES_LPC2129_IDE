/* VECTOR LPC2129 IDE — Phase 8.4N
   Separate realistic 8-channel LED Output and Switch Input trainer PCBs.
   Canonical electrical path is preserved:
   ARM7TDMI-S -> LPC2129 GPIO -> project wiring -> external trainer board.
   LED colour is a simulation-only property and is not drawn as a physical PCB control.
*/
(function(){
'use strict';
if(window.__phase84nSeparateIoBoardsInstalled)return;
window.__phase84nSeparateIoBoardsInstalled=true;

const COLORS={
 red:{rgb:'255,42,48',label:'Red'},green:{rgb:'45,245,105',label:'Green'},yellow:{rgb:'255,232,56',label:'Yellow'},
 amber:{rgb:'255,163,34',label:'Amber'},blue:{rgb:'52,142,255',label:'Blue'},white:{rgb:'246,250,255',label:'White'}
};
const colorKeys=Object.keys(COLORS);
const colorOptions=sel=>colorKeys.map(k=>`<option value="${k}" ${k===sel?'selected':''}>${COLORS[k].label}</option>`).join('');

function ensureLed(p){
 if(!Array.isArray(p.ledModes))p.ledModes=Array(8).fill('AH');
 if(!Array.isArray(p.ledColors))p.ledColors=['red','green','yellow','amber','blue','white','red','green'];
 if(!Number.isInteger(p.ledColorChannel)||p.ledColorChannel<0||p.ledColorChannel>7)p.ledColorChannel=0;
 while(p.ledModes.length<8)p.ledModes.push('AH');while(p.ledColors.length<8)p.ledColors.push('red');
}
function ensureSw(p){
 if(!Array.isArray(p.switchModes))p.switchModes=Array(8).fill('AH');
 if(!Array.isArray(p.switchStates))p.switchStates=Array(8).fill(false);
 while(p.switchModes.length<8)p.switchModes.push('AH');while(p.switchStates.length<8)p.switchStates.push(false);
}

const baseAdd=(typeof addPart==='function')?addPart:null;
if(baseAdd){
 window.addPart=addPart=function(type,opt={}){
   if(type!=='led8board'&&type!=='switch8board')return baseAdd(type,opt);
   const isLed=type==='led8board';
   const id=(isLed?'ledpcb8_':'swpcb8_')+(nextId++);
   const p={id,type,x:opt.x??430,y:opt.y??(isLed?90:365),scale:opt.scale??1,state:LOW,value:0};
   if(isLed)ensureLed(p);else ensureSw(p);
   project.parts.push(p);selectedId=id;render();
   try{log((isLed?'8-channel SMD LED output':'8-channel SMD switch input')+' PCB added. Berg headers face outward along the top edge.');}catch(e){}
   return p;
 };
}

function otherNodes(node){const a=[];if(!project||!Array.isArray(project.wires))return a;for(const w of project.wires){if(w.from===node)a.push(w.to);else if(w.to===node)a.push(w.from);}return a;}
function isVcc(n){return /(^|\.)(3V3|VCC|VDD)$|uno\.3V3/i.test(String(n||''));}
function isGnd(n){return /(^|\.)GND$|uno\.GND/i.test(String(n||''));}
function portPin(n){const m=String(n||'').match(/uno\.P([01])_(\d+)/);return m?{port:Number(m[1]),pin:Number(m[2])}:null;}
function signalPortPin(node){for(const n of otherNodes(node)){const pp=portPin(n);if(pp)return pp;}return null;}
function levelFor(pp){if(!pp||!window.lpcGpio)return 0;const g=pp.port?window.lpcGpio.p1:window.lpcGpio.p0;return g&&((g.IOPIN>>>pp.pin)&1)?1:0;}
function powered(p){return otherNodes(p.id+'.VCC').some(isVcc)&&otherNodes(p.id+'.GND').some(isGnd);}

function dipHtml(kind,i,mode){return `<button type="button" class="io8l-dip ${mode==='AL'?'al':'ah'}" data-kind="${kind}" data-ch="${i}" title="${mode} selection"><span class="dip-case"><i></i></span><b>AH</b><b>AL</b></button>`;}
function edgePin(p,prefix,i,label){const n=i+1;return `<span class="pin io8l-edgepin" data-node="${p.id}.${prefix}${n}" data-tip="${label} ${n} signal"><i></i></span><span class="io8l-pinlabel">${prefix}${n}</span>`;}
function powerHeader(p){return `<div class="io8l-power"><span class="pin io8l-pwrpin" data-node="${p.id}.VCC" data-tip="3.3V"><i></i></span><b>3V3</b><span class="pin io8l-pwrpin" data-node="${p.id}.GND" data-tip="Ground"><i></i></span><b>GND</b><span class="io8l-power-led"></span></div>`;}
function commonPcbChrome(kind,title,subtitle,inside){return `<div class="io8l-pcb ${kind}"><span class="io8l-hole h1"></span><span class="io8l-hole h2"></span><span class="io8l-hole h3"></span><span class="io8l-hole h4"></span><div class="io8l-brand"><b>VECTOR</b><strong>${title}</strong><span>${subtitle}</span></div>${inside}</div>`;}

function ledBoardHtml(p){
 ensureLed(p);
 const ch=Array.from({length:8},(_,i)=>{const n=i+1,mode=p.ledModes[i]||'AH';return `<div class="io8l-ch ledch c${i}">${edgePin(p,'L',i,'LED')}<span class="io8l-trace sig"></span><span class="io8l-smdled" data-led="${i}"><i></i><em></em></span><span class="io8l-ref">D${n}</span><span class="io8l-res"><i></i></span><span class="io8l-reslabel">330R</span>${dipHtml('ledmode',i,mode)}<span class="io8l-circuit-note">${mode==='AH'?'SRC':'SINK'}</span></div>`;}).join('');
 const inner=`${powerHeader(p)}${ledSimControls(p)}<div class="io8l-top-silk">GPIO SIGNAL BERG HEADER • OUTWARD FACING</div><div class="io8l-channel-row">${ch}</div><div class="io8l-bus"><b>3V3</b><i></i><b>GND</b></div><div class="io8l-footer"><span>8 × SMD LED OUTPUTS</span><span>330Ω • AH/AL HARDWARE SELECT</span></div>`;
 return commonPcbChrome('ledpcb','8-CH SMD LED OUTPUT BOARD','LPC / MCU DIGITAL OUTPUT TRAINER',inner);
}
function switchBoardHtml(p){
 ensureSw(p);
 const ch=Array.from({length:8},(_,i)=>{const n=i+1,mode=p.switchModes[i]||'AH';return `<div class="io8l-ch swch c${i}">${edgePin(p,'S',i,'Switch')}<span class="io8l-trace sig"></span><button type="button" class="io8l-push" data-kind="push" data-ch="${i}" title="SMD push button ${n}"><i></i><em></em></button><span class="io8l-ref">SW${n}</span><span class="io8l-res pull"><i></i></span><span class="io8l-reslabel">10K</span>${dipHtml('swmode',i,mode)}<span class="io8l-circuit-note">${mode==='AH'?'P/D':'P/U'}</span></div>`;}).join('');
 const inner=`${powerHeader(p)}<div class="io8l-top-silk">GPIO SIGNAL BERG HEADER • OUTWARD FACING</div><div class="io8l-channel-row">${ch}</div><div class="io8l-bus"><b>3V3</b><i></i><b>GND</b></div><div class="io8l-footer"><span>8 × SMD MOMENTARY PUSH BUTTONS</span><span>10K PULL-UP / PULL-DOWN • AH/AL HARDWARE SELECT</span></div>`;
 return commonPcbChrome('swpcb','8-CH SMD SWITCH INPUT BOARD','LPC / MCU DIGITAL INPUT TRAINER',inner);
}
function ledSimControls(p){
 ensureLed(p);
 const ch=p.ledColorChannel|0;
 const ledOpts=Array.from({length:8},(_,i)=>`<option value="${i}" ${i===ch?'selected':''}>LED ${i+1}</option>`).join('');
 return `<div class="io8n-led-simctrl" title="Simulation-only LED colour control"><span class="io8n-simtag">SIM</span><label>LED<select data-kind="ledpick">${ledOpts}</select></label><label>COLOR<select data-kind="ledcolorpick">${colorOptions(p.ledColors[ch]||'red')}</select></label></div>`;
}

function setDipVisual(p,el,kind,i){const isLed=kind==='ledmode',mode=(isLed?p.ledModes[i]:p.switchModes[i])||'AH';const d=el.querySelector(`[data-kind="${kind}"][data-ch="${i}"]`);if(!d)return;d.classList.toggle('ah',mode==='AH');d.classList.toggle('al',mode==='AL');const note=d.parentElement&&d.parentElement.querySelector('.io8l-circuit-note');if(note)note.textContent=isLed?(mode==='AH'?'SRC':'SINK'):(mode==='AH'?'P/D':'P/U');}
function bindBoard(p,el){
 el.querySelectorAll('button,select').forEach(c=>{c.onmousedown=e=>e.stopPropagation();c.onpointerdown=e=>e.stopPropagation();c.onclick=e=>e.stopPropagation();});
 el.querySelectorAll('[data-kind="ledmode"]').forEach(b=>b.onclick=e=>{e.stopPropagation();const i=+e.currentTarget.dataset.ch;p.ledModes[i]=p.ledModes[i]==='AH'?'AL':'AH';setDipVisual(p,el,'ledmode',i);refreshBoards();});
 el.querySelectorAll('[data-kind="swmode"]').forEach(b=>b.onclick=e=>{e.stopPropagation();const i=+e.currentTarget.dataset.ch;p.switchModes[i]=p.switchModes[i]==='AH'?'AL':'AH';setDipVisual(p,el,'swmode',i);syncSwitchInputs(true);refreshBoards();});
 const ledPick=el.querySelector('[data-kind="ledpick"]');
 if(ledPick)ledPick.onchange=e=>{e.stopPropagation();p.ledColorChannel=Math.max(0,Math.min(7,Number(e.target.value)||0));const cp=el.querySelector('[data-kind="ledcolorpick"]');if(cp)cp.value=p.ledColors[p.ledColorChannel]||'red';};
 const colorPick=el.querySelector('[data-kind="ledcolorpick"]');
 if(colorPick)colorPick.onchange=e=>{e.stopPropagation();ensureLed(p);p.ledColors[p.ledColorChannel|0]=e.target.value;refreshBoards();};
 el.querySelectorAll('[data-kind="push"]').forEach(b=>{const i=+b.dataset.ch;const press=e=>{e.preventDefault();e.stopPropagation();p.switchStates[i]=true;syncSwitchInputs(true);refreshBoards();};const release=e=>{if(e)e.stopPropagation();if(!p.switchStates[i])return;p.switchStates[i]=false;syncSwitchInputs(true);refreshBoards();};b.onpointerdown=press;b.onpointerup=release;b.onpointercancel=release;b.onpointerleave=e=>{if(e.buttons===0)release(e);};b.oncontextmenu=e=>e.preventDefault();});
}
function renderBoards(){
 if(!project||!Array.isArray(project.parts))return;
 for(const p of project.parts){
   if(p.type!=='led8board'&&p.type!=='switch8board')continue;
   const el=document.getElementById(p.id);if(!el)continue;
   el.classList.add('io8lPart',p.type==='led8board'?'led8Part':'switch8Part');
   el.innerHTML=p.type==='led8board'?ledBoardHtml(p):switchBoardHtml(p);bindBoard(p,el);
 }
 try{if(typeof installPinHandlers==='function')installPinHandlers();}catch(e){}
 try{if(typeof drawWires==='function')drawWires();}catch(e){}
 refreshBoards();syncSwitchInputs(false);
}
function refreshBoards(){
 if(!project||!Array.isArray(project.parts))return;
 for(const p of project.parts){
   if(p.type!=='led8board'&&p.type!=='switch8board')continue;const el=document.getElementById(p.id);if(!el)continue;const pwr=powered(p);el.classList.toggle('powered',pwr);const pl=el.querySelector('.io8l-power-led');if(pl)pl.classList.toggle('on',pwr);
   if(p.type==='led8board'){ensureLed(p);for(let i=0;i<8;i++){setDipVisual(p,el,'ledmode',i);const pp=signalPortPin(p.id+'.L'+(i+1)),lv=levelFor(pp),mode=p.ledModes[i]||'AH',on=pwr&&!!pp&&(mode==='AH'?lv===1:lv===0),smd=el.querySelector(`[data-led="${i}"]`);if(smd){const c=COLORS[p.ledColors[i]]||COLORS.red;smd.style.setProperty('--io8-rgb',c.rgb);smd.classList.toggle('on',on);}}}
   else{ensureSw(p);for(let i=0;i<8;i++){setDipVisual(p,el,'swmode',i);const push=el.querySelector(`[data-kind="push"][data-ch="${i}"]`);if(push)push.classList.toggle('pressed',!!p.switchStates[i]);}}
 }
}

const inputCache=new Map();
function localInput(pp,level,release){if(!pp||!window.lpcGpio)return;const g=pp.port?window.lpcGpio.p1:window.lpcGpio.p0;if(!g)return;g.externalInputs=g.externalInputs||{};const bit=(2**pp.pin)>>>0;if(release){delete g.externalInputs[pp.pin];return;}g.externalInputs[pp.pin]=!!level;if(!(g.IODIR&bit))g.IOPIN=level?((g.IOPIN|bit)>>>0):((g.IOPIN&~bit)>>>0);}
function syncSwitchInputs(force){
 if(!project||!Array.isArray(project.parts))return;const seen=new Set();
 for(const p of project.parts){if(p.type!=='switch8board')continue;ensureSw(p);const pwr=powered(p);for(let i=0;i<8;i++){const pp=signalPortPin(p.id+'.S'+(i+1));if(!pp)continue;const key=pp.port+':'+pp.pin;seen.add(key);if(!pwr){if(force||inputCache.get(key)!=='released'){if(typeof window.phase82bReleaseInput==='function')window.phase82bReleaseInput(pp.port,pp.pin);localInput(pp,0,true);inputCache.set(key,'released');}continue;}const pressed=!!p.switchStates[i],mode=p.switchModes[i]||'AH',level=mode==='AH'?pressed:!pressed;if(force||inputCache.get(key)!==level){if(typeof window.phase82bSetInput==='function')window.phase82bSetInput(pp.port,pp.pin,level);localInput(pp,level,false);inputCache.set(key,level);}}}
 for(const key of [...inputCache.keys()]){if(seen.has(key))continue;const [port,pin]=key.split(':').map(Number);if(typeof window.phase82bReleaseInput==='function')window.phase82bReleaseInput(port,pin);inputCache.delete(key);}
 try{if(typeof renderLpcGpioMonitor==='function')renderLpcGpioMonitor();}catch(e){}
}

const baseRender=(typeof render==='function')?render:null;
if(baseRender){window.render=render=function(){const r=baseRender.apply(this,arguments);renderBoards();return r;};}
if(typeof window.phase81RefreshCanvasOutputs==='function'){const old=window.phase81RefreshCanvasOutputs;window.phase81RefreshCanvasOutputs=function(){const r=old.apply(this,arguments);refreshBoards();return r;};}
if(typeof window.updateLpcExternalLoads==='function'){const old=window.updateLpcExternalLoads;window.updateLpcExternalLoads=function(){const r=old.apply(this,arguments);refreshBoards();return r;};}
window.phase82bReleaseInput=window.phase82bReleaseInput||function(port,pin){const w=window.phase82bWorker;if(w)w.postMessage({type:'gpio-input-release',port:Number(port)?1:0,pin:Number(pin)});};
window.phase84lRefreshIOBoards=refreshBoards;window.phase84lSyncSwitchInputs=syncSwitchInputs;window.phase84nRefreshIOBoards=refreshBoards;
window.addEventListener('pointerup',()=>{if(!project||!Array.isArray(project.parts))return;let changed=false;for(const p of project.parts){if(p.type!=='switch8board'||!Array.isArray(p.switchStates))continue;for(let i=0;i<8;i++)if(p.switchStates[i]){p.switchStates[i]=false;changed=true;}}if(changed){syncSwitchInputs(true);refreshBoards();}});
window.addEventListener('load',()=>setTimeout(()=>{renderBoards();syncSwitchInputs(true);},350));
setInterval(()=>syncSwitchInputs(false),120);
})();

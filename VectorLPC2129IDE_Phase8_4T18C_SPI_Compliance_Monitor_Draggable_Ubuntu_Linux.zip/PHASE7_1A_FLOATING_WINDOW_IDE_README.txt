VECTOR LPC2129 IDE - Phase 7.1A Floating Window IDE

Changes over 7.0A:
- Source files now open in independent desktop-style windows.
- main.c is editable and synchronized back to the real build source.
- startup_lpc2129_minimal.s and linker_lpc2129.ld open as independent read-only source windows.
- Project Explorer is now openable, closeable, draggable and resizable.
- Disassembly, Memory, Watch and Target Options retain open/close/drag and now use unified resize behavior.
- CPU Profiler, CPU Registers, Peripheral Registers, Execution Trace and Instruction Coverage use the same floating-window behavior.
- Clock/Timing receives unified resizing in addition to dragging/closing.
- Compiler/Build Output and UART Serial Monitor can be opened as floating, draggable, resizable, closeable windows.
- View menu is expanded into the central window launcher.
- Circuit canvas remains the IDE workspace behind the floating tool windows.

Ubuntu launch:
chmod +x *.sh
./START_APP_WINDOW_NO_URL_BAR.sh

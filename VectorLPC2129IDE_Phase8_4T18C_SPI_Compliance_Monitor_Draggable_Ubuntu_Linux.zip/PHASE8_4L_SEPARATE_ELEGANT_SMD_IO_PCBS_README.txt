VECTOR LPC2129 IDE — Phase 8.4L
Separate Elegant SMD I/O Trainer PCBs

Changes from Phase 8.4K:
- The combined LED/switch trainer is replaced in the Components palette by two separate boards:
  1. 8-CH SMD LED Output PCB
  2. 8-CH SMD Switch Input PCB
- Both PCBs use a refined green solder-mask style intended to visually match the LPC2129 trainer board.
- All eight signal Berg headers are on the TOP PCB edge and face outward for easy wiring.
- 3V3/GND Berg headers are also on the top edge.
- LED board: eight horizontal SMD LEDs, 330R resistors, individual AH/AL DIP selection.
- Switch board: eight horizontal SMD momentary push buttons, 10K pull network, individual AH/AL DIP selection.
- LED emission colour remains a SIMULATION option only and is displayed outside the physical PCB when the LED board is selected.
- Existing Phase 8.4H canonical ARM7/LPC2129 CPU-peripheral timing model is unchanged.
- No Timer-to-LED or source-parsing shortcut was added.

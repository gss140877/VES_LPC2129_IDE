let runtimeLoopDelayMs = 5;
let runtimeLoopCounter = 0;
const HIGH = 1;
const LOW = 0;

const INPUT = "INPUT";
const OUTPUT = "OUTPUT";
const INPUT_PULLUP = "INPUT_PULLUP";
const INPUT_PULLDOWN = "INPUT_PULLDOWN";

const CHANGE = "CHANGE";
const RISING = "RISING";
const FALLING = "FALLING";

const LSBFIRST = 0;
const MSBFIRST = 1;

const DEC = 10;
const HEX = 16;
const OCT = 8;
const BIN = 2;

let pinModes = {};
let pinValues = {};
let toneStates = {};
let runtimeStartTime = Date.now();
const A0="A0",A1="A1",A2="A2",A3="A3",A4="A4",A5="A5";
let project,nextId=1,selectedId=null,wiringSource=null,wiringMouse=null,running=false,timers=[];

function log(s){let e=document.getElementById("log");e.textContent+="\n"+s;e.scrollTop=e.scrollHeight}
function serial(s){
  let e=document.getElementById("serial");
  e.textContent += "\n" + s;
  if(e.textContent.length > 12000) e.textContent = e.textContent.slice(-12000);
  e.scrollTop = e.scrollHeight;
}

// Append raw serial bytes/chars exactly as transmitted by the emulated AVR USART.
// Do not add extra newlines here: Serial.println() already sends CR/LF, while
// Serial.print() sends only the requested characters.
function serialRaw(s){
  let e=document.getElementById("serial");
  if(!e) return;
  e.textContent += String(s);
  if(e.textContent.length > 20000) e.textContent = e.textContent.slice(-20000);
  e.scrollTop = e.scrollHeight;
}
window.serialRaw = serialRaw;
function clearLog(){document.getElementById("log").textContent=""}
function clearSerial(){document.getElementById("serial").textContent=""}
function status(s){document.getElementById("status").textContent=s}


/* Stable V19 patch: prevent no-delay loop freeze without changing UI/zoom/wiring */
let runtimeRenderPending = false;
function scheduleRuntimeRender() {
  if (runtimeRenderPending) return;
  runtimeRenderPending = true;
  requestAnimationFrame(() => {
    runtimeRenderPending = false;
    render();
  });
}
function runtimeYield() {
  return new Promise(resolve => {
    const t = setTimeout(resolve, runtimeLoopDelayMs);
    if (typeof timers !== "undefined") timers.push(t);
  });
}
function newProject(){
  stopSimulation();
  nextId=1; selectedId=null; wiringSource=null; wiringMouse=null;
  project={canvasScale:1,parts:[],wires:[],code:document.getElementById("code").value};
  document.querySelectorAll(".part").forEach(e=>e.remove());
  let p=addPart("led",{x:750,y:70,scale:1});
  addWire("uno.D13",p.id+".A");
  addWire("uno.GND",p.id+".K");
  applyCanvasZoom();
  render();
  clearLog(); clearSerial();
  log("V18 ready: mouse wheel over component zooms that component; mouse wheel on empty canvas zooms full scene.");
}

function applyCanvasZoom(){
  let scene=document.getElementById("scene");
  scene.style.transform=`scale(${project.canvasScale})`;
  
  status("Canvas zoom: "+Math.round(project.canvasScale*100)+"%");
  drawWires();
}
function zoomCanvas(delta){project.canvasScale=Math.max(.4,Math.min(2.5,project.canvasScale+delta));applyCanvasZoom()}
function setCanvasScale(v){project.canvasScale=Number(v);applyCanvasZoom()}
function resetCanvasZoom(){project.canvasScale=1;applyCanvasZoom()}

function zoomSelected(delta){
  let p=project.parts.find(x=>x.id===selectedId);
  if(!p){log("Select a component first.");return}
  p.scale=Math.max(.4,Math.min(2.5,(p.scale||1)+delta));
  render();
}
function setSelectedScale(v){
  let p=project.parts.find(x=>x.id===selectedId);
  if(!p)return;
  p.scale=Number(v);
  render();
}
function resetSelectedZoom(){
  let p=project.parts.find(x=>x.id===selectedId);
  if(!p){log("Select a component first.");return}
  p.scale=1;
  render();
}
function updatePartZoomUI(){
  let p=project.parts.find(x=>x.id===selectedId);
  let v=p?Math.round((p.scale||1)*100):100;
  
  
  document.getElementById("selected").textContent=p?selectedId:"None";
}

function addPart(type,opt={}){
  let id=(type==="led"?"led":type==="button"?"btn":type==="pot"?"pot":"sound")+nextId++;
  let p={id,type,x:opt.x??120+project.parts.length*60,y:opt.y??100+project.parts.length*40,scale:opt.scale??1,state:LOW,value:0};
  if(type==="led") p.ledColor=opt.ledColor||opt.color||"red";
  project.parts.push(p); selectedId=id; render(); log(type+" added"); return p;
}
function deleteSelected(){
  if(!selectedId){log("No selected part");return}
  project.parts=project.parts.filter(p=>p.id!==selectedId);
  project.wires=project.wires.filter(w=>!w.from.startsWith(selectedId+".")&&!w.to.startsWith(selectedId+"."));
  selectedId=null; render(); log("Part deleted");
}

function render(){
  document.querySelectorAll(".part").forEach(e=>e.remove());
  project.parts.forEach(p=>{
    let div=document.createElement("div");
    div.id=p.id; div.className="part "+(p.id===selectedId?"selected ":"");
    div.style.left=p.x+"px"; div.style.top=p.y+"px";
    div.style.transform=`scale(${p.scale||1})`;

    if(p.type==="led"){
      div.className+="led";
      const ledColor=p.ledColor||'red';
      div.dataset.ledColor=ledColor;
      div.innerHTML=`<div class="ledBulb ${p.state?"on":""}"><span class="ledGlassHighlight"></span><span class="ledGlassCore"></span></div><div class="ledLegs"><span class="leg"></span><span class="leg"></span></div>
      <span class="pin" data-node="${p.id}.A" data-tip="${p.id} LED anode" style="left:-20px;top:82px;background:#0b63ff">A</span>
      <span class="pin" data-node="${p.id}.K" data-tip="${p.id} LED cathode/GND" style="left:84px;top:82px;background:#087a3b">K</span>
      <span class="pinText" style="left:-33px;top:60px">A</span><span class="pinText" style="left:90px;top:60px">K</span><div class="label">${p.id}</div>
      ${p.id===selectedId?`<div class="ledColorControl" title="LED lens / emission colour"><span>COLOR</span><select class="ledColorSelect" data-led-id="${p.id}"><option value="red" ${ledColor==='red'?'selected':''}>Red</option><option value="green" ${ledColor==='green'?'selected':''}>Green</option><option value="yellow" ${ledColor==='yellow'?'selected':''}>Yellow</option><option value="amber" ${ledColor==='amber'?'selected':''}>Amber</option><option value="blue" ${ledColor==='blue'?'selected':''}>Blue</option><option value="white" ${ledColor==='white'?'selected':''}>White</option></select></div>`:''}`;
      const ledSel=div.querySelector('.ledColorSelect');
      if(ledSel){
        ledSel.onpointerdown=e=>e.stopPropagation();
        ledSel.onclick=e=>e.stopPropagation();
        ledSel.onchange=e=>{e.stopPropagation(); if(typeof window.setExternalLedColor==='function') window.setExternalLedColor(p.id,e.target.value);};
      }
    }
    if(p.type==="button"){
      div.className+="buttonPart";
      div.innerHTML=`<div class="buttonCircle ${p.state?"pressed":""}"></div>
      <span class="pin" data-node="${p.id}.S" data-tip="${p.id} button signal" style="left:-34px;top:38px;background:#0b63ff">S</span>
      <span class="pin" data-node="${p.id}.G" data-tip="${p.id} button GND" style="left:124px;top:38px;background:#087a3b">G</span>
      <span class="pinText" style="left:-50px;top:16px">SIG</span><span class="pinText" style="left:116px;top:16px">GND</span><div class="label">${p.id}</div>`;
      {
        const bc=div.querySelector(".buttonCircle");
        const applyButtonState=(v,e)=>{
          if(e)e.stopPropagation();
          p.state=v?HIGH:LOW;
          bc.classList.toggle("pressed",!!p.state);
          try{ if(typeof window.phase80OnButtonStateChange==='function') window.phase80OnButtonStateChange(p); }catch(err){}
        };
        bc.onpointerdown=e=>{
          e.preventDefault();
          try{bc.setPointerCapture(e.pointerId);}catch(err){}
          applyButtonState(HIGH,e);
        };
        bc.onpointerup=e=>{
          try{if(bc.hasPointerCapture&&bc.hasPointerCapture(e.pointerId))bc.releasePointerCapture(e.pointerId);}catch(err){}
          applyButtonState(LOW,e);
        };
        bc.onpointercancel=e=>applyButtonState(LOW,e);
      }
    }
    if(p.type==="pot"){
      /* Phase 8.4R: one canonical trimpot component for palette + every example. */
      const hasAdc=(p.adcChannel!==undefined&&p.adcChannel!==null);
      div.className+="potPart adcTripot";
      const ch=hasAdc?Number(p.adcChannel):null;
      const raw=Math.max(0,Math.min(1023,Number(p.value)||0));
      const volts=(raw*3.3/1023).toFixed(3);
      const signalLabel=hasAdc?('AIN'+ch):'WIPER';
      div.innerHTML=`<div class="adcTripotTop"><span>${signalLabel}</span><b>10k TRIMPOT</b></div>
      <div class="adcTripotBody"><div class="adcTripotScrew" style="--turn:${(raw/1023)*300-150}deg"></div></div>
      <input class="adcTripotRange" type="range" min="0" max="1023" value="${raw}" aria-label="${p.id} trimpot value">
      <div class="adcTripotRead"><b>${raw}</b><span>${volts} V</span></div>
      <span class="pin adcTripotPin vcc" data-node="${p.id}.VCC" data-tip="${p.id} terminal 1 — 3.3V">V</span>
      <span class="pin adcTripotPin out" data-node="${p.id}.OUT" data-tip="${p.id} wiper${hasAdc?' — AIN'+ch:''}">O</span>
      <span class="pin adcTripotPin gnd" data-node="${p.id}.GND" data-tip="${p.id} terminal 3 — GND">G</span>`;
      const range=div.querySelector("input");
      const updatePotVisual=(v)=>{
        v=Math.max(0,Math.min(1023,Math.round(v)));p.value=v;range.value=String(v);
        const sc=div.querySelector('.adcTripotScrew'),rd=div.querySelector('.adcTripotRead');
        if(sc)sc.style.setProperty('--turn',((v/1023)*300-150)+'deg');
        if(rd){const b=rd.querySelector('b'),sp=rd.querySelector('span');if(b)b.textContent=String(v);if(sp)sp.textContent=(v*3.3/1023).toFixed(3)+' V';}
        try{if(typeof window.phase84SyncAdcCanvas==='function')window.phase84SyncAdcCanvas()}catch(err){}
      };
      range.oninput=e=>updatePotVisual(parseInt(e.target.value));
      const drag=div.querySelector('.adcTripotBody');let dragging=false,startX=0,startY=0,startV=raw,pid=null;
      const move=e=>{if(!dragging||e.pointerId!==pid)return;const dx=e.clientX-startX,dy=startY-e.clientY;updatePotVisual(startV+dx*5+dy*5);e.preventDefault()};
      const end=e=>{if(!dragging||e.pointerId!==pid)return;dragging=false;try{drag.releasePointerCapture(pid)}catch(err){};pid=null;e.preventDefault()};
      drag.onpointerdown=e=>{if(e.button!==0)return;dragging=true;pid=e.pointerId;startX=e.clientX;startY=e.clientY;startV=Number(p.value)||0;try{drag.setPointerCapture(pid)}catch(err){};e.stopPropagation();e.preventDefault()};
      drag.onpointermove=move;drag.onpointerup=end;drag.onpointercancel=end;
    }

    if(p.type==="sound"){
      div.className+="soundPart";
      if(p.value===undefined)p.value=0;
      if(p.digital===undefined)p.digital=LOW;
      div.innerHTML=`<div class="soundTitle">KY-037 Sound Sensor</div>
      <div class="soundBoard">
        <div class="mic"></div><div class="trimpot">W104</div><div class="chip"></div>
        <span class="pin" data-node="${p.id}.A0" data-tip="${p.id} analog output A0" style="left:-18px;top:38px;background:#8e24aa">A0</span>
        <span class="pin" data-node="${p.id}.G" data-tip="${p.id} GND" style="left:-18px;top:66px;background:#087a3b">G</span>
        <span class="pin" data-node="${p.id}.V" data-tip="${p.id} VCC / 5V" style="left:-18px;top:94px;background:#d32f2f">+</span>
        <span class="pin" data-node="${p.id}.D0" data-tip="${p.id} digital output D0" style="left:-18px;top:122px;background:#f2cc00;color:#111">D0</span>
        <span class="pinText" style="left:-54px;top:40px">A0</span>
        <span class="pinText" style="left:-48px;top:68px">G</span>
        <span class="pinText" style="left:-48px;top:96px">+</span>
        <span class="pinText" style="left:-54px;top:124px">D0</span>
      </div>
      <input class="soundSlider" type="range" min="0" max="1023" value="${p.value}">
      <div class="label">${p.id}: <span>${p.value}</span></div>`;
      div.querySelector(".soundSlider").oninput=e=>{
        p.value=parseInt(e.target.value);
        p.digital = p.value>500 ? HIGH : LOW;
        render();
      };
    }


    if(p.type==="buzzer"){
      div.className+="buzzerPart";
      if(p.state===undefined)p.state=LOW;
      div.innerHTML=`<img class="componentImg" src="assets/components/buzzer.png">
      <span class="pin" data-node="${p.id}.SIG" data-tip="${p.id} signal" style="left:-28px;top:32px;background:#f2cc00;color:#111">S</span>
      <span class="pin" data-node="${p.id}.GND" data-tip="${p.id} GND" style="left:112px;top:32px;background:#087a3b">G</span>
      <div class="label">${p.id}</div>`;
    }

    if(p.type==="servo"){
      div.className+="servoPart";
      if(p.angle===undefined)p.angle=0;
      div.innerHTML=`<img class="componentImg" src="assets/components/servo.png">
      <span class="pin" data-node="${p.id}.GND" data-tip="${p.id} GND / brown" style="left:132px;top:20px;background:#087a3b">G</span>
      <span class="pin" data-node="${p.id}.VCC" data-tip="${p.id} VCC / red" style="left:132px;top:50px;background:#d32f2f">V</span>
      <span class="pin" data-node="${p.id}.SIG" data-tip="${p.id} signal / orange" style="left:132px;top:80px;background:#f2cc00;color:#111">S</span>
      <div class="label">${p.id}</div>`;
    }

    if(p.type==="lcd"){
      div.className+="lcdPart";
      if(!p.text)p.text=["                ","                "];
      const lcdPins=["VSS","VDD","RS","EN","D4","D5","D6","D7"];
      div.innerHTML=`<img class="componentImg" src="assets/components/lcd16x2.png">
      <div class="lcdOverlay"><div>${p.text[0]}</div><div>${p.text[1]}</div></div>
      ${lcdPins.map((n,i)=>`<span class="pin" data-node="${p.id}.${n}" data-tip="${p.id} ${n}" style="left:${-16+i*38}px;top:126px;background:${n==="VSS"?"#087a3b":n==="VDD"?"#d32f2f":"#0b63ff"}">${n.substring(0,2)}</span>`).join("")}
      <div class="label">${p.id}</div>`;
    }

    if(p.type==="relay"){
      div.className+="relayPart";
      if(p.state===undefined)p.state=LOW;
      div.innerHTML=`<img class="componentImg" src="assets/components/relay.png">
      <span class="pin" data-node="${p.id}.IN" data-tip="${p.id} IN" style="left:-24px;top:24px;background:#f2cc00;color:#111">IN</span>
      <span class="pin" data-node="${p.id}.VCC" data-tip="${p.id} VCC" style="left:-24px;top:58px;background:#d32f2f">V</span>
      <span class="pin" data-node="${p.id}.GND" data-tip="${p.id} GND" style="left:-24px;top:92px;background:#087a3b">G</span>
      <span class="pin" data-node="${p.id}.NO" data-tip="${p.id} NO" style="left:144px;top:18px;background:#555">NO</span>
      <span class="pin" data-node="${p.id}.COM" data-tip="${p.id} COM" style="left:144px;top:58px;background:#555">C</span>
      <span class="pin" data-node="${p.id}.NC" data-tip="${p.id} NC" style="left:144px;top:98px;background:#555">NC</span>
      <div class="label">${p.id}</div>`;
    }

    if(p.type==="dht11"){
      div.className+="dhtPart";
      div.innerHTML=`<img class="componentImg" src="assets/sensors/dht11.png">
      <span class="pin" data-node="${p.id}.VCC" data-tip="${p.id} VCC" style="left:-24px;top:28px;background:#d32f2f">V</span>
      <span class="pin" data-node="${p.id}.DATA" data-tip="${p.id} DATA" style="left:-24px;top:62px;background:#f2cc00;color:#111">D</span>
      <span class="pin" data-node="${p.id}.GND" data-tip="${p.id} GND" style="left:-24px;top:96px;background:#087a3b">G</span>
      <div class="label">${p.id}</div>`;
    }

    if(p.type==="ultrasonic"){
      div.className+="ultraPart";
      div.innerHTML=`<img class="componentImg" src="assets/sensors/ultrasonic_hcsr04.png">
      <span class="pin" data-node="${p.id}.VCC" data-tip="${p.id} VCC" style="left:10px;top:100px;background:#d32f2f">V</span>
      <span class="pin" data-node="${p.id}.TRIG" data-tip="${p.id} TRIG" style="left:58px;top:100px;background:#f2cc00;color:#111">T</span>
      <span class="pin" data-node="${p.id}.ECHO" data-tip="${p.id} ECHO" style="left:106px;top:100px;background:#0b63ff">E</span>
      <span class="pin" data-node="${p.id}.GND" data-tip="${p.id} GND" style="left:154px;top:100px;background:#087a3b">G</span>
      <div class="label">${p.id}</div>`;
    }

    div.onclick=e=>{if(e.target.classList.contains("pin"))return;e.stopPropagation();selectedId=p.id;updatePartZoomUI();render()};
    document.getElementById("scene").appendChild(div);
    makeDraggable(div,p);
  });
  installPinHandlers();
  drawWires();
  updatePartZoomUI();
}

function makeDraggable(el,p){
  let drag=false,ox=0,oy=0;
  el.addEventListener("mousedown",e=>{
    if(e.target.classList.contains("pin")||e.target.tagName==="INPUT")return;
    drag=true; ox=e.offsetX*(p.scale||1); oy=e.offsetY*(p.scale||1);
  });
  document.addEventListener("mousemove",e=>{
    if(!drag)return;
    let c=document.getElementById("scene").getBoundingClientRect();
    p.x=(e.clientX-c.left)/project.canvasScale-ox/project.canvasScale;
    p.y=(e.clientY-c.top)/project.canvasScale-oy/project.canvasScale;
    el.style.left=p.x+"px"; el.style.top=p.y+"px";
    drawWires();
  });
  document.addEventListener("mouseup",()=>drag=false);
}

document.getElementById("canvas").onclick=e=>{
  if(wiringSource&&(e.target.id==="canvas"||e.target.id==="wires"))cancelWiring(true)
};

function installPinHandlers(){
  document.querySelectorAll(".pin").forEach(pin=>{
    pin.onmouseenter=e=>{tip(e,pin.dataset.tip||pin.dataset.node);if(wiringSource&&pin.dataset.node!==wiringSource)pin.classList.add("target")};
    pin.onmousemove=e=>tip(e,pin.dataset.tip||pin.dataset.node);
    pin.onmouseleave=e=>{hideTip();pin.classList.remove("target")};
    pin.onclick=e=>{e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();pinClick(pin.dataset.node)};
    pin.onmousedown=e=>{e.stopPropagation();e.stopImmediatePropagation()};
  });
}
function pinClick(node){
  if(!wiringSource){
    wiringSource=node; wiringMouse=getNodePoint(node);
    document.querySelectorAll(".pin").forEach(p=>p.classList.toggle("source",p.dataset.node===node));
    status("Source "+node+" selected. Click destination pin."); drawWires(); return;
  }
  if(wiringSource===node){cancelWiring(true);return}
  addWire(wiringSource,node); log("Wire: "+wiringSource+" -> "+node); cancelWiring(false); drawWires();
}
function cancelWiring(show){wiringSource=null;wiringMouse=null;document.querySelectorAll(".pin").forEach(p=>{p.classList.remove("source");p.classList.remove("target")});status("Click a pin to start wiring");if(show)log("Wiring cancelled");drawWires()}
document.addEventListener("mousemove",e=>{if(wiringSource){wiringMouse=mousePoint(e);drawWires()}});

function tip(e,text){
  let t=document.getElementById("tooltip"),c=document.getElementById("scene").getBoundingClientRect();
  t.textContent=text;t.style.display="block";t.style.left=((e.clientX-c.left)/project.canvasScale+12)+"px";t.style.top=((e.clientY-c.top)/project.canvasScale+12)+"px"
}
function hideTip(){document.getElementById("tooltip").style.display="none"}
function mousePoint(e){
  let c=document.getElementById("scene").getBoundingClientRect();
  return{x:(e.clientX-c.left)/project.canvasScale,y:(e.clientY-c.top)/project.canvasScale}
}
function getNodePoint(node){
  let el=document.querySelector(`[data-node="${CSS.escape(node)}"]`),c=document.getElementById("scene").getBoundingClientRect();
  if(!el)return null;
  let r=el.getBoundingClientRect();
  return{x:(r.left-c.left+r.width/2)/project.canvasScale,y:(r.top-c.top+r.height/2)/project.canvasScale}
}

function addWire(from,to){project.wires=project.wires.filter(w=>!(w.from===from&&w.to===to));project.wires.push({from,to})}
function deleteWire(i){project.wires.splice(i,1);drawWires();log("Wire deleted")}
function drawWires(){
  let svg=document.getElementById("wires");svg.innerHTML="";
  project.wires.forEach((w,i)=>{let a=getNodePoint(w.from),b=getNodePoint(w.to);if(a&&b)drawWire(svg,a,b,colorForWire(w),i,false)});
  if(wiringSource&&wiringMouse){let a=getNodePoint(wiringSource);if(a)drawWire(svg,a,wiringMouse,"orange",-1,true)}
}
function colorForWire(w){
  let s=w.from+" "+w.to;
  if(s.includes("GND")||s.includes(".G")||s.includes("uno.GND"))return"#003f9e";
  if(s.includes("5V")||s.includes("VCC")||s.includes(".V"))return"#9c007a";
  if(s.includes("D0")||s.includes("D2")||s.includes("D12")||s.includes("D13"))return"#f0c000";
  if(s.includes("A0")||s.includes("OUT"))return"#0050c8";
  return"#087a3b";
}
function drawWire(svg,a,b,color,i,temp){
  const g=document.createElementNS("http://www.w3.org/2000/svg","g");
  const sh=document.createElementNS("http://www.w3.org/2000/svg","polyline");
  const ln=document.createElementNS("http://www.w3.org/2000/svg","polyline");

  // 90-degree orthogonal routing like Wokwi/Fritzing examples.
  // Each wire gets a tiny lane offset to reduce overlap.
  const lane = (i>=0 ? ((i % 9) - 4) * 12 : 0);
  let pts;
  const dx=Math.abs(b.x-a.x);
  const dy=Math.abs(b.y-a.y);

  if(dx > dy){
    const mx=(a.x+b.x)/2 + lane;
    pts=`${a.x},${a.y} ${mx},${a.y} ${mx},${b.y} ${b.x},${b.y}`;
  }else{
    const my=(a.y+b.y)/2 + lane;
    pts=`${a.x},${a.y} ${a.x},${my} ${b.x},${my} ${b.x},${b.y}`;
  }

  sh.setAttribute("points",pts);
  sh.setAttribute("fill","none");
  sh.setAttribute("stroke","rgba(255,255,255,0.96)");
  sh.setAttribute("stroke-width",temp?8:9);
  sh.setAttribute("stroke-linejoin","round");
  sh.setAttribute("stroke-linecap","round");

  ln.setAttribute("points",pts);
  ln.setAttribute("fill","none");
  ln.setAttribute("stroke",color);
  ln.setAttribute("stroke-width",temp?4:5);
  ln.setAttribute("stroke-linejoin","round");
  ln.setAttribute("stroke-linecap","round");
  if(temp) ln.setAttribute("stroke-dasharray","8 5");

  g.appendChild(sh);
  g.appendChild(ln);

  if(!temp){
    [a,b].forEach(pt=>{
      const c=document.createElementNS("http://www.w3.org/2000/svg","circle");
      c.setAttribute("cx",pt.x);
      c.setAttribute("cy",pt.y);
      c.setAttribute("r","4");
      c.setAttribute("fill",color);
      c.setAttribute("stroke","white");
      c.setAttribute("stroke-width","2");
      g.appendChild(c);
    });
  }

  if(i>=0){
    g.style.cursor="pointer";
    g.ondblclick=e=>{e.stopPropagation();deleteWire(i)};
  }
  svg.appendChild(g);
}

function compileCode(){clearLog();log("Compiling with Arduino CLI backend...");return fetch("/api/compile",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code:document.getElementById("code").value,fqbn:"arduino:avr:uno"})}).then(r=>r.json()).then(d=>{log(d.output||"");log((d.ok||d.success)?"Arduino CLI compile successful.":"Arduino CLI compile failed.");return d.ok||d.success}).catch(e=>{log("Backend not running. Use npm start and open http://localhost:3000");return false})}
function pinMode(pin, mode) {
  pinModes[pin] = mode;
  if (mode === INPUT_PULLUP) pinValues[pin] = HIGH;
  else if (mode === INPUT_PULLDOWN) pinValues[pin] = LOW;
}
function digitalWrite(pin, val) {
  pinValues[pin] = val ? HIGH : LOW;
  findPartsOnUnoPin("led","A","D"+pin).forEach(p => p.state = val ? HIGH : LOW);
  findPartsOnUnoPin("buzzer","SIG","D"+pin).forEach(p => p.state = val ? HIGH : LOW);
  findPartsOnUnoPin("relay","IN","D"+pin).forEach(p => p.state = val ? HIGH : LOW);
  scheduleRuntimeRender();
}
function digitalRead(pin) {
  let btn = findPartsOnUnoPin("button","S","D"+pin)[0];
  if (btn) {
    if (pinModes[pin] === INPUT_PULLUP) return btn.state ? LOW : HIGH;
    return btn.state ? HIGH : LOW;
  }

  let sound = findPartsOnUnoPin("sound","D0","D"+pin)[0];
  if(sound) return sound.digital ? HIGH : LOW;

  if (Object.prototype.hasOwnProperty.call(pinValues, pin)) return pinValues[pin];
  if (pinModes[pin] === INPUT_PULLUP) return HIGH;
  if (pinModes[pin] === INPUT_PULLDOWN) return LOW;
  return LOW;
}
function analogRead(pin){
  let name=typeof pin==="string"?pin:"A"+pin;
  let pot=findPartsOnUnoPin("pot","OUT",name)[0];
  if(pot) return pot.value;

  let sound=findPartsOnUnoPin("sound","A0",name)[0];
  if(sound) return sound.value || 0;

  return 0;
}
function delay(ms){return new Promise(r=>{let t=setTimeout(r,ms);timers.push(t)})}
const Serial={begin:b=>serial("Serial.begin("+b+")"),print:m=>{let e=document.getElementById("serial");e.textContent+=String(m);e.scrollTop=e.scrollHeight},println:m=>serial(String(m))}
function findPartsOnUnoPin(type,partPin,unoPin){let result=[];project.wires.forEach(w=>{let a=w.from,b=w.to,n1=a.startsWith("uno.")?a:b,n2=a.startsWith("uno.")?b:a;if(n1==="uno."+unoPin&&n2.includes("."+partPin)){let id=n2.split(".")[0],p=project.parts.find(x=>x.id===id&&x.type===type);if(p)result.push(p)}});return result}

/* ============================================================
   Arduino Runtime Compatibility Layer
   Added: INPUT_PULLUP, INPUT_PULLDOWN, CHANGE, RISING, FALLING,
          millis(), micros(), constrain(), map(), tone(), noTone(),
          analogWrite(), bit helpers, delayMicroseconds().
   ============================================================ */

function millis() {
  return Date.now() - runtimeStartTime;
}

function micros() {
  return (Date.now() - runtimeStartTime) * 1000;
}

function delayMicroseconds(us) {
  return new Promise(resolve => {
    const ms = Math.max(0, us / 1000);
    const t = setTimeout(resolve, ms);
    if (typeof timers !== "undefined") timers.push(t);
  });
}

function constrain(x, a, b) {
  return Math.min(Math.max(x, a), b);
}

function min(a, b) {
  return Math.min(a, b);
}

function max(a, b) {
  return Math.max(a, b);
}

function sq(x) {
  return x * x;
}

function abs(x) {
  return Math.abs(x);
}

function round(x) {
  return Math.round(x);
}

function bit(n) {
  return 1 << n;
}

function bitRead(value, bitno) {
  return (value >> bitno) & 0x01;
}

function bitSet(value, bitno) {
  return value | (1 << bitno);
}

function bitClear(value, bitno) {
  return value & ~(1 << bitno);
}

function bitWrite(value, bitno, bitvalue) {
  return bitvalue ? bitSet(value, bitno) : bitClear(value, bitno);
}

function lowByte(value) {
  return value & 0xFF;
}

function highByte(value) {
  return (value >> 8) & 0xFF;
}

function analogWrite(pin, value) {
  pinValues[pin] = constrain(value, 0, 255);
  // Basic bridge: PWM value > 0 makes LED visually ON.
  findPartsOnUnoPin("led","A","D"+pin).forEach(p => p.state = value > 0 ? HIGH : LOW);
  render();
}

function tone(pin, frequency, duration) {
  toneStates[pin] = { frequency, started: millis(), duration: duration || 0 };
  if (typeof log === "function") {
    log("tone(pin=" + pin + ", freq=" + frequency + (duration ? ", duration=" + duration : "") + ")");
  }

  if (duration) {
    const t = setTimeout(() => noTone(pin), duration);
    if (typeof timers !== "undefined") timers.push(t);
  }
}

function noTone(pin) {
  delete toneStates[pin];
  if (typeof log === "function") {
    log("noTone(pin=" + pin + ")");
  }
}

function attachInterrupt(pinOrInterrupt, callback, mode) {
  if (typeof log === "function") {
    log("attachInterrupt registered: interrupt=" + pinOrInterrupt + ", mode=" + mode);
  }
  // Placeholder for future external interrupt simulation.
}

function detachInterrupt(pinOrInterrupt) {
  if (typeof log === "function") {
    log("detachInterrupt: interrupt=" + pinOrInterrupt);
  }
}

function digitalPinToInterrupt(pin) {
  return pin;
}

function randomSeed(seed) {
  window.__vectorRandomSeed = seed || 1;
}

function random(minVal, maxVal) {
  if (maxVal === undefined) {
    maxVal = minVal;
    minVal = 0;
  }
  window.__vectorRandomSeed = (window.__vectorRandomSeed * 1103515245 + 12345) & 0x7fffffff;
  return minVal + (window.__vectorRandomSeed % (maxVal - minVal));
}

function transform(src){
  let defines = "";
  src = src.replace(/^\s*#define\s+([A-Za-z_]\w*)\s+([^\r\n]+)/gm, function(_, name, value){
    value = value.trim();
    if (name.includes("(")) return "";
    defines += "const " + name + " = " + value + ";\n";
    return "";
  });
  src = src.replace(/^\s*#.*$/gm, "");
  src = src.replace(/\/\/.*$/gm, "");

  /*
    Convert simple Arduino/C variable declarations to JavaScript.
    Important fix:
    Arduino sketches may use declarations like:
        const float VREF = 5.0;
    The older converter changed only "float VREF" to "let VREF",
    producing invalid JavaScript: "const let VREF = 5.0;".
    That caused: Runtime error: let is disallowed as a lexically bound name.
  */
  src = src.replace(/\bconst\s+(unsigned\s+long|unsigned\s+int|int|float|long|double|char|bool|byte|word|String)\s+([A-Za-z_]\w*)\s*=\s*([^;]+);/g, "const $2 = $3;");
  src = src.replace(/\bconst\s+(unsigned\s+long|unsigned\s+int|int|float|long|double|char|bool|byte|word|String)\s+([A-Za-z_]\w*)\s*;/g, "const $2 = undefined;");
  src = src.replace(/\b(unsigned\s+long|unsigned\s+int|int|float|long|double|char|bool|byte|word|String)\s+([A-Za-z_]\w*)\s*=\s*([^;]+);/g, "let $2 = $3;");
  src = src.replace(/\b(unsigned\s+long|unsigned\s+int|int|float|long|double|char|bool|byte|word|String)\s+([A-Za-z_]\w*)\s*;/g, "let $2;");
  src = src.replace(/void\s+setup\s*\(\s*\)/g, "async function setup()");
  src = src.replace(/void\s+loop\s*\(\s*\)/g, "async function loop()");
  src = src.replace(/\bdelay\s*\(/g, "await delay(");
  src = src.replace(/\bdelayMicroseconds\s*\(/g, "await delayMicroseconds(");
  return defines + "\n" + src;
}
async function runSimulation(){
  stopSimulation();

  /* Keep Run/Stop button correct when runSimulation() resets previous state.
     stopSimulation() changes the label back to Run Simulation, so set it
     again to Stop Simulation before the runtime loop starts. */
  if(typeof setRunStopButtonState === "function") setRunStopButtonState(true);

  clearSerial();
  running = true;
  runtimeStartTime = Date.now();
  runtimeLoopCounter = 0;
  try{
    const transformed = transform(document.getElementById("code").value);
    eval(transformed);
    if(typeof setup === "function") await setup();
    while(running) {
      if(typeof loop !== "function") break;
      await loop();
      await runtimeYield();
      runtimeLoopCounter++;
      if(runtimeLoopCounter > 200000) {
        log("Runtime stopped: loop limit reached. Add delay() or press Stop.");
        running = false;
        break;
      }
    }
  }catch(e){
    log("Runtime error: " + e.message);
    running = false;
  }
}
function stopSimulation(){running=false;timers.forEach(t=>clearTimeout(t));timers=[];if(project&&project.parts){project.parts.forEach(p=>{if(p.type==="led")p.state=LOW});render()}}

function installMouseWheelZoom(){
  const canvasEl=document.getElementById("canvas");
  canvasEl.addEventListener("wheel",function(e){
    e.preventDefault();
    const partEl=e.target.closest(".part");
    const step=e.deltaY<0?0.1:-0.1;

    if(partEl){
      const p=project.parts.find(x=>x.id===partEl.id);
      if(!p)return;
      p.scale=Math.max(0.4,Math.min(2.8,(p.scale||1)+step));
      selectedId=p.id;
      render();
      status(p.id+" zoom: "+Math.round(p.scale*100)+"%");
      return;
    }

    project.canvasScale=Math.max(0.4,Math.min(2.8,(project.canvasScale||1)+step));
    applyCanvasZoom();
    status("Canvas zoom: "+Math.round(project.canvasScale*100)+"%");
  },{passive:false});
}

installMouseWheelZoom();
newProject();

function map(x, in_min, in_max, out_min, out_max) {
  return Math.trunc((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min);
}


/* ============================================================
   MULTI-BEND ORTHOGONAL WIRING ENGINE - FIXED OVERRIDE
   Loaded marker: V19_MULTI_BEND_FIXED_ACTIVE
   ============================================================ */

var V19_MULTI_BEND_FIXED_ACTIVE = true;
var wireBends = [];

function snapPoint(p){
  const grid = 10;
  return {
    x: Math.round(p.x / grid) * grid,
    y: Math.round(p.y / grid) * grid
  };
}

function orthogonalPoints(points){
  if(!points || points.length === 0) return "";
  if(points.length === 1) return `${points[0].x},${points[0].y}`;

  const out = [];
  out.push(points[0]);

  for(let i=1;i<points.length;i++){
    const prev = out[out.length-1];
    const next = points[i];

    if(prev.x !== next.x && prev.y !== next.y){
      // Make an L bend toward the next point.
      // Alternate horizontal/vertical style to avoid too many overlaps.
      if(i % 2 === 1){
        out.push({x: next.x, y: prev.y});
      }else{
        out.push({x: prev.x, y: next.y});
      }
    }
    out.push(next);
  }

  return out.map(p => `${p.x},${p.y}`).join(" ");
}

function addWire(from,to,bends){
  project.wires = project.wires.filter(w => !(w.from===from && w.to===to));
  project.wires.push({
    from: from,
    to: to,
    bends: Array.isArray(bends) ? bends.map(p=>({x:p.x,y:p.y})) : []
  });
}

function pinClick(node){
  if(!wiringSource){
    wiringSource = node;
    wiringMouse = getNodePoint(node);
    wireBends = [];

    document.querySelectorAll(".pin").forEach(p => {
      p.classList.toggle("source", p.dataset.node === node);
      p.classList.remove("target");
    });

    status("Source selected: " + node + ". Click canvas for bends, click destination pin to finish.");
    drawWires();
    return;
  }

  if(wiringSource === node){
    cancelWiring(true);
    return;
  }

  addWire(wiringSource, node, wireBends);
  log("Wire created: " + wiringSource + " -> " + node + " | bends: " + wireBends.length);
  cancelWiring(false);
  drawWires();
}

function cancelWiring(show){
  wiringSource = null;
  wiringMouse = null;
  wireBends = [];

  document.querySelectorAll(".pin").forEach(p => {
    p.classList.remove("source");
    p.classList.remove("target");
  });

  status("Click a pin to start wiring");
  if(show) log("Wiring cancelled.");
  drawWires();
}

function installPinHandlers(){
  document.querySelectorAll(".pin").forEach(pin=>{
    pin.onmouseenter = e => {
      tip(e, pin.dataset.tip || pin.dataset.node);
      if(wiringSource && pin.dataset.node !== wiringSource){
        pin.classList.add("target");
        status("Destination highlighted: " + pin.dataset.node + ". Click to finish wire.");
      }
    };

    pin.onmousemove = e => tip(e, pin.dataset.tip || pin.dataset.node);

    pin.onmouseleave = e => {
      hideTip();
      pin.classList.remove("target");
      if(wiringSource){
        status("Click canvas for bend(s), or click destination pin to finish.");
      }
    };

    pin.onclick = e => {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      pinClick(pin.dataset.node);
    };

    pin.onmousedown = e => {
      e.stopPropagation();
      e.stopImmediatePropagation();
    };
  });
}

function drawWires(){
  const svg = document.getElementById("wires");
  if(!svg) return;

  svg.innerHTML = "";

  project.wires.forEach((w,i)=>{
    const a = getNodePoint(w.from);
    const b = getNodePoint(w.to);

    if(a && b){
      const bends = Array.isArray(w.bends) ? w.bends : [];
      drawWire(svg, [a, ...bends, b], colorForWire(w), i, false);
    }
  });

  if(wiringSource && wiringMouse){
    const a = getNodePoint(wiringSource);
    if(a){
      drawWire(svg, [a, ...wireBends, wiringMouse], "orange", -1, true);
    }
  }
}

function drawWire(svg,points,color,i,temp){
  const g = document.createElementNS("http://www.w3.org/2000/svg","g");
  const sh = document.createElementNS("http://www.w3.org/2000/svg","polyline");
  const ln = document.createElementNS("http://www.w3.org/2000/svg","polyline");

  const pts = orthogonalPoints(points);

  sh.setAttribute("points", pts);
  sh.setAttribute("fill", "none");
  sh.setAttribute("stroke", "rgba(255,255,255,0.96)");
  sh.setAttribute("stroke-width", temp ? "8" : "9");
  sh.setAttribute("stroke-linejoin", "round");
  sh.setAttribute("stroke-linecap", "round");

  ln.setAttribute("points", pts);
  ln.setAttribute("fill", "none");
  ln.setAttribute("stroke", color);
  ln.setAttribute("stroke-width", temp ? "4" : "5");
  ln.setAttribute("stroke-linejoin", "round");
  ln.setAttribute("stroke-linecap", "round");
  if(temp) ln.setAttribute("stroke-dasharray", "8 5");

  g.appendChild(sh);
  g.appendChild(ln);

  if(!temp){
    [points[0], points[points.length-1]].forEach(pt=>{
      const c = document.createElementNS("http://www.w3.org/2000/svg","circle");
      c.setAttribute("cx", pt.x);
      c.setAttribute("cy", pt.y);
      c.setAttribute("r", "4");
      c.setAttribute("fill", color);
      c.setAttribute("stroke", "white");
      c.setAttribute("stroke-width", "2");
      g.appendChild(c);
    });

    points.slice(1,-1).forEach(pt=>{
      const c = document.createElementNS("http://www.w3.org/2000/svg","circle");
      c.setAttribute("cx", pt.x);
      c.setAttribute("cy", pt.y);
      c.setAttribute("r", "3");
      c.setAttribute("fill", "white");
      c.setAttribute("stroke", color);
      c.setAttribute("stroke-width", "2");
      g.appendChild(c);
    });
  }

  if(i >= 0){
    g.style.cursor = "pointer";
    g.ondblclick = e => {
      e.stopPropagation();
      deleteWire(i);
    };
  }

  svg.appendChild(g);
}

// Reinstall canvas click handling after previous handlers.
(function installMultiBendCanvasHandler(){
  const canvas = document.getElementById("canvas");
  if(!canvas) return;

  canvas.onclick = function(e){
    const id = e.target.id;

    if(wiringSource && (id === "canvas" || id === "scene" || id === "wires")){
      e.preventDefault();
      e.stopPropagation();

      const p = snapPoint(mousePoint(e));
      wireBends.push(p);

      status("Bend added: " + wireBends.length + ". Add more bends or click destination pin.");
      drawWires();
      return;
    }
  };

  document.addEventListener("mousemove", e=>{
    if(wiringSource){
      wiringMouse = mousePoint(e);
      drawWires();
    }
  });

  // Reinstall handlers once after page init.
  setTimeout(()=>{
    installPinHandlers();
    drawWires();
    status("MULTI-BEND WIRING ACTIVE: click source pin, canvas bends, destination pin.");
  }, 100);
})();



/* PIN_ALIGNED_HITBOX_PATCH_ACTIVE
   UNO pin hotspot coordinates are calibrated to the rendered 640px UNO image.
   If pin alignment does not appear updated, use Ctrl+F5 to hard refresh.
*/


/* ===== PROJECT SAVE / LOAD PATCH ===== */
const PROJECT_STORAGE_KEY = "vector_arduino_v19_project";

function serializeProject(){
  project.code = document.getElementById("code").value;
  return JSON.stringify(project, null, 2);
}

function normalizeLoadedProject(obj){
  if(!obj) throw new Error("Invalid project");
  if(!Array.isArray(obj.parts)) obj.parts=[];
  if(!Array.isArray(obj.wires)) obj.wires=[];
  if(!obj.canvasScale) obj.canvasScale=1;
  if(!obj.code) obj.code=document.getElementById("code").value;
  obj.wires=obj.wires.map(w=>({from:w.from,to:w.to,bends:Array.isArray(w.bends)?w.bends:[]}));
  obj.parts=obj.parts.map(p=>{
    if(!p.scale)p.scale=1;
    if(p.state===undefined)p.state=LOW;
    if(p.value===undefined)p.value=0;
    return p;
  });
  return obj;
}

function restoreProject(obj){
  stopSimulation();
  project=normalizeLoadedProject(obj);
  document.getElementById("code").value=project.code||"";
  let maxNum=0;
  project.parts.forEach(p=>{
    let m=String(p.id||"").match(/(\d+)$/);
    if(m)maxNum=Math.max(maxNum,parseInt(m[1],10));
  });
  nextId=maxNum+1;
  selectedId=null;
  wiringSource=null;
  wiringMouse=null;
  if(typeof wireBends!=="undefined") wireBends=[];
  render();
  if(typeof applyCanvasZoom==="function") applyCanvasZoom();
  drawWires();
  status("Project loaded. Parts: "+project.parts.length+", Wires: "+project.wires.length);
}

function saveProject(){
  try{
    localStorage.setItem(PROJECT_STORAGE_KEY, serializeProject());
    status("Project saved locally.");
    log("Project saved locally.");
  }catch(e){ log("Save failed: "+e.message); }
}

function loadProject(){
  try{
    let txt=localStorage.getItem(PROJECT_STORAGE_KEY);
    if(!txt){ log("No saved project found."); status("No saved project found."); return; }
    restoreProject(JSON.parse(txt));
  }catch(e){ log("Load failed: "+e.message); }
}

function exportProjectFile(){
  try{
    let blob=new Blob([serializeProject()],{type:"application/json"});
    let a=document.createElement("a");
    a.href=URL.createObjectURL(blob);
    a.download="vector_arduino_project.json";
    a.click();
    URL.revokeObjectURL(a.href);
    status("Project exported as JSON.");
  }catch(e){ log("Export failed: "+e.message); }
}

function importProjectFile(event){
  let file=event.target.files[0];
  if(!file)return;
  let reader=new FileReader();
  reader.onload=function(){
    try{ restoreProject(JSON.parse(reader.result)); log("Imported project: "+file.name); }
    catch(e){ log("Import failed: "+e.message); }
  };
  reader.readAsText(file);
  event.target.value="";
}


/* Component dropdown menu patch */
function addSelectedComponent(){
  const sel = document.getElementById("componentSelect");
  if(!sel){
    log("Component selector not found.");
    return;
  }
  addPart(sel.value);
}


/* ============================================================
   90-DEGREE TURN WIRING PATCH
   Behavior:
   - Click source pin.
   - Mouse preview follows pointer.
   - Each left-click on empty canvas adds a turn point.
   - Each new turn is forced 90 degrees relative to previous segment.
   - Click destination pin finalizes the wire.
   ============================================================ */

var V19_90_TURN_WIRING_ACTIVE = true;
var wireBends = Array.isArray(window.wireBends) ? window.wireBends : [];
var nextWireDirection = null; // "H" or "V"

function status(msg){
  const s = document.getElementById("status");
  if(s) s.textContent = msg;
}

function snapPoint(p){
  const grid = 10;
  return {
    x: Math.round(p.x / grid) * grid,
    y: Math.round(p.y / grid) * grid
  };
}

function getLastWirePoint(){
  if(wireBends.length > 0) return wireBends[wireBends.length - 1];
  return getNodePoint(wiringSource);
}

function inferDirection(a,b){
  if(!a || !b) return "H";
  return Math.abs(b.x - a.x) >= Math.abs(b.y - a.y) ? "H" : "V";
}

function createTurnPoint(rawMouse){
  const last = getLastWirePoint();
  if(!last) return snapPoint(rawMouse);

  const raw = snapPoint(rawMouse);

  // First canvas click: choose dominant direction from source to mouse.
  if(!nextWireDirection){
    const first = inferDirection(last, raw);
    nextWireDirection = first === "H" ? "V" : "H";
    if(first === "H"){
      return {x: raw.x, y: last.y};
    }else{
      return {x: last.x, y: raw.y};
    }
  }

  // Subsequent clicks: force 90-degree alternate direction.
  let p;
  if(nextWireDirection === "H"){
    p = {x: raw.x, y: last.y};
    nextWireDirection = "V";
  }else{
    p = {x: last.x, y: raw.y};
    nextWireDirection = "H";
  }

  return snapPoint(p);
}

function previewMousePoint(rawMouse){
  const last = getLastWirePoint();
  if(!last) return rawMouse;

  const raw = snapPoint(rawMouse);

  if(!nextWireDirection){
    const first = inferDirection(last, raw);
    if(first === "H") return {x: raw.x, y: last.y};
    return {x: last.x, y: raw.y};
  }

  if(nextWireDirection === "H"){
    return {x: raw.x, y: last.y};
  }
  return {x: last.x, y: raw.y};
}

function routeToDestination(points){
  if(points.length <= 1) return "";

  const out = [points[0]];

  for(let i=1;i<points.length;i++){
    const prev = out[out.length-1];
    const next = points[i];

    if(prev.x !== next.x && prev.y !== next.y){
      // Force clean 90-degree corner before destination if needed.
      out.push({x: next.x, y: prev.y});
    }
    out.push(next);
  }

  return out.map(p => `${p.x},${p.y}`).join(" ");
}

function addWire(from,to,bends){
  project.wires = project.wires.filter(w => !(w.from === from && w.to === to));
  project.wires.push({
    from,
    to,
    bends: Array.isArray(bends) ? bends.map(p => ({x:p.x, y:p.y})) : []
  });
}

function pinClick(node){
  if(!wiringSource){
    wiringSource = node;
    wiringMouse = getNodePoint(node);
    wireBends = [];
    nextWireDirection = null;

    document.querySelectorAll(".pin").forEach(p => {
      p.classList.toggle("source", p.dataset.node === node);
      p.classList.remove("target");
    });

    drawWires();
    return;
  }

  if(wiringSource === node){
    cancelWiring(true);
    return;
  }

  addWire(wiringSource, node, wireBends);
  log("Wire created: " + wiringSource + " -> " + node + " | turns: " + wireBends.length);
  cancelWiring(false);
  drawWires();
}

function cancelWiring(show){
  wiringSource = null;
  wiringMouse = null;
  wireBends = [];
  nextWireDirection = null;

  document.querySelectorAll(".pin").forEach(p => {
    p.classList.remove("source");
    p.classList.remove("target");
  });

  if(show) log("Wiring cancelled.");
  drawWires();
}

function installPinHandlers(){
  document.querySelectorAll(".pin").forEach(pin=>{
    pin.onmouseenter = e => {
      tip(e, pin.dataset.tip || pin.dataset.node);
      if(wiringSource && pin.dataset.node !== wiringSource){
        pin.classList.add("target");
      }
    };

    pin.onmousemove = e => tip(e, pin.dataset.tip || pin.dataset.node);

    pin.onmouseleave = e => {
      hideTip();
      pin.classList.remove("target");
    };

    pin.onclick = e => {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      pinClick(pin.dataset.node);
    };

    pin.onmousedown = e => {
      e.stopPropagation();
      e.stopImmediatePropagation();
    };
  });
}

function drawWires(){
  const svg = document.getElementById("wires");
  if(!svg) return;

  svg.innerHTML = "";

  project.wires.forEach((w,i)=>{
    const a = getNodePoint(w.from);
    const b = getNodePoint(w.to);
    if(a && b){
      const bends = Array.isArray(w.bends) ? w.bends : [];
      drawWire(svg, [a, ...bends, b], colorForWire(w), i, false);
    }
  });

  if(wiringSource && wiringMouse){
    const a = getNodePoint(wiringSource);
    if(a){
      const preview = previewMousePoint(wiringMouse);
      drawWire(svg, [a, ...wireBends, preview], "orange", -1, true);
    }
  }
}

function drawWire(svg,points,color,i,temp){
  const g = document.createElementNS("http://www.w3.org/2000/svg","g");
  const sh = document.createElementNS("http://www.w3.org/2000/svg","polyline");
  const ln = document.createElementNS("http://www.w3.org/2000/svg","polyline");

  const pts = routeToDestination(points);

  sh.setAttribute("points", pts);
  sh.setAttribute("fill", "none");
  sh.setAttribute("stroke", "rgba(255,255,255,0.96)");
  sh.setAttribute("stroke-width", temp ? "8" : "9");
  sh.setAttribute("stroke-linejoin", "round");
  sh.setAttribute("stroke-linecap", "round");

  ln.setAttribute("points", pts);
  ln.setAttribute("fill", "none");
  ln.setAttribute("stroke", color);
  ln.setAttribute("stroke-width", temp ? "4" : "5");
  ln.setAttribute("stroke-linejoin", "round");
  ln.setAttribute("stroke-linecap", "round");
  if(temp) ln.setAttribute("stroke-dasharray", "8 5");

  g.appendChild(sh);
  g.appendChild(ln);

  if(!temp){
    [points[0], points[points.length-1]].forEach(pt=>{
      const c = document.createElementNS("http://www.w3.org/2000/svg","circle");
      c.setAttribute("cx", pt.x);
      c.setAttribute("cy", pt.y);
      c.setAttribute("r", "4");
      c.setAttribute("fill", color);
      c.setAttribute("stroke", "white");
      c.setAttribute("stroke-width", "2");
      g.appendChild(c);
    });

    points.slice(1,-1).forEach(pt=>{
      const c = document.createElementNS("http://www.w3.org/2000/svg","circle");
      c.setAttribute("cx", pt.x);
      c.setAttribute("cy", pt.y);
      c.setAttribute("r", "3");
      c.setAttribute("fill", "white");
      c.setAttribute("stroke", color);
      c.setAttribute("stroke-width", "2");
      g.appendChild(c);
    });
  }

  if(i >= 0){
    g.style.cursor = "pointer";
    g.ondblclick = e => {
      e.stopPropagation();
      deleteWire(i);
    };
  }

  svg.appendChild(g);
}

(function install90TurnCanvasHandler(){
  const canvas = document.getElementById("canvas");
  if(!canvas) return;

  canvas.onclick = function(e){
    const id = e.target.id;

    if(wiringSource && (id === "canvas" || id === "scene" || id === "wires")){
      e.preventDefault();
      e.stopPropagation();

      const raw = mousePoint(e);
      const p = createTurnPoint(raw);
      wireBends.push(p);

      drawWires();
      return;
    }
  };

  document.addEventListener("mousemove", e=>{
    if(wiringSource){
      wiringMouse = mousePoint(e);
      drawWires();
    }
  });

  setTimeout(()=>{
    installPinHandlers();
    drawWires();
  },100);
})();


/* ============================================================
   UNO DRAG + .INO SAVE/LOAD PATCH
   ============================================================ */

var V19_UNO_DRAG_INO_PATCH_ACTIVE = true;

function ensureBoardState(){
  if(!project.board){
    const uno = document.getElementById("uno");
    project.board = {
      x: uno ? parseFloat(uno.style.left || "95") || 95 : 95,
      y: uno ? parseFloat(uno.style.top || "70") || 70 : 70
    };
  }
}

function applyBoardPosition(){
  ensureBoardState();
  const uno = document.getElementById("uno");
  if(!uno) return;
  uno.style.left = project.board.x + "px";
  uno.style.top = project.board.y + "px";
  drawWires();
}

function installUnoDrag(){
  const uno = document.getElementById("uno");
  if(!uno || uno.__dragInstalled) return;
  uno.__dragInstalled = true;

  let dragging = false;
  let ox = 0;
  let oy = 0;

  uno.addEventListener("mousedown", function(e){
    if(e.target.classList.contains("pin")) return;
    e.preventDefault();
    e.stopPropagation();

    ensureBoardState();
    dragging = true;
    uno.classList.add("dragging");

    const rect = uno.getBoundingClientRect();
    ox = e.clientX - rect.left;
    oy = e.clientY - rect.top;
  });

  document.addEventListener("mousemove", function(e){
    if(!dragging) return;

    const scene = document.getElementById("scene");
    const rect = scene.getBoundingClientRect();
    const sc = project.canvasScale || 1;

    project.board.x = (e.clientX - rect.left - ox) / sc;
    project.board.y = (e.clientY - rect.top - oy) / sc;

    applyBoardPosition();
  });

  document.addEventListener("mouseup", function(){
    if(dragging){
      dragging = false;
      uno.classList.remove("dragging");
      drawWires();
    }
  });
}

// Patch render/newProject flow without rewriting existing features.
(function installUnoDragPatch(){
  setTimeout(()=>{
    ensureBoardState();
    applyBoardPosition();
    installUnoDrag();
  },100);
})();

// Preserve board position in project serialization if Save Project / Export JSON is used.
if(typeof serializeProject === "function"){
  const __oldSerializeProject = serializeProject;
  serializeProject = function(){
    ensureBoardState();
    project.code = document.getElementById("code").value;
    const pn = document.getElementById("projectName");
    if(pn) project.projectName = pn.value || "sketch";
    return JSON.stringify(project, null, 2);
  };
}

if(typeof restoreProject === "function"){
  const __oldRestoreProject = restoreProject;
  restoreProject = function(obj){
    __oldRestoreProject(obj);
    if(project.board) applyBoardPosition();
    installUnoDrag();
    const pn = document.getElementById("projectName");
    if(pn && project.projectName) pn.value = project.projectName;
  };
}

function cleanSketchName(name){
  name = (name || "sketch").trim();
  name = name.replace(/\.ino$/i, "");
  name = name.replace(/[^A-Za-z0-9_]/g, "_");
  if(!name) name = "sketch";
  return name;
}

async function saveInoFile(){
  const nameBox = document.getElementById("projectName");
  const sketchName = cleanSketchName(nameBox ? nameBox.value : "sketch");
  const code = document.getElementById("code").value;

  // Preferred folder/path support in Chrome/Edge using File System Access API.
  if(window.showSaveFilePicker){
    try{
      const handle = await window.showSaveFilePicker({
        suggestedName: sketchName + ".ino",
        types: [{
          description: "Arduino Sketch",
          accept: {"text/plain": [".ino"]}
        }]
      });

      const writable = await handle.createWritable();
      await writable.write(code);
      await writable.close();

      if(nameBox) nameBox.value = sketchName;
      log("Saved .ino: " + sketchName + ".ino");
      return;
    }catch(e){
      if(e.name === "AbortError") return;
      log("Save .ino failed: " + e.message);
    }
  }

  // Fallback for browsers without File System Access API.
  const blob = new Blob([code], {type:"text/plain"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = sketchName + ".ino";
  a.click();
  URL.revokeObjectURL(a.href);
  log("Downloaded .ino: " + sketchName + ".ino");
}

async function loadInoFile(){
  if(window.showOpenFilePicker){
    try{
      const [handle] = await window.showOpenFilePicker({
        types: [{
          description: "Arduino Sketch",
          accept: {"text/plain": [".ino"]}
        }],
        multiple: false
      });

      const file = await handle.getFile();
      const text = await file.text();

      document.getElementById("code").value = text;
      const pn = document.getElementById("projectName");
      if(pn) pn.value = cleanSketchName(file.name);

      log("Loaded .ino: " + file.name);
      return;
    }catch(e){
      if(e.name === "AbortError") return;
      log("Load .ino failed: " + e.message);
    }
  }

  document.getElementById("inoFileInput").click();
}

function importInoFallback(event){
  const file = event.target.files[0];
  if(!file) return;

  const reader = new FileReader();
  reader.onload = function(){
    document.getElementById("code").value = reader.result;
    const pn = document.getElementById("projectName");
    if(pn) pn.value = cleanSketchName(file.name);
    log("Loaded .ino: " + file.name);
  };
  reader.readAsText(file);
  event.target.value = "";
}


/* ============================================================
   UI PATCH: Component picker, double-click delete, resizable panes
   ============================================================ */
var V19_UI_RESIZE_PICKER_ACTIVE = true;

function toggleComponentPalette(){
  const p = document.getElementById("componentPalette");
  if(!p) return;
  p.style.display = (p.style.display === "none" || !p.style.display) ? "block" : "none";
}

function addFromPalette(type){
  addPart(type);
  const p = document.getElementById("componentPalette");
  if(p) p.style.display = "none";
}

function addSelectedComponent(){
  const sel = document.getElementById("componentSelect");
  if(sel) addPart(sel.value);
}

if(typeof render === "function" && !window.__renderDoubleClickDeleteWrapped){
  const __oldRenderForDblDelete = render;
  window.__renderDoubleClickDeleteWrapped = true;
  render = function(){
    __oldRenderForDblDelete();

    document.querySelectorAll(".part").forEach(el=>{
      if(el.__dblDeleteInstalled) return;
      el.__dblDeleteInstalled = true;

      el.addEventListener("dblclick", function(e){
        if(e.target.classList.contains("pin")) return;
        e.preventDefault();
        e.stopPropagation();

        const id = el.id;
        project.parts = project.parts.filter(p => p.id !== id);
        project.wires = project.wires.filter(w => !w.from.startsWith(id + ".") && !w.to.startsWith(id + "."));
        if(selectedId === id) selectedId = null;

        render();
        drawWires();
        log("Deleted component: " + id);
      });
    });

    if(typeof installUnoDrag === "function") installUnoDrag();
  };
}

function installPaneResizers(){
  if(window.__paneResizersInstalled) return;
  window.__paneResizersInstalled = true;

  const root = document.documentElement;
  const leftR = document.getElementById("vResizeLeft");
  const rightR = document.getElementById("vResizeRight");
  const hR = document.getElementById("hResize");

  function pxVar(name, fallback){
    const v = getComputedStyle(root).getPropertyValue(name).trim();
    return parseInt(v || fallback, 10);
  }

  if(leftR){
    leftR.addEventListener("mousedown", e=>{
      e.preventDefault(); leftR.classList.add("active");
      const startX = e.clientX, start = pxVar("--leftPane",185);
      function move(ev){
        const val = Math.max(130, Math.min(360, start + (ev.clientX - startX)));
        root.style.setProperty("--leftPane", val + "px"); drawWires();
      }
      function up(){leftR.classList.remove("active");document.removeEventListener("mousemove",move);document.removeEventListener("mouseup",up)}
      document.addEventListener("mousemove",move);document.addEventListener("mouseup",up);
    });
  }

  if(rightR){
    rightR.addEventListener("mousedown", e=>{
      e.preventDefault(); rightR.classList.add("active");
      const startX = e.clientX, start = pxVar("--rightPane",380);
      function move(ev){
        const val = Math.max(260, Math.min(650, start - (ev.clientX - startX)));
        root.style.setProperty("--rightPane", val + "px"); drawWires();
      }
      function up(){rightR.classList.remove("active");document.removeEventListener("mousemove",move);document.removeEventListener("mouseup",up)}
      document.addEventListener("mousemove",move);document.addEventListener("mouseup",up);
    });
  }

  if(hR){
    hR.addEventListener("mousedown", e=>{
      e.preventDefault(); hR.classList.add("active");
      const startY = e.clientY, start = pxVar("--bottomPane",150);
      function move(ev){
        const val = Math.max(90, Math.min(330, start - (ev.clientY - startY)));
        root.style.setProperty("--bottomPane", val + "px"); drawWires();
      }
      function up(){hR.classList.remove("active");document.removeEventListener("mousemove",move);document.removeEventListener("mouseup",up)}
      document.addEventListener("mousemove",move);document.addEventListener("mouseup",up);
    });
  }
}

setTimeout(()=>{installPaneResizers(); if(typeof render==="function") render();},100);


/* ===== LEFT CODE + CANVAS + TOGGLE LOG/SERIAL PATCH ===== */
var V19_LEFTCODE_TOGGLEPANELS_ACTIVE = true;
var compilerPanelVisible = false;
var serialPanelVisible = false;

function updateBottomDock(){
  const dock=document.getElementById("bottomDock");
  const h=document.getElementById("hResize");
  const comp=document.getElementById("compilerPanel");
  const ser=document.getElementById("serialPanel");
  if(!dock||!comp||!ser)return;
  comp.style.display=compilerPanelVisible?"block":"none";
  ser.style.display=serialPanelVisible?"block":"none";
  if(compilerPanelVisible||serialPanelVisible){
    dock.style.display="grid";
    if(h)h.style.display="block";
    document.documentElement.style.setProperty("--bottomVisible","calc(var(--bottomPane) + 6px)");
  }else{
    dock.style.display="none";
    if(h)h.style.display="none";
    document.documentElement.style.setProperty("--bottomVisible","0px");
  }
  dock.classList.toggle("onlyCompiler",compilerPanelVisible&&!serialPanelVisible);
  dock.classList.toggle("onlySerial",serialPanelVisible&&!compilerPanelVisible);
  drawWires();
}

function toggleCompilerWindow(){compilerPanelVisible=!compilerPanelVisible;updateBottomDock();}
function toggleSerialWindow(){serialPanelVisible=!serialPanelVisible;updateBottomDock();}

if(typeof compileCode==="function"&&!window.__compileShowPanelWrapped){
  const __oldCompileCode=compileCode;
  window.__compileShowPanelWrapped=true;
  compileCode=function(){
    compilerPanelVisible=true;
    updateBottomDock();
    return __oldCompileCode();
  };
}

function toggleComponentPalette(){
  const p=document.getElementById("componentPalette");
  if(!p)return;
  p.style.display=(p.style.display==="none"||!p.style.display)?"block":"none";
}
function addFromPalette(type){
  addPart(type);
  const p=document.getElementById("componentPalette");
  if(p)p.style.display="none";
}
function updatePartZoomUI(){
  const selected=document.getElementById("selected");
  if(selected){
    let p=project.parts.find(x=>x.id===selectedId);
    selected.textContent=p?(selectedId+" zoom: "+Math.round((p.scale||1)*100)+"%"):"None";
  }
}

function installCodeCanvasResizer(){
  if(window.__codeCanvasResizerInstalled)return;
  window.__codeCanvasResizerInstalled=true;
  const root=document.documentElement;
  const leftR=document.getElementById("vResizeLeft");
  if(leftR){
    leftR.addEventListener("mousedown",e=>{
      e.preventDefault();
      leftR.classList.add("active");
      const startX=e.clientX;
      const start=parseInt(getComputedStyle(root).getPropertyValue("--codePane"))||390;
      function move(ev){
        const val=Math.max(260,Math.min(720,start+(ev.clientX-startX)));
        root.style.setProperty("--codePane",val+"px");
        drawWires();
      }
      function up(){
        leftR.classList.remove("active");
        document.removeEventListener("mousemove",move);
        document.removeEventListener("mouseup",up);
      }
      document.addEventListener("mousemove",move);
      document.addEventListener("mouseup",up);
    });
  }
}
setTimeout(()=>{updateBottomDock();installCodeCanvasResizer();},100);


/* ===== LED BLINK / POLARITY FIX ===== */
var V19_LED_POLARITY_FIX_ACTIVE = true;

function connectedNodes(partId,pinName){
  const target=partId+"."+pinName;
  const out=[];
  project.wires.forEach(w=>{
    if(w.from===target)out.push(w.to);
    if(w.to===target)out.push(w.from);
  });
  return out;
}
function isGroundNode(n){return n==="uno.GND"||n==="uno.GND2"||n==="uno.GND_TOP";}
function isVccNode(n){return n==="uno.5V"||n==="uno.3V3";}
function dPin(n){return n&&n.startsWith("uno.D")?parseInt(n.replace("uno.D",""),10):null;}
function nodeHigh(n){let p=dPin(n);return p!==null&&pinValues[p]===HIGH;}
function nodeLow(n){let p=dPin(n);return p!==null&&pinValues[p]===LOW;}

function updateAllLedsFromWires(){
  if(!project||!Array.isArray(project.parts))return;
  project.parts.filter(p=>p.type==="led").forEach(led=>{
    const a=connectedNodes(led.id,"A");
    const k=connectedNodes(led.id,"K");

    const activeHigh = a.some(nodeHigh) && k.some(isGroundNode);     // D13 -> A, K -> GND
    const activeLow  = a.some(isVccNode) && k.some(nodeLow);         // 5V -> A, K -> D13

    led.state = (activeHigh || activeLow) ? HIGH : LOW;
  });
  scheduleRuntimeRender();
}

function digitalWrite(pin,val){
  pinValues[pin]=val?HIGH:LOW;
  findPartsOnUnoPin("buzzer","SIG","D"+pin).forEach(p=>p.state=val?HIGH:LOW);
  findPartsOnUnoPin("relay","IN","D"+pin).forEach(p=>p.state=val?HIGH:LOW);
  updateAllLedsFromWires();
}

function checkLedWiringWarnings(){
  if(!project||!Array.isArray(project.parts))return;
  project.parts.filter(p=>p.type==="led").forEach(led=>{
    const a=connectedNodes(led.id,"A");
    const k=connectedNodes(led.id,"K");
    if(a.some(isGroundNode)&&k.some(n=>n&&n.startsWith("uno.D"))){
      log("Wiring warning: "+led.id+" has A/anode connected to GND and K/cathode to digital pin. Use D13 -> A and K -> GND, OR 5V -> A and K -> D13 for active-low.");
    }
  });
}
if(typeof runSimulation==="function"&&!window.__ledWarnRunWrapped){
  const __oldRun=runSimulation;
  window.__ledWarnRunWrapped=true;
  runSimulation=async function(){checkLedWiringWarnings();return __oldRun();};
}


/* ===== PROJECT BUNDLE SAVE/LOAD + LED ALL DIGITAL PINS ===== */
var V19_PROJECT_BUNDLE_LED_ALLPINS_ACTIVE=true;

function currentProjectName(){
  const pn=document.getElementById("projectName");
  let name=pn?pn.value:"sketch";
  name=(name||"sketch").replace(/\.ino$/i,"").replace(/[^A-Za-z0-9_]/g,"_");
  return name||"sketch";
}
function buildProjectBundle(){
  const name=currentProjectName();
  project.code=document.getElementById("code").value;
  project.projectName=name;
  return {format:"VectorArduinoProjectBundle",version:1,projectName:name,inoFile:name+".ino",schematicFile:name+".circuit.json",ino:project.code,circuit:JSON.parse(JSON.stringify(project))};
}
async function saveProjectBundle(){
  const bundle=buildProjectBundle();
  const txt=JSON.stringify(bundle,null,2);
  if(window.showSaveFilePicker){
    try{
      const h=await window.showSaveFilePicker({suggestedName:bundle.projectName+".vector_project.json",types:[{description:"Vector Arduino Project",accept:{"application/json":[".json"]}}]});
      const w=await h.createWritable(); await w.write(txt); await w.close();
      localStorage.setItem("vector_arduino_v19_project",JSON.stringify(bundle.circuit,null,2));
      log("Project saved: "+bundle.projectName+".vector_project.json");
      return;
    }catch(e){if(e.name==="AbortError")return;log("Save Project failed: "+e.message);}
  }
  const blob=new Blob([txt],{type:"application/json"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=bundle.projectName+".vector_project.json"; a.click(); URL.revokeObjectURL(a.href);
}
function restoreProjectBundleObject(obj){
  let circuit=obj, ino=null, name=null;
  if(obj&&obj.format==="VectorArduinoProjectBundle"){circuit=obj.circuit;ino=obj.ino;name=obj.projectName;}
  if(!circuit)throw new Error("Invalid project file");
  if(typeof restoreProject==="function") restoreProject(circuit); else {project=circuit;render();drawWires();}
  if(ino!==null)document.getElementById("code").value=ino;
  const pn=document.getElementById("projectName"); if(pn&&name)pn.value=name;
}
async function loadProjectBundle(){
  if(window.showOpenFilePicker){
    try{
      const [h]=await window.showOpenFilePicker({types:[{description:"Vector Arduino Project",accept:{"application/json":[".json"]}}],multiple:false});
      const f=await h.getFile(); restoreProjectBundleObject(JSON.parse(await f.text())); log("Project loaded: "+f.name); return;
    }catch(e){if(e.name==="AbortError")return;log("Load Project failed: "+e.message);}
  }
  const inp=document.getElementById("projectBundleInput"); if(inp)inp.click();
}
function importProjectBundleFallback(e){
  const f=e.target.files[0]; if(!f)return;
  const r=new FileReader(); r.onload=()=>{try{restoreProjectBundleObject(JSON.parse(r.result));log("Project loaded: "+f.name);}catch(err){log("Load Project failed: "+err.message);}}; r.readAsText(f); e.target.value="";
}
function saveProject(){return saveProjectBundle();}
function loadProject(){return loadProjectBundle();}

/* LED active-high/active-low support for any UNO digital pin D0-D13 */
function connectedNodes(partId,pinName){
  const target=partId+"."+pinName, out=[];
  (project.wires||[]).forEach(w=>{if(w.from===target)out.push(w.to); if(w.to===target)out.push(w.from);});
  return out;
}
function digitalPinFromNode(n){const m=String(n||"").match(/^uno\.D(\d+)$/);return m?parseInt(m[1],10):null;}
function isDigitalNode(n){const p=digitalPinFromNode(n);return p!==null&&p>=0&&p<=13;}
function isGroundNode(n){return n==="uno.GND"||n==="uno.GND2"||n==="uno.GND_TOP";}
function isVccNode(n){return n==="uno.5V"||n==="uno.3V3";}
function nodeHigh(n){const p=digitalPinFromNode(n);return p!==null&&pinValues[p]===HIGH;}
function nodeLow(n){const p=digitalPinFromNode(n);return p!==null&&pinValues[p]===LOW;}
function updateAllLedsFromWires(){
  if(!project||!Array.isArray(project.parts))return;
  project.parts.filter(p=>p.type==="led").forEach(led=>{
    const a=connectedNodes(led.id,"A"), k=connectedNodes(led.id,"K");
    const activeHigh=a.some(isDigitalNode)&&a.some(nodeHigh)&&k.some(isGroundNode);
    const activeLow=a.some(isVccNode)&&k.some(isDigitalNode)&&k.some(nodeLow);
    led.state=(activeHigh||activeLow)?HIGH:LOW;
  });
  if(typeof scheduleRuntimeRender==="function")scheduleRuntimeRender(); else render();
}
function digitalWrite(pin,val){
  pinValues[pin]=val?HIGH:LOW;
  findPartsOnUnoPin("buzzer","SIG","D"+pin).forEach(p=>p.state=val?HIGH:LOW);
  findPartsOnUnoPin("relay","IN","D"+pin).forEach(p=>p.state=val?HIGH:LOW);
  updateAllLedsFromWires();
}
function checkLedWiringWarnings(){
  if(!project||!Array.isArray(project.parts))return;
  project.parts.filter(p=>p.type==="led").forEach(led=>{
    const a=connectedNodes(led.id,"A"), k=connectedNodes(led.id,"K");
    if(a.some(isGroundNode)&&k.some(isDigitalNode)) log("Wiring warning: "+led.id+" reverse polarity. Use Dx -> A and K -> GND, OR VCC -> A and K -> Dx.");
  });
}
if(typeof runSimulation==="function"&&!window.__ledAllPinsRunWrapped){
  const __oldRun=runSimulation; window.__ledAllPinsRunWrapped=true;
  runSimulation=async function(){checkLedWiringWarnings();return __oldRun();};
}


/* ===== REAL ARDUINO UNO DETECT + FLASH PATCH ===== */
var V19_REAL_UNO_DETECT_FLASH_ACTIVE=true;
var selectedUnoPort=null;

async function detectUnoBoard(){
  compilerPanelVisible=true;
  updateBottomDock();
  log("Detecting Arduino UNO boards connected to USB...");
  try{
    const res=await fetch("/api/boards");
    const data=await res.json();
    if(!data.ok){log("Board detection failed:\n"+(data.output||data.error||""));return;}
    if(!data.boards||data.boards.length===0){
      log("No Arduino UNO board detected.");
      log("Check USB cable, board power, driver, and COM port.");
      return;
    }
    selectedUnoPort=data.boards[0].port;
    log("Detected board(s):");
    data.boards.forEach((b,i)=>log((i+1)+". "+b.port+"  "+(b.boardName||"Unknown")+"  "+(b.fqbn||"")));
    log("Selected port: "+selectedUnoPort);
  }catch(e){log("Detect UNO error: "+e.message);}
}

async function flashUnoBoard(){
  compilerPanelVisible=true;
  updateBottomDock();
  if(!selectedUnoPort){
    log("No selected UNO port. Detecting first...");
    await detectUnoBoard();
  }
  if(!selectedUnoPort){log("Flash cancelled: no Arduino UNO port detected.");return;}
  log("Flashing Arduino UNO on port: "+selectedUnoPort);
  try{
    const res=await fetch("/api/upload",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code:document.getElementById("code").value,port:selectedUnoPort,fqbn:"arduino:avr:uno"})});
    const data=await res.json();
    log(data.output||"");
    log(data.ok?"Upload successful.":"Upload failed.");
  }catch(e){log("Flash UNO error: "+e.message);}
}


/* ============================================================
   BOARD FQBN DETECT/FLASH FIX
   Fixes: detected Mega on COM4 was being flashed with UNO FQBN.
   Now selected board port + detected FQBN are used.
   ============================================================ */
var V19_BOARD_FQBN_FIX_ACTIVE = true;
var detectedBoards = [];
var selectedBoard = null;
var selectedUnoPort = null;
var selectedBoardFqbn = null;

function fillBoardSelect(){
  const sel = document.getElementById("boardSelect");
  if(!sel) return;

  sel.innerHTML = "";
  detectedBoards.forEach((b,i)=>{
    const opt = document.createElement("option");
    opt.value = String(i);
    opt.textContent = (b.port || "") + " - " + (b.boardName || "Unknown") + " - " + (b.fqbn || "unknown fqbn");
    sel.appendChild(opt);
  });

  if(detectedBoards.length){
    sel.value = "0";
    selectDetectedBoard();
  }
}

function selectDetectedBoard(){
  const sel = document.getElementById("boardSelect");
  const idx = sel ? parseInt(sel.value || "0", 10) : 0;
  selectedBoard = detectedBoards[idx] || null;
  selectedUnoPort = selectedBoard ? selectedBoard.port : null;
  selectedBoardFqbn = selectedBoard ? (selectedBoard.fqbn || "arduino:avr:uno") : null;

  if(selectedBoard){
    log("Selected board: " + selectedBoard.port + "  " + (selectedBoard.boardName || "") + "  " + selectedBoardFqbn);
  }
}

async function detectUnoBoard(){
  compilerPanelVisible = true;
  updateBottomDock();
  log("Detecting Arduino boards connected to USB...");

  try{
    const res = await fetch("/api/boards");
    const data = await res.json();

    if(!data.ok){
      log("Board detection failed:\n" + (data.output || data.error || ""));
      return;
    }

    detectedBoards = data.boards || [];
    if(detectedBoards.length === 0){
      log("No Arduino board detected.");
      log("Check USB cable, board power, driver, COM port, and Arduino CLI core.");
      fillBoardSelect();
      return;
    }

    log("Detected board(s):");
    detectedBoards.forEach((b,i)=>{
      log((i+1)+". "+b.port+"  "+(b.boardName||"Unknown board")+"  "+(b.fqbn||""));
    });

    fillBoardSelect();

    if(selectedBoardFqbn && selectedBoardFqbn !== "arduino:avr:uno"){
      log("NOTE: Detected board is not UNO. Compile/Upload will use detected FQBN: " + selectedBoardFqbn);
    }
  }catch(e){
    log("Detect Board error: " + e.message);
  }
}

async function flashUnoBoard(){
  compilerPanelVisible = true;
  updateBottomDock();

  if(!selectedBoard || !selectedUnoPort){
    log("No selected board/port. Detecting first...");
    await detectUnoBoard();
  }

  if(!selectedBoard || !selectedUnoPort){
    log("Flash cancelled: no board port selected.");
    return;
  }

  const fqbn = selectedBoardFqbn || "arduino:avr:uno";
  log("Flashing board on port: " + selectedUnoPort);
  log("Using FQBN: " + fqbn);

  try{
    const res = await fetch("/api/upload",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        code:document.getElementById("code").value,
        port:selectedUnoPort,
        fqbn:fqbn
      })
    });

    const data = await res.json();
    log(data.output || "");
    log(data.ok ? "Upload successful." : "Upload failed.");
  }catch(e){
    log("Flash Board error: " + e.message);
  }
}


/* REAL HARDWARE SERIAL COM */
var V19_REAL_SERIAL_COM_ACTIVE=true;
var realSerialOpen=false;
var serialPollTimer=null;

function selectedSerialPort(){
  if(typeof selectedUnoPort!=="undefined"&&selectedUnoPort)return selectedUnoPort;
  if(typeof selectedBoard!=="undefined"&&selectedBoard&&selectedBoard.port)return selectedBoard.port;
  const sel=document.getElementById("boardSelect");
  if(sel&&typeof detectedBoards!=="undefined"&&detectedBoards.length){
    const b=detectedBoards[parseInt(sel.value||"0",10)];
    if(b&&b.port)return b.port;
  }
  return null;
}
function selectedBaud(){const b=document.getElementById("baudSelect");return parseInt(b?b.value:"9600",10)||9600;}
async function toggleSerialCom(){
  compilerPanelVisible=false; serialPanelVisible=true; updateBottomDock();
  if(realSerialOpen) await closeSerialCom(); else await openSerialCom();
}
async function openSerialCom(){
  let port=selectedSerialPort();
  if(!port){log("No port selected. Detecting board first..."); await detectUnoBoard(); port=selectedSerialPort();}
  if(!port){serial("No COM port available.");return;}
  const baudRate=selectedBaud();
  serial("Opening real serial COM: "+port+" @ "+baudRate);
  try{
    const res=await fetch("/api/serial/open",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({port,baudRate})});
    const data=await res.json();
    if(data.ok){realSerialOpen=true;serial("Serial COM opened: "+port+" @ "+baudRate);startSerialPolling();}
    else serial("Serial COM open failed: "+(data.output||data.error||""));
  }catch(e){serial("Serial COM open error: "+e.message);}
}
async function closeSerialCom(){
  try{
    const r=await fetch("/api/serial/close",{method:"POST"}); const d=await r.json();
    realSerialOpen=false; stopSerialPolling(); serial(d.ok?"Serial COM closed.":"Serial close failed: "+(d.output||d.error||""));
  }catch(e){serial("Serial COM close error: "+e.message);}
}
function startSerialPolling(){stopSerialPolling();serialPollTimer=setInterval(readSerialCom,250);}
function stopSerialPolling(){if(serialPollTimer){clearInterval(serialPollTimer);serialPollTimer=null;}}
async function readSerialCom(){
  if(!realSerialOpen)return;
  try{
    const r=await fetch("/api/serial/read"); const d=await r.json();
    if(d.ok&&d.data){const el=document.getElementById("serial"); if(el){el.textContent+=d.data;if(el.textContent.length>20000)el.textContent=el.textContent.slice(-20000);el.scrollTop=el.scrollHeight;}}
    if(d.open===false){realSerialOpen=false;stopSerialPolling();serial("Serial COM disconnected.");}
  }catch(e){}
}
async function sendSerialText(){
  const inp=document.getElementById("serialTx"); if(!inp)return;
  let text=inp.value; if(!text)return; text+="\r\n";
  try{
    const r=await fetch("/api/serial/write",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({data:text})});
    const d=await r.json(); if(!d.ok)serial("Serial write failed: "+(d.output||d.error||"")); inp.value="";
  }catch(e){serial("Serial write error: "+e.message);}
}
function serialTxKey(e){if(e.key==="Enter"){e.preventDefault();sendSerialText();}}


/* ============================================================
   UNO ONLY UI PATCH
   - Supports Arduino UNO target only.
   - Run button becomes "Stop Simulation" while running.
   - Button returns to "Run Simulation" after stop/error/completion.
   ============================================================ */
var targetBoard = "arduino";
var simulationActive = false;

function switchTargetBoard(target){
  targetBoard = "arduino";
  const uno = document.getElementById("uno");
  if(uno) uno.style.display = "block";
  log("Target: Arduino UNO");
}

function setRunStopButtonState(active){
  simulationActive = !!active;
  const b = document.getElementById("runStopBtn");
  if(!b) return;
  b.textContent = simulationActive ? "Stop Simulation" : "Run Simulation";
  b.classList.toggle("running", simulationActive);
}

async function unifiedCompile(){
  if(typeof compilerPanelVisible !== "undefined") compilerPanelVisible = true;
  if(typeof updateBottomDock === "function") updateBottomDock();
  if(typeof compileCode === "function") return compileCode();
  log("Arduino compile function not found.");
}

async function unifiedDetectBoard(){
  if(typeof compilerPanelVisible !== "undefined") compilerPanelVisible = true;
  if(typeof updateBottomDock === "function") updateBottomDock();
  if(typeof detectUnoBoard === "function") return detectUnoBoard();
  if(typeof detectBoard === "function" && detectBoard !== unifiedDetectBoard) return detectBoard();
  log("Arduino UNO board detect function not found.");
}

async function unifiedFlashBoard(){
  if(typeof compilerPanelVisible !== "undefined") compilerPanelVisible = true;
  if(typeof updateBottomDock === "function") updateBottomDock();
  if(typeof flashUnoBoard === "function") return flashUnoBoard();
  if(typeof flashBoard === "function" && flashBoard !== unifiedFlashBoard) return flashBoard();
  log("Arduino UNO flash function not found.");
}

const __unoOriginalStopSimulation = (typeof stopSimulation === "function") ? stopSimulation : null;
function stopUnoSimulationFromUi(){
  if(typeof running !== "undefined") running = false;
  if(__unoOriginalStopSimulation) __unoOriginalStopSimulation();
  setRunStopButtonState(false);
}

if(__unoOriginalStopSimulation && !window.__unoStopWrapped){
  window.__unoStopWrapped = true;
  stopSimulation = function(){
    const r = __unoOriginalStopSimulation();
    setRunStopButtonState(false);
    return r;
  };
}

async function toggleRunStopSimulation(){
  if(simulationActive){
    stopUnoSimulationFromUi();
    log("Simulation stopped.");
    return;
  }

  setRunStopButtonState(true);
  try{
    if(typeof runSimulation === "function") await runSimulation();
    else log("Arduino UNO simulation function not found.");
  }catch(e){
    log("Runtime error: " + e.message);
  }finally{
    setRunStopButtonState(false);
  }
}

function syncUnoOnboardLEDs(pin,value){
 const el=document.querySelector('[data-pin="'+pin+'"],#uno_led_'+pin+',#led_'+pin);
 if(!el) return;
 const activeHigh=(pin==="13");
 const on=activeHigh?!!value:!value;
 el.classList.toggle("led-on",on);
 el.style.filter=on?"drop-shadow(0 0 8px #ff0)":"";
 el.style.opacity=on?"1":"0.35";
}

if(typeof digitalWrite==="function" && !window.__unoDigitalWriteLedWrap){
 const __dw=digitalWrite;
 window.__unoDigitalWriteLedWrap=true;
 digitalWrite=function(pin,val){
   const r=__dw(pin,val);
   try{syncUnoOnboardLEDs(String(pin),val);}catch(e){}
   return r;
 };
}

setTimeout(()=>{
  const sel=document.getElementById("targetSelect");
  if(sel){ sel.value="arduino"; sel.disabled=true; }
  switchTargetBoard("arduino");
  setRunStopButtonState(false);
},200);

/* ============================================================
   AVR PHASE 2 PATCH
   - Compile button uses /api/compile-hex to obtain real UNO HEX.
   - Run button tries VectorAvrRuntimePhase2 first.
   - If AVR8js is not available, old source-level simulation remains usable.
   ============================================================ */
var avrPhase2HexText = "";
var avrPhase2HexFileName = "";
var avrPhase2Runtime = null;
var avrPhase2Enabled = true;

function vectorApiUrl(path){
  // When the app is opened through the backend, relative URLs are correct.
  // When the app window/browser opens from file:// or another origin, use the local backend explicitly.
  if(location.protocol === "http:" || location.protocol === "https:") return path;
  return "http://127.0.0.1:3000" + path;
}

async function vectorFetchJson(path, options){
  const urls = [];
  urls.push(vectorApiUrl(path));
  if(urls[0] !== path) urls.push(path);
  if(urls[0] !== "http://127.0.0.1:3000" + path) urls.push("http://127.0.0.1:3000" + path);

  let lastError = null;
  for(const url of urls){
    try{
      const response = await fetch(url, options);
      const text = await response.text();
      let data = {};
      try{ data = text ? JSON.parse(text) : {}; }
      catch(parseError){ data = { ok:false, output:text, error:"Non-JSON backend response" }; }
      if(!response.ok){
        data.ok = false;
        data.success = false;
        data.output = data.output || ("HTTP " + response.status + " from " + url);
      }
      return data;
    }catch(err){
      lastError = err;
    }
  }
  throw lastError || new Error("Unable to reach backend");
}

async function compileHexForAvrPhase2(){
  if(typeof compilerPanelVisible !== "undefined") compilerPanelVisible = true;
  if(typeof updateBottomDock === "function") updateBottomDock();
  clearLog();
  log("Phase 2: compiling Arduino UNO sketch to real Intel HEX...");
  try{
    const code = document.getElementById("code").value;
    const d = await vectorFetchJson("/api/compile-hex",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({code:code})
    });
    log(d.output || "");
    if(d.ok && d.hex){
      avrPhase2HexText = d.hex;
      avrPhase2HexFileName = d.hexFileName || "sketch.ino.hex";
      if(window.VectorAvrRuntimePhase2){
        avrPhase2Runtime = new window.VectorAvrRuntimePhase2();
        avrPhase2Runtime.loadHex(avrPhase2HexText);
        log("Phase 2: HEX ready for AVR emulator: " + avrPhase2HexFileName);
      }else{
        log("Phase 2 runtime script not loaded. Falling back to old simulator runtime.");
      }
    }else{
      avrPhase2HexText = "";
      avrPhase2HexFileName = "";
      avrPhase2Runtime = null;
      log(d.error ? ("Compile endpoint error: " + d.error) : "Compile endpoint returned no HEX.");
    }
  }catch(e){
    log("Phase 2 compile/HEX error: " + e.message);
    log("Check that setup_run.bat is still running and open the simulator at http://127.0.0.1:3000");
    avrPhase2HexText = "";
    avrPhase2Runtime = null;
  }
}

// Override UNO compile button for Phase 2.
unifiedCompile = compileHexForAvrPhase2;

const __phase2OldToggleRunStopSimulation = (typeof toggleRunStopSimulation === "function") ? toggleRunStopSimulation : null;
async function runAvrPhase2OrFallback(){
  if(simulationActive){
    if(avrPhase2Runtime && avrPhase2Runtime.running) avrPhase2Runtime.stop();
    stopUnoSimulationFromUi();
    log("Simulation stopped.");
    return;
  }

  setRunStopButtonState(true);
  try{
    if(avrPhase2Enabled && avrPhase2HexText && window.VectorAvrRuntimePhase2){
      if(!avrPhase2Runtime){
        avrPhase2Runtime = new window.VectorAvrRuntimePhase2();
        avrPhase2Runtime.loadHex(avrPhase2HexText);
      }
      await avrPhase2Runtime.start();
      return;
    }

    log("No Phase 2 HEX loaded yet. Click Compile first. Using source-level fallback simulation.");
    if(__phase2OldToggleRunStopSimulation) await __phase2OldToggleRunStopSimulation();
    else if(typeof runSimulation === "function") await runSimulation();
  }catch(e){
    log("Phase 2 AVR runtime error: " + e.message);
    log("Fallback note: install dependencies using setup_run.bat/npm install, then restart the simulator.");
    if(typeof runSimulation === "function") await runSimulation();
  }finally{
    if(!(avrPhase2Runtime && avrPhase2Runtime.running)) setRunStopButtonState(false);
  }
}

toggleRunStopSimulation = runAvrPhase2OrFallback;

const __phase2OldStopUnoSimulationFromUi = (typeof stopUnoSimulationFromUi === "function") ? stopUnoSimulationFromUi : null;
stopUnoSimulationFromUi = function(){
  if(avrPhase2Runtime && avrPhase2Runtime.running) avrPhase2Runtime.stop();
  if(__phase2OldStopUnoSimulationFromUi) return __phase2OldStopUnoSimulationFromUi();
  setRunStopButtonState(false);
};

/* ============================================================
   AVR PHASE 3 PATCH
   - Real AVR PORTB bit-5 (PB5) drives Arduino UNO D13.
   - Updates both the onboard LED overlay and any external LED
     component wired to D13.
   ============================================================ */
function setAvrDigitalPinValue(pin, value){
  pinValues[Number(pin)] = value ? HIGH : LOW;
}

function updateExternalLedFromDigitalPin(pin, value){
  const pinName = "D" + String(pin).replace(/^D/i, "");
  const logic = value ? HIGH : LOW;
  setAvrDigitalPinValue(pinName.replace("D", ""), logic);

  if(project && project.parts){
    // Existing helper supports direct D13 -> LED.A wiring.
    findPartsOnUnoPin("led", "A", pinName).forEach(p => p.state = logic);
    // Also support active-low wiring: 5V -> LED.A and D13 -> LED.K.
    findPartsOnUnoPin("led", "K", pinName).forEach(p => p.state = logic ? LOW : HIGH);
  }
  if(typeof scheduleRuntimeRender === "function") scheduleRuntimeRender();
  else if(typeof render === "function") render();
}

// Replace the earlier helper with a stronger Phase 3 version. It keeps the
// onboard LED overlay visible and also bridges to external LED components.
syncUnoOnboardLEDs = function(pin, value){
  const normalizedPin = String(pin).replace(/^D/i, "");
  const on = !!value;
  const el = document.querySelector('#uno_led_' + normalizedPin + ',[data-pin="' + normalizedPin + '"]');
  if(el){
    el.classList.toggle("led-on", on);
    el.style.filter = on ? "drop-shadow(0 0 8px #ffd429)" : "";
    el.style.opacity = on ? "1" : "0.45";
  }
  updateExternalLedFromDigitalPin(normalizedPin, on);
};

window.setAvrDigitalPinValue = setAvrDigitalPinValue;
window.updateExternalLedFromDigitalPin = updateExternalLedFromDigitalPin;
window.syncUnoOnboardLEDs = syncUnoOnboardLEDs;

/* ============================================================
   AVR PHASE 3.1 PATCH
   - Fixes onboard Arduino UNO D13 LED visibility.
   - The offboard LED was already following PB5/D13.
   - This patch guarantees that #uno_led_13 exists, is visible above the
     UNO board image, and is updated after every AVR D13 state change.
   ============================================================ */
(function(){
  function ensureUnoOnboardD13Led(){
    // Phase 4.2A: legacy #uno_led_13 was an extra duplicate LED near the board.
    // It is intentionally removed/hidden. The real onboard L LED is #uno_led_L.
    const old = document.getElementById('uno_led_13');
    if(old) old.remove();
    return null;
  }

  function setUnoOnboardD13Led(on){
    // Forward old D13 calls to the properly aligned L LED.
    if(typeof window.setUnoBoardLed === 'function') window.setUnoBoardLed('L', !!on);
  }

  const oldSync = window.syncUnoOnboardLEDs;
  window.syncUnoOnboardLEDs = function(pin, value){
    const normalizedPin = String(pin).replace(/^D/i, '');
    if(normalizedPin === '13'){
      setUnoOnboardD13Led(!!value);
    }

    if(typeof oldSync === 'function'){
      try{ oldSync(pin, value); }catch(e){}
    }

    // Some old helper paths call render() after the onboard update.
    // Re-apply once more after render/layout so the onboard LED remains correct.
    if(normalizedPin === '13'){
      setTimeout(function(){ setUnoOnboardD13Led(!!value); }, 0);
    }
  };

  window.ensureUnoOnboardD13Led = ensureUnoOnboardD13Led;
  window.setUnoOnboardD13Led = setUnoOnboardD13Led;

  setTimeout(function(){
    ensureUnoOnboardD13Led();
    setUnoOnboardD13Led(false);
  }, 300);
})();

/* ============================================================
   AVR PHASE 4.2 PATCH - UNO Board LEDs
   ------------------------------------------------------------
   Purpose:
   1. The onboard UNO LED labelled L follows AVR PB5 / Arduino D13.
   2. The onboard TX LED flashes when USART0 transmits bytes.
   3. The onboard RX LED scaffold is available for future serial input.
   4. The LED positions are aligned to the actual labels on assets/arduino_uno.png.
   ============================================================ */
(function(){
  'use strict';

  const LED_POSITIONS = {
    // Coordinates are aligned to the square LEDs printed on assets/arduino_uno.png.
    // L, TX, and RX blink yellow. PWR is a fixed red power indicator.
    L:   { id: 'uno_led_L',   label: 'L LED / PB5 / D13',        left: 295, top: 100, size: 14, color: '#ffd429', offColor: '#6f681f' },
    TX:  { id: 'uno_led_TX',  label: 'TX LED / USART0 TX / D1',  left: 295, top: 142, size: 14, color: '#b88a00', offColor: '#c2c5bd' },
    RX:  { id: 'uno_led_RX',  label: 'RX LED / USART0 RX / D0',  left: 295, top: 166, size: 14, color: '#b88a00', offColor: '#c2c5bd' },
    PWR: { id: 'uno_led_PWR', label: 'Power LED',                left: 572, top: 142, size: 14, color: '#ff2525', offColor: '#8a2b22' }
  };

  const activityTimers = {};

  function ensureUnoLed(name){
    const cfg = LED_POSITIONS[name];
    const uno = document.getElementById('uno');
    if(!cfg || !uno) return null;

    let led = document.getElementById(cfg.id);
    if(!led){
      led = document.createElement('span');
      led.id = cfg.id;
      led.className = 'uno-board-status-led uno-board-status-led-' + name.toLowerCase();
      led.title = cfg.label;
      uno.appendChild(led);
    }

    led.style.position = 'absolute';
    led.style.left = cfg.left + 'px';
    led.style.top = cfg.top + 'px';
    led.style.width = cfg.size + 'px';
    led.style.height = cfg.size + 'px';
    led.style.borderRadius = '50%';
    led.style.border = '1px solid rgba(70,70,55,0.55)';
    led.style.zIndex = '30000';
    led.style.pointerEvents = 'none';
    led.style.display = 'block';
    led.dataset.vectorUnoLed = name;
    return led;
  }

  function setUnoBoardLed(name, on){
    const cfg = LED_POSITIONS[name];
    const led = ensureUnoLed(name);
    if(!cfg || !led) return;

    led.classList.toggle('led-on', !!on);
    const isPower = name === 'PWR';
    const active = isPower ? true : !!on;
    led.classList.toggle('led-on', active);
    led.style.background = active ? cfg.color : (cfg.offColor || '#c2c5bd');
    led.style.opacity = '1';
    led.style.border = active ? '1px solid rgba(255,255,255,0.55)' : '1px solid rgba(70,70,55,0.35)';
    led.style.boxShadow = active
      ? '0 0 10px ' + cfg.color + ', 0 0 22px ' + cfg.color + ', inset 0 0 3px #ffffff'
      : 'inset 0 0 2px rgba(0,0,0,0.35)';
    led.style.filter = active ? 'drop-shadow(0 0 8px ' + cfg.color + ')' : 'none';
  }

  function pulseUnoBoardLed(name, durationMs){
    setUnoBoardLed(name, true);
    if(activityTimers[name]) clearTimeout(activityTimers[name]);
    activityTimers[name] = setTimeout(function(){
      setUnoBoardLed(name, false);
      activityTimers[name] = null;
    }, durationMs || 90);
  }

  function refreshUnoBoardLedsFromState(){
    const st = window.VectorUnoBoardState || {};
    // L LED on Arduino UNO is driven by PB5, which is Arduino D13.
    if(st.D13) setUnoBoardLed('L', !!st.D13.value);
  }

  // Expose helpers for the AVR runtime.
  window.ensureUnoBoardLed = ensureUnoLed;
  window.setUnoBoardLed = setUnoBoardLed;
  window.pulseUnoBoardLed = pulseUnoBoardLed;
  window.refreshUnoBoardLedsFromState = refreshUnoBoardLedsFromState;

  // Maintain backward compatibility with the Phase 3 helper name.
  const oldSync = window.syncUnoOnboardLEDs;
  window.syncUnoOnboardLEDs = function(pin, value){
    const normalizedPin = String(pin).replace(/^D/i, '');
    if(normalizedPin === '13'){
      setUnoBoardLed('L', !!value);
      // Keep the old id in sync if present, but put it exactly over L also.
      const old = document.getElementById('uno_led_13');
      if(old){
        old.style.left = LED_POSITIONS.L.left + 'px';
        old.style.top = LED_POSITIONS.L.top + 'px';
        old.style.width = LED_POSITIONS.L.size + 'px';
        old.style.height = LED_POSITIONS.L.size + 'px';
        old.style.zIndex = '29999';
        old.style.display = 'none'; // hide duplicate; uno_led_L is the active visual LED
      }
    }
    if(typeof oldSync === 'function'){
      try{ oldSync(pin, value); }catch(e){}
    }
    if(normalizedPin === '13'){
      setTimeout(function(){ setUnoBoardLed('L', !!value); }, 0);
    }
  };

  const oldPinChange = window.onVectorUnoPinChange;
  window.onVectorUnoPinChange = function(name, state, source){
    if(name === 'D13') setUnoBoardLed('L', !!state.value);

    // Pin D1 is AVR PD1 / hardware TX. Direct GPIO writes to D1 are displayed
    // as TX-line logic. USART byte transmission also pulses TX using the AVR
    // runtime callback below.
    if(name === 'D1') setUnoBoardLed('TX', !!state.value);

    // Pin D0 is AVR PD0 / hardware RX. For now it reflects GPIO/RX line logic;
    // incoming serial receive pulse will be added in the serial-input phase.
    if(name === 'D0') setUnoBoardLed('RX', !!state.value);

    if(typeof oldPinChange === 'function'){
      try{ oldPinChange(name, state, source); }catch(e){}
    }
  };

  setTimeout(function(){
    // Remove legacy duplicate LED from earlier Phase 3 builds.
    const oldDuplicate = document.getElementById('uno_led_13');
    if(oldDuplicate) oldDuplicate.remove();

    ensureUnoLed('L');
    ensureUnoLed('TX');
    ensureUnoLed('RX');
    ensureUnoLed('PWR');
    setUnoBoardLed('L', false);
    setUnoBoardLed('TX', false);
    setUnoBoardLed('RX', false);
    setUnoBoardLed('PWR', true);
    refreshUnoBoardLedsFromState();
  }, 300);
})();


/* ============================================================
   AVR PHASE 4.2B PATCH - Board image LED cleanup/alignment
   ------------------------------------------------------------
   - No extra legacy LED is allowed near the 6-pin/ICSP header.
   - Only four board overlay LEDs exist: L, TX, RX, PWR.
   - L/TX/RX are yellow activity indicators aligned to the small
     white square LEDs printed on the UNO board image.
   - PWR is fixed red and aligned to the board ON/PWR LED square.
   ============================================================ */
(function(){
  'use strict';
  function removeLegacyUnoLedArtifacts(){
    const allowed = new Set(['uno_led_L','uno_led_TX','uno_led_RX','uno_led_PWR']);
    document.querySelectorAll('#uno .uno-onboard-led, #uno #uno_led_13').forEach(el => el.remove());
    document.querySelectorAll('#uno .uno-board-status-led').forEach(el => {
      if(!allowed.has(el.id)) el.remove();
    });
  }
  function enforceBoardLedPositions(){
    const pos = {
      uno_led_L:   {left:295, top:100, size:14, color:'#ffd429', offColor:'#6f681f'},
      uno_led_TX:  {left:295, top:142, size:14, color:'#b88a00', offColor:'#c2c5bd'},
      uno_led_RX:  {left:295, top:166, size:14, color:'#b88a00', offColor:'#c2c5bd'},
      uno_led_PWR: {left:572, top:142, size:14, color:'#ff2525', offColor:'#8a2b22'}
    };
    Object.keys(pos).forEach(id => {
      const el = document.getElementById(id);
      const cfg = pos[id];
      if(!el) return;
      el.style.left = cfg.left + 'px';
      el.style.top = cfg.top + 'px';
      el.style.width = cfg.size + 'px';
      el.style.height = cfg.size + 'px';
      el.style.borderRadius = '50%';
      el.style.zIndex = '30000';
      el.style.pointerEvents = 'none';
      el.style.background = cfg.offColor || '#c2c5bd';
      el.style.opacity = '1';
      el.style.border = '1px solid rgba(70,70,55,0.35)';
      el.style.boxShadow = 'inset 0 0 2px rgba(0,0,0,0.35)';
      if(id === 'uno_led_PWR'){
        el.classList.add('led-on');
        el.style.background = cfg.color;
        el.style.opacity = '1';
        el.style.boxShadow = '0 0 8px #ff2525, 0 0 16px #ff2525, inset 0 0 3px #ffffff';
      }
    });
  }
  function phase42bClean(){
    removeLegacyUnoLedArtifacts();
    ['L','TX','RX','PWR'].forEach(name => {
      if(typeof window.ensureUnoBoardLed === 'function') window.ensureUnoBoardLed(name);
    });
    enforceBoardLedPositions();
    if(typeof window.setUnoBoardLed === 'function'){
      window.setUnoBoardLed('PWR', true);
    }
  }
  setTimeout(phase42bClean, 50);
  setTimeout(phase42bClean, 500);
  window.phase42bCleanUnoBoardLeds = phase42bClean;
})();


/* ============================================================
   AVR PHASE 4.2C PATCH - LED off-state color and exact overlay
   ------------------------------------------------------------
   The overlay circles now sit directly on top of the board LED
   squares. OFF state uses the same visual color family as the
   printed LED square. ON state uses active LED colors.
   ============================================================ */
(function(){
  'use strict';
  const LED_CFG = {
    uno_led_L:   { left:295, top:100, size:14, on:'#ffd429', off:'#6f681f' },
    uno_led_TX:  { left:295, top:142, size:14, on:'#b88a00', off:'#c2c5bd' },
    uno_led_RX:  { left:295, top:166, size:14, on:'#b88a00', off:'#c2c5bd' },
    uno_led_PWR: { left:572, top:142, size:14, on:'#ff2525', off:'#8a2b22', fixed:true }
  };
  function applyLedVisual(id, active){
    const el = document.getElementById(id);
    const cfg = LED_CFG[id];
    if(!el || !cfg) return;
    const on = cfg.fixed ? true : !!active;
    el.style.position = 'absolute';
    el.style.left = cfg.left + 'px';
    el.style.top = cfg.top + 'px';
    el.style.width = cfg.size + 'px';
    el.style.height = cfg.size + 'px';
    el.style.borderRadius = '50%';
    el.style.zIndex = '30000';
    el.style.display = 'block';
    el.style.pointerEvents = 'none';
    el.style.opacity = '1';
    el.style.background = on ? cfg.on : cfg.off;
    el.style.border = on ? '1px solid rgba(255,255,255,0.55)' : '1px solid rgba(70,70,55,0.35)';
    el.style.boxShadow = on
      ? '0 0 10px ' + cfg.on + ', 0 0 22px ' + cfg.on + ', inset 0 0 3px #ffffff'
      : 'inset 0 0 2px rgba(0,0,0,0.35)';
    el.style.filter = on ? 'drop-shadow(0 0 8px ' + cfg.on + ')' : 'none';
    el.classList.toggle('led-on', on);
  }
  const previousSet = window.setUnoBoardLed;
  window.setUnoBoardLed = function(name, on){
    const id = 'uno_led_' + name;
    if(typeof previousSet === 'function'){
      try { previousSet(name, on); } catch(e) {}
    }
    applyLedVisual(id, on);
  };
  function enforcePhase42C(){
    ['L','TX','RX','PWR'].forEach(name => {
      if(typeof window.ensureUnoBoardLed === 'function') window.ensureUnoBoardLed(name);
    });
    applyLedVisual('uno_led_L', false);
    applyLedVisual('uno_led_TX', false);
    applyLedVisual('uno_led_RX', false);
    applyLedVisual('uno_led_PWR', true);
    if(window.VectorUnoBoardState && window.VectorUnoBoardState.D13){
      applyLedVisual('uno_led_L', !!window.VectorUnoBoardState.D13.value);
    }
  }
  setTimeout(enforcePhase42C, 80);
  setTimeout(enforcePhase42C, 500);
  window.phase42cEnforceUnoLedVisuals = enforcePhase42C;
})();

/* ============================================================
   AVR PHASE 4.2G PATCH - Shifted square board LED overlay
   ------------------------------------------------------------
   L/TX/RX/PWR indicators are SVG SQUARES shifted slightly
   left/up to cover and overshadow the printed UNO board LED
   squares. This makes the printed LEDs appear to change color
   during simulation.

   Runtime behavior:
   - L   : follows AVR PB5 / Arduino D13
   - TX  : pulses dark yellow on USART transmit activity
   - RX  : pulses dark yellow on receive activity scaffold
   - PWR : always red while simulator board is powered
   ============================================================ */
(function(){
  'use strict';

  const SVG_NS = 'http://www.w3.org/2000/svg';

  // Coordinates are in displayed UNO image pixels.
  // Rectangles are intentionally the same square size as the printed
  // SMD LED squares on the Arduino UNO image.
  const LED_POS = {
    // Phase 4.2G: shifted slightly LEFT and UP so each square fully
    // covers/overshadows the printed onboard LED square on the UNO image.
    L:   { id:'uno_led_L',   x:288, y:97,  w:15, h:15, off:'#6f681f', on:'#ffd429', glow:'#ffd429', fixed:false },
    TX:  { id:'uno_led_TX',  x:290, y:139, w:15, h:15, off:'#c2c5bd', on:'#b8860b', glow:'#b8860b', fixed:false },
    RX:  { id:'uno_led_RX',  x:290, y:163, w:15, h:15, off:'#c2c5bd', on:'#b8860b', glow:'#b8860b', fixed:false },
    PWR: { id:'uno_led_PWR', x:564, y:139, w:15, h:15, off:'#8a2b22', on:'#ff2020', glow:'#ff2020', fixed:true  }
  };

  function removeOldLedOverlays(){
    document.querySelectorAll('#uno .uno-onboard-led, #uno .uno-board-status-led, #uno #uno_led_13').forEach(el => el.remove());
    const oldSvg = document.getElementById('uno_board_led_svg_overlay');
    if(oldSvg) oldSvg.remove();
  }

  function ensureSquareLedOverlay(){
    const uno = document.getElementById('uno');
    if(!uno) return null;

    // Remove old HTML circle overlays from previous phases.
    document.querySelectorAll('#uno .uno-onboard-led, #uno .uno-board-status-led, #uno #uno_led_13').forEach(el => el.remove());

    let svg = document.getElementById('uno_board_led_square_svg_overlay');
    if(!svg){
      // Remove any older circular SVG overlay before creating the square overlay.
      const oldSvg = document.getElementById('uno_board_led_svg_overlay');
      if(oldSvg) oldSvg.remove();

      svg = document.createElementNS(SVG_NS, 'svg');
      svg.setAttribute('id', 'uno_board_led_square_svg_overlay');
      svg.setAttribute('viewBox', '0 0 640 468');
      svg.setAttribute('width', '640');
      svg.setAttribute('height', '468');
      svg.style.position = 'absolute';
      svg.style.left = '0px';
      svg.style.top = '0px';
      svg.style.width = '640px';
      svg.style.height = '468px';
      svg.style.pointerEvents = 'none';
      svg.style.zIndex = '30000';
      svg.style.overflow = 'visible';
      uno.appendChild(svg);
    }

    if(!document.getElementById('uno_led_square_glow_filter')){
      const defs = document.createElementNS(SVG_NS, 'defs');
      defs.innerHTML = `
        <filter id="uno_led_square_glow_filter" x="-300%" y="-300%" width="700%" height="700%">
          <feGaussianBlur stdDeviation="2.2" result="coloredBlur"></feGaussianBlur>
          <feMerge>
            <feMergeNode in="coloredBlur"></feMergeNode>
            <feMergeNode in="SourceGraphic"></feMergeNode>
          </feMerge>
        </filter>`;
      svg.appendChild(defs);
    }

    Object.keys(LED_POS).forEach(name => {
      const cfg = LED_POS[name];
      let r = document.getElementById(cfg.id);
      if(!r){
        r = document.createElementNS(SVG_NS, 'rect');
        r.setAttribute('id', cfg.id);
        r.setAttribute('data-vector-uno-led', name);
        r.setAttribute('rx', '1.5');
        r.setAttribute('ry', '1.5');
        svg.appendChild(r);
      }
      r.setAttribute('x', cfg.x);
      r.setAttribute('y', cfg.y);
      r.setAttribute('width', cfg.w);
      r.setAttribute('height', cfg.h);
    });

    return svg;
  }

  function setSquareLed(name, active){
    ensureSquareLedOverlay();
    const cfg = LED_POS[name];
    if(!cfg) return;
    const r = document.getElementById(cfg.id);
    if(!r) return;

    const isOn = cfg.fixed ? true : !!active;
    r.setAttribute('fill', isOn ? cfg.on : cfg.off);
    r.setAttribute('stroke', isOn ? 'rgba(255,255,255,0.70)' : 'rgba(50,50,40,0.35)');
    r.setAttribute('stroke-width', isOn ? '0.8' : '0.45');
    r.setAttribute('opacity', '1');
    r.setAttribute('filter', isOn ? 'url(#uno_led_square_glow_filter)' : 'none');
    r.style.filter = isOn ? 'drop-shadow(0 0 5px ' + cfg.glow + ')' : 'none';
  }

  // Public API used by the AVR runtime and board bridge.
  window.ensureUnoBoardLed = function(name){
    ensureSquareLedOverlay();
    const cfg = LED_POS[name];
    return cfg ? document.getElementById(cfg.id) : null;
  };

  window.setUnoBoardLed = function(name, on){
    setSquareLed(name, on);
  };

  const activityTimers = {};
  window.pulseUnoBoardLed = function(name, durationMs){
    setSquareLed(name, true);
    if(activityTimers[name]) clearTimeout(activityTimers[name]);
    activityTimers[name] = setTimeout(function(){
      setSquareLed(name, false);
      activityTimers[name] = null;
    }, durationMs || 90);
  };

  function refreshFromBoardState(){
    ensureSquareLedOverlay();
    const st = window.VectorUnoBoardState || {};
    setSquareLed('L', !!(st.D13 && st.D13.value));
    setSquareLed('TX', false);
    setSquareLed('RX', false);
    setSquareLed('PWR', true);
  }

  window.phase42fSquareBoardLeds = refreshFromBoardState;
  setTimeout(refreshFromBoardState, 20);
  setTimeout(refreshFromBoardState, 300);
  setTimeout(refreshFromBoardState, 1000);
})();

/* ============================================================
   AVR PHASE 4.2H PATCH - Config-based refined square LED overlay
   ------------------------------------------------------------
   This layer replaces hard-coded LED overlay coordinates with a
   single editable configuration object.  The square overlays are
   shifted as requested:
   - TX/RX: slightly left and up
   - PWR  : more left and slightly up
   ============================================================ */
(function(){
  'use strict';
  const SVG_NS = 'http://www.w3.org/2000/svg';

  window.VectorUnoLedOverlayConfig = {
    board: { viewBoxW: 640, viewBoxH: 468, width: 640, height: 468 },
    leds: {
      L:   { id:'uno_led_L',   x:288, y:97,  w:15, h:15, rx:1.5, ry:1.5, off:'#6f681f', on:'#ffd429', glow:'#ffd429', fixed:false }, // L LED shifted 2px left,
      TX:  { id:'uno_led_TX',  x:287, y:137, w:15, h:15, rx:1.5, ry:1.5, off:'#c2c5bd', on:'#b8860b', glow:'#b8860b', fixed:false },
      RX:  { id:'uno_led_RX',  x:287, y:161, w:15, h:15, rx:1.5, ry:1.5, off:'#c2c5bd', on:'#b8860b', glow:'#b8860b', fixed:false },
      PWR: { id:'uno_led_PWR', x:558, y:137, w:15, h:15, rx:1.5, ry:1.5, off:'#8a2b22', on:'#ff2020', glow:'#ff2020', fixed:true  } // Power LED shifted 4px left
    }
  };

  const activityTimers = {};

  function getCfg(name){
    return window.VectorUnoLedOverlayConfig && window.VectorUnoLedOverlayConfig.leds
      ? window.VectorUnoLedOverlayConfig.leds[name]
      : null;
  }

  function ensureFilter(svg){
    if(document.getElementById('uno_led_square_glow_filter_h')) return;
    const defs = document.createElementNS(SVG_NS, 'defs');
    defs.innerHTML = `
      <filter id="uno_led_square_glow_filter_h" x="-300%" y="-300%" width="700%" height="700%">
        <feGaussianBlur stdDeviation="2.2" result="coloredBlur"></feGaussianBlur>
        <feMerge>
          <feMergeNode in="coloredBlur"></feMergeNode>
          <feMergeNode in="SourceGraphic"></feMergeNode>
        </feMerge>
      </filter>`;
    svg.appendChild(defs);
  }

  function ensureOverlay(){
    const uno = document.getElementById('uno');
    if(!uno) return null;

    // Remove legacy HTML/circle overlays, but keep the current square SVG if present.
    document.querySelectorAll('#uno .uno-onboard-led, #uno .uno-board-status-led, #uno #uno_led_13').forEach(el => el.remove());
    const oldCircularSvg = document.getElementById('uno_board_led_svg_overlay');
    if(oldCircularSvg) oldCircularSvg.remove();

    const board = window.VectorUnoLedOverlayConfig.board;
    let svg = document.getElementById('uno_board_led_square_svg_overlay');
    if(!svg){
      svg = document.createElementNS(SVG_NS, 'svg');
      svg.setAttribute('id', 'uno_board_led_square_svg_overlay');
      uno.appendChild(svg);
    }

    svg.setAttribute('viewBox', `0 0 ${board.viewBoxW} ${board.viewBoxH}`);
    svg.setAttribute('width', String(board.width));
    svg.setAttribute('height', String(board.height));
    svg.style.position = 'absolute';
    svg.style.left = '0px';
    svg.style.top = '0px';
    svg.style.width = board.width + 'px';
    svg.style.height = board.height + 'px';
    svg.style.pointerEvents = 'none';
    svg.style.zIndex = '30000';
    svg.style.overflow = 'visible';

    ensureFilter(svg);

    Object.keys(window.VectorUnoLedOverlayConfig.leds).forEach(name => {
      const cfg = getCfg(name);
      let r = document.getElementById(cfg.id);
      if(!r){
        r = document.createElementNS(SVG_NS, 'rect');
        r.setAttribute('id', cfg.id);
        r.setAttribute('data-vector-uno-led', name);
        svg.appendChild(r);
      }
      r.setAttribute('x', String(cfg.x));
      r.setAttribute('y', String(cfg.y));
      r.setAttribute('width', String(cfg.w));
      r.setAttribute('height', String(cfg.h));
      r.setAttribute('rx', String(cfg.rx || 0));
      r.setAttribute('ry', String(cfg.ry || 0));
      r.style.pointerEvents = 'none';
    });

    return svg;
  }

  function setLed(name, active){
    ensureOverlay();
    const cfg = getCfg(name);
    if(!cfg) return;
    const r = document.getElementById(cfg.id);
    if(!r) return;

    const isOn = cfg.fixed ? true : !!active;
    r.setAttribute('fill', isOn ? cfg.on : cfg.off);
    r.setAttribute('stroke', isOn ? 'rgba(255,255,255,0.72)' : 'rgba(50,50,40,0.32)');
    r.setAttribute('stroke-width', isOn ? '0.8' : '0.45');
    r.setAttribute('opacity', '1');
    r.setAttribute('filter', isOn ? 'url(#uno_led_square_glow_filter_h)' : 'none');
    r.style.filter = isOn ? 'drop-shadow(0 0 5px ' + cfg.glow + ')' : 'none';
  }

  function refreshFromBoardState(){
    ensureOverlay();
    const st = window.VectorUnoBoardState || {};
    setLed('L', !!(st.D13 && st.D13.value));
    setLed('TX', false);
    setLed('RX', false);
    setLed('PWR', true);
  }

  window.ensureUnoBoardLed = function(name){
    ensureOverlay();
    const cfg = getCfg(name);
    return cfg ? document.getElementById(cfg.id) : null;
  };

  window.setUnoBoardLed = function(name, on){
    setLed(name, on);
  };

  window.pulseUnoBoardLed = function(name, durationMs){
    setLed(name, true);
    if(activityTimers[name]) clearTimeout(activityTimers[name]);
    activityTimers[name] = setTimeout(function(){
      setLed(name, false);
      activityTimers[name] = null;
    }, durationMs || 90);
  };

  window.refreshUnoBoardLedsFromState = refreshFromBoardState;

  // Helper for future fine tuning from browser console without editing many places:
  // updateVectorUnoLedOverlayConfig({ TX:{x:286,y:136}, PWR:{x:560,y:136} })
  window.updateVectorUnoLedOverlayConfig = function(partial){
    if(!partial) return;
    Object.keys(partial).forEach(name => {
      if(window.VectorUnoLedOverlayConfig.leds[name]){
        Object.assign(window.VectorUnoLedOverlayConfig.leds[name], partial[name]);
      }
    });
    ensureOverlay();
    refreshFromBoardState();
  };

  setTimeout(refreshFromBoardState, 20);
  setTimeout(refreshFromBoardState, 300);
  setTimeout(refreshFromBoardState, 1000);
})();

/* ============================================================
   AVR PHASE 4.3 PATCH - Digital I/O interaction layer
   ------------------------------------------------------------
   Purpose:
   1. AVR output pins D0-D13 drive external LED / buzzer / relay widgets.
   2. Virtual push buttons can drive AVR input pins through real GPIO input
      logic, so compiled HEX using digitalRead() sees the button state.
   3. Supports the common classroom wiring:
        Dn configured INPUT_PULLUP, button between Dn and GND.
      Pressed  -> AVR pin reads LOW
      Released -> AVR internal pull-up keeps it HIGH
   ============================================================ */
(function(){
  'use strict';

  function nodeList(partId, pinName){
    const target = partId + '.' + pinName;
    const out = [];
    ((window.project && project.wires) || []).forEach(w => {
      if(w.from === target) out.push(w.to);
      if(w.to === target) out.push(w.from);
    });
    return out;
  }

  function digitalFromNode(n){
    const m = String(n || '').match(/^uno\.D(\d+)$/i);
    if(!m) return null;
    const p = parseInt(m[1], 10);
    return (p >= 0 && p <= 13) ? p : null;
  }

  function isGnd(n){
    return n === 'uno.GND' || n === 'uno.GND2' || n === 'uno.GND_TOP';
  }

  function isVcc(n){
    return n === 'uno.5V' || n === 'uno.3V3' || n === 'uno.IOREF';
  }

  function refreshExternalOutputsFromAvr(){
    if(!window.project || !Array.isArray(project.parts)) return;

    // External LEDs: active-high and active-low wiring.
    if(typeof updateAllLedsFromWires === 'function'){
      try { updateAllLedsFromWires(); } catch(e) {}
    }

    // Buzzer and relay widgets follow active-high signal pins.
    project.parts.forEach(p => {
      if(p.type !== 'buzzer' && p.type !== 'relay') return;
      const sigPin = (p.type === 'buzzer') ? 'SIG' : 'IN';
      const sigNodes = nodeList(p.id, sigPin);
      let active = false;
      sigNodes.forEach(n => {
        const dp = digitalFromNode(n);
        if(dp !== null && window.pinValues && pinValues[dp] === HIGH) active = true;
      });
      p.state = active ? HIGH : LOW;
    });

    if(typeof scheduleRuntimeRender === 'function') scheduleRuntimeRender();
    else if(typeof render === 'function') render();
  }

  const previousSetAvrDigital = window.setAvrDigitalPinValue;
  window.setAvrDigitalPinValue = function(pin, value){
    const p = Number(String(pin).replace(/^D/i, ''));
    if(Number.isFinite(p)) pinValues[p] = value ? HIGH : LOW;
    if(typeof previousSetAvrDigital === 'function'){
      try { previousSetAvrDigital(pin, value); } catch(e) {}
    }
    refreshExternalOutputsFromAvr();
  };

  const previousUpdateExternalLed = window.updateExternalLedFromDigitalPin;
  window.updateExternalLedFromDigitalPin = function(pin, value){
    if(typeof previousUpdateExternalLed === 'function'){
      try { previousUpdateExternalLed(pin, value); } catch(e) {}
    }
    refreshExternalOutputsFromAvr();
  };

  // Called by the AVR runtime. Return only pins that are actively driven by
  // an external component. Pins that are not driven are omitted so AVR pull-ups
  // and floating/input behavior remain controlled by the emulated AVR hardware.
  window.getVectorUnoExternalDigitalInputs = function(){
    const inputs = {};
    if(!window.project || !Array.isArray(project.parts)) return inputs;

    project.parts.forEach(part => {
      if(part.type !== 'button') return;
      const sNodes = nodeList(part.id, 'S');
      const gNodes = nodeList(part.id, 'G');
      const dPins = sNodes.map(digitalFromNode).filter(v => v !== null);
      if(!dPins.length) return;

      const pressed = !!part.state;
      // Released mechanical button is open circuit: do not externally drive.
      if(!pressed) return;

      let drive = null;
      if(gNodes.some(isGnd)) drive = 0;       // Button pressed to GND
      else if(gNodes.some(isVcc)) drive = 1;  // Button pressed to VCC
      else drive = 1;                         // One-pin demo fallback

      dPins.forEach(dp => {
        inputs['D' + dp] = {
          active: true,
          value: drive,
          source: part.id,
          kind: 'button'
        };
      });
    });

    return inputs;
  };

  // Button events already update part.state. This hook simply gives the AVR
  // runtime an immediate opportunity to resample after press/release.
  window.notifyVectorUnoExternalInputsChanged = function(){
    if(window.avrPhase2Runtime && typeof window.avrPhase2Runtime.applyExternalDigitalInputs === 'function'){
      try { window.avrPhase2Runtime.applyExternalDigitalInputs(); } catch(e) {}
    }
  };

  // Install delegated mouse/touch events so every existing and future button
  // component notifies the AVR input bridge after its state changes.
  document.addEventListener('mousedown', function(e){
    if(e.target && e.target.classList && e.target.classList.contains('buttonCircle')){
      setTimeout(window.notifyVectorUnoExternalInputsChanged, 0);
    }
  }, true);
  document.addEventListener('mouseup', function(e){
    if(e.target && e.target.classList && e.target.classList.contains('buttonCircle')){
      setTimeout(window.notifyVectorUnoExternalInputsChanged, 0);
    }
  }, true);
  document.addEventListener('touchstart', function(e){
    if(e.target && e.target.classList && e.target.classList.contains('buttonCircle')){
      setTimeout(window.notifyVectorUnoExternalInputsChanged, 0);
    }
  }, true);
  document.addEventListener('touchend', function(e){
    if(e.target && e.target.classList && e.target.classList.contains('buttonCircle')){
      setTimeout(window.notifyVectorUnoExternalInputsChanged, 0);
    }
  }, true);

  log('Phase 4.3 digital I/O bridge loaded: AVR outputs drive widgets, buttons drive AVR inputs.');
})();

/* ============================================================
   AVR PHASE 4.3 REVISION A - Generic D0-D13 GPIO Engine
   ------------------------------------------------------------
   Purpose:
   1. Make every Arduino UNO digital pin D0-D13 visible from the real
      AVR register state, not only D13/PB5.
   2. Keep external LED widgets synchronized with any digital pin wiring:
        Dn -> LED.A, LED.K -> GND      : active-high
        5V -> LED.A, LED.K -> Dn       : active-low
   3. Add a compact Digital Pin Monitor so pin tests using only code
      changes can be verified immediately without rewiring components.
   ============================================================ */
(function(){
  'use strict';

  const DIGITAL_PINS = Array.from({length:14}, (_,i)=>i);

  function ensurePinValuesArray(){
    if(!window.pinValues) window.pinValues = [];
    DIGITAL_PINS.forEach(p=>{ if(window.pinValues[p] === undefined) window.pinValues[p] = LOW; });
  }

  function stateForPin(pin){
    const st = window.VectorUnoBoardState || {};
    return st['D' + pin] || null;
  }

  function levelForPin(pin){
    const st = stateForPin(pin);
    if(st && typeof st.value !== 'undefined') return st.value ? HIGH : LOW;
    ensurePinValuesArray();
    return window.pinValues[pin] ? HIGH : LOW;
  }

  function connectedNodesRevA(partId,pinName){
    const target = partId + '.' + pinName;
    const out = [];
    ((window.project && project.wires) || []).forEach(w=>{
      if(w.from === target) out.push(w.to);
      if(w.to === target) out.push(w.from);
    });
    return out;
  }

  function digitalPinFromNodeRevA(n){
    const m = String(n || '').match(/^uno\.D(\d+)$/i);
    if(!m) return null;
    const p = parseInt(m[1], 10);
    return (p >= 0 && p <= 13) ? p : null;
  }

  function isGroundNodeRevA(n){
    return n === 'uno.GND' || n === 'uno.GND2' || n === 'uno.GND_TOP';
  }

  function isVccNodeRevA(n){
    return n === 'uno.5V' || n === 'uno.3V3' || n === 'uno.IOREF';
  }

  function nodeHighRevA(n){
    const p = digitalPinFromNodeRevA(n);
    return p !== null && levelForPin(p) === HIGH;
  }

  function nodeLowRevA(n){
    const p = digitalPinFromNodeRevA(n);
    return p !== null && levelForPin(p) === LOW;
  }

  function syncPinValuesFromAvrBoardState(){
    ensurePinValuesArray();
    const st = window.VectorUnoBoardState || {};
    DIGITAL_PINS.forEach(pin=>{
      const s = st['D' + pin];
      if(s && typeof s.value !== 'undefined') window.pinValues[pin] = s.value ? HIGH : LOW;
    });
  }

  function updateAllExternalDigitalOutputsRevA(){
    if(!window.project || !Array.isArray(project.parts)) return;
    syncPinValuesFromAvrBoardState();

    project.parts.forEach(part=>{
      if(part.type === 'led'){
        const a = connectedNodesRevA(part.id, 'A');
        const k = connectedNodesRevA(part.id, 'K');
        const activeHigh = a.some(nodeHighRevA) && k.some(isGroundNodeRevA);
        const activeLow  = a.some(isVccNodeRevA) && k.some(nodeLowRevA);
        part.state = (activeHigh || activeLow) ? HIGH : LOW;
      }
      else if(part.type === 'buzzer' || part.type === 'relay'){
        const sigPin = part.type === 'buzzer' ? 'SIG' : 'IN';
        const nodes = connectedNodesRevA(part.id, sigPin);
        part.state = nodes.some(nodeHighRevA) ? HIGH : LOW;
      }
    });

    updateDigitalPinMonitorRevA();
    if(typeof scheduleRuntimeRender === 'function') scheduleRuntimeRender();
    else if(typeof render === 'function') render();
  }

  function ensureDigitalPinMonitorRevA(){
    return null;
    const scene = document.getElementById('scene');
    if(!scene) return null;
    let panel = document.getElementById('digitalPinMonitorRevA');
    if(panel) return panel;

    panel = document.createElement('div');
    panel.id = 'digitalPinMonitorRevA';
    panel.style.cssText = [
      'position:absolute',
      'right:14px',
      'top:14px',
      'z-index:60',
      'background:rgba(15,23,42,0.88)',
      'border:1px solid rgba(148,163,184,0.45)',
      'border-radius:10px',
      'padding:8px 10px',
      'font:11px Arial, sans-serif',
      'color:#e5e7eb',
      'box-shadow:0 8px 24px rgba(0,0,0,0.28)',
      'pointer-events:none'
    ].join(';');

    panel.innerHTML = '<div style="font-weight:700;margin-bottom:6px;color:#facc15">Digital Pins</div>' +
      '<div id="digitalPinMonitorGridRevA" style="display:grid;grid-template-columns:repeat(7,34px);gap:5px"></div>';
    scene.appendChild(panel);

    const grid = panel.querySelector('#digitalPinMonitorGridRevA');
    DIGITAL_PINS.forEach(pin=>{
      const cell = document.createElement('div');
      cell.id = 'dpmon_D' + pin;
      cell.style.cssText = 'height:24px;border-radius:5px;background:#1f2937;border:1px solid #374151;display:flex;align-items:center;justify-content:center;gap:3px;color:#94a3b8';
      cell.innerHTML = '<span style="font-weight:700">D' + pin + '</span>';
      grid.appendChild(cell);
    });
    return panel;
  }

  function updateDigitalPinMonitorRevA(){
    if(!document.getElementById('digitalPinMonitorRevA')) return;
    DIGITAL_PINS.forEach(pin=>{
      const cell = document.getElementById('dpmon_D' + pin);
      if(!cell) return;
      const st = stateForPin(pin);
      const on = levelForPin(pin) === HIGH;
      const mode = st && st.mode ? st.mode : '';
      if(on){
        cell.style.background = '#92400e';
        cell.style.borderColor = '#facc15';
        cell.style.color = '#fff7cc';
        cell.style.boxShadow = '0 0 8px rgba(250,204,21,0.55)';
      }else{
        cell.style.background = '#1f2937';
        cell.style.borderColor = '#374151';
        cell.style.color = '#94a3b8';
        cell.style.boxShadow = 'none';
      }
      cell.title = 'D' + pin + ' = ' + (on ? 'HIGH' : 'LOW') + (mode ? ' / ' + mode : '');
    });
  }

  // Strong global hooks used by the AVR runtime whenever any UNO pin changes.
  const oldSetAvrDigitalPinValue = window.setAvrDigitalPinValue;
  window.setAvrDigitalPinValue = function(pin, value){
    ensurePinValuesArray();
    const p = Number(String(pin).replace(/^D/i,''));
    if(Number.isFinite(p) && p >= 0 && p <= 13){
      window.pinValues[p] = value ? HIGH : LOW;
    }
    if(typeof oldSetAvrDigitalPinValue === 'function'){
      try { oldSetAvrDigitalPinValue(pin, value); } catch(e) {}
    }
    updateAllExternalDigitalOutputsRevA();
  };

  const oldOnVectorUnoPinChange = window.onVectorUnoPinChange;
  window.onVectorUnoPinChange = function(name, state, source){
    const m = String(name || '').match(/^D(\d+)$/i);
    if(m){
      const pin = parseInt(m[1],10);
      if(pin >= 0 && pin <= 13){
        ensurePinValuesArray();
        window.pinValues[pin] = state && state.value ? HIGH : LOW;
      }
    }
    if(typeof oldOnVectorUnoPinChange === 'function'){
      try { oldOnVectorUnoPinChange(name, state, source); } catch(e) {}
    }
    updateAllExternalDigitalOutputsRevA();
  };

  // Replace the generic external LED updater with the Revision A implementation.
  window.updateExternalLedFromDigitalPin = function(pin, value){
    ensurePinValuesArray();
    const p = Number(String(pin).replace(/^D/i,''));
    if(Number.isFinite(p) && p >= 0 && p <= 13){
      window.pinValues[p] = value ? HIGH : LOW;
    }
    updateAllExternalDigitalOutputsRevA();
  };

  // Also override the source-level fallback digitalWrite used when AVR mode is disabled.
  if(typeof window.digitalWrite === 'function' || typeof digitalWrite === 'function'){
    window.digitalWrite = digitalWrite = function(pin, val){
      ensurePinValuesArray();
      const p = Number(pin);
      if(Number.isFinite(p) && p >= 0 && p <= 13){
        window.pinValues[p] = val ? HIGH : LOW;
      }
      updateAllExternalDigitalOutputsRevA();
    };
  }

  // Periodic refresh catches any edge that does not trigger an AVRIOPort listener.
  if(!window.__vectorPhase43RevARefreshTimer){
    window.__vectorPhase43RevARefreshTimer = setInterval(function(){
      if(window.VectorUnoBoardState){
        syncPinValuesFromAvrBoardState();
        updateAllExternalDigitalOutputsRevA();
      }else{
        updateDigitalPinMonitorRevA();
      }
    }, 80);
  }

  // Keep monitor visible after render/newProject.
  const oldRenderRevA = window.render || (typeof render === 'function' ? render : null);
  if(oldRenderRevA && !window.__vectorPhase43RevARenderWrapped){
    window.__vectorPhase43RevARenderWrapped = true;
    window.render = render = function(){
      const r = oldRenderRevA.apply(this, arguments);
      setTimeout(function(){ ensureDigitalPinMonitorRevA(); updateDigitalPinMonitorRevA(); }, 0);
      return r;
    };
  }

  setTimeout(function(){
    ensurePinValuesArray();
    ensureDigitalPinMonitorRevA();
    updateAllExternalDigitalOutputsRevA();
    if(typeof log === 'function') log('Phase 4.3 Revision A loaded: generic D0-D13 AVR GPIO engine and pin monitor active.');
  }, 100);
})();


/* ============================================================
   AVR PHASE 4.3 REVISION B - Generic Component Manager
   ------------------------------------------------------------
   Fixes / adds:
   1. External LED widgets are no longer D13-special-case driven.
      Any LED wired as Dn -> A, K -> GND works for D0-D13.
      Any LED wired as 5V -> A, K -> Dn works as active-low for D0-D13.
   2. Component visuals are updated directly from the generic pin-state
      table, so the Digital Pin Monitor and external components agree.
   3. TX/RX board LED activity uses one common activity renderer. RX now
      has the same dark-yellow brightness/glow as TX.
   ============================================================ */
(function(){
  'use strict';

  const DIGITAL_PINS = Array.from({ length: 14 }, (_, i) => i);
  const GND_NODES = new Set(['uno.GND', 'uno.GND2', 'uno.GND_TOP']);
  const VCC_NODES = new Set(['uno.5V', 'uno.3V3', 'uno.IOREF']);
  const lastPinValue = {};

  function asBool(v){ return !!v; }

  function getDigitalPinFromNode(node){
    const m = String(node || '').match(/^uno\.D(\d+)$/i);
    if(!m) return null;
    const p = parseInt(m[1], 10);
    return (p >= 0 && p <= 13) ? p : null;
  }

  function getConnections(partId, pinName){
    const target = partId + '.' + pinName;
    const out = [];
    ((window.project && project.wires) || []).forEach(w => {
      if(w.from === target) out.push(w.to);
      if(w.to === target) out.push(w.from);
    });
    return out;
  }

  function readPinLevel(pin){
    const board = window.VectorUnoBoardState || {};
    const st = board['D' + pin];
    if(st && typeof st.value !== 'undefined') return st.value ? HIGH : LOW;
    if(window.pinValues && typeof window.pinValues[pin] !== 'undefined') return window.pinValues[pin] ? HIGH : LOW;
    return LOW;
  }

  function readNodeHigh(node){
    const p = getDigitalPinFromNode(node);
    return p !== null && readPinLevel(p) === HIGH;
  }

  function readNodeLow(node){
    const p = getDigitalPinFromNode(node);
    return p !== null && readPinLevel(p) === LOW;
  }

  function nodeIsGnd(node){ return GND_NODES.has(node); }
  function nodeIsVcc(node){ return VCC_NODES.has(node); }

  function setPinCache(pin, value){
    if(!window.pinValues) window.pinValues = [];
    if(pin >= 0 && pin <= 13) window.pinValues[pin] = value ? HIGH : LOW;
  }

  function syncPinCacheFromBoard(){
    const board = window.VectorUnoBoardState || {};
    DIGITAL_PINS.forEach(pin => {
      const st = board['D' + pin];
      if(st && typeof st.value !== 'undefined') setPinCache(pin, st.value);
    });
  }

  function ledOnFromWiring(part){
    const anode = getConnections(part.id, 'A');
    const cathode = getConnections(part.id, 'K');

    // Normal LED wiring: Arduino output pin sources current into LED anode.
    const activeHigh = anode.some(readNodeHigh) && cathode.some(nodeIsGnd);

    // Active-low wiring: LED anode tied to VCC, Arduino pin sinks current from cathode.
    const activeLow = anode.some(nodeIsVcc) && cathode.some(readNodeLow);

    return activeHigh || activeLow;
  }

  function outputStateFromOneSignalPin(part, signalPinName){
    const nodes = getConnections(part.id, signalPinName);
    return nodes.some(readNodeHigh) ? HIGH : LOW;
  }

  function applyVisualToPart(part){
    const el = document.getElementById(part.id);
    if(!el) return;

    if(part.type === 'led'){
      const bulb = el.querySelector('.ledBulb');
      if(bulb) bulb.classList.toggle('on', !!part.state);
    }
    else if(part.type === 'button'){
      const b = el.querySelector('.buttonCircle');
      if(b) b.classList.toggle('pressed', !!part.state);
    }
    else if(part.type === 'buzzer' || part.type === 'relay'){
      el.classList.toggle('active', !!part.state);
      el.classList.toggle('on', !!part.state);
    }
  }

  function updateComponents(){
    if(!window.project || !Array.isArray(project.parts)) return;
    syncPinCacheFromBoard();

    project.parts.forEach(part => {
      if(part.type === 'led'){
        part.state = ledOnFromWiring(part) ? HIGH : LOW;
      }
      else if(part.type === 'buzzer'){
        part.state = outputStateFromOneSignalPin(part, 'SIG');
      }
      else if(part.type === 'relay'){
        part.state = outputStateFromOneSignalPin(part, 'IN');
      }
      applyVisualToPart(part);
    });

    if(typeof window.updateDigitalPinMonitorRevB === 'function') window.updateDigitalPinMonitorRevB();
  }

  function updateExternalInputs(){
    const inputs = {};
    if(!window.project || !Array.isArray(project.parts)) return inputs;

    project.parts.forEach(part => {
      if(part.type !== 'button') return;
      const sigNodes = getConnections(part.id, 'S');
      const gNodes = getConnections(part.id, 'G');
      const pins = sigNodes.map(getDigitalPinFromNode).filter(v => v !== null);
      if(!pins.length || !part.state) return; // released button = open circuit

      let drive;
      if(gNodes.some(nodeIsGnd)) drive = 0;
      else if(gNodes.some(nodeIsVcc)) drive = 1;
      else drive = 1;

      pins.forEach(pin => {
        inputs['D' + pin] = { active:true, value:drive, source:part.id, kind:'button' };
      });
    });

    return inputs;
  }

  function ensureRevBMonitor(){
    // Reuse Revision-A monitor if present, but update its titles with component info.
    if(typeof window.updateDigitalPinMonitorRevA === 'function') return;
  }

  function attachedComponentNames(pin){
    if(!window.project || !Array.isArray(project.parts)) return '';
    const names = [];
    project.parts.forEach(part => {
      if(part.type === 'led'){
        const a = getConnections(part.id, 'A');
        const k = getConnections(part.id, 'K');
        if(a.concat(k).some(n => getDigitalPinFromNode(n) === pin)) names.push(part.id);
      }
      if(part.type === 'button'){
        const s = getConnections(part.id, 'S');
        if(s.some(n => getDigitalPinFromNode(n) === pin)) names.push(part.id);
      }
    });
    return names.join(', ');
  }

  window.updateDigitalPinMonitorRevB = function(){
    DIGITAL_PINS.forEach(pin => {
      const cell = document.getElementById('dpmon_D' + pin);
      if(!cell) return;
      const on = readPinLevel(pin) === HIGH;
      const attached = attachedComponentNames(pin);
      if(attached) cell.title = 'D' + pin + ' = ' + (on ? 'HIGH' : 'LOW') + ' / attached: ' + attached;
    });
  };

  // Replace the external input provider with the generic component-manager version.
  window.getVectorUnoExternalDigitalInputs = updateExternalInputs;

  // Strong bridge from AVR pin state to component visuals.
  const oldSetAvr = window.setAvrDigitalPinValue;
  window.setAvrDigitalPinValue = function(pin, value){
    const p = Number(String(pin).replace(/^D/i, ''));
    if(Number.isFinite(p) && p >= 0 && p <= 13) setPinCache(p, value);
    if(typeof oldSetAvr === 'function'){
      try { oldSetAvr(pin, value); } catch(e) {}
    }
    updateComponents();
  };

  const oldPinChange = window.onVectorUnoPinChange;
  window.onVectorUnoPinChange = function(name, state, source){
    const m = String(name || '').match(/^D(\d+)$/i);
    if(m){
      const pin = parseInt(m[1], 10);
      const value = state && state.value ? HIGH : LOW;
      setPinCache(pin, value);

      // D0/D1 are also the UNO RX/TX physical lines. Show logic transitions as
      // activity pulses using the same renderer for equal brightness.
      if(pin === 0 && lastPinValue[pin] !== value && typeof window.pulseUnoBoardLed === 'function'){
        window.pulseUnoBoardLed('RX', 95);
      }
      if(pin === 1 && lastPinValue[pin] !== value && typeof window.pulseUnoBoardLed === 'function'){
        window.pulseUnoBoardLed('TX', 95);
      }
      lastPinValue[pin] = value;
    }

    if(typeof oldPinChange === 'function'){
      try { oldPinChange(name, state, source); } catch(e) {}
    }
    updateComponents();
  };

  // Generic direct LED updater for any digital pin, used by old and new runtime paths.
  window.updateExternalLedFromDigitalPin = function(pin, value){
    const p = Number(String(pin).replace(/^D/i, ''));
    if(Number.isFinite(p) && p >= 0 && p <= 13) setPinCache(p, value);
    updateComponents();
  };

  // Source-level fallback remains generic too.
  window.digitalWrite = digitalWrite = function(pin, val){
    const p = Number(pin);
    if(Number.isFinite(p) && p >= 0 && p <= 13) setPinCache(p, val);
    updateComponents();
  };

  // Button press/release should update input provider and component visuals immediately.
  const oldNotify = window.notifyVectorUnoExternalInputsChanged;
  window.notifyVectorUnoExternalInputsChanged = function(){
    if(typeof oldNotify === 'function'){
      try { oldNotify(); } catch(e) {}
    }
    if(window.avrPhase2Runtime && typeof window.avrPhase2Runtime.applyExternalDigitalInputs === 'function'){
      try { window.avrPhase2Runtime.applyExternalDigitalInputs(); } catch(e) {}
    }
    updateComponents();
  };

  // Make TX/RX pulses use the same duration and brightness. This overrides only
  // the activity behavior; the existing square overlay coordinates/colors remain.
  const activityTimers = {};
  const oldPulse = window.pulseUnoBoardLed;
  window.pulseUnoBoardLed = function(name, durationMs){
    if(name === 'TX' || name === 'RX') durationMs = durationMs || 95;
    if(typeof window.setUnoBoardLed === 'function'){
      window.setUnoBoardLed(name, true);
      if(activityTimers[name]) clearTimeout(activityTimers[name]);
      activityTimers[name] = setTimeout(function(){
        window.setUnoBoardLed(name, false);
        activityTimers[name] = null;
      }, durationMs || 95);
    }else if(typeof oldPulse === 'function'){
      oldPulse(name, durationMs || 95);
    }
  };

  // After every render, immediately re-apply component state so LED widgets do
  // not wait for the next AVR edge.
  const oldRenderB = window.render || (typeof render === 'function' ? render : null);
  if(oldRenderB && !window.__vectorPhase43BRenderWrapped){
    window.__vectorPhase43BRenderWrapped = true;
    window.render = render = function(){
      const r = oldRenderB.apply(this, arguments);
      setTimeout(updateComponents, 0);
      return r;
    };
  }

  if(!window.__vectorPhase43BRefreshTimer){
    window.__vectorPhase43BRefreshTimer = setInterval(updateComponents, 40);
  }

  window.VectorComponentManager = {
    update: updateComponents,
    getExternalDigitalInputs: updateExternalInputs,
    readPinLevel,
    getConnections
  };

  setTimeout(function(){
    updateComponents();
    if(typeof log === 'function') log('Phase 4.3B loaded: generic component manager active. External LEDs work on D0-D13; TX/RX activity renderer unified.');
  }, 150);
})();

/* ============================================================
   AVR PHASE 4.3C PATCH - External LED Visual Bridge Fix
   ------------------------------------------------------------
   Field issue fixed:
   - Digital Pins monitor and onboard L LED were updating correctly,
     but the external LED widget did not blink, even when wired to D13.

   Cause isolated to component visual refresh path. This patch creates a
   stronger generic LED renderer that directly reads the canonical AVR/UNO
   pin state table and applies the visual state to LED widgets after every
   render and during runtime.
   ============================================================ */
(function(){
  'use strict';

  const HIGH_VALUE = (typeof HIGH !== 'undefined') ? HIGH : 1;
  const LOW_VALUE  = (typeof LOW  !== 'undefined') ? LOW  : 0;
  const GND_NODES = new Set(['uno.GND', 'uno.GND2', 'uno.GND_TOP', 'GND']);
  const VCC_NODES = new Set(['uno.5V', 'uno.3V3', 'uno.IOREF', '5V', 'VCC']);

  function connections(partId, pinName){
    const target = partId + '.' + pinName;
    const out = [];
    const wires = (window.project && Array.isArray(project.wires)) ? project.wires : [];
    wires.forEach(w => {
      if(w.from === target) out.push(w.to);
      if(w.to === target) out.push(w.from);
    });
    return out;
  }

  function digitalPinFromNode(node){
    const m = String(node || '').match(/^(?:uno\.)?D(\d+)$/i);
    if(!m) return null;
    const p = parseInt(m[1], 10);
    return (p >= 0 && p <= 13) ? p : null;
  }

  function readDigitalPin(pin){
    const name = 'D' + pin;
    const st = window.VectorUnoBoardState && window.VectorUnoBoardState[name];
    if(st && typeof st.value !== 'undefined') return st.value ? HIGH_VALUE : LOW_VALUE;
    if(window.pinValues && typeof window.pinValues[pin] !== 'undefined') return window.pinValues[pin] ? HIGH_VALUE : LOW_VALUE;
    return LOW_VALUE;
  }

  function nodeHigh(node){
    const p = digitalPinFromNode(node);
    return p !== null && readDigitalPin(p) === HIGH_VALUE;
  }

  function nodeLow(node){
    const p = digitalPinFromNode(node);
    return p !== null && readDigitalPin(p) === LOW_VALUE;
  }

  function ledShouldBeOn(part){
    const a = connections(part.id, 'A');
    const k = connections(part.id, 'K');

    // Active-high: Dn -> LED.A, LED.K -> GND
    const activeHigh = a.some(nodeHigh) && k.some(n => GND_NODES.has(String(n)));

    // Active-low: 5V -> LED.A, LED.K -> Dn
    const activeLow = a.some(n => VCC_NODES.has(String(n))) && k.some(nodeLow);

    return activeHigh || activeLow;
  }

  function applyLedVisual(part, on){
    part.state = on ? HIGH_VALUE : LOW_VALUE;
    const el = document.getElementById(part.id);
    if(!el) return;
    const bulb = el.querySelector('.ledBulb');
    if(!bulb) return;

    bulb.classList.toggle('on', !!on);
    bulb.style.background = on ? 'red' : '#700';
    bulb.style.boxShadow = on ? '0 0 35px red' : 'none';
    bulb.style.opacity = '1';
    el.classList.toggle('on', !!on);
  }

  function refreshExternalLedWidgets43C(){
    if(!window.project || !Array.isArray(project.parts)) return;
    project.parts.forEach(part => {
      if(part.type !== 'led') return;
      applyLedVisual(part, ledShouldBeOn(part));
    });
  }

  // Expose for manual console check: VectorExternalLedBridge43C.refresh()
  window.VectorExternalLedBridge43C = {
    refresh: refreshExternalLedWidgets43C,
    readDigitalPin,
    ledShouldBeOn
  };

  // Strong hook used by AVR runtime and older bridge paths.
  const previousUpdateExternalLedFromDigitalPin = window.updateExternalLedFromDigitalPin;
  window.updateExternalLedFromDigitalPin = function(pin, value){
    const p = Number(String(pin).replace(/^D/i, ''));
    if(Number.isFinite(p) && p >= 0 && p <= 13){
      if(!window.pinValues) window.pinValues = [];
      window.pinValues[p] = value ? HIGH_VALUE : LOW_VALUE;
    }
    if(typeof previousUpdateExternalLedFromDigitalPin === 'function'){
      try { previousUpdateExternalLedFromDigitalPin(pin, value); } catch(e) {}
    }
    refreshExternalLedWidgets43C();
  };

  // Keep source-level fallback generic too.
  const previousDigitalWrite = (typeof window.digitalWrite === 'function') ? window.digitalWrite : (typeof digitalWrite === 'function' ? digitalWrite : null);
  if(previousDigitalWrite){
    window.digitalWrite = digitalWrite = function(pin, val){
      const p = Number(pin);
      if(Number.isFinite(p) && p >= 0 && p <= 13){
        if(!window.pinValues) window.pinValues = [];
        window.pinValues[p] = val ? HIGH_VALUE : LOW_VALUE;
      }
      try { previousDigitalWrite(pin, val); } catch(e) {}
      refreshExternalLedWidgets43C();
    };
  }

  // After render(), the DOM is recreated, so re-apply the external LED state.
  const previousRender43C = window.render || (typeof render === 'function' ? render : null);
  if(previousRender43C && !window.__vectorPhase43CRenderWrapped){
    window.__vectorPhase43CRenderWrapped = true;
    window.render = render = function(){
      const r = previousRender43C.apply(this, arguments);
      setTimeout(refreshExternalLedWidgets43C, 0);
      return r;
    };
  }

  // Runtime safety refresh. This is intentionally lightweight: it only touches
  // LED widgets and does not redraw wires/canvas.
  if(!window.__vectorPhase43CExternalLedTimer){
    window.__vectorPhase43CExternalLedTimer = setInterval(refreshExternalLedWidgets43C, 25);
  }

  setTimeout(function(){
    refreshExternalLedWidgets43C();
    if(typeof log === 'function') log('Phase 4.3C loaded: external LED visual bridge fixed for D0-D13, including D13/PB5.');
  }, 200);
})();

/* ============================================================
   AVR PHASE 4.3R - Refactoring Release / Single Component Path
   ------------------------------------------------------------
   Purpose:
   - Disable older Phase 4.3/A/B/C LED refresh timers that fought each other.
   - Establish one canonical board-state reader for D0-D13.
   - Establish one canonical component renderer for external LEDs.
   - Preserve existing AVR HEX runtime, board LED overlays, serial monitor,
     TX/RX activity, digital monitor, and button input behavior.
   ============================================================ */
(function(){
  'use strict';

  const HIGH_VALUE = (typeof HIGH !== 'undefined') ? HIGH : 1;
  const LOW_VALUE  = (typeof LOW  !== 'undefined') ? LOW  : 0;
  const DIGITAL_PINS = Array.from({length: 14}, (_, i) => i);
  const GND_NODES = new Set(['uno.GND', 'uno.GND2', 'uno.GND_TOP', 'GND', 'gnd']);
  const VCC_NODES = new Set(['uno.5V', 'uno.3V3', 'uno.IOREF', '5V', 'VCC', 'vcc']);

  // Stop old patch-layer timers. Phase 4.3R uses one refresh loop only.
  try { if(window.__vectorPhase43BRefreshTimer) clearInterval(window.__vectorPhase43BRefreshTimer); } catch(e) {}
  try { if(window.__vectorPhase43CExternalLedTimer) clearInterval(window.__vectorPhase43CExternalLedTimer); } catch(e) {}
  window.__vectorPhase43BRefreshTimer = null;
  window.__vectorPhase43CExternalLedTimer = null;

  function ensurePinCache(){
    if(!Array.isArray(window.pinValues)) window.pinValues = [];
    DIGITAL_PINS.forEach(pin => {
      if(typeof window.pinValues[pin] === 'undefined') window.pinValues[pin] = LOW_VALUE;
    });
  }

  function boardEntry(pin){
    return window.VectorUnoBoardState && window.VectorUnoBoardState['D' + pin];
  }

  function readPin(pin){
    ensurePinCache();
    const entry = boardEntry(pin);
    if(entry && typeof entry.value !== 'undefined') {
      window.pinValues[pin] = entry.value ? HIGH_VALUE : LOW_VALUE;
      return window.pinValues[pin];
    }
    return window.pinValues[pin] ? HIGH_VALUE : LOW_VALUE;
  }

  function writePinCache(pin, value){
    ensurePinCache();
    if(pin >= 0 && pin <= 13) window.pinValues[pin] = value ? HIGH_VALUE : LOW_VALUE;
  }

  function allWires(){
    return (window.project && Array.isArray(project.wires)) ? project.wires : [];
  }

  function connectedNodes(nodeName){
    const out = [];
    allWires().forEach(w => {
      if(w.from === nodeName) out.push(w.to);
      if(w.to === nodeName) out.push(w.from);
    });
    return out;
  }

  function digitalPinFromNode(node){
    const m = String(node || '').match(/^(?:uno\.)?D(\d+)$/i);
    if(!m) return null;
    const pin = parseInt(m[1], 10);
    return (pin >= 0 && pin <= 13) ? pin : null;
  }

  function isGround(node){ return GND_NODES.has(String(node)); }
  function isVcc(node){ return VCC_NODES.has(String(node)); }
  function nodeIsHigh(node){ const p = digitalPinFromNode(node); return p !== null && readPin(p) === HIGH_VALUE; }
  function nodeIsLow(node){ const p = digitalPinFromNode(node); return p !== null && readPin(p) === LOW_VALUE; }

  function ledState(part){
    const aNodes = connectedNodes(part.id + '.A');
    const kNodes = connectedNodes(part.id + '.K');

    // Correct physical/common cases:
    //   Dn -> A, K -> GND : active high
    //   5V -> A, K -> Dn : active low
    if(aNodes.some(nodeIsHigh) && kNodes.some(isGround)) return true;
    if(aNodes.some(isVcc) && kNodes.some(nodeIsLow)) return true;

    // Teaching-simulator tolerant fallback:
    // If user connected only one LED terminal to a digital pin, still show the
    // output state so pin testing is visible without perfect wiring.
    const aPin = aNodes.map(digitalPinFromNode).find(p => p !== null);
    if(aPin !== undefined && aPin !== null) return readPin(aPin) === HIGH_VALUE;
    const kPin = kNodes.map(digitalPinFromNode).find(p => p !== null);
    if(kPin !== undefined && kPin !== null) return readPin(kPin) === LOW_VALUE;

    return false;
  }

  function applyLedVisual(part, on){
    part.state = on ? HIGH_VALUE : LOW_VALUE;
    const el = document.getElementById(part.id);
    if(!el) return;
    const bulb = el.querySelector('.ledBulb');
    if(!bulb) return;
    bulb.classList.toggle('on', !!on);
    bulb.style.background = on ? 'red' : '#700';
    bulb.style.boxShadow = on ? '0 0 35px red, 0 0 10px rgba(255,0,0,0.9)' : 'none';
    bulb.style.opacity = '1';
    el.classList.toggle('on', !!on);
  }

  function ensureDigitalMonitor(){
    return null;
    const scene = document.getElementById('scene');
    if(!scene) return null;
    let panel = document.getElementById('digitalPinMonitorRevA');
    if(panel) return panel;
    panel = document.createElement('div');
    panel.id = 'digitalPinMonitorRevA';
    panel.style.cssText = 'position:absolute;right:14px;top:14px;z-index:60;background:rgba(15,23,42,.88);border:1px solid rgba(148,163,184,.45);border-radius:10px;padding:8px 10px;font:11px Arial,sans-serif;color:#e5e7eb;box-shadow:0 8px 24px rgba(0,0,0,.28);pointer-events:none';
    panel.innerHTML = '<div style="font-weight:700;margin-bottom:6px;color:#facc15">Digital Pins</div><div id="digitalPinMonitorGridRevA" style="display:grid;grid-template-columns:repeat(7,34px);gap:5px"></div>';
    scene.appendChild(panel);
    const grid = panel.querySelector('#digitalPinMonitorGridRevA');
    DIGITAL_PINS.forEach(pin => {
      const cell = document.createElement('div');
      cell.id = 'dpmon_D' + pin;
      cell.style.cssText = 'height:24px;border-radius:5px;background:#1f2937;border:1px solid #374151;display:flex;align-items:center;justify-content:center;gap:3px;color:#94a3b8';
      cell.innerHTML = '<span style="font-weight:700">D' + pin + '</span>';
      grid.appendChild(cell);
    });
    return panel;
  }

  function updateDigitalMonitor(){
    if(!document.getElementById('digitalPinMonitorRevA')) return;
    DIGITAL_PINS.forEach(pin => {
      const cell = document.getElementById('dpmon_D' + pin);
      if(!cell) return;
      const on = readPin(pin) === HIGH_VALUE;
      const entry = boardEntry(pin);
      const mode = entry && entry.mode ? entry.mode : '';
      cell.style.background = on ? '#92400e' : '#1f2937';
      cell.style.borderColor = on ? '#facc15' : '#374151';
      cell.style.color = on ? '#fff7cc' : '#94a3b8';
      cell.style.boxShadow = on ? '0 0 8px rgba(250,204,21,.55)' : 'none';
      cell.title = 'D' + pin + ' = ' + (on ? 'HIGH' : 'LOW') + (mode ? ' / ' + mode : '');
    });
  }

  function updateExternalOutputs(){
    if(!window.project || !Array.isArray(project.parts)) return;
    project.parts.forEach(part => {
      if(part.type === 'led') applyLedVisual(part, ledState(part));
      if(part.type === 'buzzer' || part.type === 'relay'){
        const sig = part.type === 'buzzer' ? 'SIG' : 'IN';
        const on = connectedNodes(part.id + '.' + sig).some(nodeIsHigh);
        part.state = on ? HIGH_VALUE : LOW_VALUE;
      }
    });
  }

  function getExternalInputs(){
    const inputs = {};
    if(!window.project || !Array.isArray(project.parts)) return inputs;
    project.parts.forEach(part => {
      if(part.type !== 'button') return;
      const sigNodes = connectedNodes(part.id + '.S');
      sigNodes.forEach(node => {
        const pin = digitalPinFromNode(node);
        if(pin === null) return;
        // Button pressed drives LOW when its G pin is connected to GND.
        // Released button is open circuit, so AVR pullup can work.
        const gndSide = connectedNodes(part.id + '.G').some(isGround);
        if(part.state && gndSide) inputs[pin] = LOW_VALUE;
        else if(part.state && !gndSide) inputs[pin] = HIGH_VALUE;
      });
    });
    return inputs;
  }

  function updateAll(){
    updateDigitalMonitor();
    updateExternalOutputs();
  }

  // Canonical hooks from AVR runtime / old compatibility layers.
  window.updateExternalLedFromDigitalPin = function(pin, value){
    const p = Number(String(pin).replace(/^D/i, ''));
    if(Number.isFinite(p)) writePinCache(p, value);
    updateAll();
  };

  window.setAvrDigitalPinValue = function(pin, value){
    const p = Number(String(pin).replace(/^D/i, ''));
    if(Number.isFinite(p)) writePinCache(p, value);
    updateAll();
  };

  window.onVectorUnoPinChange = function(name, state, source){
    const m = String(name || '').match(/^D(\d+)$/i);
    if(m){
      const p = parseInt(m[1], 10);
      writePinCache(p, state && state.value ? HIGH_VALUE : LOW_VALUE);
      if((p === 0 || p === 1) && typeof window.pulseUnoBoardLed === 'function'){
        window.pulseUnoBoardLed(p === 0 ? 'RX' : 'TX', 95);
      }
    }
    updateAll();
  };

  window.getVectorUnoExternalDigitalInputs = getExternalInputs;

  const oldNotify = window.notifyVectorUnoExternalInputsChanged;
  window.notifyVectorUnoExternalInputsChanged = function(){
    if(typeof oldNotify === 'function') { try { oldNotify(); } catch(e) {} }
    if(window.avrPhase2Runtime && typeof window.avrPhase2Runtime.applyExternalDigitalInputs === 'function'){
      try { window.avrPhase2Runtime.applyExternalDigitalInputs(); } catch(e) {}
    }
    updateAll();
  };

  // Preserve serial TX/RX brightness with one activity path.
  const ledTimers = {};
  const oldPulse = window.pulseUnoBoardLed;
  window.pulseUnoBoardLed = function(name, durationMs){
    const dur = (name === 'TX' || name === 'RX') ? (durationMs || 95) : (durationMs || 95);
    if(typeof window.setUnoBoardLed === 'function'){
      window.setUnoBoardLed(name, true);
      if(ledTimers[name]) clearTimeout(ledTimers[name]);
      ledTimers[name] = setTimeout(function(){
        if(name !== 'PWR') window.setUnoBoardLed(name, false);
        ledTimers[name] = null;
      }, dur);
    } else if(typeof oldPulse === 'function') {
      oldPulse(name, dur);
    }
  };

  // Re-apply output visuals after render() rebuilds DOM.
  const baseRender = window.render || (typeof render === 'function' ? render : null);
  if(baseRender && !window.__vectorPhase43RRenderWrapped){
    window.__vectorPhase43RRenderWrapped = true;
    window.render = render = function(){
      const ret = baseRender.apply(this, arguments);
      requestAnimationFrame(updateAll);
      return ret;
    };
  }

  if(!window.__vectorPhase43RRefreshTimer){
    window.__vectorPhase43RRefreshTimer = setInterval(updateAll, 25);
  }

  window.VectorPhase43R = {
    readPin,
    update: updateAll,
    ledState,
    getExternalInputs,
    connectedNodes
  };

  setTimeout(function(){
    updateAll();
    if(typeof log === 'function') log('Phase 4.3R loaded: single component manager active; external LEDs use the same D0-D13 state as the digital monitor.');
  }, 250);
})();

/* ============================================================
   AVR PHASE 4.3R1 - External LED Binding Hard Fix
   ------------------------------------------------------------
   Field fix:
   - AVR Digital Monitor was toggling correctly for D0-D13.
   - Onboard L LED was toggling correctly for D13/PB5.
   - External LED widget was not visually toggling.

   Strategy:
   - Use the same visible/canonical pin state used by the monitor.
   - Re-evaluate LED wiring continuously without calling render().
   - Apply LED bulb style directly with !important inline properties.
   - Support:
       Dn -> LED.A, LED.K -> GND       active-high
       5V -> LED.A, LED.K -> Dn        active-low
       Dn -> either LED terminal        pin-test fallback
   ============================================================ */
(function(){
  'use strict';

  const HIGH_VALUE = (typeof HIGH !== 'undefined') ? HIGH : 1;
  const LOW_VALUE  = (typeof LOW  !== 'undefined') ? LOW  : 0;
  const DIGITAL_PINS = Array.from({length:14}, (_, i) => i);
  const GND_NODES = new Set(['uno.GND', 'uno.GND2', 'uno.GND_TOP', 'GND', 'gnd']);
  const VCC_NODES = new Set(['uno.5V', 'uno.3V3', 'uno.IOREF', '5V', 'VCC', 'vcc']);

  function parsePinFromNode(node){
    const m = String(node || '').match(/^(?:uno\.)?D(\d+)$/i);
    if(!m) return null;
    const pin = parseInt(m[1], 10);
    return (pin >= 0 && pin <= 13) ? pin : null;
  }

  function allWires(){
    return (window.project && Array.isArray(project.wires)) ? project.wires : [];
  }

  function nodesConnectedTo(nodeName){
    const out = [];
    allWires().forEach(w => {
      if(w.from === nodeName) out.push(w.to);
      if(w.to === nodeName) out.push(w.from);
    });
    return out;
  }

  function monitorLevel(pin){
    const cell = document.getElementById('dpmon_D' + pin);
    if(!cell) return null;
    const t = String(cell.title || '').toUpperCase();
    if(t.includes('HIGH')) return HIGH_VALUE;
    if(t.includes('LOW')) return LOW_VALUE;
    return null;
  }

  function readDigitalLevel(pin){
    const name = 'D' + pin;

    // 1. Canonical AVR/UNO board state from avr-runtime-phase2.js.
    const st = window.VectorUnoBoardState && window.VectorUnoBoardState[name];
    if(st && typeof st.value !== 'undefined') return st.value ? HIGH_VALUE : LOW_VALUE;

    // 2. Compatibility pin cache used by earlier simulator layers.
    if(window.pinValues && typeof window.pinValues[pin] !== 'undefined') {
      return window.pinValues[pin] ? HIGH_VALUE : LOW_VALUE;
    }

    // 3. Last-resort: use the digital monitor itself. This guarantees the
    // external LED follows the exact same displayed state during testing.
    const m = monitorLevel(pin);
    if(m !== null) return m;

    return LOW_VALUE;
  }

  function isGround(node){ return GND_NODES.has(String(node)); }
  function isVcc(node){ return VCC_NODES.has(String(node)); }
  function nodeHigh(node){ const p = parsePinFromNode(node); return p !== null && readDigitalLevel(p) === HIGH_VALUE; }
  function nodeLow(node){ const p = parsePinFromNode(node); return p !== null && readDigitalLevel(p) === LOW_VALUE; }

  function getLedWiring(part){
    return {
      anode: nodesConnectedTo(part.id + '.A'),
      cathode: nodesConnectedTo(part.id + '.K')
    };
  }

  function ledOn(part){
    const w = getLedWiring(part);

    // Normal classroom wiring: Dn -> anode, cathode -> GND.
    if(w.anode.some(nodeHigh) && w.cathode.some(isGround)) return true;

    // Active-low wiring: VCC -> anode, cathode -> Dn.
    if(w.anode.some(isVcc) && w.cathode.some(nodeLow)) return true;

    // Pin-test fallback: if either terminal is connected to a digital pin,
    // show the pin state. This helps when testing D0-D13 one by one.
    const anodePin = w.anode.map(parsePinFromNode).find(p => p !== null);
    if(anodePin !== undefined && anodePin !== null) return readDigitalLevel(anodePin) === HIGH_VALUE;

    const cathodePin = w.cathode.map(parsePinFromNode).find(p => p !== null);
    if(cathodePin !== undefined && cathodePin !== null) return readDigitalLevel(cathodePin) === LOW_VALUE;

    return false;
  }

  function applyLed(part, on){
    part.state = on ? HIGH_VALUE : LOW_VALUE;
    const el = document.getElementById(part.id);
    if(!el) return;

    const bulb = el.querySelector('.ledBulb');
    if(!bulb) return;

    bulb.classList.toggle('on', !!on);
    el.classList.toggle('on', !!on);
    el.setAttribute('data-vector-led-state', on ? 'HIGH' : 'LOW');

    if(on){
      bulb.style.setProperty('background', '#ff2020', 'important');
      bulb.style.setProperty('box-shadow', '0 0 35px #ff2020, 0 0 14px rgba(255,32,32,0.95)', 'important');
      bulb.style.setProperty('opacity', '1', 'important');
      bulb.style.setProperty('filter', 'brightness(1.45)', 'important');
    }else{
      bulb.style.setProperty('background', '#700', 'important');
      bulb.style.setProperty('box-shadow', 'none', 'important');
      bulb.style.setProperty('opacity', '1', 'important');
      bulb.style.setProperty('filter', 'brightness(1)', 'important');
    }
  }

  function refreshExternalLeds(){
    if(!window.project || !Array.isArray(project.parts)) return;
    project.parts.forEach(part => {
      if(part.type !== 'led') return;
      applyLed(part, ledOn(part));
    });
  }

  // Public debug helper for browser console testing.
  window.VectorExternalLedFixR1 = {
    refresh: refreshExternalLeds,
    readDigitalLevel,
    ledOn,
    getLedWiring
  };

  // Compatibility hooks: every known AVR/runtime notification path now forces
  // an immediate LED refresh.
  const prevSet = window.setAvrDigitalPinValue;
  window.setAvrDigitalPinValue = function(pin, value){
    if(typeof prevSet === 'function') { try { prevSet(pin, value); } catch(e) {} }
    const p = Number(String(pin).replace(/^D/i, ''));
    if(Number.isFinite(p) && p >= 0 && p <= 13){
      if(!Array.isArray(window.pinValues)) window.pinValues = [];
      window.pinValues[p] = value ? HIGH_VALUE : LOW_VALUE;
    }
    refreshExternalLeds();
  };

  const prevPinChange = window.onVectorUnoPinChange;
  window.onVectorUnoPinChange = function(name, state, source){
    if(typeof prevPinChange === 'function') { try { prevPinChange(name, state, source); } catch(e) {} }
    refreshExternalLeds();
  };

  const prevUpdate = window.updateExternalLedFromDigitalPin;
  window.updateExternalLedFromDigitalPin = function(pin, value){
    if(typeof prevUpdate === 'function') { try { prevUpdate(pin, value); } catch(e) {} }
    const p = Number(String(pin).replace(/^D/i, ''));
    if(Number.isFinite(p) && p >= 0 && p <= 13){
      if(!Array.isArray(window.pinValues)) window.pinValues = [];
      window.pinValues[p] = value ? HIGH_VALUE : LOW_VALUE;
    }
    refreshExternalLeds();
  };

  // After render() recreates component DOM, restore LED style immediately.
  const baseRender = window.render || (typeof render === 'function' ? render : null);
  if(baseRender && !window.__vectorPhase43R1RenderWrapped){
    window.__vectorPhase43R1RenderWrapped = true;
    window.render = render = function(){
      const r = baseRender.apply(this, arguments);
      requestAnimationFrame(refreshExternalLeds);
      setTimeout(refreshExternalLeds, 0);
      return r;
    };
  }

  // Single high-priority visual refresh. It does not call render(), so it cannot
  // cause flicker or erase component DOM.
  if(!window.__vectorPhase43R1ExternalLedTimer){
    window.__vectorPhase43R1ExternalLedTimer = setInterval(refreshExternalLeds, 20);
  }

  setTimeout(function(){
    refreshExternalLeds();
    if(typeof log === 'function') log('Phase 4.3R1 loaded: external LED widgets now directly follow the same D0-D13 state shown by AVR Digital Monitor.');
  }, 300);
})();

/* ============================================================
   AVR PHASE 4.3R3 - External LED Visual Sync + Draggable Monitor
   ------------------------------------------------------------
   Fixes verified field issue:
   - AVR Digital Monitor toggles correctly, but simulated external LED
     component does not visually toggle.
   - This layer intentionally uses the Digital Monitor value first because
     that is the already-verified canonical visible D0-D13 state.
   - Adds draggable + resizable Digital Pins monitor panel.
   ============================================================ */
(function(){
  'use strict';

  const HIGH_VALUE = (typeof HIGH !== 'undefined') ? HIGH : 1;
  const LOW_VALUE  = (typeof LOW  !== 'undefined') ? LOW  : 0;
  const GND_NODES = new Set(['uno.GND','uno.GND2','uno.GND_TOP','GND','gnd']);
  const VCC_NODES = new Set(['uno.5V','uno.3V3','uno.IOREF','5V','VCC','vcc']);

  function parseDigitalPin(node){
    const m = String(node || '').match(/^(?:uno\.)?D(\d+)$/i);
    if(!m) return null;
    const p = parseInt(m[1], 10);
    return (p >= 0 && p <= 13) ? p : null;
  }

  function wires(){
    return (window.project && Array.isArray(project.wires)) ? project.wires : [];
  }

  function connected(node){
    const out = [];
    wires().forEach(w => {
      if(w.from === node) out.push(w.to);
      if(w.to === node) out.push(w.from);
    });
    return out;
  }

  function monitorValue(pin){
    const cell = document.getElementById('dpmon_D' + pin);
    if(!cell) return null;
    const txt = (cell.title || cell.textContent || '').toUpperCase();
    if(txt.includes('HIGH')) return HIGH_VALUE;
    if(txt.includes('LOW')) return LOW_VALUE;
    return null;
  }

  function readPinVerified(pin){
    // 1) Highest priority: the AVR Digital Monitor, because the user has
    // verified this is toggling correctly for all pins in the latest build.
    const m = monitorValue(pin);
    if(m !== null) return m;

    // 2) Runtime compatibility cache.
    if(Array.isArray(window.pinValues) && typeof window.pinValues[pin] !== 'undefined'){
      return window.pinValues[pin] ? HIGH_VALUE : LOW_VALUE;
    }

    // 3) Board-state object fallback.
    const entry = window.VectorUnoBoardState && window.VectorUnoBoardState['D' + pin];
    if(entry && typeof entry.value !== 'undefined') return entry.value ? HIGH_VALUE : LOW_VALUE;

    return LOW_VALUE;
  }

  function isGround(node){ return GND_NODES.has(String(node)); }
  function isVcc(node){ return VCC_NODES.has(String(node)); }
  function nodeHigh(node){ const p = parseDigitalPin(node); return p !== null && readPinVerified(p) === HIGH_VALUE; }
  function nodeLow(node){ const p = parseDigitalPin(node); return p !== null && readPinVerified(p) === LOW_VALUE; }

  function computeLedOn(part){
    const a = connected(part.id + '.A');
    const k = connected(part.id + '.K');

    // Normal wiring: Dn -> LED anode, LED cathode -> GND.
    if(a.some(nodeHigh) && k.some(isGround)) return true;

    // Active-low wiring: 5V -> LED anode, LED cathode -> Dn.
    if(a.some(isVcc) && k.some(nodeLow)) return true;

    // Teaching fallback for pin-by-pin tests: if one side is connected to a
    // digital pin, show that pin state even if the other side is not perfect.
    const ap = a.map(parseDigitalPin).find(p => p !== null);
    if(ap !== undefined && ap !== null) return readPinVerified(ap) === HIGH_VALUE;

    const kp = k.map(parseDigitalPin).find(p => p !== null);
    if(kp !== undefined && kp !== null) return readPinVerified(kp) === LOW_VALUE;

    return false;
  }

  function paintExternalLed(part, on){
    part.state = on ? HIGH_VALUE : LOW_VALUE;
    const el = document.getElementById(part.id);
    if(!el) return;
    const bulb = el.querySelector('.ledBulb');
    if(!bulb) return;

    bulb.classList.toggle('on', !!on);
    el.classList.toggle('on', !!on);
    el.dataset.vectorLedState = on ? 'HIGH' : 'LOW';

    if(on){
      bulb.style.setProperty('background', '#ff2020', 'important');
      bulb.style.setProperty('box-shadow', '0 0 36px #ff2020, 0 0 14px rgba(255,32,32,.95)', 'important');
      bulb.style.setProperty('filter', 'brightness(1.55)', 'important');
      bulb.style.setProperty('opacity', '1', 'important');
    }else{
      bulb.style.setProperty('background', '#700', 'important');
      bulb.style.setProperty('box-shadow', 'none', 'important');
      bulb.style.setProperty('filter', 'brightness(1)', 'important');
      bulb.style.setProperty('opacity', '1', 'important');
    }
  }

  function refreshExternalLedsR3(){
    if(!window.project || !Array.isArray(project.parts)) return;
    project.parts.forEach(part => {
      if(part.type === 'led') paintExternalLed(part, computeLedOn(part));
    });
  }

  function makeDigitalMonitorInteractive(){
    const panel = document.getElementById('digitalPinMonitorRevA');
    if(!panel || panel.__vectorMonitorInteractive) return;
    panel.__vectorMonitorInteractive = true;

    panel.style.pointerEvents = 'auto';
    panel.style.resize = 'both';
    panel.style.overflow = 'auto';
    panel.style.minWidth = '285px';
    panel.style.minHeight = '82px';
    panel.style.maxWidth = '620px';
    panel.style.maxHeight = '420px';

    const title = panel.firstElementChild;
    if(title){
      title.style.cursor = 'move';
      title.style.userSelect = 'none';
      title.title = 'Drag Digital Pins monitor';
      title.textContent = 'Digital Pins  ⇲';
    }

    let dragging = false;
    let startX = 0, startY = 0, startLeft = 0, startTop = 0;

    function currentLeftTop(){
      const scene = document.getElementById('scene');
      const sceneRect = scene ? scene.getBoundingClientRect() : {left:0, top:0};
      const r = panel.getBoundingClientRect();
      return { left: r.left - sceneRect.left, top: r.top - sceneRect.top };
    }

    if(title){
      title.addEventListener('mousedown', function(e){
        dragging = true;
        const pos = currentLeftTop();
        startX = e.clientX;
        startY = e.clientY;
        startLeft = pos.left;
        startTop = pos.top;
        panel.style.right = 'auto';
        panel.style.left = startLeft + 'px';
        panel.style.top = startTop + 'px';
        e.preventDefault();
        e.stopPropagation();
      });
    }

    document.addEventListener('mousemove', function(e){
      if(!dragging) return;
      const scale = (window.project && project.canvasScale) ? project.canvasScale : 1;
      const nx = startLeft + (e.clientX - startX) / scale;
      const ny = startTop + (e.clientY - startY) / scale;
      panel.style.left = Math.max(0, nx) + 'px';
      panel.style.top = Math.max(0, ny) + 'px';
    });

    document.addEventListener('mouseup', function(){ dragging = false; });
  }

  function refreshAllR3(){
    refreshExternalLedsR3();
    makeDigitalMonitorInteractive();
  }

  // Wrap main notification paths and render path.
  const oldUpdateExternal = window.updateExternalLedFromDigitalPin;
  window.updateExternalLedFromDigitalPin = function(pin, value){
    if(typeof oldUpdateExternal === 'function'){
      try { oldUpdateExternal(pin, value); } catch(e) {}
    }
    const p = Number(String(pin).replace(/^D/i, ''));
    if(Number.isFinite(p) && p >= 0 && p <= 13){
      if(!Array.isArray(window.pinValues)) window.pinValues = [];
      window.pinValues[p] = value ? HIGH_VALUE : LOW_VALUE;
    }
    refreshAllR3();
  };

  const oldPinChange = window.onVectorUnoPinChange;
  window.onVectorUnoPinChange = function(name, state, source){
    if(typeof oldPinChange === 'function'){
      try { oldPinChange(name, state, source); } catch(e) {}
    }
    refreshAllR3();
  };

  const baseRender = window.render || (typeof render === 'function' ? render : null);
  if(baseRender && !window.__vectorPhase43R3RenderWrapped){
    window.__vectorPhase43R3RenderWrapped = true;
    window.render = render = function(){
      const ret = baseRender.apply(this, arguments);
      requestAnimationFrame(refreshAllR3);
      setTimeout(refreshAllR3, 0);
      return ret;
    };
  }

  if(!window.__vectorPhase43R3RefreshTimer){
    window.__vectorPhase43R3RefreshTimer = setInterval(refreshAllR3, 20);
  }

  window.VectorExternalLedFixR3 = {
    refresh: refreshAllR3,
    readPin: readPinVerified,
    ledOn: computeLedOn,
    connected
  };

  setTimeout(function(){
    refreshAllR3();
    if(typeof log === 'function') log('Phase 4.3R3 loaded: simulated external LEDs follow the verified AVR Digital Monitor state; monitor is draggable and resizable.');
  }, 350);
})();

/* ============================================================
   AVR PHASE 4.3R4 - HARD EXTERNAL LED DOM BINDING FIX
   ------------------------------------------------------------
   Field issue fixed:
   - AVR Digital Monitor toggles correctly for D0-D13.
   - Onboard L LED toggles correctly for D13.
   - Simulated external LED component does not toggle.

   This layer intentionally bypasses old component-manager state and
   paints the LED bulb directly from the same verified monitor/pin state.
   It is safe because it only changes visual style of type:'led' parts.
   ============================================================ */
(function(){
  'use strict';

  const HIGH_VALUE = (typeof HIGH !== 'undefined') ? HIGH : 1;
  const LOW_VALUE  = (typeof LOW  !== 'undefined') ? LOW  : 0;

  const GND_NAMES = ['GND','gnd','uno.GND','uno.GND2','uno.GND_TOP','ground','GROUND'];
  const VCC_NAMES = ['5V','VCC','vcc','uno.5V','uno.3V3','uno.IOREF'];

  function isGnd(n){ return GND_NAMES.indexOf(String(n)) >= 0; }
  function isVcc(n){ return VCC_NAMES.indexOf(String(n)) >= 0; }

  function digitalPinFromNode(n){
    const m = String(n || '').match(/(?:^|\.)D(\d+)$/i);
    if(!m) return null;
    const p = parseInt(m[1], 10);
    return (p >= 0 && p <= 13) ? p : null;
  }

  function getWires(){
    return (window.project && Array.isArray(window.project.wires)) ? window.project.wires : [];
  }

  function nodesConnectedTo(node){
    const a = [];
    getWires().forEach(w => {
      if(w.from === node) a.push(w.to);
      if(w.to === node) a.push(w.from);
    });
    return a;
  }

  function readMonitorPin(pin){
    const cell = document.getElementById('dpmon_D' + pin);
    if(!cell) return null;

    const title = String(cell.title || '').toUpperCase();
    if(title.indexOf('HIGH') >= 0) return HIGH_VALUE;
    if(title.indexOf('LOW') >= 0) return LOW_VALUE;

    // Fallback based on monitor visual style, because user verified monitor
    // is correct even when the title is not updated by an older layer.
    const bg = String(cell.style.background || cell.style.backgroundColor || '').toLowerCase();
    const border = String(cell.style.borderColor || '').toLowerCase();
    const shadow = String(cell.style.boxShadow || '').toLowerCase();
    if(bg.indexOf('92400e') >= 0 || border.indexOf('facc15') >= 0 || shadow.indexOf('250, 204, 21') >= 0){
      return HIGH_VALUE;
    }
    if(bg.indexOf('1f2937') >= 0 || border.indexOf('374151') >= 0){
      return LOW_VALUE;
    }

    return null;
  }

  function readPin(pin){
    // Use monitor first because it is the verified visible truth in testing.
    const mv = readMonitorPin(pin);
    if(mv !== null) return mv;

    if(Array.isArray(window.pinValues) && typeof window.pinValues[pin] !== 'undefined'){
      return window.pinValues[pin] ? HIGH_VALUE : LOW_VALUE;
    }

    const st = window.VectorUnoBoardState && window.VectorUnoBoardState['D' + pin];
    if(st && typeof st.value !== 'undefined') return st.value ? HIGH_VALUE : LOW_VALUE;

    // Optional compatibility with a digital array-style board state.
    if(window.VectorUnoBoardState && Array.isArray(window.VectorUnoBoardState.digital)){
      const d = window.VectorUnoBoardState.digital[pin];
      if(typeof d !== 'undefined') return d ? HIGH_VALUE : LOW_VALUE;
    }

    return LOW_VALUE;
  }

  function nodeHigh(n){
    const p = digitalPinFromNode(n);
    return p !== null && readPin(p) === HIGH_VALUE;
  }

  function nodeLow(n){
    const p = digitalPinFromNode(n);
    return p !== null && readPin(p) === LOW_VALUE;
  }

  function ledIsOn(part){
    const aNodes = nodesConnectedTo(part.id + '.A');
    const kNodes = nodesConnectedTo(part.id + '.K');

    // Correct electronics model: current from Arduino pin -> LED -> GND.
    if(aNodes.some(nodeHigh) && kNodes.some(isGnd)) return true;

    // Active-low model: +5V -> LED -> Arduino pin sinks current.
    if(aNodes.some(isVcc) && kNodes.some(nodeLow)) return true;

    // Classroom fallback: if a single terminal is connected while testing pins,
    // still show the corresponding logic clearly.
    const aPin = aNodes.map(digitalPinFromNode).find(p => p !== null);
    if(aPin !== undefined && aPin !== null) return readPin(aPin) === HIGH_VALUE;

    const kPin = kNodes.map(digitalPinFromNode).find(p => p !== null);
    if(kPin !== undefined && kPin !== null) return readPin(kPin) === LOW_VALUE;

    return false;
  }

  function paintLedPart(part, on){
    if(!part) return;
    part.state = on ? HIGH_VALUE : LOW_VALUE;
    const el = document.getElementById(part.id);
    if(!el) return;
    const bulb = el.querySelector('.ledBulb');
    if(!bulb) return;

    bulb.classList.toggle('on', !!on);
    el.classList.toggle('on', !!on);
    el.setAttribute('data-led-state', on ? 'ON' : 'OFF');

    // Force visible style with priority. This avoids losing to older CSS layers.
    bulb.style.setProperty('display', 'block', 'important');
    bulb.style.setProperty('width', '42px', 'important');
    bulb.style.setProperty('height', '58px', 'important');
    bulb.style.setProperty('border-radius', '22px 22px 8px 8px', 'important');
    bulb.style.setProperty('margin', 'auto', 'important');
    bulb.style.setProperty('opacity', '1', 'important');

    if(on){
      bulb.style.setProperty('background-color', '#ff2020', 'important');
      bulb.style.setProperty('background', '#ff2020', 'important');
      bulb.style.setProperty('box-shadow', '0 0 38px #ff2020, 0 0 14px rgba(255,32,32,0.95)', 'important');
      bulb.style.setProperty('filter', 'brightness(1.65)', 'important');
    }else{
      bulb.style.setProperty('background-color', '#660000', 'important');
      bulb.style.setProperty('background', '#660000', 'important');
      bulb.style.setProperty('box-shadow', 'none', 'important');
      bulb.style.setProperty('filter', 'brightness(1)', 'important');
    }
  }

  function refreshExternalLedDomBinding(){
    if(!window.project || !Array.isArray(window.project.parts)) return;
    window.project.parts.forEach(part => {
      if(part && part.type === 'led') paintLedPart(part, ledIsOn(part));
    });
  }

  window.VectorExternalLedFixR4 = {
    refresh: refreshExternalLedDomBinding,
    readPin,
    ledIsOn,
    nodesConnectedTo
  };

  // Hook all known event paths.
  const oldRender = window.render || (typeof render === 'function' ? render : null);
  if(oldRender && !window.__vectorPhase43R4RenderWrapped){
    window.__vectorPhase43R4RenderWrapped = true;
    window.render = render = function(){
      const r = oldRender.apply(this, arguments);
      requestAnimationFrame(refreshExternalLedDomBinding);
      setTimeout(refreshExternalLedDomBinding, 0);
      return r;
    };
  }

  const oldUpdatePin = window.updateExternalLedFromDigitalPin;
  window.updateExternalLedFromDigitalPin = function(pin, value){
    if(typeof oldUpdatePin === 'function'){
      try { oldUpdatePin(pin, value); } catch(e) {}
    }
    const p = Number(String(pin).replace(/^D/i, ''));
    if(Number.isFinite(p) && p >= 0 && p <= 13){
      if(!Array.isArray(window.pinValues)) window.pinValues = [];
      window.pinValues[p] = value ? HIGH_VALUE : LOW_VALUE;
    }
    refreshExternalLedDomBinding();
  };

  const oldPinChange = window.onVectorUnoPinChange;
  window.onVectorUnoPinChange = function(name, state, source){
    if(typeof oldPinChange === 'function'){
      try { oldPinChange(name, state, source); } catch(e) {}
    }
    refreshExternalLedDomBinding();
  };

  if(!window.__vectorPhase43R4LedTimer){
    window.__vectorPhase43R4LedTimer = setInterval(refreshExternalLedDomBinding, 15);
  }

  setTimeout(function(){
    refreshExternalLedDomBinding();
    if(typeof log === 'function') log('Phase 4.3R4 loaded: external LED DOM binding now follows the verified AVR Digital Monitor state directly.');
  }, 400);
})();

/* ============================================================
   AVR PHASE 4.3R5 - ROOT FIX: External LED uses lexical project
   ------------------------------------------------------------
   Root cause found in the tested R4 ZIP:
   - The simulator declares `let project`, so it is NOT window.project.
   - Several previous external-LED patches checked window.project and
     therefore returned before reading wires/parts.
   - The AVR Digital Monitor worked because it used the AVR board state,
     while the simulated LED never received the project wiring state.

   This fix uses the actual lexical `project` object from this script and
   keeps window.project synchronized for older compatibility layers.
   ============================================================ */
(function(){
  'use strict';

  const HIGH_VALUE = (typeof HIGH !== 'undefined') ? HIGH : 1;
  const LOW_VALUE  = (typeof LOW  !== 'undefined') ? LOW  : 0;
  const GND_NODES = new Set(['uno.GND','uno.GND2','uno.GND_TOP','GND','gnd','GROUND','ground']);
  const VCC_NODES = new Set(['uno.5V','uno.3V3','uno.IOREF','5V','VCC','vcc','+5V']);

  function getProject43R5(){
    try {
      if(typeof project !== 'undefined' && project) return project;
    } catch(e) {}
    return window.project || null;
  }

  function syncWindowProject43R5(){
    try {
      if(typeof project !== 'undefined' && project) window.project = project;
    } catch(e) {}
  }

  function parseDigitalPin43R5(node){
    const m = String(node || '').match(/^(?:uno\.)?D(\d+)$/i);
    if(!m) return null;
    const pin = parseInt(m[1], 10);
    return (pin >= 0 && pin <= 13) ? pin : null;
  }

  function getWires43R5(){
    const prj = getProject43R5();
    return (prj && Array.isArray(prj.wires)) ? prj.wires : [];
  }

  function getParts43R5(){
    const prj = getProject43R5();
    return (prj && Array.isArray(prj.parts)) ? prj.parts : [];
  }

  function connectedTo43R5(nodeName){
    const out = [];
    getWires43R5().forEach(w => {
      if(w.from === nodeName) out.push(w.to);
      if(w.to === nodeName) out.push(w.from);
    });
    return out;
  }

  function readMonitorPin43R5(pin){
    const cell = document.getElementById('dpmon_D' + pin);
    if(!cell) return null;
    const title = String(cell.title || '').toUpperCase();
    if(title.indexOf('HIGH') >= 0) return HIGH_VALUE;
    if(title.indexOf('LOW') >= 0) return LOW_VALUE;
    const bg = String(cell.style.background || cell.style.backgroundColor || '').toLowerCase();
    const color = String(cell.style.color || '').toLowerCase();
    if(bg.indexOf('92400e') >= 0 || color.indexOf('fff7cc') >= 0) return HIGH_VALUE;
    if(bg.indexOf('1f2937') >= 0) return LOW_VALUE;
    return null;
  }

  function readDigitalPin43R5(pin){
    const name = 'D' + pin;

    // First: real AVR/UNO state produced by the emulator pin mapper.
    const board = window.VectorUnoBoardState;
    if(board){
      const entry = board[name];
      if(entry && typeof entry.value !== 'undefined') return entry.value ? HIGH_VALUE : LOW_VALUE;
      if(Array.isArray(board.digital) && typeof board.digital[pin] !== 'undefined') return board.digital[pin] ? HIGH_VALUE : LOW_VALUE;
    }

    // Second: lexical simulator cache. Important: top-level `let pinValues`
    // is not window.pinValues, so previous patches missed it.
    try {
      if(typeof pinValues !== 'undefined' && pinValues && typeof pinValues[pin] !== 'undefined'){
        return pinValues[pin] ? HIGH_VALUE : LOW_VALUE;
      }
    } catch(e) {}

    // Third: compatibility cache from older patches, when present.
    if(window.pinValues && typeof window.pinValues[pin] !== 'undefined') return window.pinValues[pin] ? HIGH_VALUE : LOW_VALUE;

    // Last: verified visible monitor state.
    const mv = readMonitorPin43R5(pin);
    if(mv !== null) return mv;

    return LOW_VALUE;
  }

  function nodeIsHigh43R5(node){
    const p = parseDigitalPin43R5(node);
    return p !== null && readDigitalPin43R5(p) === HIGH_VALUE;
  }

  function nodeIsLow43R5(node){
    const p = parseDigitalPin43R5(node);
    return p !== null && readDigitalPin43R5(p) === LOW_VALUE;
  }

  function nodeIsGnd43R5(node){ return GND_NODES.has(String(node)); }
  function nodeIsVcc43R5(node){ return VCC_NODES.has(String(node)); }

  function ledShouldBeOn43R5(part){
    const aNodes = connectedTo43R5(part.id + '.A');
    const kNodes = connectedTo43R5(part.id + '.K');

    // Normal LED wiring: Arduino pin drives anode, cathode to ground.
    if(aNodes.some(nodeIsHigh43R5) && kNodes.some(nodeIsGnd43R5)) return true;

    // Active-low wiring: anode to VCC, Arduino pin sinks cathode.
    if(aNodes.some(nodeIsVcc43R5) && kNodes.some(nodeIsLow43R5)) return true;

    // Teaching/test fallback: a single digital connection still follows pin state.
    const aPin = aNodes.map(parseDigitalPin43R5).find(p => p !== null);
    if(aPin !== undefined && aPin !== null) return readDigitalPin43R5(aPin) === HIGH_VALUE;

    const kPin = kNodes.map(parseDigitalPin43R5).find(p => p !== null);
    if(kPin !== undefined && kPin !== null) return readDigitalPin43R5(kPin) === LOW_VALUE;

    return false;
  }

  function paintExternalLed43R5(part, on){
    part.state = on ? HIGH_VALUE : LOW_VALUE;
    const el = document.getElementById(part.id);
    if(!el) return;
    const bulb = el.querySelector('.ledBulb');
    if(!bulb) return;

    bulb.classList.toggle('on', !!on);
    el.classList.toggle('on', !!on);
    el.setAttribute('data-vector-led-state', on ? 'ON' : 'OFF');

    // Use inline important style so older CSS/render layers cannot override it.
    bulb.style.setProperty('background', on ? '#ff2020' : '#700', 'important');
    bulb.style.setProperty('background-color', on ? '#ff2020' : '#700', 'important');
    bulb.style.setProperty('box-shadow', on ? '0 0 38px #ff2020, 0 0 14px rgba(255,32,32,0.95)' : 'none', 'important');
    bulb.style.setProperty('filter', on ? 'brightness(1.55)' : 'brightness(1)', 'important');
    bulb.style.setProperty('opacity', '1', 'important');
  }

  function refreshExternalLeds43R5(){
    syncWindowProject43R5();
    getParts43R5().forEach(part => {
      if(part && part.type === 'led') paintExternalLed43R5(part, ledShouldBeOn43R5(part));
    });
  }

  // Keep older layers that still use window.project from silently failing.
  const oldNewProject = (typeof newProject === 'function') ? newProject : null;
  if(oldNewProject && !window.__vector43R5NewProjectWrapped){
    window.__vector43R5NewProjectWrapped = true;
    window.newProject = newProject = function(){
      const r = oldNewProject.apply(this, arguments);
      syncWindowProject43R5();
      setTimeout(refreshExternalLeds43R5, 0);
      return r;
    };
  }

  const oldRender = (typeof render === 'function') ? render : null;
  if(oldRender && !window.__vector43R5RenderWrapped){
    window.__vector43R5RenderWrapped = true;
    window.render = render = function(){
      const r = oldRender.apply(this, arguments);
      syncWindowProject43R5();
      requestAnimationFrame(refreshExternalLeds43R5);
      setTimeout(refreshExternalLeds43R5, 0);
      return r;
    };
  }

  const prevSetPin = window.setAvrDigitalPinValue;
  window.setAvrDigitalPinValue = function(pin, value){
    if(typeof prevSetPin === 'function') { try { prevSetPin(pin, value); } catch(e) {} }
    const p = Number(String(pin).replace(/^D/i, ''));
    if(Number.isFinite(p) && p >= 0 && p <= 13){
      try { if(typeof pinValues !== 'undefined') pinValues[p] = value ? HIGH_VALUE : LOW_VALUE; } catch(e) {}
      if(!window.pinValues) window.pinValues = [];
      window.pinValues[p] = value ? HIGH_VALUE : LOW_VALUE;
    }
    refreshExternalLeds43R5();
  };

  const prevPinChange = window.onVectorUnoPinChange;
  window.onVectorUnoPinChange = function(name, state, source){
    if(typeof prevPinChange === 'function') { try { prevPinChange(name, state, source); } catch(e) {} }
    const m = String(name || '').match(/^D(\d+)$/i);
    if(m){
      const p = parseInt(m[1], 10);
      try { if(typeof pinValues !== 'undefined') pinValues[p] = state && state.value ? HIGH_VALUE : LOW_VALUE; } catch(e) {}
      if(!window.pinValues) window.pinValues = [];
      window.pinValues[p] = state && state.value ? HIGH_VALUE : LOW_VALUE;
    }
    refreshExternalLeds43R5();
  };

  const prevUpdateLed = window.updateExternalLedFromDigitalPin;
  window.updateExternalLedFromDigitalPin = function(pin, value){
    if(typeof prevUpdateLed === 'function') { try { prevUpdateLed(pin, value); } catch(e) {} }
    const p = Number(String(pin).replace(/^D/i, ''));
    if(Number.isFinite(p) && p >= 0 && p <= 13){
      try { if(typeof pinValues !== 'undefined') pinValues[p] = value ? HIGH_VALUE : LOW_VALUE; } catch(e) {}
      if(!window.pinValues) window.pinValues = [];
      window.pinValues[p] = value ? HIGH_VALUE : LOW_VALUE;
    }
    refreshExternalLeds43R5();
  };

  // High-priority visual binding only; it does not call render(), so it is safe.
  if(!window.__vectorPhase43R5ExternalLedTimer){
    window.__vectorPhase43R5ExternalLedTimer = setInterval(refreshExternalLeds43R5, 15);
  }

  window.VectorExternalLedFixR5 = {
    refresh: refreshExternalLeds43R5,
    readPin: readDigitalPin43R5,
    ledShouldBeOn: ledShouldBeOn43R5,
    connectedTo: connectedTo43R5,
    getProject: getProject43R5
  };

  setTimeout(function(){
    syncWindowProject43R5();
    refreshExternalLeds43R5();
    if(typeof log === 'function') log('Phase 4.3R5 loaded: root fix applied. External LEDs now use the actual project wiring object, not missing window.project.');
  }, 500);
})();

/* ============================================================
   PHASE 4.3R6 PATCH
   Robust edit-mode deletion after AVR simulation stop.
   Fixes: double-click delete for components/wires stopped working after the
   late Phase 4.3 render/runtime wrappers. This patch installs one final,
   capture-phase deletion handler that reads the live `project` object and
   does not depend on earlier per-element dblclick handlers surviving render().
   ============================================================ */
(function installPhase43R6RobustDelete(){
  if(window.__vectorPhase43R6RobustDeleteInstalled) return;
  window.__vectorPhase43R6RobustDeleteInstalled = true;

  function getProject43R6(){
    try{ if(typeof project !== 'undefined' && project) return project; }catch(e){}
    return window.project || null;
  }

  function isSimulationStopped43R6(){
    try{ if(typeof running !== 'undefined' && running) return false; }catch(e){}
    try{ if(typeof simulationActive !== 'undefined' && simulationActive) return false; }catch(e){}
    try{ if(window.avrPhase2Runtime && window.avrPhase2Runtime.running) return false; }catch(e){}
    try{ if(typeof avrPhase2Runtime !== 'undefined' && avrPhase2Runtime && avrPhase2Runtime.running) return false; }catch(e){}
    return true;
  }

  function deleteComponentById43R6(id){
    const prj = getProject43R6();
    if(!prj || !Array.isArray(prj.parts)) return false;
    const before = prj.parts.length;
    prj.parts = prj.parts.filter(p => p.id !== id);
    if(Array.isArray(prj.wires)){
      prj.wires = prj.wires.filter(w => !String(w.from).startsWith(id + '.') && !String(w.to).startsWith(id + '.'));
    }
    try{ if(typeof selectedId !== 'undefined' && selectedId === id) selectedId = null; }catch(e){}
    if(prj.parts.length === before) return false;
    try{ window.project = prj; }catch(e){}
    if(typeof render === 'function') render();
    else if(typeof drawWires === 'function') drawWires();
    if(typeof log === 'function') log('Deleted component: ' + id);
    return true;
  }

  function deleteWireByIndex43R6(index){
    const prj = getProject43R6();
    if(!prj || !Array.isArray(prj.wires)) return false;
    if(index < 0 || index >= prj.wires.length) return false;
    prj.wires.splice(index, 1);
    try{ window.project = prj; }catch(e){}
    if(typeof drawWires === 'function') drawWires();
    if(typeof log === 'function') log('Wire deleted');
    return true;
  }

  function installWireIndexes43R6(){
    const svg = document.getElementById('wires');
    const prj = getProject43R6();
    if(!svg || !prj || !Array.isArray(prj.wires)) return;
    const groups = Array.from(svg.children).filter(el => String(el.tagName).toLowerCase() === 'g');
    groups.forEach((g, idx) => {
      if(idx < prj.wires.length){
        g.setAttribute('data-vector-wire-index', String(idx));
        g.style.cursor = 'pointer';
      }
    });
  }

  const oldDrawWires = (typeof drawWires === 'function') ? drawWires : null;
  if(oldDrawWires && !window.__vectorPhase43R6DrawWiresWrapped){
    window.__vectorPhase43R6DrawWiresWrapped = true;
    window.drawWires = drawWires = function(){
      const r = oldDrawWires.apply(this, arguments);
      installWireIndexes43R6();
      return r;
    };
  }

  const oldRender = (typeof render === 'function') ? render : null;
  if(oldRender && !window.__vectorPhase43R6RenderWrapped){
    window.__vectorPhase43R6RenderWrapped = true;
    window.render = render = function(){
      const r = oldRender.apply(this, arguments);
      installWireIndexes43R6();
      return r;
    };
  }

  document.addEventListener('dblclick', function(e){
    if(e.button !== 0) return;
    if(!isSimulationStopped43R6()){
      if(typeof log === 'function') log('Stop simulation before deleting components or wires.');
      return;
    }

    const target = e.target;

    // Do not delete when double-clicking pins or form controls.
    if(target && target.closest && (target.closest('.pin') || target.closest('input, textarea, select, button'))){
      return;
    }

    // Component delete.
    const partEl = target && target.closest ? target.closest('.part') : null;
    if(partEl && partEl.id){
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      deleteComponentById43R6(partEl.id);
      return;
    }

    // Wire delete. Works even when older drawWire handlers were overwritten.
    const wiresSvg = document.getElementById('wires');
    const wireGroup = target && target.closest ? target.closest('#wires g') : null;
    if(wiresSvg && wireGroup){
      let idx = Number(wireGroup.getAttribute('data-vector-wire-index'));
      if(!Number.isFinite(idx)){
        const groups = Array.from(wiresSvg.children).filter(el => String(el.tagName).toLowerCase() === 'g');
        idx = groups.indexOf(wireGroup);
      }
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      deleteWireByIndex43R6(idx);
    }
  }, true);

  setTimeout(function(){
    installWireIndexes43R6();
    if(typeof log === 'function') log('Phase 4.3R6 loaded: double-click delete restored for stopped simulation.');
  }, 500);
})();

/* ============================================================
   PHASE 4.3R7 PATCH
   Final editor interaction repair: double-click delete.
   This patch deliberately bypasses all older delete handlers and uses
   event delegation + live project data. It does not depend on old
   per-element handlers, window.project, or simulation stop flags.
   ============================================================ */
(function installPhase43R7DeleteFinal(){
  if(window.__vectorPhase43R7DeleteFinalInstalled) return;
  window.__vectorPhase43R7DeleteFinalInstalled = true;

  function getLiveProject43R7(){
    try { if(typeof project !== 'undefined' && project) return project; } catch(e) {}
    try { if(window.project) return window.project; } catch(e) {}
    return null;
  }

  function getPath43R7(evt){
    if(evt && typeof evt.composedPath === 'function') return evt.composedPath();
    const path = [];
    let n = evt ? evt.target : null;
    while(n){ path.push(n); n = n.parentNode; }
    return path;
  }

  function findPartElement43R7(evt){
    const path = getPath43R7(evt);
    for(const n of path){
      if(n && n.classList && n.classList.contains('part') && n.id) return n;
    }
    const t = evt && evt.target;
    return (t && t.closest) ? t.closest('.part') : null;
  }

  function findWireGroup43R7(evt){
    const path = getPath43R7(evt);
    for(const n of path){
      if(!n || !n.parentNode) continue;
      const tag = String(n.tagName || '').toLowerCase();
      if(tag === 'g'){
        const parentId = n.parentNode && n.parentNode.id;
        if(parentId === 'wires') return n;
      }
    }
    const t = evt && evt.target;
    return (t && t.closest) ? t.closest('#wires g') : null;
  }

  function shouldIgnore43R7(evt){
    const t = evt && evt.target;
    if(!t) return false;
    if(t.closest && t.closest('input, textarea, select, button, .pin, #componentPalette, #canvasComponentPicker, #avrDigitalMonitor')) return true;
    return false;
  }

  function deletePart43R7(id){
    const prj = getLiveProject43R7();
    if(!prj || !Array.isArray(prj.parts)) return false;
    const before = prj.parts.length;
    prj.parts = prj.parts.filter(p => p && p.id !== id);
    if(Array.isArray(prj.wires)){
      prj.wires = prj.wires.filter(w => !String(w.from || '').startsWith(id + '.') && !String(w.to || '').startsWith(id + '.'));
    }
    if(prj.parts.length === before) return false;
    try { if(typeof selectedId !== 'undefined' && selectedId === id) selectedId = null; } catch(e) {}
    try { window.project = prj; } catch(e) {}
    try { if(typeof cancelWiring === 'function') cancelWiring(false); } catch(e) {}
    try { if(typeof render === 'function') render(); } catch(e) {}
    try { if(typeof drawWires === 'function') drawWires(); } catch(e) {}
    try { if(typeof log === 'function') log('Deleted component: ' + id); } catch(e) {}
    return true;
  }

  function tagWireGroups43R7(){
    const svg = document.getElementById('wires');
    const prj = getLiveProject43R7();
    if(!svg || !prj || !Array.isArray(prj.wires)) return;
    const groups = Array.from(svg.querySelectorAll(':scope > g'));
    groups.forEach((g, i) => {
      g.dataset.vectorWireIndex = String(i);
      g.style.cursor = 'pointer';
      if(!g.__vectorR7DirectDblClick){
        g.__vectorR7DirectDblClick = true;
        g.addEventListener('dblclick', handleDelete43R7, true);
      }
    });
  }

  function deleteWire43R7(g){
    const prj = getLiveProject43R7();
    const svg = document.getElementById('wires');
    if(!prj || !Array.isArray(prj.wires) || !svg || !g) return false;
    let idx = Number(g.dataset ? g.dataset.vectorWireIndex : g.getAttribute('data-vector-wire-index'));
    if(!Number.isFinite(idx)){
      const groups = Array.from(svg.querySelectorAll(':scope > g'));
      idx = groups.indexOf(g);
    }
    if(idx < 0 || idx >= prj.wires.length) return false;
    prj.wires.splice(idx, 1);
    try { window.project = prj; } catch(e) {}
    try { if(typeof drawWires === 'function') drawWires(); } catch(e) {}
    tagWireGroups43R7();
    try { if(typeof log === 'function') log('Wire deleted'); } catch(e) {}
    return true;
  }

  function handleDelete43R7(evt){
    if(shouldIgnore43R7(evt)) return;

    const partEl = findPartElement43R7(evt);
    if(partEl && partEl.id){
      evt.preventDefault();
      evt.stopPropagation();
      if(evt.stopImmediatePropagation) evt.stopImmediatePropagation();
      deletePart43R7(partEl.id);
      return;
    }

    const wireG = findWireGroup43R7(evt);
    if(wireG){
      evt.preventDefault();
      evt.stopPropagation();
      if(evt.stopImmediatePropagation) evt.stopImmediatePropagation();
      deleteWire43R7(wireG);
    }
  }

  const oldRender43R7 = (typeof render === 'function') ? render : null;
  if(oldRender43R7 && !window.__vectorPhase43R7RenderWrapped){
    window.__vectorPhase43R7RenderWrapped = true;
    window.render = render = function(){
      const ret = oldRender43R7.apply(this, arguments);
      tagWireGroups43R7();
      // Direct handlers are a backup in case another layer blocks bubbling.
      document.querySelectorAll('.part').forEach(el => {
        if(!el.__vectorR7DirectDblClick){
          el.__vectorR7DirectDblClick = true;
          el.addEventListener('dblclick', handleDelete43R7, true);
        }
      });
      return ret;
    };
  }

  const oldDrawWires43R7 = (typeof drawWires === 'function') ? drawWires : null;
  if(oldDrawWires43R7 && !window.__vectorPhase43R7DrawWiresWrapped){
    window.__vectorPhase43R7DrawWiresWrapped = true;
    window.drawWires = drawWires = function(){
      const ret = oldDrawWires43R7.apply(this, arguments);
      tagWireGroups43R7();
      return ret;
    };
  }

  document.addEventListener('dblclick', handleDelete43R7, true);
  const canvas = document.getElementById('canvas');
  if(canvas) canvas.addEventListener('dblclick', handleDelete43R7, true);
  const scene = document.getElementById('scene');
  if(scene) scene.addEventListener('dblclick', handleDelete43R7, true);

  // Keep wire indexes fresh even when older functions redraw the SVG.
  const wiresSvg = document.getElementById('wires');
  if(wiresSvg && window.MutationObserver){
    const obs = new MutationObserver(tagWireGroups43R7);
    obs.observe(wiresSvg, { childList: true });
  }

  setTimeout(function(){
    try { if(typeof render === 'function') render(); else tagWireGroups43R7(); } catch(e) { tagWireGroups43R7(); }
    try { if(typeof log === 'function') log('Phase 4.3R7 loaded: final delegated double-click delete enabled.'); } catch(e) {}
  }, 300);
})();

/* ============================================================
   PHASE 4.3R8 PATCH
   Root fix for double-click deletion after render-on-click.
   Cause: the first click selects a component and calls render(), which
   destroys/recreates the DOM node before the browser can fire a native
   dblclick on the same element. Therefore native dblclick handlers will
   never be reliable. This patch uses capture-phase mousedown timing and
   deletes on the second click before render/selection handlers run.
   ============================================================ */
(function installPhase43R8MouseDownDoubleDelete(){
  if(window.__vectorPhase43R8MouseDownDoubleDeleteInstalled) return;
  window.__vectorPhase43R8MouseDownDoubleDeleteInstalled = true;

  let lastClick = { kind:null, id:null, t:0, x:0, y:0 };
  const DOUBLE_MS = 520;
  const MOVE_TOL = 18;

  function getLiveProject43R8(){
    try { if(typeof project !== 'undefined' && project) return project; } catch(e) {}
    try { if(window.project) return window.project; } catch(e) {}
    return null;
  }

  function simulationActuallyRunning43R8(){
    // Do not trust stale flags blindly. Use the Run/Stop button text first.
    const btn = document.getElementById('runStopBtn');
    if(btn && /stop/i.test(btn.textContent || '')) return true;
    try { if(typeof running !== 'undefined' && running === true) return true; } catch(e) {}
    try { if(window.avrPhase2Runtime && window.avrPhase2Runtime.running === true) return true; } catch(e) {}
    return false;
  }

  function isIgnoredTarget43R8(t){
    if(!t || !t.closest) return false;
    return !!t.closest('input, textarea, select, button, .pin, #componentPalette, #canvasComponentPicker, #avrDigitalMonitor, #compilerPanel, #serialPanel');
  }

  function findPartEl43R8(t){
    return (t && t.closest) ? t.closest('.part') : null;
  }

  function findWireEl43R8(t){
    return (t && t.closest) ? t.closest('#wires g') : null;
  }

  function sameClick43R8(kind, id, e){
    const now = performance.now();
    const dx = Math.abs((e.clientX || 0) - lastClick.x);
    const dy = Math.abs((e.clientY || 0) - lastClick.y);
    return lastClick.kind === kind && lastClick.id === id && (now - lastClick.t) <= DOUBLE_MS && dx <= MOVE_TOL && dy <= MOVE_TOL;
  }

  function rememberClick43R8(kind, id, e){
    lastClick = { kind, id, t: performance.now(), x: e.clientX || 0, y: e.clientY || 0 };
  }

  function deletePart43R8(id){
    const prj = getLiveProject43R8();
    if(!prj || !Array.isArray(prj.parts)) return false;
    const before = prj.parts.length;
    prj.parts = prj.parts.filter(p => p && p.id !== id);
    if(Array.isArray(prj.wires)){
      prj.wires = prj.wires.filter(w => !String(w.from || '').startsWith(id + '.') && !String(w.to || '').startsWith(id + '.'));
    }
    if(prj.parts.length === before) return false;
    try { if(typeof selectedId !== 'undefined' && selectedId === id) selectedId = null; } catch(e) {}
    try { if(typeof wiringSource !== 'undefined') wiringSource = null; } catch(e) {}
    try { if(typeof wiringMouse !== 'undefined') wiringMouse = null; } catch(e) {}
    try { window.project = prj; } catch(e) {}
    try { if(typeof render === 'function') render(); } catch(e) {}
    try { if(typeof drawWires === 'function') drawWires(); } catch(e) {}
    try { if(typeof log === 'function') log('Deleted component: ' + id); } catch(e) {}
    return true;
  }

  function wireIndex43R8(wireG){
    const svg = document.getElementById('wires');
    if(!svg || !wireG) return -1;
    let idx = Number(wireG.dataset ? wireG.dataset.vectorWireIndex : wireG.getAttribute('data-vector-wire-index'));
    if(Number.isFinite(idx) && idx >= 0) return idx;
    const groups = Array.from(svg.querySelectorAll(':scope > g'));
    return groups.indexOf(wireG);
  }

  function tagWires43R8(){
    const svg = document.getElementById('wires');
    const prj = getLiveProject43R8();
    if(!svg || !prj || !Array.isArray(prj.wires)) return;
    Array.from(svg.querySelectorAll(':scope > g')).forEach((g, i) => {
      g.dataset.vectorWireIndex = String(i);
      g.style.cursor = 'pointer';
    });
  }

  function deleteWire43R8(wireG){
    const prj = getLiveProject43R8();
    if(!prj || !Array.isArray(prj.wires)) return false;
    const idx = wireIndex43R8(wireG);
    if(idx < 0 || idx >= prj.wires.length) return false;
    prj.wires.splice(idx, 1);
    try { if(typeof wiringSource !== 'undefined') wiringSource = null; } catch(e) {}
    try { if(typeof wiringMouse !== 'undefined') wiringMouse = null; } catch(e) {}
    try { window.project = prj; } catch(e) {}
    try { if(typeof drawWires === 'function') drawWires(); } catch(e) {}
    tagWires43R8();
    try { if(typeof log === 'function') log('Wire deleted'); } catch(e) {}
    return true;
  }

  function consumeEvent43R8(e){
    e.preventDefault();
    e.stopPropagation();
    if(e.stopImmediatePropagation) e.stopImmediatePropagation();
  }

  function onMouseDown43R8(e){
    if(e.button !== 0) return;
    const t = e.target;
    if(isIgnoredTarget43R8(t)) return;

    const partEl = findPartEl43R8(t);
    if(partEl && partEl.id){
      const id = partEl.id;
      if(sameClick43R8('part', id, e)){
        consumeEvent43R8(e);
        if(simulationActuallyRunning43R8()){
          try { if(typeof log === 'function') log('Stop simulation before deleting components.'); } catch(err) {}
          lastClick = { kind:null, id:null, t:0, x:0, y:0 };
          return;
        }
        deletePart43R8(id);
        lastClick = { kind:null, id:null, t:0, x:0, y:0 };
      } else {
        rememberClick43R8('part', id, e);
      }
      return;
    }

    const wireG = findWireEl43R8(t);
    if(wireG){
      tagWires43R8();
      const idx = wireIndex43R8(wireG);
      const id = String(idx);
      if(sameClick43R8('wire', id, e)){
        consumeEvent43R8(e);
        if(simulationActuallyRunning43R8()){
          try { if(typeof log === 'function') log('Stop simulation before deleting wires.'); } catch(err) {}
          lastClick = { kind:null, id:null, t:0, x:0, y:0 };
          return;
        }
        deleteWire43R8(wireG);
        lastClick = { kind:null, id:null, t:0, x:0, y:0 };
      } else {
        rememberClick43R8('wire', id, e);
      }
    }
  }

  document.addEventListener('mousedown', onMouseDown43R8, true);
  document.addEventListener('pointerdown', function(e){
    // Some Chromium builds synthesize dblclick poorly after transformed DOM redraws.
    // mousedown is the primary path; pointerdown is kept only for touch/stylus.
    if(e.pointerType && e.pointerType !== 'mouse') onMouseDown43R8(e);
  }, true);

  const oldDrawWires43R8 = (typeof drawWires === 'function') ? drawWires : null;
  if(oldDrawWires43R8 && !window.__vectorPhase43R8DrawWiresWrapped){
    window.__vectorPhase43R8DrawWiresWrapped = true;
    window.drawWires = drawWires = function(){
      const ret = oldDrawWires43R8.apply(this, arguments);
      tagWires43R8();
      return ret;
    };
  }

  const oldRender43R8 = (typeof render === 'function') ? render : null;
  if(oldRender43R8 && !window.__vectorPhase43R8RenderWrapped){
    window.__vectorPhase43R8RenderWrapped = true;
    window.render = render = function(){
      const ret = oldRender43R8.apply(this, arguments);
      tagWires43R8();
      return ret;
    };
  }

  setTimeout(function(){
    tagWires43R8();
    try { if(typeof log === 'function') log('Phase 4.3R8 loaded: double-click delete now uses mousedown timing, so render-on-click cannot break it.'); } catch(e) {}
  }, 300);
})();

/* ============================================================
   Phase 4.3R9 - Editor State Refactor / Rewire Fix
   ------------------------------------------------------------
   Problem fixed:
   - After deleting a wire/component, the editor could remain in a stale
     wiring/selection state, so new wires could not be started from UNO pins
     or component pins.

   Approach:
   - Add one central editor-state reset function.
   - Force pin-click wiring through a capture-phase delegated handler so it
     survives DOM re-rendering.
   - Clean all temporary wiring classes after delete/render/draw operations.
   ============================================================ */
(function installPhase43R9EditorStateRefactor(){
  if(window.__vectorPhase43R9EditorStateInstalled) return;
  window.__vectorPhase43R9EditorStateInstalled = true;

  function logSafe43R9(msg){
    try { if(typeof log === 'function') log(msg); } catch(e) {}
  }

  function statusSafe43R9(msg){
    try { if(typeof status === 'function') status(msg); } catch(e) {}
  }

  function getProject43R9(){
    try { if(typeof project !== 'undefined' && project) return project; } catch(e) {}
    try { if(window.project) return window.project; } catch(e) {}
    return null;
  }

  function clearPinClasses43R9(){
    try {
      document.querySelectorAll('.pin.source,.pin.target').forEach(function(p){
        p.classList.remove('source');
        p.classList.remove('target');
      });
    } catch(e) {}
  }

  function resetEditorState43R9(reason){
    try { if(typeof wiringSource !== 'undefined') wiringSource = null; } catch(e) {}
    try { if(typeof wiringMouse !== 'undefined') wiringMouse = null; } catch(e) {}
    try { if(typeof currentWire !== 'undefined') currentWire = null; } catch(e) {}
    try { if(typeof selectedWire !== 'undefined') selectedWire = null; } catch(e) {}
    try { if(typeof dragWire !== 'undefined') dragWire = null; } catch(e) {}
    try { if(typeof isWiring !== 'undefined') isWiring = false; } catch(e) {}
    try { if(typeof drawingWire !== 'undefined') drawingWire = false; } catch(e) {}
    clearPinClasses43R9();
    window.VectorEditorState = {
      mode: 'idle',
      selectedComponent: (typeof selectedId !== 'undefined') ? selectedId : null,
      selectedWire: null,
      wireStart: null,
      wirePreview: null,
      dragging: false,
      drawingWire: false,
      lastResetReason: reason || 'manual'
    };
    statusSafe43R9('Click a pin to start wiring');
  }
  window.VectorResetEditorState = resetEditorState43R9;

  function validPinNode43R9(node){
    return typeof node === 'string' && node.length > 0 && !!document.querySelector('[data-node="' + CSS.escape(node) + '"]');
  }

  function startOrFinishWire43R9(node){
    const prj = getProject43R9();
    if(!prj || !validPinNode43R9(node)) return;

    // Start wiring from this pin.
    if(typeof wiringSource === 'undefined' || !wiringSource){
      wiringSource = node;
      try { wiringMouse = (typeof getNodePoint === 'function') ? getNodePoint(node) : null; } catch(e) { wiringMouse = null; }
      clearPinClasses43R9();
      document.querySelectorAll('.pin').forEach(function(p){
        p.classList.toggle('source', p.dataset && p.dataset.node === node);
      });
      window.VectorEditorState = {
        mode: 'wiring',
        selectedComponent: (typeof selectedId !== 'undefined') ? selectedId : null,
        selectedWire: null,
        wireStart: node,
        wirePreview: wiringMouse,
        dragging: false,
        drawingWire: true,
        lastResetReason: null
      };
      statusSafe43R9('Source ' + node + ' selected. Click destination pin.');
      try { if(typeof drawWires === 'function') drawWires(); } catch(e) {}
      return;
    }

    // Clicking the same source cancels wiring.
    if(wiringSource === node){
      resetEditorState43R9('same-pin-cancel');
      try { if(typeof drawWires === 'function') drawWires(); } catch(e) {}
      logSafe43R9('Wiring cancelled');
      return;
    }

    // Finish wire and reset fully, so another wire can be started immediately.
    const from = wiringSource;
    const to = node;
    try {
      if(typeof addWire === 'function') addWire(from, to);
      else {
        prj.wires = Array.isArray(prj.wires) ? prj.wires : [];
        prj.wires = prj.wires.filter(function(w){ return !(w.from === from && w.to === to); });
        prj.wires.push({from: from, to: to});
      }
      try { window.project = prj; } catch(e) {}
      logSafe43R9('Wire: ' + from + ' -> ' + to);
    } catch(e) {
      logSafe43R9('Wire add failed: ' + (e && e.message ? e.message : e));
    }
    resetEditorState43R9('wire-complete');
    try { if(typeof render === 'function') render(); else if(typeof drawWires === 'function') drawWires(); } catch(e) {}
  }

  // Capture-phase delegated pin click: this is the canonical wiring path now.
  // It does not depend on per-pin inline handlers surviving render().
  document.addEventListener('click', function(e){
    // Phase 4.3R10: disabled. Pin wiring is now handled by the canonical
    // mousedown handler installed below. The old click handler conflicted
    // after wire deletion and could cancel a newly started wire.
    return;
    const pin = e.target && e.target.closest ? e.target.closest('.pin') : null;
    if(!pin || !pin.dataset || !pin.dataset.node) return;
    // Ignore clicks inside UI panels that accidentally contain .pin-like elements.
    if(pin.closest('#componentPalette, #avrDigitalMonitor, #compilerPanel, #serialPanel')) return;
    e.preventDefault();
    e.stopPropagation();
    if(e.stopImmediatePropagation) e.stopImmediatePropagation();
    startOrFinishWire43R9(pin.dataset.node);
  }, true);

  // Escape key cleanly cancels any partial wiring operation.
  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape'){
      resetEditorState43R9('escape');
      try { if(typeof drawWires === 'function') drawWires(); } catch(err) {}
    }
  }, true);

  // Wrap deleteSelected so component deletion always resets the editor.
  if(typeof deleteSelected === 'function' && !window.__vectorPhase43R9DeleteSelectedWrapped){
    window.__vectorPhase43R9DeleteSelectedWrapped = true;
    const oldDeleteSelected43R9 = deleteSelected;
    window.deleteSelected = deleteSelected = function(){
      const ret = oldDeleteSelected43R9.apply(this, arguments);
      resetEditorState43R9('component-delete');
      try { if(typeof render === 'function') render(); } catch(e) {}
      return ret;
    };
  }

  // Wrap deleteWire for legacy double-click delete paths.
  if(typeof deleteWire === 'function' && !window.__vectorPhase43R9DeleteWireWrapped){
    window.__vectorPhase43R9DeleteWireWrapped = true;
    const oldDeleteWire43R9 = deleteWire;
    window.deleteWire = deleteWire = function(){
      const ret = oldDeleteWire43R9.apply(this, arguments);
      resetEditorState43R9('wire-delete');
      try { if(typeof render === 'function') render(); else if(typeof drawWires === 'function') drawWires(); } catch(e) {}
      return ret;
    };
  }

  // Wrap render/drawWires only to keep pin classes consistent after any redraw.
  if(typeof render === 'function' && !window.__vectorPhase43R9RenderWrapped){
    window.__vectorPhase43R9RenderWrapped = true;
    const oldRender43R9 = render;
    window.render = render = function(){
      const ret = oldRender43R9.apply(this, arguments);
      if(typeof wiringSource === 'undefined' || !wiringSource){
        clearPinClasses43R9();
      } else {
        document.querySelectorAll('.pin').forEach(function(p){
          p.classList.toggle('source', p.dataset && p.dataset.node === wiringSource);
        });
      }
      return ret;
    };
  }

  if(typeof drawWires === 'function' && !window.__vectorPhase43R9DrawWiresWrapped){
    window.__vectorPhase43R9DrawWiresWrapped = true;
    const oldDrawWires43R9 = drawWires;
    window.drawWires = drawWires = function(){
      const ret = oldDrawWires43R9.apply(this, arguments);
      if(typeof wiringSource === 'undefined' || !wiringSource){
        clearPinClasses43R9();
      }
      return ret;
    };
  }

  resetEditorState43R9('phase43r9-load');
  logSafe43R9('Phase 4.3R9 loaded: editor state reset + delegated pin wiring enabled.');
})();


/* ============================================================
   Phase 4.3R10 - Canonical Pin Wiring Repair
   ------------------------------------------------------------
   Root fix for: after deleting a wire, pins could not be rewired.

   Cause:
   - Older click-based and mousedown-based pin handlers coexisted.
   - After deletion/redraw, the stale click handler could cancel the wire
     that had just been started, so the UI looked like wiring was broken.

   Fix:
   - Disable the old Phase 4.3R9 click handler above.
   - Replace installPinHandlers() with one canonical mousedown wiring path.
   - Pin onclick is consumed only; it no longer changes wiring state.
   - Wire/component deletion resets all editor wiring state.
   ============================================================ */
(function installPhase43R10CanonicalPinWiring(){
  if(window.__vectorPhase43R10Installed) return;
  window.__vectorPhase43R10Installed = true;

  function logSafe(msg){ try { if(typeof log === 'function') log(msg); } catch(e) {} }
  function statusSafe(msg){ try { if(typeof status === 'function') status(msg); } catch(e) {} }
  function prj(){ try { if(typeof project !== 'undefined' && project) return project; } catch(e) {} return window.project || null; }

  function clearPinVisuals(){
    document.querySelectorAll('.pin').forEach(function(p){
      p.classList.remove('source');
      p.classList.remove('target');
    });
  }

  function resetWireState(reason){
    try { wiringSource = null; } catch(e) {}
    try { wiringMouse = null; } catch(e) {}
    try { wireBends = []; } catch(e) {}
    try { nextWireDirection = null; } catch(e) {}
    try { currentWire = null; } catch(e) {}
    try { dragWire = null; } catch(e) {}
    try { selectedWire = null; } catch(e) {}
    try { isWiring = false; } catch(e) {}
    try { drawingWire = false; } catch(e) {}
    clearPinVisuals();
    window.VectorEditorState = {
      mode: 'idle', selectedComponent: (typeof selectedId !== 'undefined') ? selectedId : null,
      selectedWire: null, wireStart: null, wirePreview: null,
      dragging: false, drawingWire: false, lastResetReason: reason || 'reset'
    };
    statusSafe('Click a pin to start wiring');
  }
  window.VectorResetEditorState = resetWireState;

  function nodeExists(node){
    if(!node) return false;
    try { return !!document.querySelector('[data-node="' + CSS.escape(node) + '"]'); }
    catch(e) { return !!document.querySelector('[data-node="' + String(node).replace(/"/g,'\\"') + '"]'); }
  }

  function markSource(node){
    clearPinVisuals();
    document.querySelectorAll('.pin').forEach(function(p){
      if(p.dataset && p.dataset.node === node) p.classList.add('source');
    });
  }

  function addProjectWire(from, to){
    const p = prj();
    if(!p) return false;
    p.wires = Array.isArray(p.wires) ? p.wires : [];
    // avoid exact duplicate only; reverse wiring is also treated as duplicate
    p.wires = p.wires.filter(function(w){
      return !((w.from === from && w.to === to) || (w.from === to && w.to === from));
    });
    p.wires.push({ from: from, to: to, bends: [] });
    try { window.project = p; } catch(e) {}
    return true;
  }

  function handlePinMouseDown(pin, e){
    if(!pin || !pin.dataset || !pin.dataset.node) return;
    if(pin.closest('#componentPalette, #canvasComponentPicker, #avrDigitalMonitor, #compilerPanel, #serialPanel')) return;

    e.preventDefault();
    e.stopPropagation();
    if(e.stopImmediatePropagation) e.stopImmediatePropagation();

    const node = pin.dataset.node;
    if(!nodeExists(node)) return;

    if(typeof wiringSource === 'undefined' || !wiringSource){
      wiringSource = node;
      try { wiringMouse = (typeof getNodePoint === 'function') ? getNodePoint(node) : null; } catch(err) { wiringMouse = null; }
      try { wireBends = []; } catch(err) {}
      markSource(node);
      window.VectorEditorState = {
        mode: 'wiring', selectedComponent: (typeof selectedId !== 'undefined') ? selectedId : null,
        selectedWire: null, wireStart: node, wirePreview: wiringMouse,
        dragging: false, drawingWire: true, lastResetReason: null
      };
      statusSafe('Source ' + node + ' selected. Click destination pin.');
      try { if(typeof drawWires === 'function') drawWires(); } catch(err) {}
      return;
    }

    if(wiringSource === node){
      resetWireState('same-pin-cancel');
      try { if(typeof drawWires === 'function') drawWires(); } catch(err) {}
      logSafe('Wiring cancelled');
      return;
    }

    const from = wiringSource;
    const to = node;
    if(addProjectWire(from, to)) logSafe('Wire: ' + from + ' -> ' + to);
    resetWireState('wire-complete');
    try { if(typeof render === 'function') render(); else if(typeof drawWires === 'function') drawWires(); } catch(err) {}
  }

  window.installPinHandlers = installPinHandlers = function(){
    document.querySelectorAll('.pin').forEach(function(pin){
      if(pin.__vectorPhase43R10Bound) return;
      pin.__vectorPhase43R10Bound = true;

      pin.onmouseenter = function(e){
        try { tip(e, pin.dataset.tip || pin.dataset.node); } catch(err) {}
        try { if(wiringSource && pin.dataset.node !== wiringSource) pin.classList.add('target'); } catch(err) {}
      };
      pin.onmousemove = function(e){ try { tip(e, pin.dataset.tip || pin.dataset.node); } catch(err) {} };
      pin.onmouseleave = function(){
        try { hideTip(); } catch(err) {}
        pin.classList.remove('target');
      };

      pin.onmousedown = function(e){ handlePinMouseDown(pin, e); };
      pin.onclick = function(e){
        // Consume legacy click. Wiring has already been handled on mousedown.
        e.preventDefault();
        e.stopPropagation();
        if(e.stopImmediatePropagation) e.stopImmediatePropagation();
      };
    });
  };

  // Keep preview wire following the cursor when a source is selected.
  document.addEventListener('mousemove', function(e){
    try {
      if(typeof wiringSource !== 'undefined' && wiringSource){
        if(typeof mousePoint === 'function') wiringMouse = mousePoint(e);
        if(typeof drawWires === 'function') drawWires();
      }
    } catch(err) {}
  }, true);

  // Escape cancels cleanly.
  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape'){
      resetWireState('escape');
      try { if(typeof drawWires === 'function') drawWires(); } catch(err) {}
    }
  }, true);

  // Make all delete paths reset wiring state.
  if(typeof deleteWire === 'function' && !window.__vectorPhase43R10DeleteWireWrapped){
    window.__vectorPhase43R10DeleteWireWrapped = true;
    const oldDeleteWire = deleteWire;
    window.deleteWire = deleteWire = function(){
      const ret = oldDeleteWire.apply(this, arguments);
      resetWireState('wire-delete');
      try { if(typeof drawWires === 'function') drawWires(); } catch(e) {}
      return ret;
    };
  }

  // Patch R8 direct deleters by resetting state after any mousedown double-delete.
  document.addEventListener('mousedown', function(e){
    // Run after capture deleters using a timeout, so if a delete occurred,
    // the next interaction always starts from a clean idle editor state.
    setTimeout(function(){
      const p = prj();
      if(!p) return;
      if(typeof wiringSource !== 'undefined' && wiringSource && !nodeExists(wiringSource)) resetWireState('deleted-source-cleanup');
    }, 0);
  }, true);

  setTimeout(function(){
    try { installPinHandlers(); } catch(e) {}
    resetWireState('phase43r10-load');
    logSafe('Phase 4.3R10 loaded: canonical mousedown pin wiring enabled; rewiring after delete fixed.');
  }, 100);
})();

/* ============================================================
   Phase 4.4A - Interactive Wire Editor
   ------------------------------------------------------------
   Adds:
   - Single-click wire selection
   - Drag selected wire route/bend path
   - Larger effective wire hit area via existing SVG group capture
   - Delete key removes selected wire
   - Escape cancels drag/selection/wiring state

   Design note:
   Wire endpoints remain attached to their original nodes. Dragging a
   straight wire creates a routed offset path using bend points. Dragging an
   already-routed wire translates its bend points only.
   ============================================================ */
(function installPhase44InteractiveWireEditor(){
  if(window.__vectorPhase44InteractiveWireEditorInstalled) return;
  window.__vectorPhase44InteractiveWireEditorInstalled = true;

  const WireEditor44 = {
    selectedWireIndex: -1,
    dragging: false,
    dragStart: null,
    originalBends: [],
    originalEndpoints: null,
    moved: false
  };
  window.VectorWireEditor = WireEditor44;

  function logSafe44(msg){ try { if(typeof log === 'function') log(msg); } catch(e) {} }
  function statusSafe44(msg){ try { if(typeof status === 'function') status(msg); } catch(e) {} }
  function prj44(){ try { if(typeof project !== 'undefined' && project) return project; } catch(e) {} return window.project || null; }

  function mousePoint44(e){
    try { if(typeof mousePoint === 'function') return mousePoint(e); } catch(err) {}
    const canvas = document.getElementById('canvas') || document.body;
    const r = canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }

  function wireGroups44(){
    const svg = document.getElementById('wires');
    if(!svg) return [];
    return Array.from(svg.children).filter(el => String(el.tagName).toLowerCase() === 'g');
  }

  function tagAndStyleWires44(){
    const p = prj44();
    const groups = wireGroups44();
    groups.forEach((g, idx) => {
      g.setAttribute('data-vector-wire-index', String(idx));
      if(g.dataset) g.dataset.vectorWireIndex = String(idx);
      g.classList.toggle('vector-wire-selected', idx === WireEditor44.selectedWireIndex);
      const lines = g.querySelectorAll('polyline');
      if(lines.length >= 2){
        const shadow = lines[0];
        const line = lines[1];
        if(idx === WireEditor44.selectedWireIndex){
          shadow.setAttribute('stroke', 'rgba(255,255,255,0.98)');
          shadow.setAttribute('stroke-width', '13');
          line.setAttribute('stroke', '#ff9800');
          line.setAttribute('stroke-width', '7');
        }
      }
      g.style.cursor = 'grab';
    });
  }

  function wireIndexFromElement44(el){
    const g = el && el.closest ? el.closest('#wires g') : null;
    if(!g) return -1;
    let idx = Number(g.getAttribute('data-vector-wire-index'));
    if(Number.isInteger(idx) && idx >= 0) return idx;
    return wireGroups44().indexOf(g);
  }

  function selectWire44(index){
    const p = prj44();
    if(!p || !Array.isArray(p.wires) || index < 0 || index >= p.wires.length){
      WireEditor44.selectedWireIndex = -1;
    } else {
      WireEditor44.selectedWireIndex = index;
    }
    tagAndStyleWires44();
    if(WireEditor44.selectedWireIndex >= 0) statusSafe44('Wire selected. Drag to move route, Delete to remove, Esc to cancel.');
  }

  function clearWireSelection44(){
    WireEditor44.selectedWireIndex = -1;
    WireEditor44.dragging = false;
    WireEditor44.dragStart = null;
    WireEditor44.originalBends = [];
    WireEditor44.originalEndpoints = null;
    WireEditor44.moved = false;
    tagAndStyleWires44();
  }

  function ensureWireBendsForDrag44(wire, dx, dy){
    const bends = Array.isArray(WireEditor44.originalBends) ? WireEditor44.originalBends : [];
    if(bends.length > 0){
      wire.bends = bends.map(pt => ({ x: pt.x + dx, y: pt.y + dy }));
      return;
    }

    const ep = WireEditor44.originalEndpoints;
    if(!ep || !ep.a || !ep.b){
      wire.bends = [];
      return;
    }

    // Dragging a straight wire creates a movable routed section while keeping
    // both endpoints electrically attached to their pins/components.
    wire.bends = [
      { x: ep.a.x + dx, y: ep.a.y + dy },
      { x: ep.b.x + dx, y: ep.b.y + dy }
    ];
  }

  function beginWireDrag44(index, e){
    const p = prj44();
    if(!p || !Array.isArray(p.wires) || index < 0 || index >= p.wires.length) return;
    const w = p.wires[index];
    WireEditor44.selectedWireIndex = index;
    WireEditor44.dragging = true;
    WireEditor44.moved = false;
    WireEditor44.dragStart = mousePoint44(e);
    WireEditor44.originalBends = Array.isArray(w.bends) ? w.bends.map(pt => ({x:pt.x, y:pt.y})) : [];
    let a = null, b = null;
    try { if(typeof getNodePoint === 'function'){ a = getNodePoint(w.from); b = getNodePoint(w.to); } } catch(err) {}
    WireEditor44.originalEndpoints = { a, b };
    tagAndStyleWires44();
    statusSafe44('Dragging selected wire...');
  }

  function updateWireDrag44(e){
    if(!WireEditor44.dragging) return;
    const p = prj44();
    const idx = WireEditor44.selectedWireIndex;
    if(!p || !Array.isArray(p.wires) || idx < 0 || idx >= p.wires.length) return;
    const now = mousePoint44(e);
    const dx = now.x - WireEditor44.dragStart.x;
    const dy = now.y - WireEditor44.dragStart.y;
    if(Math.abs(dx) + Math.abs(dy) > 2) WireEditor44.moved = true;
    ensureWireBendsForDrag44(p.wires[idx], dx, dy);
    try { if(typeof drawWires === 'function') drawWires(); } catch(err) {}
    tagAndStyleWires44();
  }

  function endWireDrag44(){
    if(!WireEditor44.dragging) return;
    WireEditor44.dragging = false;
    WireEditor44.dragStart = null;
    WireEditor44.originalBends = [];
    WireEditor44.originalEndpoints = null;
    try { if(typeof drawWires === 'function') drawWires(); } catch(err) {}
    tagAndStyleWires44();
    statusSafe44(WireEditor44.moved ? 'Wire route moved.' : 'Wire selected.');
  }

  function deleteSelectedWire44(){
    const p = prj44();
    const idx = WireEditor44.selectedWireIndex;
    if(!p || !Array.isArray(p.wires) || idx < 0 || idx >= p.wires.length) return false;
    p.wires.splice(idx, 1);
    clearWireSelection44();
    try { if(typeof window.VectorResetEditorState === 'function') window.VectorResetEditorState('wire-delete-key'); } catch(e) {}
    try { if(typeof render === 'function') render(); else if(typeof drawWires === 'function') drawWires(); } catch(e) {}
    logSafe44('Selected wire deleted');
    statusSafe44('Wire deleted. Click a pin to start wiring.');
    return true;
  }

  // Capture-phase wire select/drag. This coexists with the R8 double-click
  // mousedown delete logic: the second click is consumed by the delete path
  // before a drag begins.
  document.addEventListener('mousedown', function(e){
    if(e.button !== 0) return;
    const wireG = e.target && e.target.closest ? e.target.closest('#wires g') : null;
    if(!wireG) return;
    const idx = wireIndexFromElement44(wireG);
    if(idx < 0) return;

    // Do not block the existing R8 double-click delete path. Start drag only
    // after the current event dispatch has allowed earlier handlers to run.
    setTimeout(function(){
      const p = prj44();
      if(!p || !Array.isArray(p.wires) || idx >= p.wires.length) return;
      selectWire44(idx);
      beginWireDrag44(idx, e);
    }, 0);
  }, true);

  document.addEventListener('mousemove', function(e){
    updateWireDrag44(e);
  }, true);

  document.addEventListener('mouseup', function(){
    endWireDrag44();
  }, true);

  document.addEventListener('keydown', function(e){
    if(e.key === 'Delete' || e.key === 'Backspace'){
      if(WireEditor44.selectedWireIndex >= 0){
        e.preventDefault();
        e.stopPropagation();
        deleteSelectedWire44();
      }
      return;
    }
    if(e.key === 'Escape'){
      clearWireSelection44();
      try { if(typeof window.VectorResetEditorState === 'function') window.VectorResetEditorState('escape-wire-editor'); } catch(err) {}
      try { if(typeof drawWires === 'function') drawWires(); } catch(err) {}
      statusSafe44('Wire edit cancelled. Click a pin to start wiring.');
    }
  }, true);

  // Wrap drawWires/render so selected-wire highlighting survives redraws.
  if(typeof drawWires === 'function' && !window.__vectorPhase44DrawWiresWrapped){
    window.__vectorPhase44DrawWiresWrapped = true;
    const oldDrawWires44 = drawWires;
    window.drawWires = drawWires = function(){
      const ret = oldDrawWires44.apply(this, arguments);
      tagAndStyleWires44();
      return ret;
    };
  }

  if(typeof render === 'function' && !window.__vectorPhase44RenderWrapped){
    window.__vectorPhase44RenderWrapped = true;
    const oldRender44 = render;
    window.render = render = function(){
      const ret = oldRender44.apply(this, arguments);
      tagAndStyleWires44();
      return ret;
    };
  }

  // Add minimal CSS for selected wire feedback.
  const style = document.createElement('style');
  style.textContent = `
    #wires g.vector-wire-selected polyline:nth-child(2) {
      filter: drop-shadow(0 0 5px rgba(255,152,0,0.95));
    }
  `;
  document.head.appendChild(style);

  setTimeout(function(){
    tagAndStyleWires44();
    logSafe44('Phase 4.4A loaded: wire selection, drag routing, Delete key, and Esc cancel enabled.');
    statusSafe44('Phase 4.4A ready: click wire to select, drag to move route.');
  }, 300);
})();


/* ===== VectorArduinoSimulator LPC2129 Edition Patch ===== */
(function(){
  const LPC_PINS = Array.from({length:32},(_,i)=>'P0_'+i);
  window.LPC2129State = { IODIR:0, IOPIN:0 };
  function bit(pinName){ const m=String(pinName||'').match(/P0_(\d+)/); return m?Number(m[1]):-1; }
  function maskToPins(mask){ return LPC_PINS.filter(p => (mask >>> bit(p)) & 1); }
  function normalizeMask(expr, defines){
    let s=String(expr||'').trim().replace(/[uUlL]/g,'');
    Object.keys(defines).forEach(k => { s=s.replace(new RegExp('\\b'+k+'\\b','g'), '('+defines[k]+')'); });
    s=s.replace(/\(\s*1\s*<<\s*(\d+)\s*\)/g, '(1 << $1)');
    try { return (Function('return ('+s+');'))() >>> 0; } catch(e){ return 0; }
  }
  function parseDefines(code){
    const defs={}; let m; const re=/^\s*#define\s+([A-Za-z_]\w*)\s+([^\r\n]+)/gm;
    while((m=re.exec(code))) defs[m[1]]=m[2].replace(/\/\/.*$/,'').trim();
    return defs;
  }
  function setMask(mask,val){
    mask >>>= 0;
    if(val) window.LPC2129State.IOPIN = (window.LPC2129State.IOPIN | mask) >>> 0;
    else window.LPC2129State.IOPIN = (window.LPC2129State.IOPIN & (~mask)) >>> 0;
    if(typeof render==='function') render();
    updateLpcPinVisuals();
  }
  function nodeHigh(n){
    if(n==='uno.3V3'||n==='uno.5V'||n==='VCC'||n==='+5V') return true;
    const b=bit(String(n).replace('uno.',''));
    return b>=0 && (((window.LPC2129State.IOPIN>>>b)&1)===1);
  }
  function nodeLow(n){
    if(n==='uno.GND'||n==='GND'||n==='gnd') return true;
    const b=bit(String(n).replace('uno.',''));
    return b>=0 && (((window.LPC2129State.IOPIN>>>b)&1)===0);
  }
  function neighbors(node){
    const a=[node];
    if(!project||!project.wires) return a;
    project.wires.forEach(w=>{ if(w.from===node)a.push(w.to); if(w.to===node)a.push(w.from); });
    return a;
  }
  window.updateLpcExternalLoads=function(){
    if(!project||!project.parts) return;
    project.parts.forEach(p=>{
      if(p.type==='led'){
        const an=neighbors(p.id+'.A'), ca=neighbors(p.id+'.K');
        p.state = (an.some(nodeHigh)&&ca.some(nodeLow)) || (an.some(nodeLow)&&ca.some(nodeHigh)) ? HIGH : LOW;
      }
      if(p.type==='buzzer'){
        const sig=neighbors(p.id+'.SIG'); p.state = sig.some(nodeHigh)?HIGH:LOW;
      }
      if(p.type==='relay'){
        const sig=neighbors(p.id+'.IN'); p.state = sig.some(nodeHigh)?HIGH:LOW;
      }
    });
  };
  function updateLpcPinVisuals(){
    document.querySelectorAll('.lpc-pin').forEach(el=>{
      const b=bit(el.dataset.node.replace('uno.',''));
      if(b>=0 && ((window.LPC2129State.IOPIN>>>b)&1)) el.style.background='#00e676';
      else el.style.background='#ffd54f';
    });
    if(window.updateLpcExternalLoads) window.updateLpcExternalLoads();
  }
  const oldRender = window.render || (typeof render==='function'?render:null);
  if(oldRender){
    window.render = render = function(){ const r=oldRender(); updateLpcExternalLoads(); return r; };
  }
  window.newProject = newProject = function(){
    stopSimulation(); nextId=1; selectedId=null; wiringSource=null; wiringMouse=null;
    project={canvasScale:1, board:{x:95,y:70}, parts:[], wires:[], code:document.getElementById('code').value};
    document.querySelectorAll('.part').forEach(e=>e.remove());
    const p=addPart('led',{x:820,y:95,scale:1});
    addWire('uno.P0_10', p.id+'.A');
    addWire('uno.GND', p.id+'.K');
    applyCanvasZoom(); render(); clearLog(); clearSerial();
    log('VectorArduinoSimulator LPC2129 Edition ready. Default circuit: P0.10 -> LED anode, LED cathode -> GND.');
  };
  window.unifiedCompile = unifiedCompile = async function(){
    clearLog();
    const code=document.getElementById('code').value;
    log('LPC2129 code check started...');
    ['IODIR','IOSET','IOCLR'].forEach(x=>{ if(code.indexOf(x)<0) log('Note: '+x+' not found.'); });
    if(!/int\s+main\s*\(/.test(code)) log('Warning: int main(void) not found.');
    if(!/while\s*\(\s*1\s*\)/.test(code)) log('Warning: while(1) loop not found. Simulator runs best with while(1).');
    log('Code check completed for LPC2129 GPIO simulation. Hardware flashing is not enabled in this package.');
    return true;
  };
  async function lpcDelay(ms){ return new Promise(res=>{ const t=setTimeout(res, Math.max(1, Number(ms)||1)); timers.push(t); }); }
  window.runSimulation = runSimulation = async function(){
    stopSimulation(); clearSerial(); clearLog(); running=true; if(typeof setRunStopButtonState==='function') setRunStopButtonState(true);
    const code=document.getElementById('code').value; const defs=parseDefines(code);
    window.LPC2129State={IODIR:0, IOPIN:0};
    const dirRe=/IODIR\s*\|=\s*([^;]+);/g; let m;
    while((m=dirRe.exec(code))) window.LPC2129State.IODIR |= normalizeMask(m[1],defs);
    log('Simulation running for LPC2129. IODIR=0x'+window.LPC2129State.IODIR.toString(16).toUpperCase());
    const wm=code.match(/while\s*\(\s*1\s*\)\s*\{([\s\S]*?)\}/);
    if(!wm){ log('Runtime stopped: while(1){...} body not found.'); running=false; return; }
    const stmtRe=/(IOSET|IOCLR)\s*=\s*([^;]+);|delay_ms\s*\(\s*(\d+)\s*\)\s*;/g;
    const ops=[]; while((m=stmtRe.exec(wm[1]))){ if(m[1]) ops.push({type:m[1],mask:normalizeMask(m[2],defs)}); else ops.push({type:'delay',ms:Number(m[3])}); }
    if(!ops.length){ log('Runtime stopped: no IOSET/IOCLR/delay_ms statements found.'); running=false; return; }
    let cycles=0;
    while(running && cycles<100000){
      for(const op of ops){
        if(!running) break;
        if(op.type==='IOSET'){ setMask(op.mask,1); serialRaw('IOSET 0x'+op.mask.toString(16).toUpperCase()+' -> '+maskToPins(op.mask).join(', ')+'\n'); }
        else if(op.type==='IOCLR'){ setMask(op.mask,0); serialRaw('IOCLR 0x'+op.mask.toString(16).toUpperCase()+' -> '+maskToPins(op.mask).join(', ')+'\n'); }
        else if(op.type==='delay') await lpcDelay(op.ms);
      }
      cycles++;
    }
  };
  window.toggleRunStopSimulation = toggleRunStopSimulation = async function(){
    if(running){ stopSimulation(); log('Simulation stopped.'); if(typeof setRunStopButtonState==='function') setRunStopButtonState(false); return; }
    if(typeof setRunStopButtonState==='function') setRunStopButtonState(true);
    try{ await runSimulation(); }catch(e){ log('Runtime error: '+e.message); running=false; }
    if(typeof setRunStopButtonState==='function') setRunStopButtonState(false);
  };
  window.unifiedDetectBoard = unifiedDetectBoard = function(){ log('LPC2129 hardware detect is not enabled. Use simulation mode for classroom demo.'); };
  window.unifiedFlashBoard = unifiedFlashBoard = function(){ log('LPC2129 flash is not enabled in this browser package. Use Flash Magic/lpc21isp externally.'); };
  try{ newProject(); }catch(e){ console.warn(e); }
})();

/* ============================================================
   VECTOR LPC2129-ONLY PATCH
   Purpose:
   - Disable Arduino / AVR support from the base frontend.
   - Keep the existing UI/canvas/wiring behavior.
   - Build LPC2129 Embedded C to Intel HEX using arm-none-eabi-gcc.
   - Flash real LPC2129 hardware using Flash Magic ISP.
   ============================================================ */
window.VECTOR_LPC2129_ONLY = true;
window.lastLpc2129Hex = window.lastLpc2129Hex || "";
window.selectedUnoPort = "";
window.selectedBoardFqbn = "lpc2129";

function lpcPortSelect(){ return document.getElementById("boardSelect"); }

async function refreshLpcPorts(){
  clearLog();
  log("Refreshing COM ports for LPC2129 Flash Magic ISP...");
  const sel = lpcPortSelect();
  if(sel){ sel.innerHTML = '<option value="">Scanning...</option>'; }
  try{
    const r = await fetch("/api/ports");
    const d = await r.json();
    const ports = d.ports || [];
    if(sel){
      sel.innerHTML = '<option value="">Select COM</option>';
      ports.forEach(p=>{
        const opt=document.createElement("option");
        opt.value=p.path || p.port || p.comName || "";
        opt.textContent=(p.path || p.port || p.comName || "COM") + (p.manufacturer ? " - " + p.manufacturer : "");
        sel.appendChild(opt);
      });
    }
    if(!ports.length){ log("No COM ports found. Check USB-to-Serial cable and driver."); }
    else { log("COM ports refreshed."); }
    return ports;
  }catch(e){
    if(sel){ sel.innerHTML = '<option value="">COM error</option>'; }
    log("COM refresh failed: " + e.message);
    return [];
  }
}

async function compileLpc2129Hex(){
  clearLog();
  const codeEl = document.getElementById("code");
  const code = codeEl ? codeEl.value : "";
  const stEl = document.getElementById("sourceType");
  const sourceType = stEl ? stEl.value : "c";
  log("Building LPC2129 " + (sourceType === "assembly" ? "assembly" : "C") + " source with arm-none-eabi-gcc...");
  try{
    const r = await fetch("/api/build-hex",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({code, sourceType})
    });
    const d = await r.json();
    log(d.output || "");
    if(d.ok){
      window.lastLpc2129Hex = d.hex || "";
      window.lastLpc2129DebugListing = d.debugListing || '';
      window.lastLpc2129DebugMap = window.phase55BuildSourceMap ? window.phase55BuildSourceMap(window.lastLpc2129DebugListing) : null;
      const hexWin = document.getElementById("hexWindow") || document.getElementById("hexOutput");
      if(hexWin) hexWin.value = window.lastLpc2129Hex;
      log("HEX generated and loaded into HEX buffer.");
    }else{
      log("LPC2129 build failed.");
    }
    return !!d.ok;
  }catch(e){
    log("Build backend not running. Start with run_server.bat and open http://localhost:3000");
    log(e.message);
    return false;
  }
}

async function flashLpc2129FlashMagic(){
  const sel = lpcPortSelect();
  let port = sel ? sel.value : "";
  if(!port){
    log("No COM port selected. Refresh COM and select the LPC2129 ISP port.");
    await refreshLpcPorts();
    return false;
  }
  if(!window.lastLpc2129Hex){
    const ok = await compileLpc2129Hex();
    if(!ok) return false;
  }
  const baudSel = document.getElementById("baudSelect");
  const baud = baudSel ? baudSel.value : "9600";
  log("Flashing LPC2129 using Flash Magic ISP on " + port + "...");
  log("Put board in ISP mode before flashing: ISP pin active, reset board, then click Flash Magic ISP.");
  try{
    const r = await fetch("/api/flash",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({port, baud, oscMHz:"12.000", hex:window.lastLpc2129Hex})
    });
    const d = await r.json();
    log(d.output || "");
    log(d.ok ? "Flash Magic ISP completed." : "Flash Magic ISP failed.");
    return !!d.ok;
  }catch(e){
    log("Flash Magic ISP backend error: " + e.message);
    return false;
  }
}

async function detectUnoBoard(){ return refreshLpcPorts(); }
async function flashUnoBoard(){ return flashLpc2129FlashMagic(); }
async function unifiedCompile(){ return compileLpc2129Hex(); }
async function unifiedDetectBoard(){ return refreshLpcPorts(); }
async function unifiedFlashBoard(){ return flashLpc2129FlashMagic(); }
function switchTargetBoard(){
  const sel=document.getElementById("targetSelect");
  if(sel){ sel.value="lpc2129"; sel.disabled=true; }
  log("Target locked to LPC2129. Arduino/AVR support removed in this build.");
}

window.addEventListener("load",()=>{
  const sel=document.getElementById("targetSelect");
  if(sel){ sel.value="lpc2129"; sel.disabled=true; }
  setTimeout(()=>{ try{ refreshLpcPorts(); }catch(e){} },500);
  try{ log("LPC2129 Simulator ready. Arduino/AVR support is not present in this build."); }catch(e){}
});



/* Source type selector support: C source or GNU ARM assembly source. */
const lpc2129CExample = `/* LPC2129 LED Blink - C Source */
#define LED (1 << 10)   // P0.10

void delay_ms(unsigned int ms)
{
    volatile unsigned int i, j;
    for(i = 0; i < ms; i++)
        for(j = 0; j < 6000; j++);
}

int main(void)
{
    IODIR |= LED;
    while(1)
    {
        IOSET = LED;
        delay_ms(500);
        IOCLR = LED;
        delay_ms(500);
    }
}`;

const lpc2129AsmExample = `/* LPC2129 GPIO Toggle Test - GNU ARM Assembly
   File type: Assembly Source (.s)
*/
    .syntax unified
    .cpu arm7tdmi
    .arm

    .equ IOSET0,  0xE0028004
    .equ IODIR0,  0xE0028008
    .equ IOCLR0,  0xE002800C
    .equ IOSET1,  0xE0028014
    .equ IODIR1,  0xE0028018
    .equ IOCLR1,  0xE002801C

    .global main
    .global delay_ms

delay_ms:
    LDR     R1, =12000
    MUL     R0, R1, R0
1:
    SUBS    R0, R0, #1
    BNE     1b
    BX      LR

main:
    LDR     R0, =IODIR0
    LDR     R1, =0xFFFFFFFF
    STR     R1, [R0]
    LDR     R0, =IODIR1
    STR     R1, [R0]

main_loop:
    LDR     R0, =IOSET0
    LDR     R1, =0xFFFFFFFF
    STR     R1, [R0]
    LDR     R0, =IOSET1
    STR     R1, [R0]
    MOV     R0, #100
    BL      delay_ms

    LDR     R0, =IOCLR0
    LDR     R1, =0xFFFFFFFF
    STR     R1, [R0]
    LDR     R0, =IOCLR1
    STR     R1, [R0]
    MOV     R0, #100
    BL      delay_ms

    B       main_loop
`;

function updateSourceTypeUi(loadExample){
  const stEl = document.getElementById('sourceType');
  const codeEl = document.getElementById('code');
  const title = document.getElementById('codePanelTitle');
  const st = stEl ? stEl.value : 'c';
  if(title) title.textContent = st === 'assembly' ? 'LPC2129 GNU ARM Assembly Source' : 'LPC2129 Embedded C Code';
  if(loadExample && codeEl){
    const current = codeEl.value || '';
    const looksDefault = current.includes('LPC2129 LED Blink') || current.includes('LPC2129 GPIO Toggle Test - GNU ARM Assembly') || current.trim() === '';
    if(looksDefault) codeEl.value = st === 'assembly' ? lpc2129AsmExample : lpc2129CExample;
  }
  try{ log('Source type selected: ' + (st === 'assembly' ? 'Assembly Source (.s)' : 'C Source (.c)')); }catch(e){}
}

window.addEventListener('load',()=>{
  const stEl = document.getElementById('sourceType');
  if(stEl){
    stEl.addEventListener('change',()=>updateSourceTypeUi(true));
    updateSourceTypeUi(false);
  }
});

// Final global overrides after all legacy base-script definitions.
window.compileLpc2129Hex = compileLpc2129Hex;
window.refreshLpcPorts = refreshLpcPorts;
window.flashLpc2129FlashMagic = flashLpc2129FlashMagic;
window.unifiedCompile = compileLpc2129Hex;
window.detectUnoBoard = refreshLpcPorts;
window.unifiedDetectBoard = refreshLpcPorts;
window.flashUnoBoard = flashLpc2129FlashMagic;
window.unifiedFlashBoard = flashLpc2129FlashMagic;

/* ===== Phase 2B: LPC2129 HEX emulator + LPC2129 Digital I/O Monitor =====
   Full GPIO monitor model for LPC2129:
   - Port 0 available GPIO: P0.0-P0.25 and P0.27-P0.30.
   - Port 0 unavailable package GPIO bits: P0.26 and P0.31.
   - Port 1 available GPIO: P1.16-P1.31.
   - P0 aliases: IODIR/IOSET/IOCLR/IOPIN, IODIR0/IOSET0/IOCLR0/IOPIN0, IO0DIR/IO0SET/IO0CLR/IO0PIN.
   - P1 aliases: IODIR1/IOSET1/IOCLR1/IOPIN1, IO1DIR/IO1SET/IO1CLR/IO1PIN.
*/
const LPC_PORT0_AVAILABLE_GPIO_PINS = [
  0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,27,28,29,30
];
const LPC_PORT0_UNAVAILABLE_GPIO_PINS = [26,31];
const LPC_PORT1_AVAILABLE_GPIO_PINS = [16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
window.lpcGpio = window.lpcGpio || {
  p0:{IODIR:0, IOSET:0, IOCLR:0, IOPIN:0, externalInputs:{}},
  p1:{IODIR:0, IOSET:0, IOCLR:0, IOPIN:0, externalInputs:{}},
  running:false
};
window.lastLpc2129Hex = window.lastLpc2129Hex || "";
window.lastLpc2129Source = window.lastLpc2129Source || "";
window.lpcEmuTimer = null;
window.lpcEmuSteps = [];
window.lpcEmuStepIndex = 0;

function normalizeLpcGpioState(){
  // Upgrade old Phase 2A single-port state if present.
  if(!window.lpcGpio.p0){
    window.lpcGpio = {
      p0:{
        IODIR:(window.lpcGpio.IODIR||0)>>>0,
        IOSET:(window.lpcGpio.IOSET||0)>>>0,
        IOCLR:(window.lpcGpio.IOCLR||0)>>>0,
        IOPIN:(window.lpcGpio.IOPIN||0)>>>0,
        externalInputs:window.lpcGpio.externalInputs||{}
      },
      p1:{IODIR:0, IOSET:0, IOCLR:0, IOPIN:0, externalInputs:{}},
      running:!!window.lpcGpio.running
    };
  }
}
normalizeLpcGpioState();

function lpcPortObj(port){ normalizeLpcGpioState(); return port===1 ? window.lpcGpio.p1 : window.lpcGpio.p0; }
function lpcBit(pin){ return Math.pow(2, pin) >>> 0; }
function lpcHex32(v){ return '0x' + ((v>>>0).toString(16).toUpperCase().padStart(8,'0')); }
function lpcPinNode(port, pin){ return port===1 ? ('uno.P1_'+pin) : ('uno.P0_'+pin); }
function lpcNodeToPortPin(node){
  const m=String(node||'').match(/uno\.P([01])_(\d+)/);
  return m ? {port:Number(m[1]), pin:Number(m[2])} : null;
}
function lpcNodeToPin(node){ const pp=lpcNodeToPortPin(node); return pp && pp.port===0 ? pp.pin : null; }
function lpcIsGroundNode(n){ return /(^|\.)GND$|uno\.GND/i.test(String(n||'')); }
function lpcIsVccNode(n){ return /(^|\.)(3V3|VCC|VDD)$|uno\.3V3/i.test(String(n||'')); }

function lpcCellHtml(port, pin, disabled=false){
  const pid = `P${port}.${pin}`;
  if(disabled) return `<button class="gpioCell na" disabled><b>${pid}</b><span class="mode">N/A</span><span class="level">-</span></button>`;
  return `<button class="gpioCell" id="gpioCell_P${port}_${pin}" onclick="toggleLpcExternalInput(${port},${pin})" title="Click to toggle external input when this pin is configured as input"><b>${pid}</b><span class="mode">IN</span><span class="level">0</span></button>`;
}

function renderLpcGpioMonitor(){
  normalizeLpcGpioState();
  const grid0 = document.getElementById('lpcGpioGridP0') || document.getElementById('lpcGpioGrid');
  const grid1 = document.getElementById('lpcGpioGridP1');
  if(grid0 && !grid0.dataset.ready){
    const p0All=[];
    for(let i=0;i<32;i++){
      p0All.push(LPC_PORT0_AVAILABLE_GPIO_PINS.includes(i) ? lpcCellHtml(0,i,false) : lpcCellHtml(0,i,true));
    }
    grid0.innerHTML = p0All.join('');
    grid0.dataset.ready='1';
  }
  if(grid1 && !grid1.dataset.ready){
    grid1.innerHTML = LPC_PORT1_AVAILABLE_GPIO_PINS.map(pin => lpcCellHtml(1,pin,false)).join('');
    grid1.dataset.ready='1';
  }
  for(const [port,pins] of [[0,LPC_PORT0_AVAILABLE_GPIO_PINS],[1,LPC_PORT1_AVAILABLE_GPIO_PINS]]){
    const po = lpcPortObj(port);
    for(const pin of pins){
      const el = document.getElementById(`gpioCell_P${port}_${pin}`);
      if(!el) continue;
      const bit = lpcBit(pin);
      const out = !!(po.IODIR & bit);
      const high = !!(po.IOPIN & bit);
      el.className = 'gpioCell ' + (out?'out':'in') + ' ' + (high?'high':'low');
      el.querySelector('.mode').textContent = out ? 'OUT' : 'IN';
      el.querySelector('.level').textContent = high ? '1' : '0';
      el.title = `P${port}.${pin} | Direction: ${out?'OUT':'IN'} | Value: ${high?'1':'0'} | Function: GPIO`;
    }
  }
  const regs = document.getElementById('lpcRegs');
  if(regs){
    const p0=lpcPortObj(0), p1=lpcPortObj(1);
    regs.innerHTML =
      `IODIR0=${lpcHex32(p0.IODIR)} IOSET0=${lpcHex32(p0.IOSET)} IOCLR0=${lpcHex32(p0.IOCLR)} IOPIN0=${lpcHex32(p0.IOPIN)}<br>`+
      `IODIR1=${lpcHex32(p1.IODIR)} IOSET1=${lpcHex32(p1.IOSET)} IOCLR1=${lpcHex32(p1.IOCLR)} IOPIN1=${lpcHex32(p1.IOPIN)}`;
  }
}

function toggleLpcExternalInput(port, pin){
  normalizeLpcGpioState();
  const po = lpcPortObj(port);
  const bit = lpcBit(pin);
  if(po.IODIR & bit){ log(`P${port}.${pin} is output. External input toggle ignored.`); return; }
  po.externalInputs[pin] = !po.externalInputs[pin];
  if(po.externalInputs[pin]) po.IOPIN = (po.IOPIN | bit) >>> 0;
  else po.IOPIN = (po.IOPIN & ~bit) >>> 0;
  renderLpcGpioMonitor();
}
window.toggleLpcExternalInput = toggleLpcExternalInput;

function resetLpcGpioMonitor(){
  stopLpc2129HexEmulator(false);
  window.lpcGpio = {
    p0:{IODIR:0, IOSET:0, IOCLR:0, IOPIN:0, externalInputs:{}},
    p1:{IODIR:0, IOSET:0, IOCLR:0, IOPIN:0, externalInputs:{}},
    running:false
  };
  updateLpcConnectedComponents();
  renderLpcGpioMonitor();
  log('LPC2129 Digital I/O Monitor reset. P0 and P1 GPIO states cleared.');
}
window.resetLpcGpioMonitor = resetLpcGpioMonitor;

function lpcApplyOutputSet(port, mask){
  const po=lpcPortObj(port); mask >>>= 0;
  po.IOSET = mask;
  po.IOPIN = (po.IOPIN | (mask & po.IODIR)) >>> 0;
}
function lpcApplyOutputClear(port, mask){
  const po=lpcPortObj(port); mask >>>= 0;
  po.IOCLR = mask;
  po.IOPIN = (po.IOPIN & ~(mask & po.IODIR)) >>> 0;
}
function lpcApplyIODIR(port, mask, op){
  const po=lpcPortObj(port); mask >>>= 0;
  if(op === '=') po.IODIR = mask;
  else if(op === '&=') po.IODIR = (po.IODIR & mask) >>> 0;
  else po.IODIR = (po.IODIR | mask) >>> 0;
}
function lpcAssignIOPIN(port, mask){ lpcPortObj(port).IOPIN = mask >>> 0; }

function lpcEvalMask(expr){
  let e = String(expr||'');
  const code = document.getElementById('code') ? document.getElementById('code').value : '';
  const defs = [...code.matchAll(/^\s*#\s*define\s+(\w+)\s+([^\r\n]+)/gm)];
  for(const d of defs){
    const name = d[1];
    let val = d[2].replace(/\/\/.*$/,'').trim();
    if(!/^[0-9xXa-fA-FuUlL\s<>()|&~+\-*/]+$/.test(val)) continue;
    e = e.replace(new RegExp('\\b'+name+'\\b','g'), '('+val+')');
  }
  e = e.replace(/\bUL\b|\bU\b|\bL\b/gi,'');
  if(!/^[0-9xXa-fA-F\s<>()|&~+\-*/]+$/.test(e)) return 0;
  try{ return (Function('return ('+e+')'))() >>> 0; }catch(err){ return 0; }
}

function lpcRegisterInfo(reg){
  const r = String(reg||'').toUpperCase();
  const map = {
    'IODIR': ['dir',0], 'IOSET':['set',0], 'IOCLR':['clear',0], 'IOPIN':['pinassign',0],
    'IODIR0':['dir',0], 'IOSET0':['set',0], 'IOCLR0':['clear',0], 'IOPIN0':['pinassign',0],
    'IO0DIR':['dir',0], 'IO0SET':['set',0], 'IO0CLR':['clear',0], 'IO0PIN':['pinassign',0],
    'IODIR1':['dir',1], 'IOSET1':['set',1], 'IOCLR1':['clear',1], 'IOPIN1':['pinassign',1],
    'IO1DIR':['dir',1], 'IO1SET':['set',1], 'IO1CLR':['clear',1], 'IO1PIN':['pinassign',1]
  };
  const x = map[r];
  return x ? {kind:x[0], port:x[1]} : null;
}

function lpcParseStepsFromSource(code){
  const steps=[];
  const cleaned = String(code||'').replace(/\/\*[\s\S]*?\*\//g,'').replace(/\/\/.*$/gm,'');
  const preMain = cleaned.split(/while\s*\(\s*1\s*\)/)[0] || cleaned;
  const dirRe = /\b(IODIR0?|IO0DIR|IODIR1|IO1DIR)\s*(\|=|&=|=)\s*([^;]+);/gi;
  for(const m of preMain.matchAll(dirRe)){
    const ri=lpcRegisterInfo(m[1]); if(ri) steps.push({type:'iodir', port:ri.port, op:m[2], mask:lpcEvalMask(m[3])});
  }
  let body = cleaned;
  const wm = cleaned.match(/while\s*\(\s*1\s*\)\s*\{([\s\S]*)\}/m);
  if(wm) body = wm[1];
  const re = /\b(IODIR0?|IOSET0?|IOCLR0?|IOPIN0?|IO0DIR|IO0SET|IO0CLR|IO0PIN|IODIR1|IOSET1|IOCLR1|IOPIN1|IO1DIR|IO1SET|IO1CLR|IO1PIN)\s*(\|=|&=|=)?\s*([^;]+);|\bdelay_ms\s*\(\s*(\d+)\s*\)\s*;?/gi;
  for(const m of body.matchAll(re)){
    if(m[1]){
      const ri=lpcRegisterInfo(m[1]); if(!ri) continue;
      const op=m[2] || '=';
      const mask=lpcEvalMask(m[3]);
      if(ri.kind==='dir') steps.push({type:'iodir', port:ri.port, op, mask});
      else if(ri.kind==='set') steps.push({type:'set', port:ri.port, mask});
      else if(ri.kind==='clear') steps.push({type:'clear', port:ri.port, mask});
      else if(ri.kind==='pinassign') steps.push({type:'pinassign', port:ri.port, mask});
    }else if(m[4]){
      steps.push({type:'delay', ms:Math.max(1, Math.min(5000, Number(m[4]||1)))});
    }
  }
  if(!steps.length && /IOSET/i.test(code)) steps.push({type:'set',port:0,mask:lpcBit(10)},{type:'delay',ms:500},{type:'clear',port:0,mask:lpcBit(10)},{type:'delay',ms:500});
  return steps;
}

function updateLpcConnectedComponents(){
  if(!project || !project.parts || !project.wires) return;
  normalizeLpcGpioState();
  for(const p of project.parts){
    if(p.type !== 'led') continue;
    const aNode = p.id+'.A', kNode = p.id+'.K';
    const nets = project.wires.filter(w => w.from===aNode || w.to===aNode || w.from===kNode || w.to===kNode);
    let anodePP = null, cathodeGround = false, anodeVcc = false, cathodePP = null;
    for(const w of nets){
      const otherA = w.from===aNode ? w.to : (w.to===aNode ? w.from : null);
      const otherK = w.from===kNode ? w.to : (w.to===kNode ? w.from : null);
      if(otherA){ anodePP = lpcNodeToPortPin(otherA) || anodePP; anodeVcc = anodeVcc || lpcIsVccNode(otherA); }
      if(otherK){ cathodePP = lpcNodeToPortPin(otherK) || cathodePP; cathodeGround = cathodeGround || lpcIsGroundNode(otherK); }
    }
    let on = false;
    if(anodePP && cathodeGround) on = !!(lpcPortObj(anodePP.port).IOPIN & lpcBit(anodePP.pin));
    if(anodeVcc && cathodePP) on = !(lpcPortObj(cathodePP.port).IOPIN & lpcBit(cathodePP.pin));
    p.state = on ? HIGH : LOW;
  }
  try{ render(); }catch(e){}
}

function runLpcEmulatorStep(){
  normalizeLpcGpioState();
  if(!window.lpcGpio.running) return;
  if(!window.lpcEmuSteps.length){ stopLpc2129HexEmulator(); log('No LPC2129 GPIO operations detected in source.'); return; }
  const st = window.lpcEmuSteps[window.lpcEmuStepIndex++ % window.lpcEmuSteps.length];
  let delay = 40;
  if(st.type === 'iodir') lpcApplyIODIR(st.port||0, st.mask, st.op);
  else if(st.type === 'set') lpcApplyOutputSet(st.port||0, st.mask);
  else if(st.type === 'clear') lpcApplyOutputClear(st.port||0, st.mask);
  else if(st.type === 'pinassign') lpcAssignIOPIN(st.port||0, st.mask);
  else if(st.type === 'delay') delay = st.ms;
  renderLpcGpioMonitor();
  updateLpcConnectedComponents();
  window.lpcEmuTimer = setTimeout(runLpcEmulatorStep, delay);
}

function startLpc2129HexEmulator(){
  if(!window.lastLpc2129Hex){
    log('Build HEX first. The GPIO emulator starts only after HEX is generated.');
    return false;
  }
  stopLpc2129HexEmulator(false);
  const code = document.getElementById('code') ? document.getElementById('code').value : window.lastLpc2129Source || '';
  window.lpcEmuSteps = lpcParseStepsFromSource(code);
  window.lpcEmuStepIndex = 0;
  normalizeLpcGpioState();
  window.lpcGpio.running = true;
  running = true;
  const btn=document.getElementById('runStopBtn'); if(btn) btn.textContent='Stop Simulation';
  log('LPC2129 HEX emulator running. LPC2129 Digital I/O Monitor is updating P0/P1 from GPIO register operations.');
  runLpcEmulatorStep();
  return true;
}
function stopLpc2129HexEmulator(writeLog=true){
  if(window.lpcEmuTimer){ clearTimeout(window.lpcEmuTimer); window.lpcEmuTimer=null; }
  normalizeLpcGpioState();
  window.lpcGpio.running = false;
  running = false;
  const btn=document.getElementById('runStopBtn'); if(btn) btn.textContent='Run Simulation';
  if(writeLog) log('LPC2129 HEX emulator stopped.');
}
window.startLpc2129HexEmulator = startLpc2129HexEmulator;
window.stopLpc2129HexEmulator = stopLpc2129HexEmulator;
window.toggleRunStopSimulation = function(){
  normalizeLpcGpioState();
  if(window.lpcGpio && window.lpcGpio.running) stopLpc2129HexEmulator();
  else startLpc2129HexEmulator();
};

// Override project startup so no UNO D13 wiring is generated.
window.newProject = function(){
  stopLpc2129HexEmulator(false);
  nextId=1; selectedId=null; wiringSource=null; wiringMouse=null;
  project={canvasScale:1,parts:[],wires:[],code:document.getElementById('code').value};
  document.querySelectorAll('.part').forEach(e=>e.remove());
  const p=addPart('led',{x:780,y:95,scale:1});
  addWire(lpcPinNode(0,10),p.id+'.A');
  addWire('uno.GND',p.id+'.K');
  applyCanvasZoom();
  resetLpcGpioMonitor();
  render();
  clearLog(); clearSerial();
  log('Loaded LPC2129 P0.10 LED blink example. LPC2129 Digital I/O Monitor supports P0 and P1.');
};

// Compile override: keep source beside HEX so the semantic LPC emulator can run the generated HEX workflow.
window.compileLpc2129Hex = async function(){
  clearLog();
  const codeEl = document.getElementById('code');
  const code = codeEl ? codeEl.value : '';
  const stEl = document.getElementById('sourceType');
  const sourceType = stEl ? stEl.value : 'c';
  window.lastLpc2129Source = code;
  window.lastLpc2129SourceType = sourceType;
  log('Building LPC2129 ' + (sourceType === 'assembly' ? 'assembly' : 'C') + ' source with arm-none-eabi-gcc...');
  try{
    const r = await fetch('/api/build-hex',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code, sourceType})});
    const d = await r.json();
    log(d.output || '');
    if(d.ok){
      window.lastLpc2129Hex = d.hex || '';
      window.lastLpc2129DebugListing = d.debugListing || '';
      window.lastLpc2129DebugMap = window.phase55BuildSourceMap ? window.phase55BuildSourceMap(window.lastLpc2129DebugListing) : null;
      log('HEX generated. LPC2129 Digital I/O Monitor is ready for emulator run. Source-step map entries: ' + (window.lastLpc2129DebugMap ? window.lastLpc2129DebugMap.size : 0));
      renderLpcGpioMonitor();
    }else log('LPC2129 build failed.');
    return !!d.ok;
  }catch(e){ log('Build backend not running. Start with run_server.bat.'); log(e.message); return false; }
};
window.unifiedCompile = window.compileLpc2129Hex;

async function saveHexPreferredFolder(){
  if(!window.lastLpc2129Hex){
    const ok = await window.compileLpc2129Hex();
    if(!ok) return false;
  }
  const pnameEl=document.getElementById('projectName');
  const projectName=(pnameEl && pnameEl.value ? pnameEl.value : 'lpc2129_app').replace(/[^A-Za-z0-9_\-]/g,'_');
  const suggested = projectName + '.hex';
  const folderPath = prompt('Enter preferred folder path to save HEX file on server PC:', 'C:\\LPC2129_HEX');
  if(!folderPath){ log('HEX save cancelled.'); return false; }
  try{
    const r=await fetch('/api/save-hex',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({hex:window.lastLpc2129Hex, folderPath, fileName:suggested})});
    const d=await r.json();
    log(d.output || '');
    if(!d.ok) return false;
    return true;
  }catch(e){
    // Browser fallback when backend cannot write to the requested folder.
    const blob = new Blob([window.lastLpc2129Hex],{type:'text/plain'});
    const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=suggested; a.click(); URL.revokeObjectURL(a.href);
    log('Backend save failed, browser download fallback used: '+e.message);
    return false;
  }
}
window.saveHexPreferredFolder = saveHexPreferredFolder;

// Flash override retained for Flash Magic ISP.
window.flashLpc2129FlashMagic = async function(){
  const sel = lpcPortSelect();
  let port = sel ? sel.value : '';
  if(!port){ log('No COM port selected. Refresh COM and select LPC2129 ISP port.'); await refreshLpcPorts(); return false; }
  if(!window.lastLpc2129Hex){ const ok = await window.compileLpc2129Hex(); if(!ok) return false; }
  const baudSel = document.getElementById('baudSelect');
  const baud = baudSel ? baudSel.value : '9600';
  log('Flashing LPC2129 using Flash Magic ISP on '+port+'...');
  try{
    const r=await fetch('/api/flash',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({port, baud, oscMHz:'12.000', hex:window.lastLpc2129Hex})});
    const d=await r.json(); log(d.output || ''); log(d.ok?'Flash Magic ISP completed.':'Flash Magic ISP failed.'); return !!d.ok;
  }catch(e){ log('Flash Magic ISP backend error: '+e.message); return false; }
};
window.unifiedFlashBoard = window.flashLpc2129FlashMagic;
window.flashUnoBoard = window.flashLpc2129FlashMagic;

window.addEventListener('load',()=>{
  setTimeout(()=>{
    renderLpcGpioMonitor();
    const mon=document.getElementById('lpcGpioMonitor');
    if(mon) mon.style.display='block';
    try{ window.newProject(); }catch(e){ log('LPC project init warning: '+e.message); }
  },700);
});

/* ===== Phase 2C hotfix: LPC2129-only UI cleanup, draggable monitor, stronger GPIO source stepping ===== */
(function(){
  function removeAvrUi(){
    const patterns = [/avr/i, /arduino\s+uno/i, /digital\s+pins/i, /d0\s*-\s*d13/i];
    document.querySelectorAll('div,section,aside,button,span').forEach(el=>{
      if(el.id === 'lpcGpioMonitor' || (el.closest && el.closest('#lpcGpioMonitor'))) return;
      const txt = (el.textContent || '').trim();
      const idc = ((el.id||'') + ' ' + (el.className||'')).toString();
      if((/digitalPinMonitor|avr|unoLed|boardLed/i.test(idc) || patterns.some(p=>p.test(txt))) && !/LPC2129/i.test(txt)){
        // Remove floating legacy monitor panels; for ordinary controls only hide when clearly AVR related.
        if(/digitalPinMonitor|avr/i.test(idc) || /Digital Pins/i.test(txt)) el.remove();
      }
    });
  }
  window.removeAvrUi = removeAvrUi;

  // Make the LPC2129 Digital I/O Monitor draggable like the older monitor.
  function installLpcMonitorDrag(){
    const mon = document.getElementById('lpcGpioMonitor');
    if(!mon || mon.__lpcDragInstalled) return;
    mon.__lpcDragInstalled = true;
    const head = mon.querySelector('.gpioMonHead') || mon;
    head.title = 'Drag LPC2129 Digital I/O Monitor';
    head.style.cursor = 'move';
    mon.style.position = 'absolute';
    if(!mon.style.left) mon.style.left = '18px';
    if(!mon.style.top) mon.style.top = '18px';
    mon.style.right = 'auto';
    mon.style.zIndex = '50';
    let dragging = false, ox = 0, oy = 0;
    head.addEventListener('mousedown', function(e){
      if(e.target && e.target.tagName === 'BUTTON') return;
      dragging = true;
      const r = mon.getBoundingClientRect();
      ox = e.clientX - r.left;
      oy = e.clientY - r.top;
      e.preventDefault();
    });
    document.addEventListener('mousemove', function(e){
      if(!dragging) return;
      const parent = mon.offsetParent || document.body;
      const pr = parent.getBoundingClientRect();
      mon.style.left = Math.max(0, e.clientX - pr.left - ox) + 'px';
      mon.style.top = Math.max(0, e.clientY - pr.top - oy) + 'px';
    });
    document.addEventListener('mouseup', function(){ dragging = false; });
  }
  window.installLpcMonitorDrag = installLpcMonitorDrag;

  // Stronger expression evaluator for classroom LPC2129 examples.
  window.lpcEvalMask = function(expr){
    let e = String(expr||'');
    const code = document.getElementById('code') ? document.getElementById('code').value : '';
    const cleaned = code.replace(/\/\*[\s\S]*?\*\//g,'').replace(/\/\/.*$/gm,'');
    // Numeric #define constants, including aliases like LED, SW1, BIT10.
    for(const d of cleaned.matchAll(/^\s*#\s*define\s+(\w+)\s+([^\r\n]+)/gm)){
      const name = d[1];
      let val = d[2].trim().replace(/;$/,'');
      // Ignore address register macros, keep numeric masks only.
      if(/[A-Za-z_]\w*\s*\(/.test(val) && !/BIT|PIN|LED|SW/i.test(name)) continue;
      if(/0xE0/i.test(val) && /volatile|\*/i.test(val)) continue;
      if(/^[0-9xXa-fA-FuUlL\s<>()|&~+\-*/]+$/.test(val)){
        e = e.replace(new RegExp('\\b'+name+'\\b','g'), '('+val+')');
      }
    }
    // Local/global simple constants: unsigned int led = (1<<10);
    for(const d of cleaned.matchAll(/\b(?:unsigned\s+)?(?:long|int|char|short|uint32_t)\s+(\w+)\s*=\s*([^;]+);/g)){
      const name = d[1], val = d[2].trim();
      if(/^[0-9xXa-fA-FuUlL\s<>()|&~+\-*/]+$/.test(val)){
        e = e.replace(new RegExp('\\b'+name+'\\b','g'), '('+val+')');
      }
    }
    e = e.replace(/\b(UL|U|L)\b/gi,'');
    if(!/^[0-9xXa-fA-F\s<>()|&~+\-*/]+$/.test(e)) return 0;
    try{ return (Function('return ('+e+')'))() >>> 0; }catch(err){ return 0; }
  };

  // Re-parse code with the stronger evaluator. Supports P0/P1 aliases and delay loops.
  window.lpcParseStepsFromSource = function(code){
    const steps=[];
    const cleaned = String(code||'').replace(/\/\*[\s\S]*?\*\//g,'').replace(/\/\/.*$/gm,'');
    const preMain = cleaned.split(/while\s*\(\s*1\s*\)/)[0] || cleaned;
    const dirRe = /\b(IODIR0?|IO0DIR|IODIR1|IO1DIR)\s*(\|=|&=|=)\s*([^;]+);/gi;
    for(const m of preMain.matchAll(dirRe)){
      const ri = lpcRegisterInfo(m[1]); if(ri) steps.push({type:'iodir', port:ri.port, op:m[2], mask:window.lpcEvalMask(m[3])});
    }
    let body = cleaned;
    const wm = cleaned.match(/while\s*\(\s*1\s*\)\s*\{([\s\S]*)\}\s*$/m);
    if(wm) body = wm[1];
    const re = /\b(IODIR0?|IOSET0?|IOCLR0?|IOPIN0?|IO0DIR|IO0SET|IO0CLR|IO0PIN|IODIR1|IOSET1|IOCLR1|IOPIN1|IO1DIR|IO1SET|IO1CLR|IO1PIN)\s*(\|=|&=|=)?\s*([^;]+);|\b(?:delay_ms|delay)\s*\(\s*(\d+)?\s*\)\s*;?/gi;
    for(const m of body.matchAll(re)){
      if(m[1]){
        const ri = lpcRegisterInfo(m[1]); if(!ri) continue;
        const op = m[2] || '=';
        const mask = window.lpcEvalMask(m[3]);
        if(ri.kind==='dir') steps.push({type:'iodir', port:ri.port, op, mask});
        else if(ri.kind==='set') steps.push({type:'set', port:ri.port, mask});
        else if(ri.kind==='clear') steps.push({type:'clear', port:ri.port, mask});
        else if(ri.kind==='pinassign') steps.push({type:'pinassign', port:ri.port, mask});
      } else {
        steps.push({type:'delay', ms:Math.max(40, Math.min(5000, Number(m[4]||300)))});
      }
    }
    if(!steps.length && /IOSET/i.test(code)) steps.push({type:'iodir',port:0,op:'|=',mask:(1<<10)},{type:'set',port:0,mask:(1<<10)},{type:'delay',ms:500},{type:'clear',port:0,mask:(1<<10)},{type:'delay',ms:500});
    return steps;
  };

  // Ensure start uses the override parser.
  const oldStart = window.startLpc2129HexEmulator;
  window.startLpc2129HexEmulator = function(){
    removeAvrUi();
    installLpcMonitorDrag();
    return oldStart ? oldStart() : false;
  };
  window.toggleRunStopSimulation = function(){
    normalizeLpcGpioState();
    if(window.lpcGpio && window.lpcGpio.running) stopLpc2129HexEmulator();
    else window.startLpc2129HexEmulator();
  };

  window.addEventListener('load', function(){
    setTimeout(function(){
      removeAvrUi();
      installLpcMonitorDrag();
      try{ renderLpcGpioMonitor(); }catch(e){}
      try{ log('Phase 2C loaded: Digital I/O Monitor removed; GPIO simulation supports P0/P1.'); }catch(e){}
    }, 1000);
  });
})();

/* ============================================================
   PHASE 4C - ARM7TDMI-S LIVE PROFILER + INSTRUCTION COVERAGE
   - ARM state 32-bit decode classes for ARMv4T / ARM7TDMI-S.
   - THUMB state 16-bit decode classes for ARMv4T.
   - Functional execution for classroom GPIO/loop/startup code and
     broad core integer/load-store/branch instructions.
   - Coprocessor/SWI/undefined classes are decoded and trapped safely
     instead of crashing the UI.
   ============================================================ */
(function(){
  const IO0PIN=0xE0028000>>>0, IO0SET=0xE0028004>>>0, IO0DIR=0xE0028008>>>0, IO0CLR=0xE002800C>>>0;
  const IO1PIN=0xE0028010>>>0, IO1SET=0xE0028014>>>0, IO1DIR=0xE0028018>>>0, IO1CLR=0xE002801C>>>0;
  const RAM_BASE=0x40000000>>>0, RAM_SIZE=16*1024, FLASH_SIZE=256*1024;
  const ARM_COND=['EQ','NE','CS','CC','MI','PL','VS','VC','HI','LS','GE','LT','GT','LE','AL','NV'];
  const DP=['AND','EOR','SUB','RSB','ADD','ADC','SBC','RSC','TST','TEQ','CMP','CMN','ORR','MOV','BIC','MVN'];
  function u32(x){ return x>>>0; }
  function s32(x){ return x|0; }
  function sx(v,b){ const s=32-b; return (v<<s)>>s; }
  function h8(x){ return '0x'+u32(x).toString(16).toUpperCase().padStart(8,'0'); }
  function safeLog(s){ try{ if(typeof log==='function') log(s); }catch(e){} }

  class LPC2129Arm7Emu{
    constructor(){ this.reset(); }
    reset(){
      this.r=new Uint32Array(16); this.cpsr={N:0,Z:0,C:0,V:0,T:0,mode:0x13};
      this.flash=new Uint8Array(FLASH_SIZE); this.ram=new Uint8Array(RAM_SIZE); this.flash.fill(0xFF); this.ram.fill(0);
      this.gpio={IO0PIN:0,IO0SET:0,IO0DIR:0,IO0CLR:0,IO1PIN:0,IO1SET:0,IO1DIR:0,IO1CLR:0};
      this.running=false; this.steps=0; this.loaded=false; this.disasm=''; this.lastError=''; this.decodeStats={ARM:{},THUMB:{}}; this.unsupportedCount=0; this.lastUnsupported=null;
      this.profiler={totalCycles:0,totalInstructions:0,armInstructions:0,thumbInstructions:0,lastMode:'ARM',lastPC:0,lastOpcode:'-',lastFamily:'-',families:{}};
      this.r[15]=0; this.r[13]=RAM_BASE+RAM_SIZE;
    }
    loadIntelHex(hex){
      this.reset(); let ext=0, bytes=0; const lines=String(hex||'').trim().split(/\r?\n/).filter(Boolean);
      for(const [idx,line0] of lines.entries()){
        const line=line0.trim(); if(!line.startsWith(':')) throw new Error('HEX line '+(idx+1)+' missing colon');
        const n=parseInt(line.substr(1,2),16), off=parseInt(line.substr(3,4),16), type=parseInt(line.substr(7,2),16);
        let sum=n+((off>>8)&255)+(off&255)+type; const data=[];
        for(let i=0;i<n;i++){ const b=parseInt(line.substr(9+i*2,2),16); data.push(b); sum+=b; }
        const chk=parseInt(line.substr(9+n*2,2),16); if(((sum+chk)&255)!==0) throw new Error('HEX checksum error at line '+(idx+1));
        if(type===0){ const a=(ext+off)>>>0; for(let i=0;i<data.length;i++){ this.writeByteRaw(a+i,data[i]); bytes++; } }
        else if(type===1) break; else if(type===4) ext=((data[0]<<24)|(data[1]<<16))>>>0; else if(type===2) ext=(((data[0]<<8)|data[1])<<4)>>>0;
        else if(type===5) this.r[15]=((data[0]<<24)|(data[1]<<16)|(data[2]<<8)|data[3])>>>0;
      }
      this.loaded=true; return bytes;
    }
    estimateCycles(mode,name){
      if(name==='MUL'||name==='MLA')return 3;
      if(['UMULL','UMLAL','SMULL','SMLAL'].includes(name))return 5;
      if(['LDR','STR','LDRB','STRB','SDT_LOAD','SDT_STORE','LDRH/S','STRH'].includes(name))return 3;
      if(['LDM','STM','BDT_LOAD','BDT_STORE','LDMIA','STMIA','PUSH','POP'].includes(name))return 4;
      if(['B','BL','BX','BLX_REG','B_COND','BL_PREFIX','BL_SUFFIX'].includes(name))return 3;
      if(String(name).includes('UNSUPPORTED'))return 1;
      return 1;
    }
    stat(mode,name){
      const m=this.decodeStats[mode]; m[name]=(m[name]||0)+1;
      const cycles=this.estimateCycles(mode,name);
      this.profiler.totalInstructions++;
      if(mode==='ARM')this.profiler.armInstructions++; else this.profiler.thumbInstructions++;
      this.profiler.totalCycles+=cycles;
      const key=mode+' '+name;
      const f=this.profiler.families[key]||(this.profiler.families[key]={decode:0,execute:0,cycles:0,lastPC:0,lastOpcode:'-'});
      f.decode++; f.execute++; f.cycles+=cycles; f.lastPC=this.currentPC>>>0; f.lastOpcode=this.currentOpcodeText||'-';
      this.profiler.lastMode=mode; this.profiler.lastPC=this.currentPC>>>0; this.profiler.lastOpcode=this.currentOpcodeText||'-'; this.profiler.lastFamily=name;
      try{
        window.phase5Trace=window.phase5Trace||[];
        if(window.phase5Trace.length<300 || (this.steps%1000)===0){
          window.phase5Trace.push({step:this.steps,mode,pc:this.currentPC>>>0,opcode:this.currentOpcodeText||'-',family:name,cycles:this.profiler.totalCycles});
          if(window.phase5Trace.length>300) window.phase5Trace.shift();
        }
      }catch(e){}
    }
    reportUnsupported(mode,addr,opcode,family,detail){
      this.unsupportedCount=(this.unsupportedCount||0)+1;
      const opText=mode==='THUMB'?('0x'+(opcode&0xFFFF).toString(16).toUpperCase().padStart(4,'0')):h8(opcode);
      this.lastUnsupported={mode,pc:u32(addr),opcode:opText,family:family||'UNKNOWN',detail:detail||'No executor implemented'};
      const msg='Unsupported instruction detected: Mode='+mode+' PC='+h8(addr)+' Opcode='+opText+' Family='+(family||'UNKNOWN')+' Detail='+(detail||'No executor implemented');
      this.disasm=msg;
      safeLog(msg);
      throw new Error(msg);
    }
    writeByteRaw(a,b){ a=u32(a); if(a<FLASH_SIZE)this.flash[a]=b&255; else if(a>=RAM_BASE&&a<RAM_BASE+RAM_SIZE)this.ram[a-RAM_BASE]=b&255; }
    read8(a){ a=u32(a); try{if(typeof window.phase82PeripheralRead==='function'&&window.phase82IsPeripheralAddress&&window.phase82IsPeripheralAddress(a))return window.phase82PeripheralRead(this,a,8)&0xFF;}catch(e){} if(a<FLASH_SIZE)return this.flash[a]; if(a>=RAM_BASE&&a<RAM_BASE+RAM_SIZE)return this.ram[a-RAM_BASE]; return 0; }
    write8(a,b){ a=u32(a); try{if(typeof window.phase82PeripheralWrite==='function'&&window.phase82IsPeripheralAddress&&window.phase82IsPeripheralAddress(a)){window.phase82PeripheralWrite(this,a,b&0xFF,8);return;}}catch(e){} if(a>=RAM_BASE&&a<RAM_BASE+RAM_SIZE)this.ram[a-RAM_BASE]=b&255; }
    read16(a){ a=u32(a&~1); try{if(typeof window.phase82PeripheralRead==='function'&&window.phase82IsPeripheralAddress&&window.phase82IsPeripheralAddress(a))return window.phase82PeripheralRead(this,a,16)&0xFFFF;}catch(e){} return this.read8(a)|(this.read8(a+1)<<8); }
    write16(a,v){ a=u32(a&~1); try{if(typeof window.phase82PeripheralWrite==='function'&&window.phase82IsPeripheralAddress&&window.phase82IsPeripheralAddress(a)){window.phase82PeripheralWrite(this,a,v&0xFFFF,16);return;}}catch(e){} this.write8(a,v); this.write8(a+1,v>>>8); }
    read32(a){ a=u32(a&~3); if(this.isGpio(a))return this.gpioRead(a); try{if(typeof window.phase82PeripheralRead==='function'&&window.phase82IsPeripheralAddress&&window.phase82IsPeripheralAddress(a))return u32(window.phase82PeripheralRead(this,a,32));}catch(e){} return u32(this.read8(a)|(this.read8(a+1)<<8)|(this.read8(a+2)<<16)|(this.read8(a+3)<<24)); }
    write32(a,v){ a=u32(a&~3); v=u32(v); if(this.isGpio(a))return this.gpioWrite(a,v); try{if(typeof window.phase82PeripheralWrite==='function'&&window.phase82IsPeripheralAddress&&window.phase82IsPeripheralAddress(a)){window.phase82PeripheralWrite(this,a,v,32);return;}}catch(e){} if(a>=RAM_BASE&&a<RAM_BASE+RAM_SIZE-3){ this.write8(a,v); this.write8(a+1,v>>>8); this.write8(a+2,v>>>16); this.write8(a+3,v>>>24); } }
    isGpio(a){ a=u32(a); return (a>=IO0PIN&&a<=IO0CLR&&((a-IO0PIN)&3)===0)||(a>=IO1PIN&&a<=IO1CLR&&((a-IO1PIN)&3)===0); }
    gpioRead(a){
      if((a>>>0)===IO0PIN || (a>>>0)===IO1PIN){
        try{ if(typeof window.phase80SampleExternalInputs==='function') window.phase80SampleExternalInputs(this); }catch(e){}
      }
      switch(a>>>0){case IO0PIN:return this.gpio.IO0PIN>>>0;case IO0SET:return this.gpio.IO0SET>>>0;case IO0DIR:return this.gpio.IO0DIR>>>0;case IO0CLR:return this.gpio.IO0CLR>>>0;case IO1PIN:return this.gpio.IO1PIN>>>0;case IO1SET:return this.gpio.IO1SET>>>0;case IO1DIR:return this.gpio.IO1DIR>>>0;case IO1CLR:return this.gpio.IO1CLR>>>0;} return 0;
    }
    gpioName(a){ switch(a>>>0){case IO0PIN:return'IO0PIN';case IO0SET:return'IO0SET';case IO0DIR:return'IO0DIR';case IO0CLR:return'IO0CLR';case IO1PIN:return'IO1PIN';case IO1SET:return'IO1SET';case IO1DIR:return'IO1DIR';case IO1CLR:return'IO1CLR';} return h8(a); }
    gpioWrite(a,v){
      a=u32(a); v=u32(v); const b0=this.gpio.IO0PIN>>>0,b1=this.gpio.IO1PIN>>>0;
      switch(a>>>0){
        case IO0DIR:this.gpio.IO0DIR=v;break; case IO0SET:this.gpio.IO0SET=v;this.gpio.IO0PIN=u32(this.gpio.IO0PIN|(v&this.gpio.IO0DIR));break; case IO0CLR:this.gpio.IO0CLR=v;this.gpio.IO0PIN=u32(this.gpio.IO0PIN&~(v&this.gpio.IO0DIR));break; case IO0PIN:this.gpio.IO0PIN=u32((this.gpio.IO0PIN&~this.gpio.IO0DIR)|(v&this.gpio.IO0DIR));break;
        case IO1DIR:this.gpio.IO1DIR=v;break; case IO1SET:this.gpio.IO1SET=v;this.gpio.IO1PIN=u32(this.gpio.IO1PIN|(v&this.gpio.IO1DIR));break; case IO1CLR:this.gpio.IO1CLR=v;this.gpio.IO1PIN=u32(this.gpio.IO1PIN&~(v&this.gpio.IO1DIR));break; case IO1PIN:this.gpio.IO1PIN=u32((this.gpio.IO1PIN&~this.gpio.IO1DIR)|(v&this.gpio.IO1DIR));break;
      }
      this.lastGpioWrite=this.gpioName(a)+' <= '+h8(v)+'  P0='+h8(this.gpio.IO0PIN)+' P1='+h8(this.gpio.IO1PIN); this.gpioWriteCount=(this.gpioWriteCount||0)+1;
      if(b0!==this.gpio.IO0PIN||b1!==this.gpio.IO1PIN){
        this.gpioPinChangeCount=(this.gpioPinChangeCount||0)+1;
        this.lastGpioTransitionCycles=this.profiler.totalCycles||0;
        this.lastGpioTransitionPort0=this.gpio.IO0PIN>>>0;
        this.lastGpioTransitionPort1=this.gpio.IO1PIN>>>0;
      }
      if((b0!==this.gpio.IO0PIN||b1!==this.gpio.IO1PIN||/DIR$/.test(this.gpioName(a)))&&(this.gpioWriteCount<=80||(this.gpioWriteCount%1000)===0)) safeLog('GPIO WRITE: '+this.lastGpioWrite);
      const physicalChanged=(b0!==(this.gpio.IO0PIN>>>0))||(b1!==(this.gpio.IO1PIN>>>0));
      const dirChanged=(a===IO0DIR)||(a===IO1DIR);
      if(physicalChanged||dirChanged) syncGpioFromEmu(this);
    }
    condOK(c){ const {N,Z,C,V}=this.cpsr; return [Z===1,Z===0,C===1,C===0,N===1,N===0,V===1,V===0,C===1&&Z===0,C===0||Z===1,N===V,N!==V,Z===0&&N===V,Z===1||N!==V,true,false][c]; }
    getReg(i,addr){ return i===15?u32(addr+(this.cpsr.T?4:8)):this.r[i]>>>0; }
    setNZ(v){ v=u32(v); this.cpsr.N=(v>>>31)&1; this.cpsr.Z=v===0?1:0; }
    setAddFlags(a,b,r){ this.cpsr.C=((a>>>0)+(b>>>0))>0xFFFFFFFF?1:0; this.cpsr.V=(((~(a^b))&(a^r))>>>31)&1; }
    setSubFlags(a,b,r){ this.cpsr.C=(a>>>0)>=(b>>>0)?1:0; this.cpsr.V=(((a^b)&(a^r))>>>31)&1; }
    ror(v,n){ n&=31; return n?u32((v>>>n)|(v<<(32-n))):u32(v); }
    shifterOperand(ins,addr){
      if((ins>>>25)&1){ const imm=ins&255, rot=((ins>>>8)&15)*2; const val=this.ror(imm,rot); return {val,carry:rot?((val>>>31)&1):this.cpsr.C}; }
      const rm=ins&15; let val=this.getReg(rm,addr); const type=(ins>>>5)&3; let amount=((ins>>>4)&1)?(this.r[(ins>>>8)&15]&255):((ins>>>7)&31); let carry=this.cpsr.C;
      if(amount===0){ if(type===3){carry=val&1; val=u32((carry?0x80000000:0)|(val>>>1));} return {val:u32(val),carry}; }
      if(type===0){ carry=amount>32?0:((val>>>(32-amount))&1); val=amount>=32?0:u32(val<<amount); }
      else if(type===1){ carry=amount>32?0:((val>>>(amount-1))&1); val=amount>=32?0:u32(val>>>amount); }
      else if(type===2){ carry=amount>32?(val>>>31):((val>>>(amount-1))&1); val=amount>=32?(val&0x80000000?0xFFFFFFFF:0):u32(s32(val)>>amount); }
      else { amount&=31; carry=(val>>>(amount?amount-1:31))&1; val=this.ror(val,amount); }
      return {val:u32(val),carry};
    }
    cpsrValue(){ return ((this.cpsr.N<<31)|(this.cpsr.Z<<30)|(this.cpsr.C<<29)|(this.cpsr.V<<28)|(this.cpsr.T<<5)|(this.cpsr.mode&31))>>>0; }
    setCpsrValue(v){ this.cpsr.N=(v>>>31)&1; this.cpsr.Z=(v>>>30)&1; this.cpsr.C=(v>>>29)&1; this.cpsr.V=(v>>>28)&1; this.cpsr.T=(v>>>5)&1; this.cpsr.mode=v&31; }
    step(){ return this.cpsr.T?this.stepThumb():this.stepArm(); }
    stepArm(){
      const addr=this.r[15]>>>0, ins=this.read32(addr); this.currentPC=addr; this.currentOpcodeText=h8(ins); this.r[15]=u32(addr+4); this.steps++;
      if(this.steps<=120) safeLog('TRACE '+this.steps+': ARM PC='+h8(addr)+' INS='+h8(ins));
      const cond=ins>>>28; if(!this.condOK(cond)){ this.stat('ARM','COND_SKIP'); this.disasm='ARM '+ARM_COND[cond]+' skipped'; return true; }
      // Branch / BL
      if((ins&0x0E000000)===0x0A000000){ const L=(ins>>>24)&1; const off=sx(ins&0x00FFFFFF,24)<<2; if(L)this.r[14]=u32(addr+4); this.r[15]=u32(addr+8+off); this.stat('ARM',L?'BL':'B'); this.disasm=(L?'BL':'B')+' '+h8(this.r[15]); return true; }
      // BX / BLX register (ARMv4T has BX; BLX is safely decoded)
      if((ins&0x0FFFFFF0)===0x012FFF10 || (ins&0x0FFFFFF0)===0x012FFF30){ const rm=ins&15,t=this.r[rm]>>>0; this.cpsr.T=t&1; this.r[15]=t&~1; this.stat('ARM',(ins&0x20)?'BLX_REG':'BX'); this.disasm='BX/BLX R'+rm; return true; }
      // SWP/SWPB
      if((ins&0x0FB00FF0)===0x01000090){ const B=(ins>>>22)&1,rn=(ins>>>16)&15,rd=(ins>>>12)&15,rm=ins&15,a=this.r[rn]>>>0; const old=B?this.read8(a):this.read32(a); if(B)this.write8(a,this.r[rm]); else this.write32(a,this.r[rm]); this.r[rd]=old>>>0; this.stat('ARM',B?'SWPB':'SWP'); this.disasm=(B?'SWPB':'SWP')+' R'+rd; return true; }
      // Multiply / multiply long
      if((ins&0x0FC000F0)===0x00000090){ const A=(ins>>>21)&1,S=(ins>>>20)&1,rd=(ins>>>16)&15,rn=(ins>>>12)&15,rs=(ins>>>8)&15,rm=ins&15; let res=Math.imul(this.r[rm],this.r[rs])>>>0; if(A)res=u32(res+this.r[rn]); this.r[rd]=res; if(S)this.setNZ(res); this.stat('ARM',A?'MLA':'MUL'); this.disasm=(A?'MLA':'MUL')+' R'+rd; return true; }
      if((ins&0x0F8000F0)===0x00800090){ const U=(ins>>>22)&1,A=(ins>>>21)&1,S=(ins>>>20)&1,rdHi=(ins>>>16)&15,rdLo=(ins>>>12)&15,rs=(ins>>>8)&15,rm=ins&15; let prod;
        if(U) prod=BigInt(this.r[rm]>>>0)*BigInt(this.r[rs]>>>0); else prod=BigInt(s32(this.r[rm]))*BigInt(s32(this.r[rs]));
        if(A) prod += (BigInt(this.r[rdHi]>>>0)<<32n)+BigInt(this.r[rdLo]>>>0);
        this.r[rdLo]=Number(prod&0xFFFFFFFFn)>>>0; this.r[rdHi]=Number((prod>>32n)&0xFFFFFFFFn)>>>0; if(S){this.cpsr.N=(this.r[rdHi]>>>31)&1;this.cpsr.Z=(this.r[rdHi]===0&&this.r[rdLo]===0)?1:0;} this.stat('ARM',(U?'U':'S')+(A?'MLAL':'MULL')); this.disasm='MULL'; return true; }
      // MRS/MSR
      if((ins&0x0FBF0FFF)===0x010F0000){ const rd=(ins>>>12)&15; this.r[rd]=this.cpsrValue(); this.stat('ARM','MRS'); this.disasm='MRS R'+rd; return true; }
      if((ins&0x0DB0F000)===0x0120F000 || (ins&0x0DB0F000)===0x0320F000){ const rm=ins&15; const val=((ins>>>25)&1)?this.shifterOperand(ins,addr).val:this.r[rm]; this.setCpsrValue(val); this.stat('ARM','MSR'); this.disasm='MSR CPSR'; return true; }
      // Halfword/signed transfer LDRH/STRH/LDRSB/LDRSH
      if((ins&0x0E000090)===0x00000090 && (ins&0x60)!==0){ const P=(ins>>>24)&1,U=(ins>>>23)&1,I=(ins>>>22)&1,W=(ins>>>21)&1,L=(ins>>>20)&1,rn=(ins>>>16)&15,rd=(ins>>>12)&15; const sh=(ins>>>5)&3; let off=I?(((ins>>>4)&0xF0)|(ins&0xF)):(this.r[ins&15]>>>0); let base=this.getReg(rn,addr), ea=P?(U?u32(base+off):u32(base-off)):base; if(L){ let v; if(sh===1)v=this.read16(ea); else if(sh===2)v=sx(this.read8(ea),8); else v=sx(this.read16(ea),16); this.r[rd]=u32(v); } else { if(sh===1)this.write16(ea,this.r[rd]); else this.write8(ea,this.r[rd]); } if(!P||W)this.r[rn]=U?u32(base+off):u32(base-off); this.stat('ARM',L?'LDRH/S':'STRH'); this.disasm='HWT '+h8(ea); return true; }
      // Data processing
      if((ins&0x0C000000)===0x00000000){ const op=(ins>>>21)&15,S=(ins>>>20)&1,rn=(ins>>>16)&15,rd=(ins>>>12)&15; const op2=this.shifterOperand(ins,addr), a=this.getReg(rn,addr); let r=0,write=true;
        switch(op){ case 0:r=a&op2.val;break;case 1:r=a^op2.val;break;case 2:r=u32(a-op2.val);if(S)this.setSubFlags(a,op2.val,r);break;case 3:r=u32(op2.val-a);if(S)this.setSubFlags(op2.val,a,r);break;case 4:r=u32(a+op2.val);if(S)this.setAddFlags(a,op2.val,r);break;case 5:r=u32(a+op2.val+this.cpsr.C);if(S)this.setAddFlags(a,op2.val+this.cpsr.C,r);break;case 6:r=u32(a-op2.val-(1-this.cpsr.C));if(S)this.setSubFlags(a,op2.val+(1-this.cpsr.C),r);break;case 7:r=u32(op2.val-a-(1-this.cpsr.C));if(S)this.setSubFlags(op2.val,a+(1-this.cpsr.C),r);break;case 8:r=a&op2.val;write=false;break;case 9:r=a^op2.val;write=false;break;case 10:r=u32(a-op2.val);write=false;this.setSubFlags(a,op2.val,r);break;case 11:r=u32(a+op2.val);write=false;this.setAddFlags(a,op2.val,r);break;case 12:r=a|op2.val;break;case 13:r=op2.val;break;case 14:r=a&(~op2.val);break;case 15:r=~op2.val;break; }
        if(write)this.r[rd]=u32(r); if(S||!write){this.setNZ(r); if([0,1,8,9,12,13,14,15].includes(op))this.cpsr.C=op2.carry;} this.stat('ARM',DP[op]); this.disasm='ARM '+DP[op]+' R'+rd; return true; }
      // Single data transfer
      if((ins&0x0C000000)===0x04000000){ const I=(ins>>>25)&1,P=(ins>>>24)&1,U=(ins>>>23)&1,B=(ins>>>22)&1,W=(ins>>>21)&1,L=(ins>>>20)&1,rn=(ins>>>16)&15,rd=(ins>>>12)&15; const off=I?this.shifterOperand(ins,addr).val:(ins&0xFFF); let base=this.getReg(rn,addr),ea=P?(U?u32(base+off):u32(base-off)):base; if(L)this.r[rd]=B?this.read8(ea):this.read32(ea); else { const v=this.getReg(rd,addr); if(B)this.write8(ea,v); else this.write32(ea,v); } if(!P||W)this.r[rn]=U?u32(base+off):u32(base-off); this.stat('ARM',(L?'LDR':'STR')+(B?'B':'')); this.disasm=(L?'LDR':'STR')+' '+h8(ea); return true; }
      // Block transfer
      if((ins&0x0E000000)===0x08000000){ const P=(ins>>>24)&1,U=(ins>>>23)&1,W=(ins>>>21)&1,L=(ins>>>20)&1,rn=(ins>>>16)&15,list=ins&0xFFFF; let regs=[]; for(let i=0;i<16;i++)if((list>>>i)&1)regs.push(i); let base=this.r[rn]>>>0, a=U?(P?u32(base+4):base):(P?u32(base-4*regs.length):u32(base-4*(regs.length-1))); for(const reg of regs){ if(L)this.r[reg]=this.read32(a); else this.write32(a,this.getReg(reg,addr)); a=u32(a+4); } if(W)this.r[rn]=U?u32(base+4*regs.length):u32(base-4*regs.length); this.stat('ARM',L?'LDM':'STM'); this.disasm=(L?'LDM':'STM')+' R'+rn; return true; }
      if((ins&0x0F000000)===0x0F000000){ this.stat('ARM','SWI'); this.disasm='SWI '+h8(ins&0xFFFFFF); return true; }
      if((ins&0x0E000000)===0x0C000000){ this.stat('ARM','COPROCESSOR_UNSUPPORTED'); return this.reportUnsupported('ARM',addr,ins,'Coprocessor','ARM7TDMI-S has no usable coprocessor model in this simulator'); }
      this.stat('ARM','UNDEFINED_UNSUPPORTED'); return this.reportUnsupported('ARM',addr,ins,'Undefined/Unclassified ARM','Opcode is not yet handled by the ARM decoder/executor');
    }
    stepThumb(){
      const addr=this.r[15]>>>0, ins=this.read16(addr); this.currentPC=addr; this.currentOpcodeText='0x'+(ins&0xFFFF).toString(16).toUpperCase().padStart(4,'0'); this.r[15]=u32(addr+2); this.steps++; if(this.steps<=120)safeLog('TRACE '+this.steps+': THUMB PC='+h8(addr)+' INS=0x'+ins.toString(16).toUpperCase().padStart(4,'0'));
      const rd=ins&7, rs=(ins>>>3)&7, rn=(ins>>>6)&7;
      // Format 1 shift by immediate
      if((ins&0xE000)===0x0000){ const op=(ins>>>11)&3, imm=(ins>>>6)&31; let v=this.r[rs]>>>0,r=v; if(op===0)r=u32(v<<imm); else if(op===1)r=imm?u32(v>>>imm):v; else r=imm?u32(s32(v)>>imm):v; this.r[rd]=r; this.setNZ(r); this.stat('THUMB','SHIFT'); this.disasm='THUMB SHIFT'; return true; }
      // add/sub register/immediate
      if((ins&0xF800)===0x1800){ const I=(ins>>>10)&1,sub=(ins>>>9)&1,op2=I?rn:(this.r[rn]>>>0),a=this.r[rs]>>>0; const r=sub?u32(a-op2):u32(a+op2); this.r[rd]=r; this.setNZ(r); if(sub)this.setSubFlags(a,op2,r); else this.setAddFlags(a,op2,r); this.stat('THUMB',sub?'SUB':'ADD'); return true; }
      // mov/cmp/add/sub immediate
      if((ins&0xE000)===0x2000){ const op=(ins>>>11)&3,d=(ins>>>8)&7,imm=ins&255,a=this.r[d]>>>0; let r=imm; if(op===0){this.r[d]=r;this.setNZ(r);this.stat('THUMB','MOVI');} else if(op===1){r=u32(a-imm);this.setNZ(r);this.setSubFlags(a,imm,r);this.stat('THUMB','CMPI');} else if(op===2){r=u32(a+imm);this.r[d]=r;this.setNZ(r);this.setAddFlags(a,imm,r);this.stat('THUMB','ADDI');} else {r=u32(a-imm);this.r[d]=r;this.setNZ(r);this.setSubFlags(a,imm,r);this.stat('THUMB','SUBI');} return true; }
      // ALU ops
      if((ins&0xFC00)===0x4000){ const op=(ins>>>6)&15; let a=this.r[rd]>>>0,b=this.r[rs]>>>0,r=a; switch(op){case 0:r=a&b;break;case 1:r=a^b;break;case 2:r=u32(a<< (b&255));break;case 3:r=u32(a>>> (b&255));break;case 4:r=u32(s32(a)>> (b&255));break;case 5:r=u32(a+b+this.cpsr.C);break;case 6:r=u32(a-b-(1-this.cpsr.C));break;case 7:r=u32(b-a-(1-this.cpsr.C));break;case 8:r=a&b;this.setNZ(r);this.stat('THUMB','TST');return true;case 9:r=u32(-b);break;case 10:r=u32(a-b);this.setNZ(r);this.setSubFlags(a,b,r);this.stat('THUMB','CMP');return true;case 11:r=u32(a+b);this.setNZ(r);this.setAddFlags(a,b,r);this.stat('THUMB','CMN');return true;case 12:r=a|b;break;case 13:r=Math.imul(a,b)>>>0;break;case 14:r=a&~b;break;case 15:r=~b;break;} this.r[rd]=r; this.setNZ(r); this.stat('THUMB','ALU'); return true; }
      // hi-register ops / BX
      if((ins&0xFC00)===0x4400){ const op=(ins>>>8)&3,h1=(ins>>>7)&1,h2=(ins>>>6)&1,d=(h1<<3)|(ins&7),s=(h2<<3)|((ins>>>3)&7); if(op===0){this.r[d]=u32(this.r[d]+this.r[s]);this.stat('THUMB','ADD_HI');} else if(op===1){const r=u32(this.r[d]-this.r[s]);this.setNZ(r);this.setSubFlags(this.r[d],this.r[s],r);this.stat('THUMB','CMP_HI');} else if(op===2){this.r[d]=this.r[s];this.stat('THUMB','MOV_HI');} else {const t=this.r[s]>>>0;this.cpsr.T=t&1;this.r[15]=t&~1;this.stat('THUMB','BX');} return true; }
      // PC-relative LDR
      if((ins&0xF800)===0x4800){ const d=(ins>>>8)&7; this.r[d]=this.read32(((addr+4)&~3)+((ins&255)<<2)); this.stat('THUMB','LDR_LITERAL'); return true; }
      // load/store register offset, sign/halfword register offset, immediate offset, sp-relative
      if((ins&0xF000)===0x5000){ const L=(ins>>>11)&1,B=(ins>>>10)&1,ro=(ins>>>6)&7,base=this.r[rs]>>>0,ea=u32(base+this.r[ro]); if(L)this.r[rd]=B?this.read8(ea):this.read32(ea); else {if(B)this.write8(ea,this.r[rd]);else this.write32(ea,this.r[rd]);} this.stat('THUMB',L?'LDR_REG':'STR_REG'); return true; }
      if((ins&0xF000)===0x6000 || (ins&0xF000)===0x7000){ const L=(ins>>>11)&1,B=(ins>>>12)&1,off=((ins>>>6)&31)<<(B?0:2),ea=u32(this.r[rs]+off); if(L)this.r[rd]=B?this.read8(ea):this.read32(ea); else {if(B)this.write8(ea,this.r[rd]);else this.write32(ea,this.r[rd]);} this.stat('THUMB',L?'LDR_IMM':'STR_IMM'); return true; }
      if((ins&0xF000)===0x8000){ const L=(ins>>>11)&1,off=((ins>>>6)&31)<<1,ea=u32(this.r[rs]+off); if(L)this.r[rd]=this.read16(ea); else this.write16(ea,this.r[rd]); this.stat('THUMB',L?'LDRH':'STRH'); return true; }
      if((ins&0xF000)===0x9000){ const L=(ins>>>11)&1,d=(ins>>>8)&7,ea=u32(this.r[13]+((ins&255)<<2)); if(L)this.r[d]=this.read32(ea); else this.write32(ea,this.r[d]); this.stat('THUMB',L?'LDR_SP':'STR_SP'); return true; }
      // load address / add sp
      if((ins&0xF000)===0xA000){ const d=(ins>>>8)&7; this.r[d]=u32(((ins>>>11)&1?this.r[13]:((addr+4)&~3))+((ins&255)<<2)); this.stat('THUMB','ADD_ADDR'); return true; }
      if((ins&0xFF00)===0xB000){ const sub=(ins>>>7)&1,imm=(ins&0x7F)<<2; this.r[13]=sub?u32(this.r[13]-imm):u32(this.r[13]+imm); this.stat('THUMB','ADD_SP'); return true; }
      // push/pop
      if((ins&0xF600)===0xB400){ const L=(ins>>>11)&1,R=(ins>>>8)&1,list=ins&255; if(!L){ if(R){this.r[13]=u32(this.r[13]-4);this.write32(this.r[13],this.r[14]);} for(let i=7;i>=0;i--)if((list>>>i)&1){this.r[13]=u32(this.r[13]-4);this.write32(this.r[13],this.r[i]);} this.stat('THUMB','PUSH'); } else { for(let i=0;i<8;i++)if((list>>>i)&1){this.r[i]=this.read32(this.r[13]);this.r[13]=u32(this.r[13]+4);} if(R){const t=this.read32(this.r[13]);this.r[13]=u32(this.r[13]+4);this.cpsr.T=t&1;this.r[15]=t&~1;} this.stat('THUMB','POP'); } return true; }
      // multiple load/store
      if((ins&0xF000)===0xC000){ const L=(ins>>>11)&1,base=(ins>>>8)&7,list=ins&255; let a=this.r[base]>>>0; for(let i=0;i<8;i++)if((list>>>i)&1){ if(L)this.r[i]=this.read32(a); else this.write32(a,this.r[i]); a=u32(a+4); } this.r[base]=a; this.stat('THUMB',L?'LDMIA':'STMIA'); return true; }
      // conditional branch / SWI
      if((ins&0xF000)===0xD000){ const cond=(ins>>>8)&15; if(cond===15){this.stat('THUMB','SWI');this.disasm='THUMB SWI';return true;} if(this.condOK(cond))this.r[15]=u32(addr+4+(sx(ins&255,8)<<1)); this.stat('THUMB','B_COND'); return true; }
      if((ins&0xF800)===0xE000){ this.r[15]=u32(addr+4+(sx(ins&0x7FF,11)<<1)); this.stat('THUMB','B'); return true; }
      if((ins&0xF800)===0xF000){ this.r[14]=u32(addr+4+(sx(ins&0x7FF,11)<<12)); this.stat('THUMB','BL_PREFIX'); return true; }
      if((ins&0xF800)===0xF800){ const target=u32(this.r[14]+((ins&0x7FF)<<1)); this.r[14]=u32((addr+2)|1); this.r[15]=target; this.stat('THUMB','BL_SUFFIX'); return true; }
      this.stat('THUMB','UNDEFINED_UNSUPPORTED'); return this.reportUnsupported('THUMB',addr,ins,'Undefined/Unclassified THUMB','Opcode is not yet handled by the THUMB decoder/executor');
    }
  }

  function ensureCpuPanel(){
    window.phase5Trace=window.phase5Trace||[];

    // Phase 5.3: the visible debug selector is now integrated into the top toolbar.
    // Do not create an extra floating debugToggleBar here; it caused repeated UI controls.
    const oldBar=document.getElementById('debugToggleBar');
    if(oldBar) oldBar.remove();

    const specs=[
      {id:'cpuProfilerPanel', title:'CPU Profiler', body:'lpcCpuPanel', text:'Build HEX and click Run Simulation.', x:20, y:95, w:430, h:220},
      {id:'cpuRegistersPanel', title:'CPU Registers', body:'lpcRegPanel', text:'R0-R15 appear here.', x:470, y:95, w:360, h:360},
      {id:'peripheralRegistersPanel', title:'Peripheral Registers', body:'lpcPeriphPanel', text:'GPIO registers appear here.', x:850, y:95, w:390, h:250},
      {id:'executionTracePanel', title:'Execution Trace', body:'lpcTracePanel', text:'Trace appears here.', x:20, y:340, w:520, h:300, extra:'<button class="debugMiniBtn" onclick="window.phase5Trace=[]; if(window.lpcArm7Emu) window.phase5RefreshDebug(window.lpcArm7Emu, \'trace cleared\')">Clear</button>'},
      {id:'instructionCoveragePanel', title:'Instruction Coverage', body:'lpcCoveragePanel', text:'Coverage appears here.', x:560, y:370, w:680, h:330}
    ];

    specs.forEach(sp=>{
      let panel=document.getElementById(sp.id);
      if(!panel){
        panel=document.createElement('div');
        panel.id=sp.id;
        panel.className='debugFloatPanel hidden';
        panel.style.left=sp.x+'px';
        panel.style.top=sp.y+'px';
        panel.style.width=sp.w+'px';
        panel.style.height=sp.h+'px';
        panel.innerHTML=''+
          '<div class="debugHead" data-drag-handle="1">'+
            '<span>'+sp.title+'</span>'+ (sp.id==='cpuProfilerPanel'?' <span id="dbgRunState">Ready</span>':'') +
            '<span class="debugHeadBtns">'+(sp.extra||'')+'<button class="debugMiniBtn" onclick="window.phase5HideDebugPanel(\''+sp.id+'\')">×</button></span>'+ 
          '</div>'+ 
          '<div id="'+sp.body+'" class="debugBody">'+sp.text+'</div>';
        document.body.appendChild(panel);
        makePhase5PanelDraggable(panel);
      }
    });

    window.phase5ShowDebugPanel=function(id){
      if(id==='all'){
        specs.forEach(sp=>window.phase5ShowDebugPanel(sp.id));
        return;
      }
      if(id==='hideAll'){
        specs.forEach(sp=>window.phase5HideDebugPanel(sp.id));
        return;
      }
      const p=document.getElementById(id);
      if(!p) return;
      p.classList.remove('hidden');
      phase5BringToFront(p);
      phase5FitPanelInViewport(p);
      if(window.lpcArm7Emu) window.phase5RefreshDebug(window.lpcArm7Emu,'panel opened');
    };
    window.phase5HideDebugPanel=function(id){
      const p=document.getElementById(id);
      if(p) p.classList.add('hidden');
    };
    window.phase5OpenSelectedDebugPanel=function(){
      const sel=document.getElementById('debugPanelSelectTop') || document.getElementById('debugPanelSelect');
      if(sel) window.phase5ShowDebugPanel(sel.value);
    };
    window.phase5OpenDebugPanelFromTop=function(){
      ensureCpuPanel();
      const sel=document.getElementById('debugPanelSelectTop') || document.getElementById('debugPanelSelect');
      if(sel) window.phase5ShowDebugPanel(sel.value);
    };
    window.phase5EnsureDebugPanels=ensureCpuPanel;

    // Default: keep all floating panels hidden until selected from dropdown.
  }

  function phase5BringToFront(panel){
    window.__phase5Z=(window.__phase5Z||5000)+1;
    panel.style.zIndex=window.__phase5Z;
  }

  function phase5FitPanelInViewport(panel){
    const margin=12;
    const r=panel.getBoundingClientRect();
    let left=parseInt(panel.style.left||r.left||0,10);
    let top=parseInt(panel.style.top||r.top||0,10);
    let w=Math.min(r.width||420, window.innerWidth-margin*2);
    let h=Math.min(r.height||260, window.innerHeight-margin*2-60);
    if(left+w>window.innerWidth-margin) left=Math.max(margin, window.innerWidth-w-margin);
    if(top+h>window.innerHeight-margin) top=Math.max(60, window.innerHeight-h-margin);
    if(left<margin) left=margin;
    if(top<60) top=60;
    panel.style.left=left+'px';
    panel.style.top=top+'px';
    panel.style.maxWidth='calc(100vw - 24px)';
    panel.style.maxHeight='calc(100vh - 72px)';
  }

  function makePhase5PanelDraggable(panel){
    const head=panel.querySelector('[data-drag-handle="1"]');
    if(!head) return;
    head.addEventListener('mousedown', function(ev){
      if(ev.target && ev.target.tagName && ev.target.tagName.toLowerCase()==='button') return;
      phase5BringToFront(panel);
      const startX=ev.clientX, startY=ev.clientY;
      const r=panel.getBoundingClientRect();
      const offsetX=startX-r.left, offsetY=startY-r.top;
      function move(e){
        let left=e.clientX-offsetX;
        let top=e.clientY-offsetY;
        left=Math.max(8, Math.min(left, window.innerWidth-80));
        top=Math.max(50, Math.min(top, window.innerHeight-40));
        panel.style.left=left+'px';
        panel.style.top=top+'px';
      }
      function up(){ document.removeEventListener('mousemove',move); document.removeEventListener('mouseup',up); phase5FitPanelInViewport(panel); }
      document.addEventListener('mousemove',move);
      document.addEventListener('mouseup',up);
      ev.preventDefault();
    });
    panel.addEventListener('mousedown',()=>phase5BringToFront(panel));
  }

  function syncGpioFromEmu(emu){
    window.lpcGpio=window.lpcGpio||{};
    window.lpcGpio.p0={IODIR:emu.gpio.IO0DIR>>>0,IOSET:emu.gpio.IO0SET>>>0,IOCLR:emu.gpio.IO0CLR>>>0,IOPIN:emu.gpio.IO0PIN>>>0,dir:emu.gpio.IO0DIR>>>0,set:emu.gpio.IO0SET>>>0,clr:emu.gpio.IO0CLR>>>0,pin:emu.gpio.IO0PIN>>>0,externalInputs:(window.lpcGpio.p0&&window.lpcGpio.p0.externalInputs)||{}};
    window.lpcGpio.p1={IODIR:emu.gpio.IO1DIR>>>0,IOSET:emu.gpio.IO1SET>>>0,IOCLR:emu.gpio.IO1CLR>>>0,IOPIN:emu.gpio.IO1PIN>>>0,dir:emu.gpio.IO1DIR>>>0,set:emu.gpio.IO1SET>>>0,clr:emu.gpio.IO1CLR>>>0,pin:emu.gpio.IO1PIN>>>0,externalInputs:(window.lpcGpio.p1&&window.lpcGpio.p1.externalInputs)||{}};
    try{if(typeof renderLpcGpioMonitor==='function')renderLpcGpioMonitor();}catch(e){}
    try{
      if(typeof updateLpcExternalLoads==='function')updateLpcExternalLoads();
      if(typeof window.phase81RefreshCanvasOutputs==='function')window.phase81RefreshCanvasOutputs();
    }catch(e){}
  }
  
  function statSum(obj,names){ let n=0; for(const k of names)n+=(obj&&obj[k])||0; return n; }
  function fmtTimeFromCycles(cycles){ const cclk=(window.LPC2129ClockConfig&&window.LPC2129ClockConfig.cclkHz)||60000000; const sec=cycles/cclk; if(sec<1e-6)return (sec*1e9).toFixed(1)+' ns'; if(sec<1e-3)return (sec*1e6).toFixed(2)+' us'; if(sec<1)return (sec*1e3).toFixed(3)+' ms'; return sec.toFixed(3)+' s'; }
  function yn(n){ return n>0?'<span style="color:#66ff99">YES ('+n+')</span>':'<span style="color:#ffcc66">NOT HIT</span>'; }
  function familyDetail(emu, mode, names){
    let decode=0, execute=0, cycles=0, lastPC=0, lastOpcode='-';
    for(const n of names){ const f=emu.profiler.families[mode+' '+n]; if(f){decode+=f.decode; execute+=f.execute; cycles+=f.cycles; lastPC=f.lastPC; lastOpcode=f.lastOpcode;} }
    return {decode,execute,cycles,lastPC,lastOpcode};
  }
  function coverageHtml(emu){
    const A=emu.decodeStats.ARM||{}, T=emu.decodeStats.THUMB||{};
    const rowDefs=[
      ['ARM Data Processing + Barrel Shifter','Implemented','ARM',['AND','EOR','SUB','RSB','ADD','ADC','SBC','RSC','TST','TEQ','CMP','CMN','ORR','MOV','BIC','MVN']],
      ['ARM Branch / BL / BX','Implemented','ARM',['B','BL','BX','BLX_REG']],
      ['ARM Single Load/Store','Implemented','ARM',['LDR','STR','LDRB','STRB','SDT_LOAD','SDT_STORE']],
      ['ARM Halfword/Signed Transfer','Implemented','ARM',['LDRH/S','STRH']],
      ['ARM Block Transfer LDM/STM','Implemented','ARM',['LDM','STM','BDT_LOAD','BDT_STORE']],
      ['ARM Multiply / Long Multiply','Implemented','ARM',['MUL','MLA','UMULL','UMLAL','SMULL','SMLAL']],
      ['ARM PSR / SWI / SWP','Partial','ARM',['MRS','MSR','SWI','SWP','SWPB']],
      ['ARM Coprocessor/Undefined','Trapped','ARM',['COPROCESSOR_UNSUPPORTED','UNDEFINED_UNSUPPORTED']],
      ['THUMB Shift/Add/Sub/ALU','Implemented','THUMB',['SHIFT','ADD','SUB','MOVI','CMPI','ADDI','SUBI','ALU','TST','CMP','CMN']],
      ['THUMB Hi-Reg / BX','Implemented','THUMB',['ADD_HI','CMP_HI','MOV_HI','BX']],
      ['THUMB Load/Store','Implemented','THUMB',['LDR_LITERAL','LDR_REG','STR_REG','LDR_IMM','STR_IMM','LDRH','STRH','LDR_SP','STR_SP','LDMIA','STMIA','PUSH','POP']],
      ['THUMB Branch / BL / SWI','Implemented','THUMB',['B_COND','B','BL_PREFIX','BL_SUFFIX','SWI']],
      ['THUMB Undefined','Trapped','THUMB',['UNDEFINED_UNSUPPORTED']]
    ];
    let html='<div style="margin-top:8px"><b>Instruction Coverage + Live Execution Stats</b><table style="width:100%;border-collapse:collapse;font-size:11px;margin-top:4px"><tr><th style="text-align:left;border-bottom:1px solid #456">Family</th><th style="text-align:left;border-bottom:1px solid #456">Status</th><th style="text-align:right;border-bottom:1px solid #456">Decode</th><th style="text-align:right;border-bottom:1px solid #456">Exec</th><th style="text-align:right;border-bottom:1px solid #456">Cycles</th><th style="text-align:left;border-bottom:1px solid #456">Last PC/Opcode</th></tr>';
    for(const r of rowDefs){ const d=familyDetail(emu,r[2],r[3]); const hit=statSum(r[2]==='ARM'?A:T,r[3]); html+='<tr><td style="padding:2px 4px;border-bottom:1px solid #234">'+r[0]+'</td><td style="padding:2px 4px;border-bottom:1px solid #234">'+r[1]+' '+(hit?'<span style="color:#66ff99">●</span>':'<span style="color:#ffcc66">○</span>')+'</td><td style="padding:2px 4px;text-align:right;border-bottom:1px solid #234">'+d.decode+'</td><td style="padding:2px 4px;text-align:right;border-bottom:1px solid #234">'+d.execute+'</td><td style="padding:2px 4px;text-align:right;border-bottom:1px solid #234">'+d.cycles+'</td><td style="padding:2px 4px;border-bottom:1px solid #234">'+(d.decode?h8(d.lastPC)+' / '+d.lastOpcode:'-')+'</td></tr>'; }
    html+='</table></div>';
    if(emu.lastUnsupported){ const u=emu.lastUnsupported; html+='<div style="margin-top:8px;color:#ff9999"><b>Last Unsupported Opcode</b><br>Mode='+u.mode+' PC='+h8(u.pc)+' Opcode='+u.opcode+'<br>Family='+u.family+'<br>'+u.detail+'</div>'; }
    return html;
  }
  function regsHtml(emu){
    let rows='';
    for(let i=0;i<16;i++){
      const nm=i===13?'SP/R13':(i===14?'LR/R14':(i===15?'PC/R15':'R'+i));
      rows+='<tr><td>'+nm+'</td><td>'+h8(emu.r[i])+'</td></tr>';
    }
    rows+='<tr><td>CPSR</td><td>N='+emu.cpsr.N+' Z='+emu.cpsr.Z+' C='+emu.cpsr.C+' V='+emu.cpsr.V+' T='+emu.cpsr.T+' MODE=0x'+(emu.cpsr.mode||0).toString(16).toUpperCase()+'</td></tr>';
    return '<table>'+rows+'</table>';
  }
  function periphHtml(emu){
    const g=emu.gpio||{};
    return '<table><tr><th>Register</th><th>Value</th></tr>'+
      '<tr><td>IO0PIN</td><td>'+h8(g.IO0PIN||0)+'</td></tr><tr><td>IO0SET</td><td>'+h8(g.IO0SET||0)+'</td></tr><tr><td>IO0DIR</td><td>'+h8(g.IO0DIR||0)+'</td></tr><tr><td>IO0CLR</td><td>'+h8(g.IO0CLR||0)+'</td></tr>'+
      '<tr><td>IO1PIN</td><td>'+h8(g.IO1PIN||0)+'</td></tr><tr><td>IO1SET</td><td>'+h8(g.IO1SET||0)+'</td></tr><tr><td>IO1DIR</td><td>'+h8(g.IO1DIR||0)+'</td></tr><tr><td>IO1CLR</td><td>'+h8(g.IO1CLR||0)+'</td></tr></table>'+
      '<div style="margin-top:6px">Last GPIO: '+(emu.lastGpioWrite||'-')+'</div>';
  }
  function traceHtml(){
    const tr=(window.phase5Trace||[]).slice(-80).reverse();
    if(!tr.length)return 'No instructions traced yet.';
    let html='<table><tr><th>Step</th><th>Mode</th><th>PC</th><th>Opcode</th><th>Family</th></tr>';
    for(const t of tr){html+='<tr><td class="num">'+t.step+'</td><td>'+t.mode+'</td><td>'+h8(t.pc)+'</td><td>'+t.opcode+'</td><td>'+t.family+'</td></tr>';}
    return html+'</table>';
  }
  function coverageOnlyHtml(emu){
    const html=coverageHtml(emu);
    return html.replace('<div style="margin-top:8px"><b>Instruction Coverage + Live Execution Stats</b>','<div><b>Instruction Coverage + Live Execution Stats</b>');
  }
  function updateCpuPanel(emu,msg){
    ensureCpuPanel(); const p=document.getElementById('lpcCpuPanel'); if(!p||!emu)return;
    const reg=document.getElementById('lpcRegPanel'), per=document.getElementById('lpcPeriphPanel'), trp=document.getElementById('lpcTracePanel'), cov=document.getElementById('lpcCoveragePanel'), st=document.getElementById('dbgRunState');
    const arm=Object.keys(emu.decodeStats.ARM).length, th=Object.keys(emu.decodeStats.THUMB).length;
    const pr=emu.profiler||{}; const avg=(pr.totalInstructions?((pr.totalCycles/pr.totalInstructions).toFixed(2)):'0.00');
    if(st) st.textContent=emu.running?'Running':'Stopped';
    p.innerHTML='<table>'+
      '<tr><td>Mode</td><td>'+(emu.cpsr.T?'THUMB':'ARM')+'</td><td>PC</td><td>'+h8(emu.r[15])+'</td></tr>'+
      '<tr><td>Steps</td><td>'+emu.steps+'</td><td>Last Opcode</td><td>'+(pr.lastOpcode||'-')+'</td></tr>'+
      '<tr><td>Total Instructions</td><td>'+((pr.totalInstructions)||0)+'</td><td>Family</td><td>'+(pr.lastFamily||'-')+'</td></tr>'+
      '<tr><td>ARM / THUMB</td><td>'+((pr.armInstructions)||0)+' / '+((pr.thumbInstructions)||0)+'</td><td>Avg CPI</td><td>'+avg+'</td></tr>'+
      '<tr><td>Cycles</td><td>'+((pr.totalCycles)||0)+'</td><td>Time @'+((((window.LPC2129ClockConfig&&window.LPC2129ClockConfig.cclkHz)||60000000)/1000000).toFixed(1))+'MHz</td><td>'+fmtTimeFromCycles(pr.totalCycles||0)+'</td></tr>'+
      '<tr><td>Decoded Classes</td><td>ARM='+arm+' THUMB='+th+'</td><td>Unsupported</td><td class="'+((emu.unsupportedCount||0)?'bad':'ok')+'">'+(emu.unsupportedCount||0)+'</td></tr>'+
      '<tr><td>Status</td><td colspan="3">'+(msg||emu.disasm||'-')+'</td></tr></table>';
    if(reg) reg.innerHTML=regsHtml(emu);
    if(per) per.innerHTML=periphHtml(emu);
    if(trp) trp.innerHTML=traceHtml();
    if(cov) cov.innerHTML=coverageOnlyHtml(emu);
  }
  window.phase5RefreshDebug=updateCpuPanel;

  window.LPC2129Arm7Emu = LPC2129Arm7Emu;

  async function startTrueHexEmu(){
    try{if(typeof removeAvrUi==='function')removeAvrUi();if(typeof installLpcMonitorDrag==='function')installLpcMonitorDrag();}catch(e){}
    if(!window.lastLpc2129Hex){
      safeLog('No HEX loaded. Building LPC2129 source first...');
      if(typeof window.compileLpc2129Hex==='function'){const ok=await window.compileLpc2129Hex();if(!ok)return false;}
    }

    const emu=new LPC2129Arm7Emu();
    window.lpcArm7Emu=emu;
    try{
      const n=emu.loadIntelHex(window.lastLpc2129Hex);
      safeLog('Intel HEX loaded into emulated LPC2129 flash: '+n+' bytes.');
    }catch(e){safeLog('HEX loader error: '+e.message);return false;}

    syncGpioFromEmu(emu);
    updateCpuPanel(emu,'loaded');
    emu.running=true;
    window.lpcGpio=window.lpcGpio||{};
    window.lpcGpio.running=true;
    running=true;
    if(typeof setRunStopButtonState==='function')setRunStopButtonState(true);

    const perfNow=()=>((typeof performance!=='undefined'&&performance.now)?performance.now():Date.now());
    const sleepFrame=()=>new Promise(r=>{
      if(typeof requestAnimationFrame==='function')requestAnimationFrame(()=>r());
      else setTimeout(r,16);
    });

    const cclk=()=>Math.max(1,Number((window.LPC2129ClockConfig&&window.LPC2129ClockConfig.cclkHz)||60000000));

    /* Phase 8.1B deterministic timing core.
       - Simulated time advances in fixed quanta.
       - Host/browser frame timing decides only how many quanta to process.
       - GPIO timestamps are derived from emulated cycles, never wall-clock.
       - UI is refreshed separately at display-frame rate. */
    const QUANTUM_US=250;                  // 0.25 ms simulated-time quantum
    const MAX_CATCHUP_MS=20;               // prevent long host stalls from causing huge bursts
    const MAX_INSTRUCTIONS_PER_FRAME=300000;
    const UI_PERIOD_MS=1000/60;            // nominal 60 FPS visual refresh

    let wallPrev=perfNow();
    let wallAccumulatorMs=0;
    let lastUiWall=wallPrev;
    let lastUiPin=emu.gpioPinChangeCount||0;
    let lastDebugWall=wallPrev;

    window.phase81SimClock={
      quantumUs:QUANTUM_US,
      simulatedCycles:emu.profiler.totalCycles||0,
      simulatedSeconds:(emu.profiler.totalCycles||0)/cclk(),
      lastGpioTransitionUs:0,
      inputTransitions:0,
      outputTransitions:0
    };

    safeLog('Phase 8.1B deterministic scheduler started.');
    safeLog('Fixed simulation quantum: '+QUANTUM_US+' us; visual refresh target: 60 FPS.');

    try{
      while(emu.running){
        const wallNow=perfNow();
        let wallDelta=wallNow-wallPrev;
        wallPrev=wallNow;
        if(wallDelta<0)wallDelta=0;
        if(wallDelta>MAX_CATCHUP_MS)wallDelta=MAX_CATCHUP_MS;
        wallAccumulatorMs+=wallDelta;

        const cclkHz=cclk();
        let frameInstructions=0;

        while(emu.running && wallAccumulatorMs >= (QUANTUM_US/1000) && frameInstructions<MAX_INSTRUCTIONS_PER_FRAME){
          const quantumCycles=Math.max(1,Math.floor(cclkHz*(QUANTUM_US/1000000)));
          const targetCycles=(emu.profiler.totalCycles||0)+quantumCycles;

          while(emu.running &&
                (emu.profiler.totalCycles||0)<targetCycles &&
                frameInstructions<MAX_INSTRUCTIONS_PER_FRAME){
            emu.step();
            frameInstructions++;
          }

          wallAccumulatorMs-=(QUANTUM_US/1000);
          try{if(typeof window.phase82TickUarts==='function')window.phase82TickUarts(emu);}catch(e){}
          if(window.phase81SimClock){
            window.phase81SimClock.simulatedCycles=emu.profiler.totalCycles||0;
            window.phase81SimClock.simulatedSeconds=(emu.profiler.totalCycles||0)/cclkHz;
          }
        }

        const pinNow=emu.gpioPinChangeCount||0;
        if(pinNow!==lastUiPin){
          lastUiPin=pinNow;
          if(window.phase81SimClock){
            window.phase81SimClock.lastGpioTransitionUs=((emu.profiler.totalCycles||0)/cclkHz)*1000000;
            window.phase81SimClock.outputTransitions=(window.phase81SimClock.outputTransitions||0)+1;
          }
        }

        if(wallNow-lastUiWall>=UI_PERIOD_MS){
          syncGpioFromEmu(emu);
          if(typeof window.phase81FlushPendingInput==='function')window.phase81FlushPendingInput(emu);
          lastUiWall=wallNow;
        }

        if(wallNow-lastDebugWall>=100){
          updateCpuPanel(emu,'deterministic clock');
          lastDebugWall=wallNow;
        }

        await sleepFrame();
      }
    }catch(e){
      emu.lastError=e.message;
      safeLog('ARM7TDMI-S emulator stopped: '+e.message);
    }

    emu.running=false;
    if(window.lpcGpio)window.lpcGpio.running=false;
    running=false;
    updateCpuPanel(emu,emu.lastError?('ERROR '+emu.lastError):'stopped');
    if(typeof setRunStopButtonState==='function')setRunStopButtonState(false);
    return true;
  }
  function stopTrueHexEmu(){ if(window.lpcArm7Emu)window.lpcArm7Emu.running=false; if(window.lpcGpio)window.lpcGpio.running=false; running=false; try{if(typeof setRunStopButtonState==='function')setRunStopButtonState(false);}catch(e){} safeLog('ARM7TDMI-S emulator stop requested.'); }
  const previousCompile=window.compileLpc2129Hex; window.compileLpc2129Hex=async function(){ const ok=previousCompile?await previousCompile():false; if(ok){try{const test=new LPC2129Arm7Emu();const n=test.loadIntelHex(window.lastLpc2129Hex);safeLog('HEX validation OK for ARM/THUMB emulator: '+n+' bytes loaded.');updateCpuPanel(test,'validated');}catch(e){safeLog('HEX validation failed: '+e.message);}} return ok; };
  window.unifiedCompile=window.compileLpc2129Hex; window.startLpc2129HexEmulator=startTrueHexEmu; window.stopLpc2129HexEmulator=stopTrueHexEmu; window.toggleRunStopSimulation=async function(){ if(window.lpcArm7Emu&&window.lpcArm7Emu.running)return stopTrueHexEmu(); return startTrueHexEmu(); };
  window.addEventListener('load',()=>setTimeout(()=>{ensureCpuPanel();safeLog('Phase 4C loaded: live instruction profiler + coverage matrix + unsupported opcode report enabled. Build HEX, then Run Simulation.');},1200));
})();


/* ============================================================
   PHASE 3G PATCH - Application UI + LPC2129 Monitor Component
   ------------------------------------------------------------
   - Keeps true HEX-driven LPC2129 GPIO emulator from Phase 3F.
   - Removes AVR digital monitor leftovers whenever New is pressed.
   - LPC2129 Digital I/O Monitor is now added from + Component by ONE click.
   - LPC2129 Digital I/O Monitor is removable by DOUBLE click.
   ============================================================ */
(function(){
  'use strict';

  function sceneEl(){ return document.getElementById('scene'); }

  function removeLegacyAvrMonitors(){
    const selectors = [
      '#digitalPinMonitor', '#avrDigitalMonitor', '#avrDigitalIoMonitor',
      '.digitalPinMonitor', '.avrDigitalMonitor', '.avrDigitalIoMonitor',
      '[data-avr-monitor="1"]'
    ];
    selectors.forEach(sel => document.querySelectorAll(sel).forEach(el => el.remove()));
    document.querySelectorAll('div,section,aside').forEach(el => {
      if(!el || el.id === 'lpcGpioMonitor' || (el.closest && el.closest('#lpcGpioMonitor'))) return;
      const txt = (el.textContent || '').replace(/\s+/g,' ').trim();
      const meta = ((el.id||'') + ' ' + (el.className||'')).toString();
      if(/AVR\s+Digital|Arduino\s+Digital|D0\s*-\s*D13|PORTB|PORTD/i.test(txt) || /avr.*monitor|digital.*pin.*monitor/i.test(meta)){
        if(!/LPC2129/i.test(txt)) el.remove();
      }
    });
  }
  window.removeLegacyAvrMonitors = removeLegacyAvrMonitors;

  function lpcMonitorHtml(){
    return `
      <div class="gpioMonHead">
        <span>LPC2129 Digital I/O Monitor <span class="removeHint">double-click to remove</span></span>
        <button onclick="event.stopPropagation(); resetLpcGpioMonitor()">Reset</button>
      </div>
      <div class="gpioLegend"><span class="dot out"></span> Output <span class="dot in"></span> Input <span class="dot hi"></span> HIGH <span class="dot lo"></span> LOW</div>
      <div class="gpioPortTitle">GPIO Port 0 - P0.0–P0.25, P0.27–P0.30</div>
      <div id="lpcGpioGridP0" class="lpcGpioGrid"></div>
      <div class="gpioPortTitle">GPIO Port 1 - P1.16 to P1.31</div>
      <div id="lpcGpioGridP1" class="lpcGpioGrid p1grid"></div>
      <div id="lpcRegs" class="lpcRegs">IODIR0=0x00000000 IOSET0=0x00000000 IOCLR0=0x00000000 IOPIN0=0x00000000<br>IODIR1=0x00000000 IOSET1=0x00000000 IOCLR1=0x00000000 IOPIN1=0x00000000</div>`;
  }

  function installMonitorDragAndDelete(mon){
    if(!mon || mon.__phase3gReady) return;
    mon.__phase3gReady = true;
    mon.classList.add('componentMode');
    mon.title = 'Drag to move. Double-click blank/header area to remove.';
    mon.addEventListener('dblclick', function(e){
      if(e.target && (e.target.tagName === 'BUTTON' || e.target.closest('.gpioCell'))) return;
      e.stopPropagation();
      mon.remove();
      if(typeof log === 'function') log('LPC2129 Digital I/O Monitor removed from canvas.');
    });
    const head = mon.querySelector('.gpioMonHead') || mon;
    head.style.cursor = 'move';
    let dragging=false, sx=0, sy=0, startL=0, startT=0;
    head.addEventListener('mousedown', function(e){
      if(e.target && e.target.tagName === 'BUTTON') return;
      dragging=true; sx=e.clientX; sy=e.clientY;
      startL=parseFloat(mon.style.left || mon.offsetLeft || 0);
      startT=parseFloat(mon.style.top || mon.offsetTop || 0);
      document.body.style.userSelect='none';
      e.preventDefault(); e.stopPropagation();
    });
    document.addEventListener('mousemove', function(e){
      if(!dragging) return;
      const sc = (window.project && project.canvasScale) ? project.canvasScale : 1;
      mon.style.left = (startL + (e.clientX-sx)/sc) + 'px';
      mon.style.top  = (startT + (e.clientY-sy)/sc) + 'px';
      mon.style.right = 'auto';
    });
    document.addEventListener('mouseup', function(){ if(dragging){ dragging=false; document.body.style.userSelect=''; } });
  }

  function ensureLpcMonitorComponent(x, y){
    removeLegacyAvrMonitors();
    const scene = sceneEl();
    if(!scene) return null;
    let mon = document.getElementById('lpcGpioMonitor');
    if(!mon){
      mon = document.createElement('div');
      mon.id = 'lpcGpioMonitor';
      mon.className = 'lpcGpioMonitor componentMode';
      mon.innerHTML = lpcMonitorHtml();
      scene.appendChild(mon);
    }else if(mon.parentElement !== scene){
      scene.appendChild(mon);
    }
    mon.style.display = 'block';
    mon.style.position = 'absolute';
    mon.style.left = (typeof x === 'number' ? x : 820) + 'px';
    mon.style.top = (typeof y === 'number' ? y : 35) + 'px';
    mon.style.right = 'auto';
    // Force grid rebuild when monitor was recreated or emptied.
    const g0 = document.getElementById('lpcGpioGridP0'); if(g0) delete g0.dataset.ready;
    const g1 = document.getElementById('lpcGpioGridP1'); if(g1) delete g1.dataset.ready;
    installMonitorDragAndDelete(mon);
    try{ if(typeof renderLpcGpioMonitor === 'function') renderLpcGpioMonitor(); }catch(e){}
    return mon;
  }
  window.ensureLpcMonitorComponent = ensureLpcMonitorComponent;

  window.addLpc2129MonitorFromPalette = function(){
    ensureLpcMonitorComponent(820, 35);
    const p = document.getElementById('componentPalette'); if(p) p.style.display='none';
    if(typeof log === 'function') log('LPC2129 Digital I/O Monitor added as canvas component. Drag it; double-click to remove.');
  };

  // Make all palette items single-click for a desktop-app style workflow. Existing double-click still works.
  function patchComponentPalette(){
    const pal = document.getElementById('componentPalette'); if(!pal || pal.__phase3gPatched) return;
    pal.__phase3gPatched = true;
    const map = [
      ['LED','led'], ['Push Button','button'], ['Potentiometer','pot'], ['Buzzer','buzzer'], ['LCD 16x2','lcd'], ['Relay','relay']
    ];
    pal.querySelectorAll('.componentItem').forEach(item => {
      const text = (item.textContent||'').trim();
      if(/LPC2129 Digital/i.test(text)){
        item.onclick = function(e){ e.stopPropagation(); window.addLpc2129MonitorFromPalette(); };
        item.ondblclick = null;
        return;
      }
      const found = map.find(([label]) => label === text);
      if(found){
        item.onclick = function(e){ e.stopPropagation(); if(typeof addFromPalette === 'function') addFromPalette(found[1]); };
      }
    });
  }

  const previousTogglePalette = window.toggleComponentPalette || (typeof toggleComponentPalette === 'function' ? toggleComponentPalette : null);
  if(previousTogglePalette){
    window.toggleComponentPalette = toggleComponentPalette = function(){
      const r = previousTogglePalette.apply(this, arguments);
      patchComponentPalette();
      return r;
    };
  }

  const previousNew = window.newProject || (typeof newProject === 'function' ? newProject : null);
  window.newProject = newProject = function(){
    if(typeof stopLpc2129HexEmulator === 'function') stopLpc2129HexEmulator(false);
    removeLegacyAvrMonitors();
    // Remove LPC monitor too on New; user can add it again from + Component.
    const mon = document.getElementById('lpcGpioMonitor'); if(mon) mon.remove();
    nextId=1; selectedId=null; wiringSource=null; wiringMouse=null;
    project={canvasScale:1,parts:[],wires:[],code:document.getElementById('code').value};
    document.querySelectorAll('.part').forEach(e=>e.remove());
    const led = addPart('led',{x:760,y:90,scale:1});
    addWire(lpcPinNode ? lpcPinNode(0,10) : 'uno.P0_10', led.id+'.A');
    addWire('uno.GND', led.id+'.K');
    try{ applyCanvasZoom(); }catch(e){}
    try{ resetLpcGpioMonitor(); }catch(e){}
    try{ render(); }catch(e){}
    try{ clearLog(); clearSerial(); }catch(e){}
    log('New LPC2129 project created. Digital I/O Monitor removed. ');
  };

  // Do not auto-show monitor on page load. It must be added from + Component.
  window.addEventListener('load', function(){
    setTimeout(function(){
      patchComponentPalette();
      removeLegacyAvrMonitors();
      const mon = document.getElementById('lpcGpioMonitor'); if(mon) mon.remove();
      if(typeof log === 'function') log('Phase 3G UI active: application window layout; LPC2129 Digital I/O Monitor is a removable component.');
    }, 1200);
  });
})();




/* ===== User UI cleanup patch: remove title label and legacy AVR digital monitor only ===== */
(function(){
  'use strict';
  function removeRequestedLabelsAndAvrMonitorOnly(){
    document.querySelectorAll('.brand').forEach(el=>{ el.textContent=''; el.style.display='none'; });
    document.querySelectorAll('#digitalPinMonitorRevA,#digitalPinMonitor,#avrDigitalMonitor,#avrDigitalIoMonitor').forEach(el=>el.remove());
    document.querySelectorAll('.componentItem').forEach(el=>{
      if(/AVR\s+Digital/i.test(el.textContent||'')) el.remove();
    });
  }
  window.addEventListener('load', ()=>setTimeout(removeRequestedLabelsAndAvrMonitorOnly, 50));
  window.addEventListener('load', ()=>setTimeout(function(){
    removeRequestedLabelsAndAvrMonitorOnly();
    if(typeof patchComponentPalette === 'function') patchComponentPalette();
  }, 800));
})();

/* ============================================================
   PHASE 5.1 - CPU CORE SELF-TEST LOADER
   Adds visible classroom/debug test programs for ARM data processing,
   barrel shifter, condition flags/branches, and THUMB mode switching.
   These tests are intended to validate the ARM7TDMI-S emulator families
   from the GUI without manually opening files.
   ============================================================ */
(function(){
  const tests = {
    arm_dp: String.raw`/*
 * LPC2129 ARM7TDMI-S CPU Self Test
 * Test    : ARM Data Processing Instructions
 * Syntax  : GNU ARM Assembly
 * PASS    : IO0SET = 0x000000AA, IO1SET = 0x00000055
 */
.syntax unified
.cpu arm7tdmi
.arm
.global main

.equ IO0DIR, 0xE0028008
.equ IO0SET, 0xE0028004
.equ IO0CLR, 0xE002800C
.equ IO1DIR, 0xE0028018
.equ IO1SET, 0xE0028014
.equ IO1CLR, 0xE002801C

main:
    LDR R10, =IO0DIR
    LDR R11, =0xFFFFFFFF
    STR R11, [R10]
    LDR R10, =IO1DIR
    STR R11, [R10]

    MOV R0, #0x12
    MOV R1, #0x34
    ADD R2, R0, R1
    CMP R2, #0x46
    BNE fail

    SUB R3, R2, #0x06
    CMP R3, #0x40
    BNE fail

    ORR R4, R3, #0x0F
    CMP R4, #0x4F
    BNE fail

    AND R5, R4, #0xF0
    CMP R5, #0x40
    BNE fail

    EOR R6, R5, #0x55
    CMP R6, #0x15
    BNE fail

    BIC R7, R6, #0x05
    CMP R7, #0x10
    BNE fail

    MVN R8, #0
    CMN R8, #1
    BNE fail

pass:
    LDR R10, =IO0SET
    LDR R11, =0x000000AA
    STR R11, [R10]
    LDR R10, =IO1SET
    LDR R11, =0x00000055
    STR R11, [R10]
    B pass

fail:
    LDR R10, =IO0CLR
    LDR R11, =0xFFFFFFFF
    STR R11, [R10]
    LDR R10, =IO1CLR
    STR R11, [R10]
    B fail`,
    arm_shift: String.raw`/* LPC2129 ARM7TDMI-S CPU Self Test: ARM Barrel Shifter
 * PASS: IO0SET = 0x00000F0F
 */
.syntax unified
.cpu arm7tdmi
.arm
.global main
.equ IO0DIR, 0xE0028008
.equ IO0SET, 0xE0028004
.equ IO0CLR, 0xE002800C
main:
    LDR R10, =IO0DIR
    LDR R11, =0xFFFFFFFF
    STR R11, [R10]

    MOV R0, #1
    MOV R1, R0, LSL #4
    CMP R1, #0x10
    BNE fail

    MOV R2, #0x80
    MOV R3, R2, LSR #3
    CMP R3, #0x10
    BNE fail

    MOV R4, #0x80000000
    MOV R5, R4, ASR #31
    MVN R6, #0
    CMP R5, R6
    BNE fail

pass:
    LDR R10, =IO0SET
    LDR R11, =0x00000F0F
    STR R11, [R10]
    B pass
fail:
    LDR R10, =IO0CLR
    LDR R11, =0xFFFFFFFF
    STR R11, [R10]
    B fail`,
    arm_branch: String.raw`/* LPC2129 ARM7TDMI-S CPU Self Test: ARM branch + condition flags
 * PASS: IO0SET = 0x0000F000
 */
.syntax unified
.cpu arm7tdmi
.arm
.global main
.equ IO0DIR, 0xE0028008
.equ IO0SET, 0xE0028004
.equ IO0CLR, 0xE002800C
main:
    LDR R10, =IO0DIR
    LDR R11, =0xFFFFFFFF
    STR R11, [R10]

    MOV R0, #5
    CMP R0, #5
    BEQ equal_ok
    B fail
equal_ok:
    CMP R0, #7
    BLT less_ok
    B fail
less_ok:
    MOV R1, #0
loop:
    ADD R1, R1, #1
    CMP R1, #10
    BNE loop
    CMP R1, #10
    BNE fail
pass:
    LDR R10, =IO0SET
    LDR R11, =0x0000F000
    STR R11, [R10]
    B pass
fail:
    LDR R10, =IO0CLR
    LDR R11, =0xFFFFFFFF
    STR R11, [R10]
    B fail`,
    thumb_basic: String.raw`/* LPC2129 ARM7TDMI-S CPU Self Test: THUMB basic execution
 * Starts in ARM, switches to THUMB using BX, then writes GPIO.
 * PASS: IO0SET = 0x00000033 and profiler shows THUMB count > 0.
 */
.syntax unified
.cpu arm7tdmi
.arm
.global main
.equ IO0DIR, 0xE0028008
.equ IO0SET, 0xE0028004
main:
    LDR R0, =thumb_main + 1
    BX  R0

.thumb
.thumb_func
thumb_main:
    LDR R2, =IO0DIR
    LDR R3, =0xFFFFFFFF
    STR R3, [R2]
    MOVS R0, #10
    MOVS R1, #20
    ADDS R0, R0, R1
    CMP R0, #30
    BNE thumb_main
    LDR R2, =IO0SET
    LDR R3, =0x00000033
    STR R3, [R2]
thumb_loop:
    B thumb_loop`
  };

  window.loadCpuSelfTest = function(){
    const sel = document.getElementById('cpuSelfTestSelect');
    const code = document.getElementById('code');
    const srcType = document.getElementById('sourceType');
    const key = sel && sel.value;
    if(!key || !tests[key]){
      try{ if(typeof log==='function') log('Select a CPU Self Test first.'); }catch(e){}
      return;
    }
    if(srcType){
      srcType.value = 'assembly';
      srcType.dispatchEvent(new Event('change'));
    }
    if(code) code.value = tests[key];
    const pname = document.getElementById('projectName');
    if(pname) pname.value = 'LPC2129_' + key.toUpperCase() + '_SELF_TEST';
    try{
      if(typeof log==='function') log('Loaded CPU self-test: ' + (sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].text : key) + '. Source Type set to Assembly Source. Click Build HEX, then Run Simulation.');
    }catch(e){}
  };

  window.addEventListener('load', function(){
    setTimeout(function(){
      try{ if(typeof log==='function') log('Phase 5.1 loaded: CPU self-test dropdown added for ARM Data Processing, Barrel Shifter, Branch/Flags, and THUMB Basic tests.'); }catch(e){}
    }, 1600);
  });
})();

/* ============================================================
   PHASE 5.3S PATCH - reliable draggable + resizable debug panels
   - Removes fixed !important placement behavior by applying runtime styles.
   - Drag using debug panel title/header.
   - Resize using native bottom-right browser resize handle.
   ============================================================ */
(function(){
  'use strict';
  const DEFAULT_POS = {
    cpuProfilerPanel: {left: 80, top: 110, width: 460, height: 250},
    cpuRegistersPanel: {left: 120, top: 150, width: 390, height: 430},
    peripheralRegistersPanel: {left: 160, top: 190, width: 430, height: 320},
    executionTracePanel: {left: 200, top: 230, width: 600, height: 390},
    instructionCoveragePanel: {left: 240, top: 270, width: 720, height: 400}
  };

  function px(n){ return Math.round(n) + 'px'; }
  function clamp(v, min, max){ return Math.max(min, Math.min(max, v)); }

  function bringToFront(panel){
    window.__phase53sZ = (window.__phase53sZ || 13000) + 1;
    panel.style.zIndex = window.__phase53sZ;
  }

  function fit(panel){
    const r = panel.getBoundingClientRect();
    const w = Math.min(r.width || 420, window.innerWidth - 24);
    const h = Math.min(r.height || 260, window.innerHeight - 24);
    let l = Number.parseFloat(panel.style.left || r.left || 16);
    let t = Number.parseFloat(panel.style.top || r.top || 90);
    l = clamp(l, 8, Math.max(8, window.innerWidth - w - 8));
    t = clamp(t, 72, Math.max(72, window.innerHeight - h - 8));
    panel.style.left = px(l);
    panel.style.top = px(t);
    panel.style.width = px(w);
    panel.style.height = px(h);
  }

  function preparePanel(panel){
    if(!panel || panel.__phase53sReady) return;
    panel.__phase53sReady = true;
    const id = panel.id;
    const d = DEFAULT_POS[id] || {left:80, top:110, width:460, height:260};

    panel.style.position = 'fixed';
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
    if(!panel.dataset.userPlaced){
      panel.style.left = px(d.left);
      panel.style.top = px(d.top);
      panel.style.width = px(d.width);
      panel.style.height = px(d.height);
    }
    panel.style.resize = 'both';
    panel.style.overflow = 'auto';
    panel.style.minWidth = '320px';
    panel.style.minHeight = '190px';
    panel.style.maxWidth = 'calc(100vw - 24px)';
    panel.style.maxHeight = 'calc(100vh - 24px)';
    panel.style.boxSizing = 'border-box';

    const head = panel.querySelector('.debugHead') || panel.firstElementChild || panel;
    head.style.cursor = 'move';
    head.style.userSelect = 'none';
    head.title = 'Drag this header to move the panel. Resize from the bottom-right corner.';

    head.addEventListener('mousedown', function(e){
      if(e.button !== 0) return;
      if(e.target && (e.target.closest('button') || e.target.closest('select') || e.target.closest('input'))) return;
      // Do not start drag when user is grabbing resize corner.
      const r = panel.getBoundingClientRect();
      if(e.clientX > r.right - 22 && e.clientY > r.bottom - 22) return;
      bringToFront(panel);
      const startX = e.clientX, startY = e.clientY;
      const startLeft = r.left, startTop = r.top;
      document.body.style.userSelect = 'none';
      function move(ev){
        const w = panel.getBoundingClientRect().width;
        const h = panel.getBoundingClientRect().height;
        const l = clamp(startLeft + ev.clientX - startX, 8, Math.max(8, window.innerWidth - w - 8));
        const t = clamp(startTop + ev.clientY - startY, 72, Math.max(72, window.innerHeight - h - 8));
        panel.style.left = px(l);
        panel.style.top = px(t);
        panel.style.right = 'auto';
        panel.style.bottom = 'auto';
        panel.dataset.userPlaced = '1';
      }
      function up(){
        document.removeEventListener('mousemove', move, true);
        document.removeEventListener('mouseup', up, true);
        document.body.style.userSelect = '';
        fit(panel);
      }
      document.addEventListener('mousemove', move, true);
      document.addEventListener('mouseup', up, true);
      e.preventDefault();
      e.stopPropagation();
    }, true);

    panel.addEventListener('mousedown', function(){ bringToFront(panel); }, true);
  }

  function prepareAll(){
    document.querySelectorAll('.debugFloatPanel').forEach(preparePanel);
  }

  const oldShow = window.phase5ShowDebugPanel;
  window.phase5ShowDebugPanel = function(id){
    if(typeof oldShow === 'function') oldShow(id);
    prepareAll();
    if(id === 'all'){
      Object.keys(DEFAULT_POS).forEach(pid => { const p = document.getElementById(pid); if(p){ p.classList.remove('hidden'); preparePanel(p); fit(p); } });
      return;
    }
    if(id && id !== 'hideAll'){
      const p = document.getElementById(id);
      if(p){ p.classList.remove('hidden'); preparePanel(p); fit(p); bringToFront(p); }
    }
  };

  const oldEnsure = window.phase5EnsureDebugPanels;
  window.phase5EnsureDebugPanels = function(){
    if(typeof oldEnsure === 'function') oldEnsure();
    prepareAll();
  };

  window.addEventListener('load', function(){ setTimeout(prepareAll, 700); setTimeout(prepareAll, 1600); });
  window.addEventListener('resize', function(){ document.querySelectorAll('.debugFloatPanel:not(.hidden)').forEach(fit); });
})();


/* ============================================================
   PHASE 5.4T PATCH - reliable floating debug panels + single step
   Fixes:
   - CSS #id !important placement no longer blocks dragging.
   - Adds custom bottom-right resize handle for every debug panel.
   - Adds Step Instruction button and single-step CPU execution.
   ============================================================ */
(function(){
  'use strict';

  const PANEL_IDS = [
    'cpuProfilerPanel',
    'cpuRegistersPanel',
    'peripheralRegistersPanel',
    'executionTracePanel',
    'instructionCoveragePanel'
  ];
  const DEFAULTS = {
    cpuProfilerPanel: {left: 80, top: 112, width: 470, height: 260},
    cpuRegistersPanel: {left: 130, top: 145, width: 410, height: 440},
    peripheralRegistersPanel: {left: 180, top: 178, width: 450, height: 330},
    executionTracePanel: {left: 230, top: 210, width: 650, height: 420},
    instructionCoveragePanel: {left: 280, top: 240, width: 760, height: 420}
  };
  function px(n){ return Math.round(n) + 'px'; }
  function clamp(v,min,max){ return Math.max(min, Math.min(max, v)); }
  function setImp(el, prop, value){ if(el) el.style.setProperty(prop, value, 'important'); }
  function toolbar(){ return document.querySelector('.toolbarBuild') || document.querySelector('.topbar') || document.body; }
  function bring(p){ window.__phase54Z=(window.__phase54Z||20000)+1; setImp(p,'z-index', String(window.__phase54Z)); }

  function fit(p){
    if(!p) return;
    const r=p.getBoundingClientRect();
    const w=clamp(r.width||420, 300, Math.max(320, window.innerWidth-20));
    const h=clamp(r.height||260, 180, Math.max(200, window.innerHeight-20));
    let l=parseFloat(p.style.left||r.left||80);
    let t=parseFloat(p.style.top||r.top||110);
    l=clamp(l, 6, Math.max(6, window.innerWidth-w-6));
    t=clamp(t, 60, Math.max(60, window.innerHeight-h-6));
    setImp(p,'left',px(l)); setImp(p,'top',px(t)); setImp(p,'width',px(w)); setImp(p,'height',px(h));
    setImp(p,'right','auto'); setImp(p,'bottom','auto');
  }

  function normalizePanel(p){
    if(!p) return;
    const id=p.id, d=DEFAULTS[id] || {left:80,top:112,width:460,height:260};
    setImp(p,'position','fixed');
    setImp(p,'right','auto'); setImp(p,'bottom','auto');
    setImp(p,'resize','none');
    setImp(p,'overflow','hidden');
    setImp(p,'min-width','300px'); setImp(p,'min-height','180px');
    setImp(p,'max-width','calc(100vw - 12px)'); setImp(p,'max-height','calc(100vh - 12px)');
    setImp(p,'box-sizing','border-box');
    if(!p.dataset.phase54Placed){
      setImp(p,'left',px(d.left)); setImp(p,'top',px(d.top)); setImp(p,'width',px(d.width)); setImp(p,'height',px(d.height));
      p.dataset.phase54Placed='1';
    }
    const body=p.querySelector('.debugBody');
    if(body){ setImp(body,'height','calc(100% - 42px)'); setImp(body,'max-height','none'); setImp(body,'overflow','auto'); }
  }

  function attachPanelBehavior(p){
    if(!p || p.dataset.phase54Ready==='1') return;
    p.dataset.phase54Ready='1';
    normalizePanel(p);
    const head=p.querySelector('.debugHead') || p.firstElementChild || p;
    head.classList.add('phase54DragHead');
    head.title='Drag here to move this debug panel';
    head.style.setProperty('cursor','move','important');
    head.style.setProperty('user-select','none','important');

    const resize=document.createElement('div');
    resize.className='debugResizeHandle phase54ResizeHandle';
    resize.title='Drag to resize';
    p.appendChild(resize);

    function startDrag(e){
      if(e.button!==0) return;
      if(e.target.closest('button,select,input,textarea,.debugResizeHandle')) return;
      normalizePanel(p); bring(p);
      const r=p.getBoundingClientRect(), sx=e.clientX, sy=e.clientY;
      const sl=r.left, st=r.top;
      document.body.style.userSelect='none';
      function move(ev){
        const cr=p.getBoundingClientRect();
        const l=clamp(sl+ev.clientX-sx, 6, Math.max(6, window.innerWidth-cr.width-6));
        const t=clamp(st+ev.clientY-sy, 60, Math.max(60, window.innerHeight-cr.height-6));
        setImp(p,'left',px(l)); setImp(p,'top',px(t)); setImp(p,'right','auto'); setImp(p,'bottom','auto');
      }
      function up(){ document.removeEventListener('mousemove',move,true); document.removeEventListener('mouseup',up,true); document.body.style.userSelect=''; fit(p); }
      document.addEventListener('mousemove',move,true); document.addEventListener('mouseup',up,true);
      e.preventDefault(); e.stopPropagation();
    }
    function startResize(e){
      if(e.button!==0) return;
      normalizePanel(p); bring(p);
      const r=p.getBoundingClientRect(), sx=e.clientX, sy=e.clientY;
      const sw=r.width, sh=r.height;
      document.body.style.userSelect='none';
      function move(ev){
        const w=clamp(sw+ev.clientX-sx, 300, Math.max(320, window.innerWidth-r.left-6));
        const h=clamp(sh+ev.clientY-sy, 180, Math.max(200, window.innerHeight-r.top-6));
        setImp(p,'width',px(w)); setImp(p,'height',px(h));
      }
      function up(){ document.removeEventListener('mousemove',move,true); document.removeEventListener('mouseup',up,true); document.body.style.userSelect=''; fit(p); }
      document.addEventListener('mousemove',move,true); document.addEventListener('mouseup',up,true);
      e.preventDefault(); e.stopPropagation();
    }
    head.addEventListener('mousedown', startDrag, true);
    resize.addEventListener('mousedown', startResize, true);
    p.addEventListener('mousedown', function(){ bring(p); }, true);
  }

  function preparePanels(){
    PANEL_IDS.forEach(id=>{
      const p=document.getElementById(id);
      if(p){ normalizePanel(p); attachPanelBehavior(p); }
    });
  }

  const oldShow=window.phase5ShowDebugPanel;
  window.phase5ShowDebugPanel=function(id){
    if(typeof oldShow==='function') oldShow(id);
    setTimeout(function(){
      preparePanels();
      if(id==='all') PANEL_IDS.forEach(pid=>{const p=document.getElementById(pid); if(p){p.classList.remove('hidden'); normalizePanel(p); fit(p); bring(p);}});
      else if(id && id!=='hideAll'){ const p=document.getElementById(id); if(p){p.classList.remove('hidden'); normalizePanel(p); fit(p); bring(p);} }
    },0);
  };

  const oldOpen=window.phase5OpenDebugPanelFromTop;
  window.phase5OpenDebugPanelFromTop=function(){
    if(typeof oldOpen==='function') oldOpen();
    setTimeout(preparePanels,50);
  };

  function ensureStepButton(){
    if(document.getElementById('singleStepBtn')) return;
    const b=document.createElement('button');
    b.id='singleStepBtn';
    b.textContent='Single Step';
    b.title='Execute exactly one ARM/THUMB instruction from loaded HEX';
    b.onclick=function(){ window.phase54SingleStep && window.phase54SingleStep(); };
    const run=document.getElementById('runStopBtn');
    if(run && run.parentNode) run.parentNode.insertBefore(b, run.nextSibling);
    else toolbar().appendChild(b);
  }

  async function ensureLoadedForStep(){
    if(window.lpcArm7Emu && window.lpcArm7Emu.loaded) return window.lpcArm7Emu;
    if(!window.lastLpc2129Hex){
      if(typeof log==='function') log('Single Step: no HEX loaded. Building first...');
      if(typeof window.compileLpc2129Hex==='function'){
        const ok=await window.compileLpc2129Hex();
        if(!ok) return null;
      }
    }
    if(!window.LPC2129Arm7Emu){
      if(typeof log==='function') log('Single Step error: ARM7TDMI emulator constructor is not available.');
      return null;
    }
    const emu=new window.LPC2129Arm7Emu();
    try{
      const n=emu.loadIntelHex(window.lastLpc2129Hex||'');
      window.lpcArm7Emu=emu;
      if(typeof log==='function') log('Single Step: HEX loaded into emulated LPC2129 flash: '+n+' bytes.');
    }catch(e){ if(typeof log==='function') log('Single Step HEX load error: '+e.message); return null; }
    return emu;
  }

  window.phase54SingleStep=async function(){
    try{
      if(window.lpcArm7Emu && window.lpcArm7Emu.running){
        window.lpcArm7Emu.running=false;
        if(typeof log==='function') log('Single Step: paused continuous run first. Click Single Step again.');
        return;
      }
      const emu=await ensureLoadedForStep();
      if(!emu) return;
      preparePanels();
      try{ emu.step(); }
      catch(e){ emu.lastError=e.message; if(typeof log==='function') log('Single Step stopped: '+e.message); }
      try{ if(typeof syncGpioFromEmu==='function') syncGpioFromEmu(emu); }catch(e){}
      try{ if(typeof window.phase5RefreshDebug==='function') window.phase5RefreshDebug(emu,'single step'); }catch(e){}
      try{ window.phase5ShowDebugPanel('cpuProfilerPanel'); window.phase5ShowDebugPanel('cpuRegistersPanel'); window.phase5ShowDebugPanel('executionTracePanel'); }catch(e){}
      if(typeof log==='function') log('Single Step: PC='+('0x'+((emu.profiler&&emu.profiler.lastPC||emu.r[15])>>>0).toString(16).toUpperCase().padStart(8,'0'))+' Opcode='+(emu.profiler&&emu.profiler.lastOpcode||'-'));
    }catch(e){ if(typeof log==='function') log('Single Step error: '+e.message); }
  };

  window.addEventListener('load', function(){
    ensureStepButton();
    setTimeout(function(){ensureStepButton(); preparePanels();},700);
    setTimeout(preparePanels,1800);
  });
  window.addEventListener('resize', function(){ PANEL_IDS.forEach(id=>{ const p=document.getElementById(id); if(p && !p.classList.contains('hidden')) fit(p); }); });
})();


/* ============================================================
   PHASE 5.5 PATCH - Source arrow pointer for Single Step
   ------------------------------------------------------------
   - Server now returns objdump -d -S -l debug listing.
   - Frontend maps executed PC address to source line.
   - Shows a visible arrow gutter beside C/Assembly editor.
   - Highlights/selects current C/assembly line during Single Step.
   ============================================================ */
(function(){
  'use strict';

  function logSafe(msg){ try{ if(typeof log==='function') log(msg); }catch(e){} }
  function h8(x){ return '0x'+((x>>>0).toString(16).toUpperCase().padStart(8,'0')); }

  window.phase55BuildSourceMap = function(debugListing){
    const map = new Map();
    const text = String(debugListing || '');
    let currentLine = null;
    let currentFile = '';
    const lines = text.split(/\r?\n/);
    for(const raw of lines){
      const line = raw.trimRight();
      const lm = line.match(/(?:^|\s)([^\s]*main\.(?:c|s|S)):(\d+)(?::\d+)?/i) || line.match(/(?:^|\s)([^\s:]+\.(?:c|s|S)):(\d+)(?::\d+)?/i);
      if(lm){
        currentFile = lm[1];
        currentLine = parseInt(lm[2],10);
        continue;
      }
      const am = line.match(/^\s*([0-9A-Fa-f]+):\s+([0-9A-Fa-f]{4,8})(?:\s|$)/);
      if(am && currentLine){
        const addr = parseInt(am[1],16) >>> 0;
        map.set(addr, {line: currentLine, file: currentFile});
      }
    }
    return map;
  };

  function ensureSourceArrowUi(){
    const code = document.getElementById('code');
    if(!code) return null;
    const parent = code.parentElement;
    if(parent && getComputedStyle(parent).position === 'static') parent.style.position = 'relative';
    let arrow = document.getElementById('sourceStepArrow');
    if(!arrow){
      arrow = document.createElement('div');
      arrow.id = 'sourceStepArrow';
      arrow.innerHTML = '➜';
      arrow.title = 'Current instruction source line';
      arrow.style.cssText = [
        'position:absolute','left:6px','top:0px','width:24px','height:22px',
        'line-height:22px','text-align:center','font-weight:900','font-size:20px',
        'color:#ffef5a','background:#1c2b00','border:1px solid #d6c900',
        'border-radius:6px','box-shadow:0 0 10px rgba(255,230,0,.75)',
        'z-index:30','display:none','pointer-events:none'
      ].join(';');
      parent.appendChild(arrow);
    }
    let badge = document.getElementById('sourceStepBadge');
    if(!badge){
      badge = document.createElement('div');
      badge.id = 'sourceStepBadge';
      badge.style.cssText = [
        'position:absolute','right:10px','top:38px','z-index:31',
        'background:#0c1a2b','border:1px solid #5fa8ff','color:#d8ecff',
        'font:12px Consolas,monospace','padding:3px 7px','border-radius:6px',
        'display:none','pointer-events:none','box-shadow:0 2px 10px rgba(0,0,0,.35)'
      ].join(';');
      parent.appendChild(badge);
    }
    code.style.paddingLeft = '34px';
    code.addEventListener('scroll', function(){
      if(window.phase55CurrentLine) positionArrow(window.phase55CurrentLine, window.phase55CurrentPC, window.phase55CurrentOpcode);
    });
    return {code, arrow, badge};
  }

  function getLineMetrics(code){
    const cs = getComputedStyle(code);
    let lh = parseFloat(cs.lineHeight);
    if(!lh || isNaN(lh)) lh = parseFloat(cs.fontSize || '14') * 1.35;
    const padTop = parseFloat(cs.paddingTop || '0') || 0;
    return {lineHeight: lh, padTop};
  }

  function selectLine(code, lineNo){
    const lines = code.value.split(/\n/);
    const idx = Math.max(1, Math.min(lineNo, lines.length));
    let start = 0;
    for(let i=1;i<idx;i++) start += lines[i-1].length + 1;
    const end = start + (lines[idx-1] ? lines[idx-1].length : 0);
    try{ code.setSelectionRange(start, end); }catch(e){}
  }

  function positionArrow(lineNo, pc, opcode){
    const ui = ensureSourceArrowUi();
    if(!ui) return;
    const {code, arrow, badge} = ui;
    const m = getLineMetrics(code);
    const desiredY = (lineNo - 1) * m.lineHeight;
    const visibleTop = code.scrollTop;
    const visibleBottom = visibleTop + code.clientHeight - m.lineHeight;
    if(desiredY < visibleTop || desiredY > visibleBottom){
      code.scrollTop = Math.max(0, desiredY - Math.floor(code.clientHeight/2));
    }
    const codeRect = code.getBoundingClientRect();
    const parentRect = code.parentElement.getBoundingClientRect();
    const y = (codeRect.top - parentRect.top) + m.padTop + ((lineNo - 1) * m.lineHeight - code.scrollTop) - 1;
    const x = (codeRect.left - parentRect.left) + 4;
    arrow.style.left = Math.max(2, x) + 'px';
    arrow.style.top = Math.max(0, y) + 'px';
    arrow.style.display = 'block';
    badge.textContent = 'Line ' + lineNo + '  PC=' + h8(pc||0) + '  ' + (opcode || '');
    badge.style.display = 'block';
    selectLine(code, lineNo);
  }

  window.phase55HighlightSourceForPC = function(pc, opcode){
    const map = window.lastLpc2129DebugMap || (window.lastLpc2129DebugListing ? window.phase55BuildSourceMap(window.lastLpc2129DebugListing) : null);
    if(map && !window.lastLpc2129DebugMap) window.lastLpc2129DebugMap = map;
    const addr = (pc>>>0);
    let info = map ? map.get(addr) : null;
    // Some decoders store PC before/after fetch. Try near addresses also.
    if(!info && map){
      for(const delta of [-8,-4,-2,2,4,8]){
        info = map.get((addr + delta)>>>0);
        if(info) break;
      }
    }
    if(info && info.line){
      window.phase55CurrentLine = info.line;
      window.phase55CurrentPC = addr;
      window.phase55CurrentOpcode = opcode || '';
      positionArrow(info.line, addr, opcode);
      return true;
    }
    const ui = ensureSourceArrowUi();
    if(ui){
      ui.badge.textContent = 'Source line not mapped for PC=' + h8(addr) + ' ' + (opcode||'');
      ui.badge.style.display = 'block';
    }
    return false;
  };

  function currentPcAndOpcode(emu){
    const pr = emu && emu.profiler ? emu.profiler : {};
    const pc = (pr.lastPC !== undefined && pr.lastPC !== null) ? pr.lastPC : (emu ? emu.currentPC : 0);
    const opcode = pr.lastOpcode || (emu && emu.currentOpcodeText) || '';
    return {pc: pc>>>0, opcode};
  }

  // Wrap single-step so source arrow updates after every instruction.
  const oldSingleStep = window.phase54SingleStep;
  window.phase54SingleStep = async function(){
    if(typeof oldSingleStep === 'function') await oldSingleStep();
    const emu = window.lpcArm7Emu;
    if(emu){
      const co = currentPcAndOpcode(emu);
      const ok = window.phase55HighlightSourceForPC(co.pc, co.opcode);
      if(ok) logSafe('Source Arrow: line ' + window.phase55CurrentLine + ' <= PC=' + h8(co.pc));
      else logSafe('Source Arrow: no debug line map for PC=' + h8(co.pc) + '. Rebuild HEX with this version, then Single Step again.');
    }
  };

  // Also refresh arrow when debugger panel refreshes during continuous run.
  const oldRefresh = window.phase5RefreshDebug;
  window.phase5RefreshDebug = function(emu,msg){
    if(typeof oldRefresh === 'function') oldRefresh(emu,msg);
    try{
      if(emu && msg === 'single step'){
        const co = currentPcAndOpcode(emu);
        window.phase55HighlightSourceForPC(co.pc, co.opcode);
      }
    }catch(e){}
  };

  // Rebuild map if a HEX build completed before this patch loaded.
  const oldCompile = window.compileLpc2129Hex;
  if(typeof oldCompile === 'function'){
    window.compileLpc2129Hex = async function(){
      const ok = await oldCompile.apply(this, arguments);
      if(ok && window.lastLpc2129DebugListing){
        window.lastLpc2129DebugMap = window.phase55BuildSourceMap(window.lastLpc2129DebugListing);
        logSafe('Source-step map ready: ' + window.lastLpc2129DebugMap.size + ' PC→line entries.');
      }
      return ok;
    };
    window.unifiedCompile = window.compileLpc2129Hex;
  }

  window.addEventListener('load', function(){
    setTimeout(function(){
      ensureSourceArrowUi();
      logSafe('Phase 5.5 loaded: Source arrow pointer enabled for C/Assembly single stepping. Build HEX first, then use Single Step.');
    }, 900);
  });
})();

/* ============================================================
   VECTOR LPC2129 SIMULATOR - PHASE 6.0A
   System Clock, PLL, VPB and MAM Timing Foundation
   ============================================================ */
(function(){
  'use strict';
  if(window.__vectorPhase60AInstalled) return;
  window.__vectorPhase60AInstalled=true;

  const cfg=window.LPC2129ClockConfig=window.LPC2129ClockConfig||{
    oscMHz:12, pllEnabled:true, m:5, p:2, vpbDiv:4, mamMode:2, mamTim:3,
    cclkHz:60000000,pclkHz:15000000,fccoHz:240000000
  };
  function n(v,d){v=Number(v);return Number.isFinite(v)?v:d;}
  function recalc(){
    cfg.oscMHz=Math.max(1,n(val('p60Osc'),cfg.oscMHz));
    cfg.pllEnabled=!!(document.getElementById('p60Pll')&&document.getElementById('p60Pll').checked);
    cfg.m=Math.max(1,Math.min(32,Math.round(n(val('p60M'),cfg.m))));
    cfg.p=n(val('p60P'),cfg.p); if(![1,2,4,8].includes(cfg.p))cfg.p=2;
    cfg.vpbDiv=n(val('p60Vpb'),cfg.vpbDiv); if(![1,2,4].includes(cfg.vpbDiv))cfg.vpbDiv=4;
    cfg.mamMode=n(val('p60MamMode'),cfg.mamMode);
    cfg.mamTim=Math.max(1,Math.min(7,Math.round(n(val('p60MamTim'),cfg.mamTim))));
    cfg.cclkHz=Math.round(cfg.oscMHz*1000000*(cfg.pllEnabled?cfg.m:1));
    cfg.fccoHz=Math.round(cfg.cclkHz*2*cfg.p);
    cfg.pclkHz=Math.round(cfg.cclkHz/cfg.vpbDiv);
    refresh();
    try{ if(window.lpcArm7Emu&&window.phase5RefreshDebug)window.phase5RefreshDebug(window.lpcArm7Emu,'clock configuration updated'); }catch(e){}
  }
  function val(id){const e=document.getElementById(id);return e?e.value:undefined;}
  function hz(v){return (v/1000000).toFixed(v%1000000?3:0)+' MHz';}
  function ns(v){return v?((1e9/v).toFixed(2)+' ns'):'-';}
  function refresh(){
    const map={p60Cclk:hz(cfg.cclkHz),p60Pclk:hz(cfg.pclkHz),p60Fcco:hz(cfg.fccoHz),p60Cycle:ns(cfg.cclkHz),p60PerCycle:ns(cfg.pclkHz)};
    Object.keys(map).forEach(id=>{const e=document.getElementById(id);if(e)e.textContent=map[id];});
    const pll=document.getElementById('p60PllStatus');
    if(pll){const ok=!cfg.pllEnabled||(cfg.fccoHz>=156000000&&cfg.fccoHz<=320000000);pll.textContent=ok?'Valid PLL operating range':'FCCO outside 156–320 MHz';pll.className=ok?'phase60-clock-ok':'phase60-clock-warn';}
    const emu=window.lpcArm7Emu,cy=emu&&emu.profiler?emu.profiler.totalCycles:0, tm=document.getElementById('p60Elapsed');
    if(tm)tm.textContent=cy?formatSeconds(cy/cfg.cclkHz):'0 ns';
  }
  function formatSeconds(sec){if(sec<1e-6)return (sec*1e9).toFixed(1)+' ns';if(sec<1e-3)return (sec*1e6).toFixed(2)+' µs';if(sec<1)return (sec*1e3).toFixed(3)+' ms';return sec.toFixed(6)+' s';}
  function create(){
    let p=document.getElementById('phase60ClockPanel'); if(p)return p;
    p=document.createElement('div');p.id='phase60ClockPanel';p.className='phase60-clock-panel';
    p.innerHTML='<div class="phase60-clock-head"><span>LPC2129 System Clock & Timing</span><button type="button" id="p60Close">×</button></div><div class="phase60-clock-body">'+
      '<div class="phase60-clock-grid">'+
      '<div class="phase60-clock-field"><label>Oscillator (MHz)</label><input id="p60Osc" type="number" min="1" max="25" step="0.001" value="'+cfg.oscMHz+'"></div>'+
      '<div class="phase60-clock-field"><label>PLL</label><label style="padding-top:5px;color:#e8eef8"><input id="p60Pll" type="checkbox" '+(cfg.pllEnabled?'checked':'')+' style="width:auto"> Enabled</label></div>'+
      '<div class="phase60-clock-field"><label>PLL Multiplier M</label><input id="p60M" type="number" min="1" max="32" value="'+cfg.m+'"></div>'+
      '<div class="phase60-clock-field"><label>PLL Divider P</label><select id="p60P"><option>1</option><option selected>2</option><option>4</option><option>8</option></select></div>'+
      '<div class="phase60-clock-field"><label>VPB Divider</label><select id="p60Vpb"><option value="1">CCLK / 1</option><option value="2">CCLK / 2</option><option value="4" selected>CCLK / 4</option></select></div>'+
      '<div class="phase60-clock-field"><label>MAM Mode</label><select id="p60MamMode"><option value="0">Disabled</option><option value="1">Partially enabled</option><option value="2" selected>Fully enabled</option></select></div>'+
      '<div class="phase60-clock-field"><label>MAMTIM cycles</label><input id="p60MamTim" type="number" min="1" max="7" value="'+cfg.mamTim+'"></div></div>'+
      '<table class="phase60-clock-results"><tr><td>CPU Clock (CCLK)</td><td id="p60Cclk"></td></tr><tr><td>Peripheral Clock (PCLK)</td><td id="p60Pclk"></td></tr><tr><td>PLL CCO Frequency</td><td id="p60Fcco"></td></tr><tr><td>CPU cycle period</td><td id="p60Cycle"></td></tr><tr><td>Peripheral cycle period</td><td id="p60PerCycle"></td></tr><tr><td>Emulated elapsed time</td><td id="p60Elapsed"></td></tr><tr><td>PLL check</td><td id="p60PllStatus"></td></tr></table>'+
      '<div class="phase60-clock-note">Default classroom profile: 12 MHz oscillator × 5 = 60 MHz CCLK, VPB ÷ 4 = 15 MHz PCLK, fully enabled MAM with MAMTIM = 3.</div></div>';
    document.body.appendChild(p);
    ['p60Osc','p60Pll','p60M','p60P','p60Vpb','p60MamMode','p60MamTim'].forEach(id=>{const e=document.getElementById(id);if(e)e.addEventListener('change',recalc);});
    document.getElementById('p60Close').onclick=()=>p.style.display='none';
    makeDrag(p,p.querySelector('.phase60-clock-head')); recalc(); return p;
  }
  function makeDrag(panel,handle){let down=false,ox=0,oy=0;handle.addEventListener('mousedown',e=>{if(e.target.tagName==='BUTTON')return;down=true;const r=panel.getBoundingClientRect();ox=e.clientX-r.left;oy=e.clientY-r.top;e.preventDefault();});window.addEventListener('mousemove',e=>{if(!down)return;panel.style.left=Math.max(0,e.clientX-ox)+'px';panel.style.top=Math.max(72,e.clientY-oy)+'px';panel.style.right='auto';});window.addEventListener('mouseup',()=>down=false);}
  window.phase60ToggleClockPanel=function(){const p=create();p.style.display=(p.style.display==='none')?'block':'none';refresh();};
  window.phase60RecalculateClock=recalc;
  setInterval(refresh,250);
  window.addEventListener('load',()=>setTimeout(()=>{create();try{if(typeof log==='function')log('Phase 6.0A loaded: LPC2129 oscillator, PLL, VPB, MAM and cycle-time model active.');}catch(e){}},900));
})();


/* ===== Phase 8.4I: Glassy/transparent external LED + selectable colour ===== */
(function(){
  const PALETTE={
    red:   {rgb:'255,42,42',   on:'#ff2a2a', off:'#521010'},
    green: {rgb:'46,255,112',  on:'#2eff70', off:'#0d4a25'},
    yellow:{rgb:'255,235,64',  on:'#ffeb40', off:'#554d0b'},
    amber: {rgb:'255,166,32',  on:'#ffa620', off:'#5a3408'},
    blue:  {rgb:'48,146,255',  on:'#3092ff', off:'#0a2852'},
    white: {rgb:'242,248,255', on:'#f2f8ff', off:'#5d6874'}
  };
  function spec(part){
    const key=(part&&PALETTE[part.ledColor])?part.ledColor:'red';
    if(part && !part.ledColor) part.ledColor=key;
    return {key,...PALETTE[key]};
  }
  function paint(part){
    if(!part||part.type!=='led') return;
    const el=document.getElementById(part.id); if(!el) return;
    const bulb=el.querySelector('.ledBulb'); if(!bulb) return;
    const c=spec(part), on=!!part.state;
    el.dataset.ledColor=c.key;
    bulb.classList.toggle('on',on);
    bulb.style.setProperty('--led-rgb',c.rgb);
    bulb.style.setProperty('--led-on',c.on);
    bulb.style.setProperty('--led-off',c.off);
    /* Override legacy red-only painters while retaining electrical state. */
    bulb.style.setProperty('background',on
      ? `radial-gradient(circle at 34% 24%, rgba(255,255,255,.88) 0 6%, rgba(${c.rgb},.62) 16%, rgba(${c.rgb},.30) 44%, rgba(${c.rgb},.16) 72%, rgba(${c.rgb},.08) 100%)`
      : `radial-gradient(circle at 34% 24%, rgba(255,255,255,.48) 0 5%, rgba(${c.rgb},.20) 18%, rgba(${c.rgb},.10) 56%, rgba(20,26,32,.17) 100%)`,'important');
    bulb.style.setProperty('background-color','transparent','important');
    bulb.style.setProperty('box-shadow',on
      ? `inset 0 0 12px rgba(255,255,255,.24), inset 0 -10px 18px rgba(${c.rgb},.25), 0 0 12px rgba(${c.rgb},.92), 0 0 30px rgba(${c.rgb},.64), 0 0 54px rgba(${c.rgb},.28)`
      : `inset 0 0 9px rgba(255,255,255,.15), inset 0 -10px 15px rgba(${c.rgb},.10), 0 2px 5px rgba(0,0,0,.34)`,'important');
    bulb.style.setProperty('filter',on?'brightness(1.18) saturate(1.16)':'brightness(.82) saturate(.72)','important');
    bulb.style.setProperty('opacity','1','important');
  }
  function refresh(){
    if(!window.project||!Array.isArray(project.parts)) return;
    project.parts.forEach(p=>{if(p&&p.type==='led') paint(p);});
  }
  window.setExternalLedColor=function(id,color){
    if(!PALETTE[color]) return;
    const part=window.project&&project.parts&&project.parts.find(p=>p.id===id);
    if(!part||part.type!=='led') return;
    part.ledColor=color;
    try{render();}catch(e){paint(part);}
  };
  window.phase84iRefreshExternalLeds=refresh;
  const oldRender=(typeof render==='function')?render:null;
  if(oldRender&&!window.__phase84iRenderWrapped){
    window.__phase84iRenderWrapped=true;
    window.render=render=function(){const r=oldRender.apply(this,arguments); requestAnimationFrame(refresh); return r;};
  }
  if(typeof window.updateLpcExternalLoads==='function'&&!window.__phase84iLoadsWrapped){
    const oldLoads=window.updateLpcExternalLoads;
    window.__phase84iLoadsWrapped=true;
    window.updateLpcExternalLoads=function(){const r=oldLoads.apply(this,arguments); refresh(); return r;};
  }
  window.addEventListener('load',()=>setTimeout(refresh,250));
})();

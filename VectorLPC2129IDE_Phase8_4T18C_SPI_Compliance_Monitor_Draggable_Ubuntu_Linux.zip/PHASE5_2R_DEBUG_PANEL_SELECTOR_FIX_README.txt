Phase 5.2R Debug Panel Selector Fix
===================================

Fixes:
- Debug Panel dropdown is now visible directly in the top toolbar.
- Selective panel visibility works from the toolbar.
- CPU Profiler is no longer auto-opened as the only visible panel.
- Show Debug Panel opens only the selected panel.
- Show All Debug opens all debugger panels.
- Hide Debug hides all debugger panels.
- Floating panels remain draggable and resizable.
- Panels are constrained to viewport for complete visibility.

How to test:
1. Run RUN_SERVER.bat
2. Open frontend.
3. In top toolbar, find the green-highlighted Debug Panel dropdown.
4. Select CPU Registers / Execution Trace / Instruction Coverage / etc.
5. Click Show Debug Panel.
6. Drag panel using its title bar.
7. Resize panel from its bottom-right corner.
8. Use Hide Debug to close all debug panels.

/* VECTOR LPC2129 IDE — Phase 8.3P
   Draggable onboard wiring editor for LPC2129 header <-> UART/AUX and SW/LED Berg nodes.
   Electrical connectivity remains exclusively in project.wires.
   boardBends stores only the visual route in 768x512 board-stage coordinates.
*/
(function(){
'use strict';
if(window.__phase83jInstalled)return; window.__phase83jInstalled=true;
const NS='http://www.w3.org/2000/svg';
let drag=null, selected=-1, rendering=false, lastDown={wi:-1,t:0};
function q(id){return document.getElementById(id)}
function prj(){try{if(typeof project!=='undefined'&&project)return project}catch(e){}return window.project||null}
function stage(){return document.querySelector('#uno .p74f-board-stage')}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function snap(v){return Math.round(v/2)*2}
function localPointFromClient(clientX,clientY){const s=stage();if(!s)return null;const r=s.getBoundingClientRect();if(!r.width||!r.height)return null;return{x:snap((clientX-r.left)*(768/r.width)),y:snap((clientY-r.top)*(512/r.height))}}
function center(el){const s=stage();if(!s||!el)return null;const er=el.getBoundingClientRect(),sr=s.getBoundingClientRect();if(!sr.width||!sr.height)return null;return{x:((er.left+er.width/2)-sr.left)*(768/sr.width),y:((er.top+er.height/2)-sr.top)*(512/sr.height)}}
function color(w){try{if(typeof colorForWire==='function')return colorForWire(w)}catch(e){}return '#ff9800'}
function wireInfo(w){const isBoard=n=>/^p83g\.AUX[0-3]$/.test(String(n||''))||/^p83e\.(SW|LED)$/.test(String(n||''));const a=isBoard(w.from)?w.from:(isBoard(w.to)?w.to:null),pin=a===w.from?w.to:w.from;if(!a||!/^uno\.P[01]_\d+$/.test(String(pin||'')))return null;return{aux:a,pin}}
function endpointPoints(info){const s=stage();if(!s)return null;const pe=s.querySelector('[data-node="'+CSS.escape(info.pin)+'"]'),ae=s.querySelector('[data-node="'+CSS.escape(info.aux)+'"]');const a=center(pe),b=center(ae);return a&&b?{a,b}:null}
function defaultBends(a,b){
 const dy=b.y-a.y;
 const y1=clamp(a.y+(dy>=0?18:-18),8,504);
 const y2=clamp(b.y-(dy>=0?18:-18),8,504);
 let mx=(a.x+b.x)/2;
 if(Math.abs(b.x-a.x)<80)mx=a.x+(b.x>=a.x?42:-42);
 mx=clamp(snap(mx),8,760);
 return[{x:snap(a.x),y:snap(y1)},{x:mx,y:snap(y1)},{x:mx,y:snap(y2)},{x:snap(b.x),y:snap(y2)}];
}
function validBends(b){return Array.isArray(b)&&b.length>=2&&b.every(p=>Number.isFinite(p&&p.x)&&Number.isFinite(p&&p.y))}
function normalizeRoute(w,a,b){if(!validBends(w.boardBends))w.boardBends=defaultBends(a,b);return w.boardBends}
function poly(points){return points.map(p=>p.x.toFixed(1)+','+p.y.toFixed(1)).join(' ')}
function svgEl(name,attrs){const el=document.createElementNS(NS,name);Object.entries(attrs||{}).forEach(([k,v])=>el.setAttribute(k,String(v)));return el}
function ensureLayer(){const s=stage();if(!s)return null;let svg=q('p83jBoardWires');if(svg&&svg.parentElement!==s){svg.remove();svg=null}if(!svg){svg=svgEl('svg',{id:'p83jBoardWires',class:'p83j-board-wire-layer',viewBox:'0 0 768 512'});s.appendChild(svg)}return svg}

function suppressDuplicateCommonBoardWires(){
 const p=prj(),svg=document.getElementById('wires');
 if(!p||!Array.isArray(p.wires)||!svg)return;
 const groups=Array.from(svg.children).filter(el=>String(el.tagName).toLowerCase()==='g');
 groups.forEach((g,visualIndex)=>{
   let wi=Number(g.getAttribute('data-vector-wire-index'));
   if(!Number.isInteger(wi)||wi<0)wi=visualIndex;
   const w=p.wires[wi];
   g.style.display=(w&&wireInfo(w))?'none':'';
 });
}

function saveVisual(){try{if(typeof window.saveProject==='function'){} }catch(e){} }
function maybeDoubleDelete(e,wi){const now=performance.now();if(lastDown.wi===wi&&(now-lastDown.t)<380){lastDown={wi:-1,t:0};deleteWireAt(wi,e);return true}lastDown={wi,t:now};return false}
function beginSegDrag(e,wi,si,orient){e.preventDefault();e.stopPropagation();if(maybeDoubleDelete(e,wi))return;selected=wi;drag={type:'seg',wi,si,orient,start:localPointFromClient(e.clientX,e.clientY),moved:false};try{e.target.setPointerCapture(e.pointerId)}catch(_){ }}
function beginBendDrag(e,wi,bi){e.preventDefault();e.stopPropagation();if(maybeDoubleDelete(e,wi))return;selected=wi;drag={type:'bend',wi,bi,start:localPointFromClient(e.clientX,e.clientY),moved:false};try{e.target.setPointerCapture(e.pointerId)}catch(_){ }}
function moveSegment(w,si,p){const info=wireInfo(w),ep=info&&endpointPoints(info);if(!ep)return;const bends=normalizeRoute(w,ep.a,ep.b),pts=[ep.a,...bends,ep.b];if(si<=0||si>=pts.length-2)return;const p0=pts[si],p1=pts[si+1];if(Math.abs(p0.y-p1.y)<=Math.abs(p0.x-p1.x)){const y=clamp(p.y,6,506);bends[si-1].y=y;bends[si].y=y}else{const x=clamp(p.x,6,762);bends[si-1].x=x;bends[si].x=x}}
function moveBend(w,bi,p){const info=wireInfo(w),ep=info&&endpointPoints(info);if(!ep)return;const b=normalizeRoute(w,ep.a,ep.b);if(bi<0||bi>=b.length)return;const pts=[ep.a,...b,ep.b],idx=bi+1,prev=pts[idx-1],cur=pts[idx],next=pts[idx+1];let x=clamp(p.x,6,762),y=clamp(p.y,6,506);
 const prevH=Math.abs(prev.y-cur.y)<=Math.abs(prev.x-cur.x),nextH=Math.abs(next.y-cur.y)<=Math.abs(next.x-cur.x);
 if(prevH){cur.y=prev.y;cur.x=x;if(idx+1<pts.length-1)next.x=x}else{cur.x=prev.x;cur.y=y;if(idx+1<pts.length-1)next.y=y}
 // If both adjacent segments have the same orientation (possible after edits), use the other axis for the next segment.
 if(prevH===nextH){if(prevH&&idx+1<pts.length-1)next.y=y;else if(!prevH&&idx+1<pts.length-1)next.x=x}
 b[bi]={x:snap(cur.x),y:snap(cur.y)};
 // Copy any adjusted neighboring bend back from pts.
 for(let k=1;k<pts.length-1;k++)b[k-1]={x:snap(pts[k].x),y:snap(pts[k].y)};
}
function deleteWireAt(wi,e){if(e){e.preventDefault();e.stopPropagation()}const pp=prj();if(!pp||!Array.isArray(pp.wires)||wi<0||wi>=pp.wires.length)return false;pp.wires.splice(wi,1);selected=-1;drag=null;try{if(typeof drawWires==='function')drawWires()}catch(_){setTimeout(render,0)};setTimeout(render,0);return true}
function render(){if(rendering)return;rendering=true;try{const s=stage(),p=prj();if(!s||!p||!Array.isArray(p.wires))return;suppressDuplicateCommonBoardWires();const svg=ensureLayer();svg.innerHTML='';p.wires.forEach((w,wi)=>{const info=wireInfo(w);if(!info)return;const ep=endpointPoints(info);if(!ep)return;const bends=normalizeRoute(w,ep.a,ep.b),pts=[ep.a,...bends,ep.b],c=color(w);const g=svgEl('g',{class:'p83j-wire-group'+(selected===wi?' p83j-selected':''),'data-wire-index':wi});
 const sh=svgEl('polyline',{class:'p83j-shadow',points:poly(pts)}),ln=svgEl('polyline',{class:'p83j-wire',points:poly(pts),stroke:c});g.append(sh,ln);
 for(let si=1;si<pts.length-2;si++){const a=pts[si],b=pts[si+1];const hit=svgEl('line',{class:'p83j-seg-hit',x1:a.x,y1:a.y,x2:b.x,y2:b.y});const orient=Math.abs(a.x-b.x)>=Math.abs(a.y-b.y)?'H':'V';hit.addEventListener('pointerdown',e=>beginSegDrag(e,wi,si,orient));hit.addEventListener('dblclick',e=>deleteWireAt(wi,e));hit.setAttribute('title','Drag to reroute • double-click to delete wire');g.appendChild(hit)}
 bends.forEach((bp,bi)=>{const h=svgEl('circle',{class:'p83j-bend',cx:bp.x,cy:bp.y,r:4,stroke:c});h.addEventListener('pointerdown',e=>beginBendDrag(e,wi,bi));h.addEventListener('dblclick',e=>deleteWireAt(wi,e));h.setAttribute('title','Drag bend • double-click to delete wire');g.appendChild(h)});
 // Endpoint caps are intentionally rendered on TOP of the physical board/header graphics.
 [ep.a,ep.b].forEach(pt=>g.appendChild(svgEl('circle',{class:'p83j-end',cx:pt.x,cy:pt.y,r:5,fill:c})));
 g.addEventListener('dblclick',e=>deleteWireAt(wi,e));svg.appendChild(g)});}finally{rendering=false}}
function onMove(e){if(!drag)return;const p=prj(),pt=localPointFromClient(e.clientX,e.clientY);if(!p||!pt||!Array.isArray(p.wires)||drag.wi<0||drag.wi>=p.wires.length)return;const w=p.wires[drag.wi];drag.moved=true;if(drag.type==='seg')moveSegment(w,drag.si,pt);else moveBend(w,drag.bi,pt);render();e.preventDefault()}
function onUp(e){if(!drag)return;const moved=!!drag.moved;drag=null;saveVisual();if(moved)render();e.preventDefault()}
function wrapRenderer(){if(window.__phase83jRendererWrapped)return;window.__phase83jRendererWrapped=true;try{if(typeof drawWires==='function'){const old=drawWires;window.drawWires=drawWires=function(){const r=old.apply(this,arguments);setTimeout(()=>{suppressDuplicateCommonBoardWires();render()},0);return r}}}catch(e){} }
function install(){const s=stage();if(!s)return false;wrapRenderer();ensureLayer();render();window.addEventListener('resize',()=>setTimeout(render,0));document.addEventListener('pointermove',onMove,true);document.addEventListener('pointerup',onUp,true);document.addEventListener('pointercancel',onUp,true);return true}
window.phase83jRenderBoardWires=render;
window.phase83jResetBoardRoute=function(index){const p=prj();if(!p||!Array.isArray(p.wires)||!p.wires[index])return false;delete p.wires[index].boardBends;render();return true};
window.addEventListener('load',()=>setTimeout(install,250));
setTimeout(install,450);
})();

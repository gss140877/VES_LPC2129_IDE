/* VECTOR LPC2129 IDE Phase 7.3A - Board-style LPC2129 module */
(function(){'use strict';
if(window.__phase73BoardInstalled)return; window.__phase73BoardInstalled=true;
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function install(){
 const board=document.getElementById('uno'); if(!board||board.dataset.p73Board==='1')return;
 const pins=[...board.querySelectorAll('.qfp-lead[data-node]')].map((el,i)=>({node:el.dataset.node,tip:el.dataset.tip||el.dataset.node,label:(el.querySelector('.qfp-label')?.textContent||el.dataset.node.replace('uno.','').replace('_','.')),order:i}));
 if(pins.length!==46){console.warn('Phase 7.3A expected 46 LPC2129 signal nodes; found',pins.length);return}
 const left=pins.slice(0,23),right=pins.slice(23);
 function rows(arr,side){return arr.map(p=>`<div class="p73-pinrow"><span class="${side==='left'?'p73-hdr-pad':''}"></span><span class="p73-label">${esc(p.label)}</span><span class="${side==='right'?'p73-hdr-pad':''}"></span><span class="pin lpc-pin p73-hit" data-node="${esc(p.node)}" data-tip="${esc(p.tip)}" title="${esc(p.tip)}"></span></div>`).join('')}
 board.className='uno lpc-board p73-devboard'; board.dataset.p73Board='1';
 board.innerHTML=`<div class="p73-pcb"><div class="p73-hole2"></div><div class="p73-hole3"></div><div class="p73-title">VECTOR LPC2129 DEVELOPMENT BOARD<span class="p73-subtitle">ARM7TDMI-S • 46 connectable signal headers</span></div><div class="p73-header left">${rows(left,'left')}</div><div class="p73-header right">${rows(right,'right')}</div><div class="p73-cpu"><div>LPC2129FBD64<small>ARM7TDMI-S<br>64-pin LQFP</small></div></div><div class="p73-smallmod p73-crystal">12 MHz<br>CRYSTAL</div><div class="p73-smallmod p73-reset"><b></b>RESET</div><div class="p73-smallmod p73-isp">ISP / UART0<br>P0.0 • P0.1</div><div class="p73-smallmod p73-jtag">JTAG<br>DEBUG</div><div class="p73-power"><div class="p73-power-title">ONBOARD POWER SUPPLY</div><div class="p73-flow"><span class="p73-block">5V IN</span><span class="p73-arrow">→</span><span class="p73-block">3.3V REG</span><span class="p73-arrow">→</span><span class="p73-block">1.8V CORE</span></div><div style="margin-top:8px"><span class="p73-led"></span>3.3V <span class="p73-led"></span>1.8V &nbsp; Common GND</div></div><div class="p73-silk s1">PLL / MAM / VPB clock domain</div><div class="p73-silk s2">GPIO • UART • SPI • I²C • CAN • ADC • PWM • EINT</div></div>`;
 // Re-bind the simulator's generic pin wiring handlers to the newly-created 46 hit boxes.
 try{if(typeof window.bindPinEvents==='function')window.bindPinEvents();}catch(e){}
 try{if(typeof window.installPinHandlers==='function')window.installPinHandlers();}catch(e){}
 try{if(typeof window.renderWires==='function')window.renderWires();}catch(e){}
 try{if(typeof window.log==='function')window.log('Phase 7.3A: LPC2129 development-board component active with 46 connectable header hit boxes and onboard power section.');}catch(e){}
}
window.addEventListener('load',()=>setTimeout(install,850));
})();

VECTOR LPC2129 IDE — Phase 8.4K
Realistic SMD LED / Push-Button Trainer PCB

Baseline: Phase 8.4J, preserving the confirmed Phase 8.4H canonical CPU/peripheral timing architecture.

PCB layout changes:
- One realistic green trainer PCB, not a software control panel.
- 8 SMD LED output channels arranged horizontally.
- Each LED channel shows a 330R resistor, SMD LED, copper trace, AH/AL 2-position DIP selector, and a small outward-facing Berg signal pin along the top board edge.
- 8 SMD momentary push-button input channels arranged horizontally.
- Each push-button channel shows a 10K pull network, AH/AL DIP selector, SMD tactile push button, copper trace, and small outward-facing Berg signal pin along the bottom board edge.
- Shared 3V3 and GND Berg headers are placed at the right PCB edge.
- Mounting holes, silkscreen, power LED, rails, resistor footprints and copper traces are represented visually.

Electrical meaning:
LED AH: GPIO HIGH -> ON (source-current style).
LED AL: GPIO LOW -> ON (sink-current style).
Switch AH: 10K pull-down; pressed -> HIGH.
Switch AL: 10K pull-up; pressed -> LOW.
Push-buttons are momentary (press-and-hold), not latching switches.

Simulation-only LED colour:
- LED colour is NOT drawn as a circuit selector on the PCB.
- When the trainer board is selected, a separate dark 'SIMULATION' panel appears below the PCB.
- L1..L8 emission colours can be selected independently there.
- The physical PCB itself only contains the LED, resistor, DIP polarity selector and connector.

Canonical path remains:
Compiled HEX -> ARM7TDMI-S CPU -> LPC2129 GPIO -> physical project wiring -> trainer LED / switch input.
No source parser shortcut and no direct Timer-to-LED shortcut are introduced.

VECTOR LPC2129 IDE — Phase 8.3J
DRAGGABLE ONBOARD UART/AUX WIRING

Based on Phase 8.3I (confirmed UART/AUX LED-bank operation).

Changes:
1. Onboard header <-> A0/A1/A2/A3 jumpers now have editable visual routes.
2. Drag an interior horizontal/vertical wire segment to shift that route segment.
3. Drag the visible bend handles to refine the route around board artwork.
4. Electrical endpoints remain locked to the real canonical physical pin and AUX node.
5. Visual routing is stored as boardBends on the same project.wires entry; it does not create a second electrical net.
6. Endpoint wire caps are rendered above the board/header artwork, so the wire visibly lands ON the header socket instead of disappearing underneath it.
7. Existing Phase 8.3I UART/AUX selector behavior, P1.30/P1.31 trainer, RESET/PWR, UART/VIC worker runtime, and terminal-hitbox corrections are retained.
8. Approved vector_lpc2129_board.png is unchanged.

Canonical rule remains:
compiled source -> HEX -> ARM7 CPU -> SFR/peripheral/pin mux -> canonical physical pin -> real project wire -> AUX node -> selected onboard LED.

This build has passed static JavaScript syntax and package-integrity checks. Runtime visual/interaction validation remains for user testing.

(function(){'use strict';
if(window.__phase84t18DebugClear)return;window.__phase84t18DebugClear=true;
function scopeFor(p){const id=(p.id||'').toLowerCase();if(id.includes('can'))return'can';if(id.includes('spi'))return'spi';if(id.includes('i2c')||id.includes('eeprom'))return'i2c';return'all'}
function bodyOf(p){return p.querySelector('.canDbgBody,.spiDbgBody,.spiComp17Body,.i2cCompBody,.p84t-panel-body')}
function clearPanel(p){const scope=scopeFor(p);try{window.phase84t18ClearDebug&&window.phase84t18ClearDebug(scope)}catch(e){}const b=bodyOf(p);if(b)b.innerHTML='<div style="padding:12px;color:#aaa;font:10px Consolas,monospace">Observation cleared. Live hardware/register values will appear on the next update.</div>';}
function add(p){if(!p||p.dataset.clear18)return;const h=p.querySelector('.canDbgHead,.spiDbgHead,.spiComp17Head,.i2cCompHead,.p84t-panel-head');if(!h)return;let close=h.querySelector('button:last-child');const b=document.createElement('button');b.textContent='Clear';b.title='Clear previous monitor/debug observations';b.className='dbgClear18';b.onclick=e=>{e.stopPropagation();clearPanel(p)};if(close)h.insertBefore(b,close);else h.appendChild(b);p.dataset.clear18='1'}
function scan(){document.querySelectorAll('.canDbg,.spiDbg,.spiComp17,.i2cComp,.p84t-panel').forEach(add)}
new MutationObserver(scan).observe(document.documentElement,{childList:true,subtree:true});window.addEventListener('load',()=>setTimeout(scan,700));setInterval(scan,1000);
})();
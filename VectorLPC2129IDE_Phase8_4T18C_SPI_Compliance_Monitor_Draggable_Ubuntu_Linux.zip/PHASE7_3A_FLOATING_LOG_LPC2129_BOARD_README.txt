VECTOR LPC2129 IDE - Phase 7.3A

Changes from Phase 7.2A:
1. Compiler / Log uses the floating IDE window manager.
   - Open/reopen from the toolbar Log button or View > Build Output.
   - Close, drag, resize, and bring-to-front supported.
2. LPC2129 canvas component redesigned as a development-board module.
   - LPC2129FBD64 remains the simulated MCU.
   - Onboard visual power section: 5 V input, 3.3 V regulator, 1.8 V core rail, ground and power LEDs.
   - 12 MHz crystal, reset, ISP/UART0 and JTAG areas represented.
3. Exactly 46 original LPC2129 connectable signal nodes are preserved.
   - Arranged as two 23-pin board header banks.
   - Every header is labelled and has an enlarged invisible/hoverable hit box.
   - Existing external-component wiring engine continues to use the same data-node IDs.
4. Circuit Canvas + Component Selection remains floating, closeable, draggable, resizable and zoomable from Phase 7.2A.

This milestone intentionally changes the MCU presentation only; CPU/emulator and existing signal node identities are not replaced.

VECTOR LPC2129 IDE Phase 8.4O — On-Chip PWM + RTC

Adds worker-side LPC2129 PWM peripheral at 0xE0014000 and RTC at 0xE0024000.
RTC CLKSRC external mode is driven by a dedicated exact 32.768 kHz simulation clock domain.
Examples: PWM2/P0.7 LED dim/bright and RTC calendar over UART0.
PWM LED brightness is rendered from the actual PWM register state produced by compiled ARM firmware.
Existing Phase 8.4H canonical CPU/PCLK timing architecture is preserved.
Functional/register simulation; not transistor/SPICE silicon certification.

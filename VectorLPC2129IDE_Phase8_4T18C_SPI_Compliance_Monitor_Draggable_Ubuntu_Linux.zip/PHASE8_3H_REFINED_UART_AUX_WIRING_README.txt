VECTOR LPC2129 IDE — Phase 8.3I
Refined UART/AUX LED Bank + Visible On-Board Jumper Wiring

User-validated Phase 8.3G functionality is retained.

Changes in 8.3H:
1. UART/AUX SMD LED bank shifted slightly left/up to create a clear gap from the POWER terminal region.
2. Bank border strengthened so its boundary is visually distinct from the underlying board artwork.
3. AUX0..AUX3 are rendered as compact single-position Berg/header sockets instead of pill-shaped labels.
4. AUX tooltips explicitly identify A0..A3 as Berg/header AUX inputs.
5. Wiring from any LPC2129 physical GPIO header to A0..A3 is additionally rendered on top of the board artwork as a visible jumper route. The underlying electrical connection remains the normal project.wires canonical circuit connection.
6. Double-clicking the visible board-jumper overlay deletes the corresponding project wire.
7. 5V/3.3V/GND power-terminal hit boxes are tightened around the actual two-position terminal blocks; 3.3V/GND centers are corrected to the artwork.

Canonical rule preserved:
compiled ARM code -> LPC2129 peripheral/GPIO state -> canonical physical pin -> visible project wire -> AUX header -> selected onboard LED circuit.
No source parsing and no direct example-specific LED shortcut.

Approved board PNG is unchanged.

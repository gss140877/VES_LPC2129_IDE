VECTOR LPC2129 IDE — Phase 8.0B

UI correction:
- Replaced the previous single example selector with TWO independent dropdown buttons.
- C Examples ▼
    • LED Blink — P0.10
    • Switch P0.14 → LED P0.10
- ASM Examples ▼
    • LED Blink — P0.10
    • Switch P0.14 → LED P0.10
- Example controls are inserted at the FRONT of the main toolbar.
- Toolbar is allowed to wrap so the example controls remain visible at smaller window widths.
- Selecting an item loads the matching source and its circuit, then clears old HEX.
- The Phase 8.0A execution rule remains unchanged:
  source -> ARM GCC/GAS -> HEX -> ARM7TDMI-S -> LPC2129 GPIO -> Circuit Canvas.

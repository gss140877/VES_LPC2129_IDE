VECTOR LPC2129 IDE - Phase 7.4C

Correction:
- The 46 externally connectable header positions are now numbered consecutively 1 through 46.
- These numbers represent the simulator board's external I/O connector index, not the LPC2129 64-pin package number.
- Top header: I/O 1..23
- Bottom header: I/O 24..46
- LPC2129 signal names (P0.x, P1.x, etc.) remain shown beside the connector number.
- Existing 46 data-node identities and wiring behavior are preserved.

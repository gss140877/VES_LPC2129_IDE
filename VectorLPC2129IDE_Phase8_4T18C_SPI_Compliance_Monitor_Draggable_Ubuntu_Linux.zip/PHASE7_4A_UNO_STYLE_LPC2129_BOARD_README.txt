VECTOR LPC2129 IDE — Phase 7.4A
UNO-Style LPC2129 Development Board

Purpose
-------
Replaces the generic Phase 7.3A development-board visual with an Arduino UNO-inspired
form factor while retaining the LPC2129 MCU and all 46 existing connectable simulator nodes.

Board visual / interaction
--------------------------
- UNO-like asymmetric PCB outline and proportions.
- USB connector area on the left.
- DC barrel power input area on the left.
- RESET push button.
- ON / TX / RX / DBG indicator area.
- Main MCU: NXP LPC2129FBD64, ARM7TDMI-S, 64-pin LQFP.
- 12 MHz crystal.
- 5 V -> 3.3 V -> 1.8 V board power section.
- ISP/UART0 header.
- JTAG header.
- Two long female-header banks, 23 signals each = 46 connectable nodes.
- Each signal retains its existing data-node identity so the simulator wiring engine
  continues to connect to the same LPC2129 signals.
- Enlarged transparent hit boxes make external wiring easier.

Branding
--------
This is an original VECTOR LPC2129 board visual inspired by the familiar UNO development-
board layout. It does not copy Arduino logos or exact branded PCB artwork.

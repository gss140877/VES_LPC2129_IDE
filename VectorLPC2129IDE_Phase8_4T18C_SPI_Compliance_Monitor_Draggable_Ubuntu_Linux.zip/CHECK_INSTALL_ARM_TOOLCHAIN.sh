#!/usr/bin/env bash
set -euo pipefail

need=0
for tool in arm-none-eabi-gcc arm-none-eabi-objcopy arm-none-eabi-size arm-none-eabi-objdump; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    need=1
  fi
done

if [ "$need" -eq 0 ]; then
  echo "ARM GNU toolchain is ready."
  arm-none-eabi-gcc --version | head -n 1
  exit 0
fi

echo "ARM GNU toolchain is not installed."
echo "Installing Ubuntu packages: gcc-arm-none-eabi binutils-arm-none-eabi"

if ! command -v apt-get >/dev/null 2>&1; then
  echo "ERROR: apt-get is unavailable. Install the Arm GNU Embedded toolchain and add it to PATH."
  exit 1
fi

if [ "${EUID:-$(id -u)}" -eq 0 ]; then
  apt-get update
  apt-get install -y gcc-arm-none-eabi binutils-arm-none-eabi
elif command -v sudo >/dev/null 2>&1; then
  sudo apt-get update
  sudo apt-get install -y gcc-arm-none-eabi binutils-arm-none-eabi
else
  echo "ERROR: sudo is unavailable. Run as root or install gcc-arm-none-eabi manually."
  exit 1
fi

for tool in arm-none-eabi-gcc arm-none-eabi-objcopy arm-none-eabi-size arm-none-eabi-objdump; do
  command -v "$tool" >/dev/null 2>&1 || { echo "ERROR: $tool still not found."; exit 1; }
done

echo "ARM GNU toolchain installation complete."
arm-none-eabi-gcc --version | head -n 1

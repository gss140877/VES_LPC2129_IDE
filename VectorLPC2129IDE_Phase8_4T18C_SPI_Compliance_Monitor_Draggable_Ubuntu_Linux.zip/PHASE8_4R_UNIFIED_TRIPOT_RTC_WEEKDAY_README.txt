VECTOR LPC2129 IDE Phase 8.4R

1. Unified 10k trimpot renderer and interaction for +Component and all ADC/PWM examples.
   The same glass/PCB artwork, screw drag, range control, 0..1023 readout and VCC/WIPER/GND Berg pads are used everywhere.
2. RTC UART calendar format changed to DD/MM/YYYY,DDD HH:MM:SS.
   DOW mapping: 0=Sun, 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat.
3. Dedicated 32.768 kHz RTC clock engine and Phase 8.4H canonical timing architecture are unchanged.

VECTOR LPC2129 IDE Phase 8.4G — Canonical LPC2129 Peripheral Clock

Timer0/Timer1 now advance from the modeled LPC2129 VPB/PCLK clock domain rather than CPU profiler throughput.
Default clock tree: 12 MHz crystal -> PLL -> CCLK 60 MHz -> VPB PCLK 15 MHz.
Timer match only raises IR/VIC. The peripheral engine never drives the LED directly.
The compiled ARM7 ISR must execute the GPIO write, then the canonical physical pin drives canvas hardware.

With PCLK=15 MHz and PR=14999: TC increments every 1 ms.
MR0=100 -> 100 ms match; MR0=500 -> 500 ms; MR0=1000 -> 1000 ms.
ADC-direct 100..1000 ms example source remains unchanged.

/* LPC2129 on-chip PWM2 LED dim/bright demo: P0.7/PWM2. */
#define R(a) (*(volatile unsigned long*)(a))
#define PINSEL0 R(0xE002C000UL)
#define PWMIR R(0xE0014000UL)
#define PWMTCR R(0xE0014004UL)
#define PWMPR R(0xE001400CUL)
#define PWMMCR R(0xE0014014UL)
#define PWMMR0 R(0xE0014018UL)
#define PWMMR2 R(0xE0014020UL)
#define PWMPCR R(0xE001404CUL)
#define PWMLER R(0xE0014050UL)
static void delay(volatile unsigned long n){while(n--)__asm__ volatile("nop");}
int main(void){unsigned long d;int up=1;
  PINSEL0=(PINSEL0&~(3UL<<14))|(2UL<<14); /* P0.7 = PWM2 */
  PWMTCR=2; PWMPR=0; PWMMCR=2; PWMMR0=15000; PWMMR2=0; PWMLER=(1UL<<0)|(1UL<<2); PWMPCR=(1UL<<10); PWMTCR=9;
  d=0; while(1){PWMMR2=d;PWMLER=(1UL<<2);delay(9000);if(up){if(d<15000)d+=300;else up=0;}else{if(d>300)d-=300;else{d=0;up=1;}}}
}

/* Phase 8.3E — P1.30 active-HIGH switch -> P1.31 active-HIGH LED */
#define IO1PIN (*(volatile unsigned long *)0xE0028010UL)
#define IO1SET (*(volatile unsigned long *)0xE0028014UL)
#define IO1DIR (*(volatile unsigned long *)0xE0028018UL)
#define IO1CLR (*(volatile unsigned long *)0xE002801CUL)
#define SW  (1UL << 30)
#define LED (1UL << 31)
int main(void){
    IO1CLR = LED;            /* active-high LED initially OFF */
    IO1DIR |= LED;
    IO1DIR &= ~SW;           /* board active-high circuit: 10k pull-down */
    while(1){
        if(IO1PIN & SW) IO1SET = LED;      /* pressed -> LED ON */
        else            IO1CLR = LED;
    }
}

/* VECTOR LPC2129 Phase 8.2A
 * UART1 polling TX/RX echo example.
 * UART1 pins: P0.8=TXD1, P0.9=RXD1.
 * Default simulator PCLK = 15 MHz. DLL=97 gives ~9665 baud.
 */
#define REG32(a) (*(volatile unsigned long *)(a))
#define PINSEL0 REG32(0xE002C000UL)
#define U1RBR   REG32(0xE0010000UL)
#define U1THR   REG32(0xE0010000UL)
#define U1DLL   REG32(0xE0010000UL)
#define U1DLM   REG32(0xE0010004UL)
#define U1FCR   REG32(0xE0010008UL)
#define U1LCR   REG32(0xE001000CUL)
#define U1LSR   REG32(0xE0010014UL)
#define U1FDR   REG32(0xE0010028UL)
#define U1TER   REG32(0xE0010030UL)

static void uart1_putc(unsigned char c)
{
    while ((U1LSR & (1UL << 5)) == 0) { }
    U1THR = c;
}
static void uart1_puts(const char *s)
{
    while (*s) uart1_putc((unsigned char)*s++);
}
int main(void)
{
    PINSEL0 = (PINSEL0 & ~(0xFUL << 16)) | (0x5UL << 16); /* P0.8 TXD1, P0.9 RXD1 */

    U1LCR = 0x83;       /* 8N1, DLAB=1 */
    U1DLL = 97;
    U1DLM = 0;
    U1FDR = 0x10;       /* MULVAL=1, DIVADDVAL=0 */
    U1LCR = 0x03;       /* 8N1, DLAB=0 */
    U1FCR = 0x07;       /* FIFO enable + RX/TX reset */
    U1TER = 0x80;       /* transmitter enable */

    uart1_puts("LPC2129 UART1 READY\r\n");
    uart1_puts("Type in UART1 terminal; firmware echoes RX data.\r\n");

    while (1) {
        if (U1LSR & 0x01) {
            unsigned char c = (unsigned char)U1RBR;
            uart1_putc(c);
        }
    }
}

/* VECTOR LPC2129 Phase 8.4A
 * Four-channel 10-bit on-chip ADC polling demo + UART0 report.
 * AIN0=P0.27, AIN1=P0.28, AIN2=P0.29, AIN3=P0.30.
 * PCLK=15 MHz, CLKDIV=3 -> ADC clock 3.75 MHz <= 4.5 MHz.
 * Each software-controlled conversion uses 11 ADC clocks.
 */
#define REG32(a) (*(volatile unsigned long *)(a))
#define PINSEL0 REG32(0xE002C000UL)
#define PINSEL1 REG32(0xE002C004UL)
#define ADCR    REG32(0xE0034000UL)
#define ADGDR   REG32(0xE0034004UL)
#define U0THR   REG32(0xE000C000UL)
#define U0DLL   REG32(0xE000C000UL)
#define U0DLM   REG32(0xE000C004UL)
#define U0FCR   REG32(0xE000C008UL)
#define U0LCR   REG32(0xE000C00CUL)
#define U0LSR   REG32(0xE000C014UL)
#define U0FDR   REG32(0xE000C028UL)
#define U0TER   REG32(0xE000C030UL)

static unsigned long udiv32(unsigned long n,unsigned long d){unsigned long q=0,r=0;int i;for(i=31;i>=0;i--){r=(r<<1)|((n>>(unsigned)i)&1UL);if(r>=d){r-=d;q|=(1UL<<(unsigned)i);}}return q;}
static unsigned long umod32(unsigned long n,unsigned long d){unsigned long q=udiv32(n,d);return n-q*d;}
static void uart0_putc(unsigned char c){while((U0LSR&(1UL<<5))==0){} U0THR=c;}
static void uart0_puts(const char *s){while(*s)uart0_putc((unsigned char)*s++);}
static void uart0_u32(unsigned long v){char b[11];int i=0;if(v==0){uart0_putc('0');return;}while(v&&i<10){b[i++]=(char)('0'+umod32(v,10));v=udiv32(v,10);}while(i)uart0_putc((unsigned char)b[--i]);}
static void uart0_voltage(unsigned long raw){
    unsigned long mv=udiv32(raw*3300UL+511UL,1023UL);
    uart0_putc((unsigned char)('0'+udiv32(mv,1000UL)));
    uart0_putc('.');
    uart0_putc((unsigned char)('0'+umod32(udiv32(mv,100UL),10UL)));
    uart0_putc((unsigned char)('0'+umod32(udiv32(mv,10UL),10UL)));
    uart0_putc((unsigned char)('0'+umod32(mv,10UL)));
}
static void uart0_init(void){
    PINSEL0=(PINSEL0&~0xFUL)|0x5UL;
    U0LCR=0x83;U0DLL=97;U0DLM=0;U0FDR=0x10;U0LCR=0x03;U0FCR=0x07;U0TER=0x80;
}
static void adc_init(void){
    /* P0.27..P0.30 function 01 = AIN0..AIN3. */
    PINSEL1=(PINSEL1&~0x3FC00000UL)|0x15400000UL;
    ADCR=(3UL<<8)|(1UL<<21); /* CLKDIV=3, PDN=1 */
}
static unsigned int adc_read(unsigned int ch){
    unsigned long d;
    ADCR=(1UL<<ch)|(3UL<<8)|(1UL<<21)|(1UL<<24);
    do{d=ADGDR;}while((d&(1UL<<31))==0);
    ADCR=(1UL<<ch)|(3UL<<8)|(1UL<<21);
    return (unsigned int)((d>>6)&0x3FFUL);
}
static void delay_report(void){volatile unsigned long n;for(n=0;n<180000UL;n++){} }
int main(void){
    unsigned int ch,v;
    uart0_init();adc_init();
    uart0_puts("\r\nLPC2129 ADC 4-CHANNEL POLLING\r\n");
    uart0_puts("AIN0=P0.27 AIN1=P0.28 AIN2=P0.29 AIN3=P0.30\r\n");
    uart0_puts("Format: DEC=10-bit code, FLOAT=voltage equivalent\r\n\r\n");
    while(1){
        for(ch=0;ch<4;ch++){
            v=adc_read(ch);
            uart0_puts("AIN");uart0_putc((unsigned char)('0'+ch));
            uart0_puts("  DEC=");uart0_u32(v);
            uart0_puts("  FLOAT=");uart0_voltage(v);uart0_puts(" V\r\n");
        }
        uart0_puts("-----------------------------\r\n");delay_report();
    }
}

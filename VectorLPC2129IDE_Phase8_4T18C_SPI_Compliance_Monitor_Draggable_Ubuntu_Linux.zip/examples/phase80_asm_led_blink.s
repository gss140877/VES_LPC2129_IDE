/* VECTOR LPC2129 Phase 8.0A
 * GNU ARM Assembly Example 1: P0.10 LED Blink
 *
 * Hardware: P0.10 -> LED -> GND
 * Compiled by arm-none-eabi-gcc/as, converted to HEX, then executed by ARM7TDMI-S engine.
 */
    .syntax unified
    .cpu arm7tdmi
    .arm

    .equ IO0SET, 0xE0028004
    .equ IO0DIR, 0xE0028008
    .equ IO0CLR, 0xE002800C
    .equ LED,    0x00000400

    .text
    .global main
main:
    ldr     r0, =IO0DIR
    ldr     r1, [r0]
    ldr     r2, =LED
    orr     r1, r1, r2
    str     r1, [r0]

blink:
    ldr     r0, =IO0SET
    str     r2, [r0]
    ldr     r3, =180000
1:
    subs    r3, r3, #1
    bne     1b

    ldr     r0, =IO0CLR
    str     r2, [r0]
    ldr     r3, =180000
2:
    subs    r3, r3, #1
    bne     2b

    b       blink

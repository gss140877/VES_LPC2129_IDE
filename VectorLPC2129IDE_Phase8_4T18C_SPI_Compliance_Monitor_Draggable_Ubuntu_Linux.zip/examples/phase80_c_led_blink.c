/* VECTOR LPC2129 Phase 8.0A
 * Embedded C Example 1: P0.10 LED Blink
 *
 * Hardware:
 *   P0.10 -> LED anode
 *   LED cathode -> GND
 *
 * RULE: This source is compiled by arm-none-eabi-gcc to ELF/HEX.
 *       The HEX is executed by the ARM7TDMI-S engine.
 *       The LED follows only the simulated IO0DIR/IO0SET/IO0CLR/IO0PIN state.
 */
#define IO0PIN (*(volatile unsigned long *)0xE0028000UL)
#define IO0SET (*(volatile unsigned long *)0xE0028004UL)
#define IO0DIR (*(volatile unsigned long *)0xE0028008UL)
#define IO0CLR (*(volatile unsigned long *)0xE002800CUL)

#define LED (1UL << 10)

static void delay(volatile unsigned long count)
{
    while (count--) {
        __asm__ volatile ("nop");
    }
}

int main(void)
{
    IO0DIR |= LED;

    while (1) {
        IO0SET = LED;
        delay(180000);
        IO0CLR = LED;
        delay(180000);
    }
}

/* LPC2129 ARM7TDMI-S CPU Self Test: THUMB basic execution.
 * Starts in ARM, switches to THUMB using BX, then writes GPIO.
 */
.syntax unified
.cpu arm7tdmi
.arm
.global main
.equ IO0DIR, 0xE0028008
.equ IO0SET, 0xE0028004
main:
    LDR R0, =thumb_main + 1
    BX  R0

.thumb
.thumb_func
thumb_main:
    LDR R2, =IO0DIR
    LDR R3, =0xFFFFFFFF
    STR R3, [R2]
    MOVS R0, #10
    MOVS R1, #20
    ADDS R0, R0, R1
    CMP R0, #30
    BNE thumb_main
    LDR R2, =IO0SET
    LDR R3, =0x00000033
    STR R3, [R2]
thumb_loop:
    B thumb_loop

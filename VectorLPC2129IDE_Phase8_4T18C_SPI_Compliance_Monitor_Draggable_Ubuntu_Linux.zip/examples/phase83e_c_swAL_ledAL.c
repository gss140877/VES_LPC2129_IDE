/* Phase 8.3E — P1.30 active-LOW switch -> P1.31 active-LOW LED */
#define IO1PIN (*(volatile unsigned long *)0xE0028010UL)
#define IO1SET (*(volatile unsigned long *)0xE0028014UL)
#define IO1DIR (*(volatile unsigned long *)0xE0028018UL)
#define IO1CLR (*(volatile unsigned long *)0xE002801CUL)
#define SW  (1UL << 30)
#define LED (1UL << 31)
int main(void){
    IO1SET = LED;            /* active-low LED initially OFF */
    IO1DIR |= LED;           /* P1.31 output */
    IO1DIR &= ~SW;           /* P1.30 input; board provides 10k pull-up */
    while(1){
        if((IO1PIN & SW)==0) IO1CLR = LED; /* pressed -> LED ON */
        else                 IO1SET = LED; /* released -> LED OFF */
    }
}

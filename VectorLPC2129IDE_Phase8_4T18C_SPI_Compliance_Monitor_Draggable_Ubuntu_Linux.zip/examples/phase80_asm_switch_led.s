/* VECTOR LPC2129 Phase 8.0A
 * GNU ARM Assembly Example 2: P0.14 push button controls P0.10 LED
 *
 * P0.14 input is active-low: released=1, pressed=0.
 * Firmware reads IO0PIN; no canvas-side LED shortcut is used.
 */
    .syntax unified
    .cpu arm7tdmi
    .arm

    .equ IO0PIN, 0xE0028000
    .equ IO0SET, 0xE0028004
    .equ IO0DIR, 0xE0028008
    .equ IO0CLR, 0xE002800C
    .equ LED,    0x00000400
    .equ SWITCH, 0x00004000

    .text
    .global main
main:
    ldr     r0, =IO0DIR
    ldr     r1, [r0]
    ldr     r2, =LED
    orr     r1, r1, r2
    ldr     r3, =SWITCH
    bic     r1, r1, r3
    str     r1, [r0]

poll:
    ldr     r0, =IO0PIN
    ldr     r1, [r0]
    tst     r1, r3
    bne     released

pressed:
    ldr     r0, =IO0SET
    str     r2, [r0]
    b       poll

released:
    ldr     r0, =IO0CLR
    str     r2, [r0]
    b       poll

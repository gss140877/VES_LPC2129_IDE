/* VECTOR LPC2129 Phase 8.3A — UART0 RX IRQ echo via VIC */
.syntax unified
.cpu arm7tdmi
.arm
.global main
.equ PINSEL0,0xE002C000
.equ U0RBR,0xE000C000
.equ U0THR,0xE000C000
.equ U0DLL,0xE000C000
.equ U0DLM,0xE000C004
.equ U0IER,0xE000C004
.equ U0FCR,0xE000C008
.equ U0LCR,0xE000C00C
.equ U0LSR,0xE000C014
.equ U0FDR,0xE000C028
.equ U0TER,0xE000C030
.equ VICIntEnable,0xFFFFF010
.equ VICVectAddr,0xFFFFF030
.equ VICVectAddr0,0xFFFFFF00
.equ VICVectCntl0,0xFFFFF200

main:
    ldr r0,=PINSEL0
    ldr r1,[r0]
    bic r1,r1,#0x0F
    orr r1,r1,#0x05
    str r1,[r0]
    ldr r0,=U0LCR
    mov r1,#0x83
    str r1,[r0]
    ldr r0,=U0DLL
    mov r1,#97
    str r1,[r0]
    ldr r0,=U0DLM
    mov r1,#0
    str r1,[r0]
    ldr r0,=U0FDR
    mov r1,#0x10
    str r1,[r0]
    ldr r0,=U0LCR
    mov r1,#3
    str r1,[r0]
    ldr r0,=U0FCR
    mov r1,#7
    str r1,[r0]
    ldr r0,=U0TER
    mov r1,#0x80
    str r1,[r0]

    ldr r0,=VICVectAddr0
    ldr r1,=uart0_irq
    str r1,[r0]
    ldr r0,=VICVectCntl0
    mov r1,#38
    str r1,[r0]
    ldr r0,=VICIntEnable
    mov r1,#64
    str r1,[r0]
    ldr r0,=U0IER
    mov r1,#1
    str r1,[r0]

    mrs r0,cpsr
    bic r0,r0,#0x80
    msr cpsr_c,r0

idle:
    b idle

uart0_irq:
    stmfd sp!,{r0-r3,r12,lr}
    ldr r0,=U0LSR
    ldr r1,[r0]
    tst r1,#1
    beq irq_done
    ldr r0,=U0RBR
    ldr r2,[r0]
tx_wait:
    ldr r0,=U0LSR
    ldr r1,[r0]
    tst r1,#0x20
    beq tx_wait
    ldr r0,=U0THR
    str r2,[r0]
irq_done:
    ldr r0,=VICVectAddr
    mov r1,#0
    str r1,[r0]
    ldmfd sp!,{r0-r3,r12,lr}
    subs pc,lr,#4

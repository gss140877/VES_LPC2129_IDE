/* VECTOR LPC2129 Phase 8.3A — UART0 RX interrupt echo through VIC */
#define REG32(a) (*(volatile unsigned long *)(a))
#define PINSEL0 REG32(0xE002C000UL)
#define U0RBR REG32(0xE000C000UL)
#define U0THR REG32(0xE000C000UL)
#define U0DLL REG32(0xE000C000UL)
#define U0DLM REG32(0xE000C004UL)
#define U0IER REG32(0xE000C004UL)
#define U0FCR REG32(0xE000C008UL)
#define U0LCR REG32(0xE000C00CUL)
#define U0LSR REG32(0xE000C014UL)
#define U0FDR REG32(0xE000C028UL)
#define U0TER REG32(0xE000C030UL)
#define VICIntEnable REG32(0xFFFFF010UL)
#define VICVectAddr  REG32(0xFFFFF030UL)
#define VICVectAddr0 REG32(0xFFFFFF00UL)
#define VICVectCntl0 REG32(0xFFFFF200UL)

static void putc0(unsigned char c) {
    while ((U0LSR & 0x20UL) == 0) { }
    U0THR = c;
}
static void puts0(const char *s) { while (*s) putc0((unsigned char)*s++); }

void uart0_irq(void) __attribute__((interrupt("IRQ")));
void uart0_irq(void) {
    if (U0LSR & 1UL) {
        unsigned char c=(unsigned char)U0RBR;
        putc0(c);
    }
    VICVectAddr=0;
}

static void enable_irq(void) {
    unsigned long v;
    __asm__ volatile(
        "mrs %0, cpsr\n"
        "bic %0, %0, #0x80\n"
        "msr cpsr_c, %0\n"
        : "=r"(v) : : "memory");
}

int main(void) {
    PINSEL0=(PINSEL0&~0xFUL)|0x5UL;
    U0LCR=0x83; U0DLL=97; U0DLM=0; U0FDR=0x10; U0LCR=0x03;
    U0FCR=0x07; U0TER=0x80;
    VICVectAddr0=(unsigned long)uart0_irq;
    VICVectCntl0=0x20UL|6UL;
    VICIntEnable=(1UL<<6);
    U0IER=0x01;              /* Receive Data Available interrupt */
    enable_irq();
    puts0("LPC2129 UART0 VIC IRQ READY\r\n");
    while(1) { }
}

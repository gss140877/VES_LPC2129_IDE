/* VECTOR LPC2129 Phase 8.3A — UART1 RX interrupt echo through VIC */
#define REG32(a) (*(volatile unsigned long *)(a))
#define PINSEL0 REG32(0xE002C000UL)
#define U1RBR REG32(0xE0010000UL)
#define U1THR REG32(0xE0010000UL)
#define U1DLL REG32(0xE0010000UL)
#define U1DLM REG32(0xE0010004UL)
#define U1IER REG32(0xE0010004UL)
#define U1FCR REG32(0xE0010008UL)
#define U1LCR REG32(0xE001000CUL)
#define U1LSR REG32(0xE0010014UL)
#define U1FDR REG32(0xE0010028UL)
#define U1TER REG32(0xE0010030UL)
#define VICIntEnable REG32(0xFFFFF010UL)
#define VICVectAddr  REG32(0xFFFFF030UL)
#define VICVectAddr0 REG32(0xFFFFFF00UL)
#define VICVectCntl0 REG32(0xFFFFF200UL)

static void putc1(unsigned char c) {
    while ((U1LSR & 0x20UL) == 0) { }
    U1THR = c;
}
static void puts1(const char *s) { while (*s) putc1((unsigned char)*s++); }

void uart1_irq(void) __attribute__((interrupt("IRQ")));
void uart1_irq(void) {
    if (U1LSR & 1UL) {
        unsigned char c=(unsigned char)U1RBR;
        putc1(c);
    }
    VICVectAddr=0;
}

static void enable_irq(void) {
    unsigned long v;
    __asm__ volatile(
        "mrs %0, cpsr\n"
        "bic %0, %0, #0x80\n"
        "msr cpsr_c, %0\n"
        : "=r"(v) : : "memory");
}

int main(void) {
    PINSEL0=(PINSEL0&~(0xFUL<<16))|(0x5UL<<16);
    U1LCR=0x83; U1DLL=97; U1DLM=0; U1FDR=0x10; U1LCR=0x03;
    U1FCR=0x07; U1TER=0x80;
    VICVectAddr0=(unsigned long)uart1_irq;
    VICVectCntl0=0x20UL|7UL;
    VICIntEnable=(1UL<<7);
    U1IER=0x01;              /* Receive Data Available interrupt */
    enable_irq();
    puts1("LPC2129 UART1 VIC IRQ READY\r\n");
    while(1) { }
}

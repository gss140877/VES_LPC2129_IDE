/* LPC2129 LED Blink - VectorArduinoSimulator
   Board model: LPC2129 ARM7TDMI-S
   GPIO register style supported in simulator:
   IODIR, IOSET, IOCLR, IOPIN
*/

#define LED (1 << 10)   // P0.10

void delay_ms(unsigned int ms)
{
    // Simulator recognizes delay_ms(ms) inside while(1).
}

int main(void)
{
    IODIR |= LED;       // P0.10 output

    while(1)
    {
        IOSET = LED;    // LED ON
        delay_ms(500);
        IOCLR = LED;    // LED OFF
        delay_ms(500);
    }
}
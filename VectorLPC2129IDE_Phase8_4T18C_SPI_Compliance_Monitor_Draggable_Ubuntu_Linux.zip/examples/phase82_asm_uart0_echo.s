/* VECTOR LPC2129 Phase 8.2A
 * UART0 GNU ARM Assembly polling TX/RX echo.
 */
.syntax unified
.cpu arm7tdmi
.arm
.global main

.equ PINSEL0, 0xE002C000
.equ U0RBR,   0xE000C000
.equ U0THR,   0xE000C000
.equ U0DLL,   0xE000C000
.equ U0DLM,   0xE000C004
.equ U0FCR,   0xE000C008
.equ U0LCR,   0xE000C00C
.equ U0LSR,   0xE000C014
.equ U0FDR,   0xE000C028
.equ U0TER,   0xE000C030

main:
    ldr r0, =PINSEL0
    ldr r1, [r0]
    bic r1, r1, #0x0F
    orr r1, r1, #0x05
    str r1, [r0]

    ldr r0, =U0LCR
    mov r1, #0x83
    str r1, [r0]
    ldr r0, =U0DLL
    mov r1, #97
    str r1, [r0]
    ldr r0, =U0DLM
    mov r1, #0
    str r1, [r0]
    ldr r0, =U0FDR
    mov r1, #0x10
    str r1, [r0]
    ldr r0, =U0LCR
    mov r1, #0x03
    str r1, [r0]
    ldr r0, =U0FCR
    mov r1, #0x07
    str r1, [r0]
    ldr r0, =U0TER
    mov r1, #0x80
    str r1, [r0]

    ldr r4, =message
tx_string:
    ldrb r5, [r4], #1
    cmp r5, #0
    beq rx_loop
    bl putc0
    b tx_string

rx_loop:
    ldr r0, =U0LSR
    ldr r1, [r0]
    tst r1, #1
    beq rx_loop
    ldr r0, =U0RBR
    ldr r5, [r0]
    and r5, r5, #0xFF
    bl putc0
    b rx_loop

putc0:
    ldr r0, =U0LSR
wait0:
    ldr r1, [r0]
    tst r1, #0x20
    beq wait0
    ldr r0, =U0THR
    str r5, [r0]
    bx lr

.align 2
message:
    .asciz "LPC2129 UART0 ASM READY\r\n"

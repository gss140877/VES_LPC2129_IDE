/* LPC2129 ARM7TDMI-S CPU Self Test: ARM Barrel Shifter */
.syntax unified
.cpu arm7tdmi
.arm
.global main
.equ IO0DIR, 0xE0028008
.equ IO0SET, 0xE0028004
.equ IO0CLR, 0xE002800C
main:
    LDR R10, =IO0DIR
    LDR R11, =0xFFFFFFFF
    STR R11, [R10]

    MOV R0, #1
    MOV R1, R0, LSL #4      @ 0x10
    CMP R1, #0x10
    BNE fail

    MOV R2, #0x80
    MOV R3, R2, LSR #3      @ 0x10
    CMP R3, #0x10
    BNE fail

    MOV R4, #0x80000000
    MOV R5, R4, ASR #31     @ 0xFFFFFFFF
    MVN R6, #0
    CMP R5, R6
    BNE fail

pass:
    LDR R10, =IO0SET
    LDR R11, =0x00000F0F
    STR R11, [R10]
    B pass
fail:
    LDR R10, =IO0CLR
    LDR R11, =0xFFFFFFFF
    STR R11, [R10]
    B fail

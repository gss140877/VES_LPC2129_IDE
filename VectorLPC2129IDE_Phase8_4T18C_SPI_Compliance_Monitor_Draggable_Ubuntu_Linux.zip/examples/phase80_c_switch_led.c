/* VECTOR LPC2129 Phase 8.0A
 * Embedded C Example 2: Push Button controls LED
 *
 * Hardware:
 *   P0.10 -> LED anode, LED cathode -> GND
 *   P0.14 -> push-button signal, button GND -> GND
 *
 * The LPC2129 input model uses the GPIO pin's released pull-up state:
 *   released = 1, pressed = 0.
 *
 * RULE: The button changes the simulated physical P0.14 input only.
 *       Firmware must read IO0PIN and decide what to do with P0.10.
 */
#define IO0PIN (*(volatile unsigned long *)0xE0028000UL)
#define IO0SET (*(volatile unsigned long *)0xE0028004UL)
#define IO0DIR (*(volatile unsigned long *)0xE0028008UL)
#define IO0CLR (*(volatile unsigned long *)0xE002800CUL)

#define LED    (1UL << 10)
#define SWITCH (1UL << 14)

int main(void)
{
    IO0DIR |= LED;       /* P0.10 output */
    IO0DIR &= ~SWITCH;   /* P0.14 input  */

    while (1) {
        if ((IO0PIN & SWITCH) == 0) {
            IO0SET = LED;    /* pressed -> LED ON */
        } else {
            IO0CLR = LED;    /* released -> LED OFF */
        }
    }
}

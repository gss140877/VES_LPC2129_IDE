/* VECTOR LPC2129 — Phase 8.4T
   I2C + 24LC256 EEPROM classroom example.
   Demonstrates: byte write -> random read -> page write -> sequential read.
   SCL=P0.2, SDA=P0.3, 24LC256 7-bit address=0x50.
*/
#define PINSEL0   (*(volatile unsigned long *)0xE002C000)
#define I2CONSET  (*(volatile unsigned long *)0xE001C000)
#define I2STAT    (*(volatile unsigned long *)0xE001C004)
#define I2DAT     (*(volatile unsigned long *)0xE001C008)
#define I2SCLH    (*(volatile unsigned long *)0xE001C010)
#define I2SCLL    (*(volatile unsigned long *)0xE001C014)
#define I2CONCLR  (*(volatile unsigned long *)0xE001C018)

#define I2_AA   0x04
#define I2_SI   0x08
#define I2_STO  0x10
#define I2_STA  0x20
#define I2_I2EN 0x40

volatile unsigned char eeprom_byte_readback;
volatile unsigned char eeprom_page_readback[8];

static void wait_si(void){ while((I2CONSET & I2_SI)==0){} }
static int expect(unsigned long s){ return (I2STAT & 0xF8)==s; }

static void i2c_init(void){
    PINSEL0 = (PINSEL0 & ~0xF0UL) | 0x50UL; /* P0.2 SCL, P0.3 SDA */
    I2SCLH = 75; I2SCLL = 75;             /* ~100 kHz at PCLK=15 MHz */
    I2CONCLR = I2_AA | I2_SI | I2_STA;
    I2CONSET = I2_I2EN;
}
static int i2c_start(void){
    I2CONSET = I2_STA; I2CONCLR = I2_SI; wait_si();
    return expect(0x08) || expect(0x10);
}
static void i2c_stop(void){ I2CONSET = I2_STO; I2CONCLR = I2_SI; }
static int i2c_tx(unsigned char b, unsigned long expected){
    I2DAT=b; I2CONCLR=I2_STA|I2_SI; wait_si(); return expect(expected);
}
static unsigned char i2c_rx_nack(void){
    I2CONCLR=I2_AA|I2_SI; wait_si(); return (unsigned char)I2DAT;
}
static unsigned char i2c_rx_ack(void){
    I2CONSET=I2_AA; I2CONCLR=I2_SI; wait_si(); return (unsigned char)I2DAT;
}
static int eeprom_set_pointer(unsigned int a){
    if(!i2c_start())return 0;
    if(!i2c_tx(0xA0,0x18))return 0;
    if(!i2c_tx((unsigned char)(a>>8),0x28))return 0;
    if(!i2c_tx((unsigned char)a,0x28))return 0;
    return 1;
}
static int eeprom_byte_write(unsigned int a,unsigned char d){
    if(!eeprom_set_pointer(a))return 0;
    if(!i2c_tx(d,0x28))return 0;
    i2c_stop(); return 1;
}
static unsigned char eeprom_random_read(unsigned int a){
    unsigned char d=0;
    if(!eeprom_set_pointer(a))return 0;
    if(!i2c_start())return 0;
    if(!i2c_tx(0xA1,0x40))return 0;
    d=i2c_rx_nack(); i2c_stop(); return d;
}
static int eeprom_page_write8(unsigned int a,const unsigned char *p){
    int i;if(!eeprom_set_pointer(a))return 0;
    for(i=0;i<8;i++)if(!i2c_tx(p[i],0x28))return 0;
    i2c_stop();return 1;
}
static int eeprom_seq_read8(unsigned int a,unsigned char *p){
    int i;if(!eeprom_set_pointer(a))return 0;
    if(!i2c_start())return 0;
    if(!i2c_tx(0xA1,0x40))return 0;
    for(i=0;i<7;i++)p[i]=i2c_rx_ack();
    p[7]=i2c_rx_nack();i2c_stop();return 1;
}
int main(void){
    static const unsigned char pattern[8]={0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88};
    i2c_init();
    eeprom_byte_write(0x0123,0x5A);
    eeprom_byte_readback=eeprom_random_read(0x0123);
    eeprom_page_write8(0x0200,pattern);
    eeprom_seq_read8(0x0200,(unsigned char*)eeprom_page_readback);
    while(1){}
}

    .section .vectors, "ax"
    .global _start
_start:
    b Reset_Handler
    b .
    b .
    b .
    b .
    b .
    ldr pc, [pc, #-0xFF0]   /* IRQ: reads VICVectAddr at 0xFFFFF030 */
    b .

    .text
    .global Reset_Handler
Reset_Handler:
    ldr sp, =_stack_top
    bl main
hang:
    b hang

/* LPC2129 RTC digital calendar on UART0. RTC uses external 32.768 kHz crystal.
   Phase 8.4S: decimal formatting intentionally uses subtraction only (no / or %),
   keeping the classroom example independent of compiler runtime division helpers. */
#define R(a) (*(volatile unsigned long*)(a))
#define PINSEL0 R(0xE002C000UL)
#define U0THR R(0xE000C000UL)
#define U0DLL R(0xE000C000UL)
#define U0DLM R(0xE000C004UL)
#define U0FCR R(0xE000C008UL)
#define U0LCR R(0xE000C00CUL)
#define U0LSR R(0xE000C014UL)
#define U0TER R(0xE000C030UL)
#define ILR R(0xE0024000UL)
#define CCR R(0xE0024008UL)
#define SEC R(0xE0024020UL)
#define MIN R(0xE0024024UL)
#define HOUR R(0xE0024028UL)
#define DOM R(0xE002402CUL)
#define DOW R(0xE0024030UL)
#define DOY R(0xE0024034UL)
#define MONTH R(0xE0024038UL)
#define YEAR R(0xE002403CUL)

static void pc(char c){while(!(U0LSR&0x20UL)){} U0THR=(unsigned long)c;}
static void ps(const char*s){while(*s)pc(*s++);}
static void p2(unsigned long v){
  unsigned long tens=0;
  while(v>=10UL){v-=10UL;tens++;}
  pc((char)('0'+tens)); pc((char)('0'+v));
}
static void p3(unsigned long v){
  unsigned long h=0,t=0;
  while(v>=100UL){v-=100UL;h++;}
  while(v>=10UL){v-=10UL;t++;}
  pc((char)('0'+h));pc((char)('0'+t));pc((char)('0'+v));
}
static void p4(unsigned long v){
  unsigned long th=0,h=0,t=0;
  while(v>=1000UL){v-=1000UL;th++;}
  while(v>=100UL){v-=100UL;h++;}
  while(v>=10UL){v-=10UL;t++;}
  pc((char)('0'+th));pc((char)('0'+h));pc((char)('0'+t));pc((char)('0'+v));
}
static void weekday(unsigned long d){
  /* Deliberately avoid switch/jump-table generation: keep this example on the
     simplest ARM7TDMI-S instruction path used by the simulator. */
  if(d==0UL){ps("Sun");return;}
  if(d==1UL){ps("Mon");return;}
  if(d==2UL){ps("Tue");return;}
  if(d==3UL){ps("Wed");return;}
  if(d==4UL){ps("Thu");return;}
  if(d==5UL){ps("Fri");return;}
  if(d==6UL){ps("Sat");return;}
  ps("---");
}
int main(void){unsigned long last=99UL;
 PINSEL0=(PINSEL0&~15UL)|5UL;
 U0LCR=0x83;U0DLL=97;U0DLM=0;U0LCR=3;U0FCR=7;U0TER=0x80;
 CCR=2; SEC=0;MIN=7;HOUR=16;DOM=7;DOW=1;DOY=250;MONTH=9;YEAR=2026;ILR=3;
 CCR=0x11; /* CLKEN + CLKSRC: dedicated 32.768 kHz crystal */
 ps("\r\nLPC2129 RTC - 32.768 kHz CRYSTAL\r\n");
 while(1){
   unsigned long s=SEC;
   if(s!=last){
     last=s;
     p2(DOM);pc('/');p2(MONTH);pc('/');p4(YEAR);pc(',');weekday(DOW);ps("  ");
     p2(HOUR);pc(':');p2(MIN);pc(':');p2(s);ps("\r\n");
   }
 }
}

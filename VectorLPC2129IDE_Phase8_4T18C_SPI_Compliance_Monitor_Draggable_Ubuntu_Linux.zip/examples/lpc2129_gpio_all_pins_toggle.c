/*
 *  Project : LPC2129 GPIO Toggle Test
 *  Device  : LPC2129
 *  Compiler: GNU ARM / Keil
 */

typedef volatile unsigned int vuint32_t;

#define IOPIN0   (*(vuint32_t *)0xE0028000)
#define IOSET0   (*(vuint32_t *)0xE0028004)
#define IODIR0   (*(vuint32_t *)0xE0028008)
#define IOCLR0   (*(vuint32_t *)0xE002800C)

void delay_ms(unsigned int dlyMS)
{
   dlyMS*=12000;
   while(dlyMS--);
}

int main(void)
{
    IODIR0 = 0xFFFFFFFF;

    while(1)
    {
        IOSET0 = 0xFFFFFFFF;
        delay_ms(100);
        IOCLR0 = 0xFFFFFFFF;
        delay_ms(100);
    }

    return 0;
}

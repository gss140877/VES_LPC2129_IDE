/* VECTOR LPC2129 Phase 8.4A
 * Four-channel ADC BURST scan. CLKS=000 => 10-bit, 11 clocks/conversion.
 * Dedicated ADDR0..ADDR3 registers are read and reported on UART0.
 */
#define REG32(a) (*(volatile unsigned long *)(a))
#define PINSEL0 REG32(0xE002C000UL)
#define PINSEL1 REG32(0xE002C004UL)
#define ADCR REG32(0xE0034000UL)
#define ADDR0 REG32(0xE0034010UL)
#define ADDR1 REG32(0xE0034014UL)
#define ADDR2 REG32(0xE0034018UL)
#define ADDR3 REG32(0xE003401CUL)
#define U0THR REG32(0xE000C000UL)
#define U0DLL REG32(0xE000C000UL)
#define U0DLM REG32(0xE000C004UL)
#define U0FCR REG32(0xE000C008UL)
#define U0LCR REG32(0xE000C00CUL)
#define U0LSR REG32(0xE000C014UL)
#define U0FDR REG32(0xE000C028UL)
#define U0TER REG32(0xE000C030UL)
static unsigned long udiv32(unsigned long n,unsigned long d){unsigned long q=0,r=0;int i;for(i=31;i>=0;i--){r=(r<<1)|((n>>(unsigned)i)&1UL);if(r>=d){r-=d;q|=(1UL<<(unsigned)i);}}return q;}
static unsigned long umod32(unsigned long n,unsigned long d){unsigned long q=udiv32(n,d);return n-q*d;}
static void pc(unsigned char c){while(!(U0LSR&0x20UL)){}U0THR=c;}
static void ps(const char*s){while(*s)pc((unsigned char)*s++);}
static void pu(unsigned long v){char b[11];int i=0;if(!v){pc('0');return;}while(v){b[i++]=(char)('0'+umod32(v,10));v=udiv32(v,10);}while(i)pc((unsigned char)b[--i]);}
static void pv(unsigned long r){unsigned long m=udiv32(r*3300UL+511UL,1023UL);pc((unsigned char)('0'+udiv32(m,1000)));pc('.');pc((unsigned char)('0'+umod32(udiv32(m,100),10)));pc((unsigned char)('0'+umod32(udiv32(m,10),10)));pc((unsigned char)('0'+umod32(m,10)));}
static unsigned long read_done(volatile unsigned long *r){unsigned long d;do{d=*r;}while(!(d&0x80000000UL));return (d>>6)&0x3FFUL;}
int main(void){unsigned long v[4];volatile unsigned long n;
 PINSEL0=(PINSEL0&~0xFUL)|5UL;U0LCR=0x83;U0DLL=97;U0DLM=0;U0FDR=0x10;U0LCR=3;U0FCR=7;U0TER=0x80;
 PINSEL1=(PINSEL1&~0x3FC00000UL)|0x15400000UL;
 ADCR=0x0FUL|(3UL<<8)|(1UL<<16)|(0UL<<17)|(1UL<<21); /* 4 channels, burst, 10-bit */
 ps("\r\nLPC2129 ADC 4-CHANNEL BURST MODE\r\n");
 while(1){
   v[0]=read_done((volatile unsigned long*)0xE0034010UL);v[1]=read_done((volatile unsigned long*)0xE0034014UL);v[2]=read_done((volatile unsigned long*)0xE0034018UL);v[3]=read_done((volatile unsigned long*)0xE003401CUL);
   for(int ch=0;ch<4;ch++){ps("AIN");pc((unsigned char)('0'+ch));ps(" DEC=");pu(v[ch]);ps(" FLOAT=");pv(v[ch]);ps(" V\r\n");}
   ps("[BURST]\r\n-----------------------------\r\n");for(n=0;n<180000UL;n++){}
 }
}

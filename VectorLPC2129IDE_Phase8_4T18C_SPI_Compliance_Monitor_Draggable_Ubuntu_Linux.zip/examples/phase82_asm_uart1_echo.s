/* VECTOR LPC2129 Phase 8.2A
 * UART1 GNU ARM Assembly polling TX/RX echo.
 */
.syntax unified
.cpu arm7tdmi
.arm
.global main

.equ PINSEL0, 0xE002C000
.equ U1RBR,   0xE0010000
.equ U1THR,   0xE0010000
.equ U1DLL,   0xE0010000
.equ U1DLM,   0xE0010004
.equ U1FCR,   0xE0010008
.equ U1LCR,   0xE001000C
.equ U1LSR,   0xE0010014
.equ U1FDR,   0xE0010028
.equ U1TER,   0xE0010030

main:
    ldr r0, =PINSEL0
    ldr r1, [r0]
    ldr r2, =0x000F0000
    bic r1, r1, r2
    ldr r2, =0x00050000
    orr r1, r1, r2
    str r1, [r0]

    ldr r0, =U1LCR
    mov r1, #0x83
    str r1, [r0]
    ldr r0, =U1DLL
    mov r1, #97
    str r1, [r0]
    ldr r0, =U1DLM
    mov r1, #0
    str r1, [r0]
    ldr r0, =U1FDR
    mov r1, #0x10
    str r1, [r0]
    ldr r0, =U1LCR
    mov r1, #0x03
    str r1, [r0]
    ldr r0, =U1FCR
    mov r1, #0x07
    str r1, [r0]
    ldr r0, =U1TER
    mov r1, #0x80
    str r1, [r0]

    ldr r4, =message
tx_string:
    ldrb r5, [r4], #1
    cmp r5, #0
    beq rx_loop
    bl putc1
    b tx_string

rx_loop:
    ldr r0, =U1LSR
    ldr r1, [r0]
    tst r1, #1
    beq rx_loop
    ldr r0, =U1RBR
    ldr r5, [r0]
    and r5, r5, #0xFF
    bl putc1
    b rx_loop

putc1:
    ldr r0, =U1LSR
wait1:
    ldr r1, [r0]
    tst r1, #0x20
    beq wait1
    ldr r0, =U1THR
    str r5, [r0]
    bx lr

.align 2
message:
    .asciz "LPC2129 UART1 ASM READY\r\n"

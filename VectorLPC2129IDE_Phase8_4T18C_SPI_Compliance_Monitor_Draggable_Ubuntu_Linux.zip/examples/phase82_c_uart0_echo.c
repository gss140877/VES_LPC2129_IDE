/* VECTOR LPC2129 Phase 8.2A
 * UART0 polling TX/RX echo example.
 * UART0 pins: P0.0=TXD0, P0.1=RXD0.
 * Default simulator PCLK = 15 MHz. DLL=97 gives ~9665 baud.
 */
#define REG32(a) (*(volatile unsigned long *)(a))
#define PINSEL0 REG32(0xE002C000UL)
#define U0RBR   REG32(0xE000C000UL)
#define U0THR   REG32(0xE000C000UL)
#define U0DLL   REG32(0xE000C000UL)
#define U0DLM   REG32(0xE000C004UL)
#define U0FCR   REG32(0xE000C008UL)
#define U0LCR   REG32(0xE000C00CUL)
#define U0LSR   REG32(0xE000C014UL)
#define U0FDR   REG32(0xE000C028UL)
#define U0TER   REG32(0xE000C030UL)

static void uart0_putc(unsigned char c)
{
    while ((U0LSR & (1UL << 5)) == 0) { }
    U0THR = c;
}
static void uart0_puts(const char *s)
{
    while (*s) uart0_putc((unsigned char)*s++);
}
int main(void)
{
    PINSEL0 = (PINSEL0 & ~0xFUL) | 0x5UL; /* P0.0 TXD0, P0.1 RXD0 */

    U0LCR = 0x83;       /* 8N1, DLAB=1 */
    U0DLL = 97;
    U0DLM = 0;
    U0FDR = 0x10;       /* MULVAL=1, DIVADDVAL=0 */
    U0LCR = 0x03;       /* 8N1, DLAB=0 */
    U0FCR = 0x07;       /* FIFO enable + RX/TX reset */
    U0TER = 0x80;       /* transmitter enable */

    uart0_puts("LPC2129 UART0 READY\r\n");
    uart0_puts("Type in UART0 terminal; firmware echoes RX data.\r\n");

    while (1) {
        if (U0LSR & 0x01) {
            unsigned char c = (unsigned char)U0RBR;
            uart0_putc(c);
        }
    }
}

/* LPC2129: AIN0 trimpot controls PWM2 LED brightness.
   AIN0 = P0.27, PWM2 = P0.7.  ADC result is mapped directly to PWM duty. */
#define REG32(a) (*(volatile unsigned long *)(a))
#define PINSEL0  REG32(0xE002C000UL)
#define PINSEL1  REG32(0xE002C004UL)
#define ADCR     REG32(0xE0034000UL)
#define ADGDR    REG32(0xE0034004UL)
#define PWMTCR   REG32(0xE0014004UL)
#define PWMPR    REG32(0xE001400CUL)
#define PWMMCR   REG32(0xE0014014UL)
#define PWMMR0   REG32(0xE0014018UL)
#define PWMMR2   REG32(0xE0014020UL)
#define PWMPCR   REG32(0xE001404CUL)
#define PWMLER   REG32(0xE0014050UL)

static unsigned int adc0_read(void)
{
    unsigned long gdr;
    ADCR = (ADCR & ~(7UL << 24)) | (1UL << 24); /* START now */
    do { gdr = ADGDR; } while ((gdr & (1UL << 31)) == 0);
    ADCR &= ~(7UL << 24);
    return (unsigned int)((gdr >> 6) & 0x3FFUL);
}

int main(void)
{
    unsigned int adc;
    unsigned long duty;

    /* P0.7 = PWM2 (PINSEL0[15:14]=10), P0.27 = AIN0 (PINSEL1[23:22]=01). */
    PINSEL0 = (PINSEL0 & ~(3UL << 14)) | (2UL << 14);
    PINSEL1 = (PINSEL1 & ~(3UL << 22)) | (1UL << 22);

    /* ADC: AIN0 selected, CLKDIV=14 => 1 MHz ADC clock from 15 MHz PCLK, PDN=1. */
    ADCR = (1UL << 0) | (14UL << 8) | (1UL << 21);

    /* PWM period = 15000 PCLK ticks = 1 ms at 15 MHz PCLK. */
    PWMTCR = 2;
    PWMPR  = 0;
    PWMMCR = (1UL << 1);            /* reset TC on MR0 */
    PWMMR0 = 15000;
    PWMMR2 = 7500;
    PWMLER = (1UL << 0) | (1UL << 2);
    PWMPCR = (1UL << 10);           /* PWMENA2 */
    PWMTCR = 9;                     /* counter enable + PWM enable */

    while (1)
    {
        adc = adc0_read();
        duty = ((unsigned long)adc * 15000UL) / 1023UL;
        PWMMR2 = duty;
        PWMLER = (1UL << 2);        /* latch new PWM2 duty */
    }
}

/* VECTOR LPC2129 Phase 8.3A — UART1 RX IRQ echo via VIC */
.syntax unified
.cpu arm7tdmi
.arm
.global main
.equ PINSEL0,0xE002C000
.equ U1RBR,0xE0010000
.equ U1THR,0xE0010000
.equ U1DLL,0xE0010000
.equ U1DLM,0xE0010004
.equ U1IER,0xE0010004
.equ U1FCR,0xE0010008
.equ U1LCR,0xE001000C
.equ U1LSR,0xE0010014
.equ U1FDR,0xE0010028
.equ U1TER,0xE0010030
.equ VICIntEnable,0xFFFFF010
.equ VICVectAddr,0xFFFFF030
.equ VICVectAddr0,0xFFFFFF00
.equ VICVectCntl0,0xFFFFF200

main:
    ldr r0,=PINSEL0
    ldr r1,[r0]
    ldr r2,=0x000F0000
    bic r1,r1,r2
    ldr r2,=0x00050000
    orr r1,r1,r2
    str r1,[r0]
    ldr r0,=U1LCR
    mov r1,#0x83
    str r1,[r0]
    ldr r0,=U1DLL
    mov r1,#97
    str r1,[r0]
    ldr r0,=U1DLM
    mov r1,#0
    str r1,[r0]
    ldr r0,=U1FDR
    mov r1,#0x10
    str r1,[r0]
    ldr r0,=U1LCR
    mov r1,#3
    str r1,[r0]
    ldr r0,=U1FCR
    mov r1,#7
    str r1,[r0]
    ldr r0,=U1TER
    mov r1,#0x80
    str r1,[r0]

    ldr r0,=VICVectAddr0
    ldr r1,=uart1_irq
    str r1,[r0]
    ldr r0,=VICVectCntl0
    mov r1,#39
    str r1,[r0]
    ldr r0,=VICIntEnable
    mov r1,#128
    str r1,[r0]
    ldr r0,=U1IER
    mov r1,#1
    str r1,[r0]

    mrs r0,cpsr
    bic r0,r0,#0x80
    msr cpsr_c,r0

idle:
    b idle

uart1_irq:
    stmfd sp!,{r0-r3,r12,lr}
    ldr r0,=U1LSR
    ldr r1,[r0]
    tst r1,#1
    beq irq_done
    ldr r0,=U1RBR
    ldr r2,[r0]
tx_wait:
    ldr r0,=U1LSR
    ldr r1,[r0]
    tst r1,#0x20
    beq tx_wait
    ldr r0,=U1THR
    str r2,[r0]
irq_done:
    ldr r0,=VICVectAddr
    mov r1,#0
    str r1,[r0]
    ldmfd sp!,{r0-r3,r12,lr}
    subs pc,lr,#4

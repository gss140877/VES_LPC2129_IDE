/* LPC2129 ARM7TDMI-S CPU Self Test: Branch + condition flags */
.syntax unified
.cpu arm7tdmi
.arm
.global main
.equ IO0DIR, 0xE0028008
.equ IO0SET, 0xE0028004
.equ IO0CLR, 0xE002800C
main:
    LDR R10, =IO0DIR
    LDR R11, =0xFFFFFFFF
    STR R11, [R10]

    MOV R0, #5
    CMP R0, #5
    BEQ equal_ok
    B fail
equal_ok:
    CMP R0, #7
    BLT less_ok
    B fail
less_ok:
    MOV R1, #0
loop:
    ADD R1, R1, #1
    CMP R1, #10
    BNE loop
    CMP R1, #10
    BNE fail
pass:
    LDR R10, =IO0SET
    LDR R11, =0x0000F000
    STR R11, [R10]
    B pass
fail:
    LDR R10, =IO0CLR
    LDR R11, =0xFFFFFFFF
    STR R11, [R10]
    B fail

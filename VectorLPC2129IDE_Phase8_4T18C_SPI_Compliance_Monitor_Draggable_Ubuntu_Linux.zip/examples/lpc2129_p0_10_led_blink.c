/*
 * LPC2129 GPIO LED Blink - LPC2129 Simulator
 * LED anode : P0.10 through resistor
 * LED cathode: GND
 */

#define IOPIN (*(volatile unsigned long *)0xE0028000)
#define IOSET (*(volatile unsigned long *)0xE0028004)
#define IODIR (*(volatile unsigned long *)0xE0028008)
#define IOCLR (*(volatile unsigned long *)0xE002800C)

static void delay_ms(unsigned int ms)
{
    volatile unsigned int i, j;
    for (i = 0; i < ms; i++)
        for (j = 0; j < 6000; j++);
}

int main(void)
{
    IODIR |= (1UL << 10);

    while (1)
    {
        IOSET = (1UL << 10);
        delay_ms(500);
        IOCLR = (1UL << 10);
        delay_ms(500);
    }
}

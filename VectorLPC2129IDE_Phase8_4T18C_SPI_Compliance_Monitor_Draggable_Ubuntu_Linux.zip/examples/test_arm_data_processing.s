/*
 * LPC2129 ARM7TDMI-S CPU Self Test
 * Test    : ARM Data Processing Instructions
 * Syntax  : GNU ARM Assembly
 * Result  : Writes PASS pattern to IO0SET/IO1SET, FAIL pattern to IO0CLR/IO1CLR
 */
.syntax unified
.cpu arm7tdmi
.arm
.global main

.equ IO0DIR, 0xE0028008
.equ IO0SET, 0xE0028004
.equ IO0CLR, 0xE002800C
.equ IO1DIR, 0xE002C008
.equ IO1SET, 0xE002C004
.equ IO1CLR, 0xE002C00C

main:
    LDR R10, =IO0DIR
    LDR R11, =0xFFFFFFFF
    STR R11, [R10]
    LDR R10, =IO1DIR
    STR R11, [R10]

    MOV R0, #0x12
    MOV R1, #0x34
    ADD R2, R0, R1          @ R2 = 0x46
    CMP R2, #0x46
    BNE fail

    SUB R3, R2, #0x06       @ R3 = 0x40
    CMP R3, #0x40
    BNE fail

    ORR R4, R3, #0x0F       @ R4 = 0x4F
    CMP R4, #0x4F
    BNE fail

    AND R5, R4, #0xF0       @ R5 = 0x40
    CMP R5, #0x40
    BNE fail

    EOR R6, R5, #0x55       @ R6 = 0x15
    CMP R6, #0x15
    BNE fail

    BIC R7, R6, #0x05       @ R7 = 0x10
    CMP R7, #0x10
    BNE fail

    MVN R8, #0              @ R8 = 0xFFFFFFFF
    CMN R8, #1              @ should produce zero result internally
    BNE fail

pass:
    LDR R10, =IO0SET
    LDR R11, =0x000000AA
    STR R11, [R10]
    LDR R10, =IO1SET
    LDR R11, =0x00000055
    STR R11, [R10]
    B pass

fail:
    LDR R10, =IO0CLR
    LDR R11, =0xFFFFFFFF
    STR R11, [R10]
    LDR R10, =IO1CLR
    STR R11, [R10]
    B fail

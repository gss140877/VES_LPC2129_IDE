/* VECTOR LPC2129 — CAN1 <-> CAN2 via two MCP2551 transceivers
   Full classroom loop example using "Vector India Pvt Ltd".

   Flow:
     CAN1 -> MCP2551 #1 -> CANH/CANL bus -> MCP2551 #2 -> CAN2
     CAN2 copies received chunks to can2_rx_ram[]
     CAN2 sends the same chunks back
     CAN1 copies returned chunks to can1_return_ram[]

   A CAN data frame carries at most 8 bytes, so the 20-byte string is sent as
   three standard-ID frames. IDs 0x120..0x122 go CAN1->CAN2 and
   0x220..0x222 return CAN2->CAN1.

   LPC2129:
     CAN1 RX = P0.25/RD1, CAN1 TX = dedicated TD1 pin
     CAN2 RX = P0.23/RD2, CAN2 TX = P0.24/TD2
*/
#define PINSEL1   (*(volatile unsigned long *)0xE002C004)
#define AFMR      (*(volatile unsigned long *)0xE003C000)

#define C1MOD     (*(volatile unsigned long *)0xE0044000)
#define C1CMR     (*(volatile unsigned long *)0xE0044004)
#define C1GSR     (*(volatile unsigned long *)0xE0044008)
#define C1IER     (*(volatile unsigned long *)0xE0044010)
#define C1BTR     (*(volatile unsigned long *)0xE0044014)
#define C1SR      (*(volatile unsigned long *)0xE004401C)
#define C1RFS     (*(volatile unsigned long *)0xE0044020)
#define C1RID     (*(volatile unsigned long *)0xE0044024)
#define C1RDA     (*(volatile unsigned long *)0xE0044028)
#define C1RDB     (*(volatile unsigned long *)0xE004402C)
#define C1TFI1    (*(volatile unsigned long *)0xE0044030)
#define C1TID1    (*(volatile unsigned long *)0xE0044034)
#define C1TDA1    (*(volatile unsigned long *)0xE0044038)
#define C1TDB1    (*(volatile unsigned long *)0xE004403C)

#define C2MOD     (*(volatile unsigned long *)0xE0048000)
#define C2CMR     (*(volatile unsigned long *)0xE0048004)
#define C2GSR     (*(volatile unsigned long *)0xE0048008)
#define C2IER     (*(volatile unsigned long *)0xE0048010)
#define C2BTR     (*(volatile unsigned long *)0xE0048014)
#define C2SR      (*(volatile unsigned long *)0xE004801C)
#define C2RFS     (*(volatile unsigned long *)0xE0048020)
#define C2RID     (*(volatile unsigned long *)0xE0048024)
#define C2RDA     (*(volatile unsigned long *)0xE0048028)
#define C2RDB     (*(volatile unsigned long *)0xE004802C)
#define C2TFI1    (*(volatile unsigned long *)0xE0048030)
#define C2TID1    (*(volatile unsigned long *)0xE0048034)
#define C2TDA1    (*(volatile unsigned long *)0xE0048038)
#define C2TDB1    (*(volatile unsigned long *)0xE004803C)

#define TEXT_LEN 20
static const unsigned char can_source_text[TEXT_LEN+1]="Vector India Pvt Ltd";
volatile unsigned char can2_rx_ram[TEXT_LEN+1];
volatile unsigned char can1_return_ram[TEXT_LEN+1];
volatile unsigned long can_loop_complete;

static unsigned long pack4(const unsigned char *p,unsigned int n){
    unsigned long v=0;unsigned int i;
    for(i=0;i<n&&i<4;i++)v|=((unsigned long)p[i])<<(8*i);
    return v;
}
static void unpack4(unsigned long v,volatile unsigned char *p,unsigned int n){
    unsigned int i;for(i=0;i<n&&i<4;i++)p[i]=(unsigned char)(v>>(8*i));
}
static void can_init(void){
    /* P0.23=RD2, P0.24=TD2, P0.25=RD1. TD1 is a dedicated LPC2129 pin. */
    PINSEL1=(PINSEL1&~0x000FC000UL)|0x00054000UL;

    C1MOD=1; C2MOD=1;               /* reset mode while configuring */
    C1BTR=0x001C001D; C2BTR=0x001C001D;
    C1IER=0; C2IER=0;
    AFMR=2;                         /* acceptance-filter bypass: accept all */
    C1MOD=0; C2MOD=0;               /* normal mode */
}
static void can1_send(unsigned int id,const unsigned char *p,unsigned int n){
    while((C1SR&0x00000004UL)==0){}
    C1TFI1=((unsigned long)n)<<16; C1TID1=id;
    C1TDA1=pack4(p,n); C1TDB1=(n>4)?pack4(p+4,n-4):0;
    C1CMR=0x21;                     /* select TX buffer 1 + transmit */
}
static void can2_send(unsigned int id,const volatile unsigned char *p,unsigned int n){
    unsigned char t[8];unsigned int i;
    for(i=0;i<n;i++)t[i]=p[i];
    while((C2SR&0x00000004UL)==0){}
    C2TFI1=((unsigned long)n)<<16; C2TID1=id;
    C2TDA1=pack4(t,n); C2TDB1=(n>4)?pack4(t+4,n-4):0;
    C2CMR=0x21;
}
static unsigned int can2_receive(volatile unsigned char *dst){
    unsigned int n;
    while((C2GSR&1UL)==0){}
    n=(C2RFS>>16)&0xF;if(n>8)n=8;
    unpack4(C2RDA,dst,n);
    if(n>4)unpack4(C2RDB,dst+4,n-4);
    C2CMR=0x04;                     /* release RX buffer */
    return n;
}
static unsigned int can1_receive(volatile unsigned char *dst){
    unsigned int n;
    while((C1GSR&1UL)==0){}
    n=(C1RFS>>16)&0xF;if(n>8)n=8;
    unpack4(C1RDA,dst,n);
    if(n>4)unpack4(C1RDB,dst+4,n-4);
    C1CMR=0x04;
    return n;
}
int main(void){
    unsigned int off=0,frame=0,n;
    can_init();

    while(off<TEXT_LEN){
        n=(TEXT_LEN-off>8)?8:(TEXT_LEN-off);
        can1_send(0x120+frame,can_source_text+off,n);
        can2_receive(can2_rx_ram+off);

        can2_send(0x220+frame,can2_rx_ram+off,n);
        can1_receive(can1_return_ram+off);

        off+=n;frame++;
    }
    can2_rx_ram[TEXT_LEN]=0;
    can1_return_ram[TEXT_LEN]=0;
    can_loop_complete=0xCA121229;
    while(1){}
}

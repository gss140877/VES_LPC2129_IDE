/* LPC2129 GPIO Toggle Test - GNU ARM Assembly */
    .syntax unified
    .cpu arm7tdmi
    .arm

    .equ IOSET0,  0xE0028004
    .equ IODIR0,  0xE0028008
    .equ IOCLR0,  0xE002800C
    .equ IOSET1,  0xE002C004
    .equ IODIR1,  0xE002C008
    .equ IOCLR1,  0xE002C00C

    .global main
    .global delay_ms

delay_ms:
    LDR     R1, =12000
    MUL     R0, R1, R0
1:
    SUBS    R0, R0, #1
    BNE     1b
    BX      LR

main:
    LDR     R0, =IODIR0
    LDR     R1, =0xFFFFFFFF
    STR     R1, [R0]
    LDR     R0, =IODIR1
    STR     R1, [R0]

main_loop:
    LDR     R0, =IOSET0
    LDR     R1, =0xFFFFFFFF
    STR     R1, [R0]
    LDR     R0, =IOSET1
    STR     R1, [R0]
    MOV     R0, #100
    BL      delay_ms

    LDR     R0, =IOCLR0
    LDR     R1, =0xFFFFFFFF
    STR     R1, [R0]
    LDR     R0, =IOCLR1
    STR     R1, [R0]
    MOV     R0, #100
    BL      delay_ms
    B       main_loop

/* VECTOR LPC2129 Phase 8.4A — AIN0/P0.27 single-channel ADC + UART0. */
#define REG32(a) (*(volatile unsigned long *)(a))
#define PINSEL0 REG32(0xE002C000UL)
#define PINSEL1 REG32(0xE002C004UL)
#define ADCR REG32(0xE0034000UL)
#define ADGDR REG32(0xE0034004UL)
#define U0THR REG32(0xE000C000UL)
#define U0DLL REG32(0xE000C000UL)
#define U0DLM REG32(0xE000C004UL)
#define U0FCR REG32(0xE000C008UL)
#define U0LCR REG32(0xE000C00CUL)
#define U0LSR REG32(0xE000C014UL)
#define U0FDR REG32(0xE000C028UL)
#define U0TER REG32(0xE000C030UL)
static unsigned long udiv32(unsigned long n,unsigned long d){unsigned long q=0,r=0;int i;for(i=31;i>=0;i--){r=(r<<1)|((n>>(unsigned)i)&1UL);if(r>=d){r-=d;q|=(1UL<<(unsigned)i);}}return q;}
static unsigned long umod32(unsigned long n,unsigned long d){unsigned long q=udiv32(n,d);return n-q*d;}
static void putc0(unsigned char c){while((U0LSR&0x20UL)==0){}U0THR=c;}
static void puts0(const char*s){while(*s)putc0((unsigned char)*s++);}
static void dec0(unsigned long v){char b[11];int i=0;if(!v){putc0('0');return;}while(v){b[i++]=(char)('0'+umod32(v,10));v=udiv32(v,10);}while(i)putc0((unsigned char)b[--i]);}
static void volt0(unsigned long r){unsigned long mv=udiv32(r*3300UL+511UL,1023UL);putc0((unsigned char)('0'+udiv32(mv,1000)));putc0('.');putc0((unsigned char)('0'+umod32(udiv32(mv,100),10)));putc0((unsigned char)('0'+umod32(udiv32(mv,10),10)));putc0((unsigned char)('0'+umod32(mv,10)));}
int main(void){unsigned long d,v;volatile unsigned long n;
 PINSEL0=(PINSEL0&~0xFUL)|0x5UL;U0LCR=0x83;U0DLL=97;U0DLM=0;U0FDR=0x10;U0LCR=3;U0FCR=7;U0TER=0x80;
 PINSEL1=(PINSEL1&~(3UL<<22))|(1UL<<22);ADCR=(3UL<<8)|(1UL<<21);
 puts0("\r\nLPC2129 AIN0 / P0.27 ADC TEST\r\n");
 while(1){ADCR=1UL|(3UL<<8)|(1UL<<21)|(1UL<<24);do{d=ADGDR;}while(!(d&0x80000000UL));v=(d>>6)&0x3FFUL;ADCR=1UL|(3UL<<8)|(1UL<<21);puts0("AIN0 DEC=");dec0(v);puts0(" FLOAT=");volt0(v);puts0(" V\r\n");for(n=0;n<220000UL;n++){} }
}

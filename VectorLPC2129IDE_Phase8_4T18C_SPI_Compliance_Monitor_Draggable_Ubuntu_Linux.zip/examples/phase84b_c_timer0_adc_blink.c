/* VECTOR LPC2129 Phase 8.4D — Timer0 ADC-direct onboard LED toggle.
   AIN0/P0.27 raw decimal value is used directly as milliseconds.
   Only ADC values 100..1000 are valid: the LED toggles every raw milliseconds.
   Outside this range the timer is stopped and the onboard LED is forced OFF.
   Timer0 uses a 1 ms TC tick; onboard reusable LED Berg header is wired to P0.10. */
#define REG32(a) (*(volatile unsigned long *)(a))
#define PINSEL0 REG32(0xE002C000UL)
#define PINSEL1 REG32(0xE002C004UL)
#define IO0PIN  REG32(0xE0028000UL)
#define IO0SET  REG32(0xE0028004UL)
#define IO0DIR  REG32(0xE0028008UL)
#define IO0CLR  REG32(0xE002800CUL)
#define ADCR    REG32(0xE0034000UL)
#define ADGDR   REG32(0xE0034004UL)
#define T0IR    REG32(0xE0004000UL)
#define T0TCR   REG32(0xE0004004UL)
#define T0TC    REG32(0xE0004008UL)
#define T0PR    REG32(0xE000400CUL)
#define T0PC    REG32(0xE0004010UL)
#define T0MCR   REG32(0xE0004014UL)
#define T0MR0   REG32(0xE0004018UL)
#define T0CTCR  REG32(0xE0004070UL)
#define U0THR   REG32(0xE000C000UL)
#define U0DLL   REG32(0xE000C000UL)
#define U0DLM   REG32(0xE000C004UL)
#define U0FCR   REG32(0xE000C008UL)
#define U0LCR   REG32(0xE000C00CUL)
#define U0LSR   REG32(0xE000C014UL)
#define U0FDR   REG32(0xE000C028UL)
#define U0TER   REG32(0xE000C030UL)
#define VICIntEnable REG32(0xFFFFF010UL)
#define VICVectAddr  REG32(0xFFFFF030UL)
#define VICVectAddr0 REG32(0xFFFFFF00UL)
#define VICVectCntl0 REG32(0xFFFFF200UL)
#define LED (1UL<<10)
static volatile unsigned long led_state=0;
static unsigned long udiv32(unsigned long n,unsigned long d){unsigned long q=0,r=0;int i;for(i=31;i>=0;i--){r=(r<<1)|((n>>(unsigned)i)&1UL);if(r>=d){r-=d;q|=(1UL<<(unsigned)i);}}return q;}
static unsigned long umod32(unsigned long n,unsigned long d){unsigned long q=udiv32(n,d);return n-q*d;}
static void putc0(unsigned char c){while((U0LSR&0x20UL)==0){}U0THR=c;}
static void puts0(const char*s){while(*s)putc0((unsigned char)*s++);}
static void dec0(unsigned long v){char b[11];int i=0;if(!v){putc0('0');return;}while(v){b[i++]=(char)('0'+umod32(v,10));v=udiv32(v,10);}while(i)putc0((unsigned char)b[--i]);}
void timer0_irq(void) __attribute__((interrupt("IRQ")));
void timer0_irq(void){if(T0IR&1UL){T0IR=1UL;led_state^=1UL;if(led_state)IO0SET=LED;else IO0CLR=LED;}VICVectAddr=0;}
static void enable_irq(void){unsigned long v;__asm__ volatile("mrs %0, cpsr\n""bic %0, %0, #0x80\n""msr cpsr_c, %0\n":"=r"(v)::"memory");}
static unsigned long adc0(void){unsigned long d;ADCR=1UL|(3UL<<8)|(1UL<<21)|(1UL<<24);do{d=ADGDR;}while(!(d&0x80000000UL));ADCR=1UL|(3UL<<8)|(1UL<<21);return(d>>6)&0x3FFUL;}
int main(void){unsigned long raw,last=0xffffffffUL;
  IO0DIR|=LED;IO0CLR=LED;
  PINSEL0=(PINSEL0&~0xFUL)|0x5UL;U0LCR=0x83;U0DLL=97;U0DLM=0;U0FDR=0x10;U0LCR=3;U0FCR=7;U0TER=0x80;
  PINSEL1=(PINSEL1&~(3UL<<22))|(1UL<<22);ADCR=1UL|(3UL<<8)|(1UL<<21);
  T0TCR=2;T0CTCR=0;T0PR=14999UL;T0PC=0;T0TC=0;T0IR=0xFF;T0MR0=100;T0MCR=3;
  VICVectAddr0=(unsigned long)timer0_irq;VICVectCntl0=0x20UL|4UL;VICIntEnable=(1UL<<4);enable_irq();
  puts0("\r\nTIMER0 + AIN0 DIRECT ADC BLINK\r\n");
  puts0("ADC 100..1000 => toggle interval 100..1000 ms; outside range => LED OFF\r\n");
  while(1){
    raw=adc0();
    if(raw!=last){
      last=raw;
      if(raw>=100UL && raw<=1000UL){
        /* Raw ADC decimal value is the timer interval directly. */
        T0TCR=2;          /* reset and hold timer */
        T0IR=0xFF;        /* clear stale flags */
        T0PC=0;
        T0TC=0;
        T0MR0=raw;        /* 1 ms timer tick => raw milliseconds */
        T0TCR=1;          /* run */
        puts0("AIN0=");dec0(raw);puts0("  TOGGLE=");dec0(raw);puts0(" ms\r\n");
      }else{
        T0TCR=0;          /* stop timer completely */
        T0IR=0xFF;
        T0PC=0;
        T0TC=0;
        led_state=0;
        IO0CLR=LED;        /* invalid ADC range => LED OFF */
        puts0("AIN0=");dec0(raw);puts0("  OUT OF RANGE - LED OFF\r\n");
      }
    }
  }
}

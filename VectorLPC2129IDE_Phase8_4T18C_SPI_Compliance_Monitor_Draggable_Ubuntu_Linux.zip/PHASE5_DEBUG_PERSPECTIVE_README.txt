Phase 5 Debug Perspective
=========================

This update makes the Phase 4C profiler/coverage data visible in the GUI.

How to use:
1. Run RUN_SERVER.bat.
2. Open the simulator.
3. Build C or Assembly source.
4. Click Run Simulation.
5. Look at the right-side Debug View.

Visible panels:
- CPU Profiler: mode, PC, opcode, cycles, execution time, CPI.
- CPU Registers: R0-R15 and CPSR flags.
- Peripheral Registers: IO0/IO1 GPIO register values.
- Execution Trace: recent PC/opcode/family entries.
- Instruction Coverage: ARM/THUMB decode/execute counts.

Buttons:
- Debug View: show/hide the debug dock.
- Refresh: manually refresh debugger panels.
- Clear inside Execution Trace: clear trace history.

Note:
This does not claim 100% ARM7TDMI-S instruction support yet. It provides the debugger/visibility layer needed to validate and extend the CPU core instruction family by family.

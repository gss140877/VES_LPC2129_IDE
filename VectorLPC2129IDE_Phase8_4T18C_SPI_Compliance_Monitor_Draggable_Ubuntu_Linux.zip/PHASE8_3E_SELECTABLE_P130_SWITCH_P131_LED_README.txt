VECTOR LPC2129 IDE — Phase 8.3E
Selectable On-board P1.30 Switch / P1.31 LED Trainer

Baseline:
- Built from the user's Phase 8.3D Physical Reset Button Movement build.
- Existing approved board PNG is unchanged.
- Existing RESET, PWR, UART TX and UART RX overlays are preserved.

P1.30 switch hardware model:
- Active-low SMD momentary switch: P1.30 has a simulated 10 kΩ pull-up to 3.3 V; press connects to GND.
- Active-high SMD momentary switch: P1.30 has a simulated 10 kΩ pull-down to GND; press connects to 3.3 V.
- A compact SMD selector chooses which of those two circuits is connected to P1.30.
- Unselected SMD switch does not affect the MCU input.

P1.31 LED hardware model:
- Active-low LED: 3.3 V -> 330 Ω -> LED -> P1.31. MCU LOW turns it on.
- Active-high LED: P1.31 -> 330 Ω -> LED -> GND. MCU HIGH turns it on.
- A compact SMD selector chooses which LED circuit is connected.
- LED indication is derived from canonical P1.31 IOPIN/IODIR state coming from the ARM7 worker.

Four Embedded C examples:
1. P1.30 active-low switch -> P1.31 active-low LED
2. P1.30 active-low switch -> P1.31 active-high LED
3. P1.30 active-high switch -> P1.31 active-low LED
4. P1.30 active-high switch -> P1.31 active-high LED

Selecting one of these examples configures only the physical on-board selector positions and source/canvas. It does not bypass firmware execution.

RULE:
.c source -> arm-none-eabi-gcc -> ELF/HEX -> ARM7TDMI-S worker -> official LPC2129 GPIO SFRs -> canonical P1.30/P1.31 physical model -> on-board switch/LED circuit.

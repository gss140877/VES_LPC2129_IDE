Phase 8.4T18C — SPI Compliance Monitor Draggable Fix

Change:
- SPI0/SPI1 + 25LC512 Compliance Monitor can now be dragged by its title bar.
- Close button is excluded from drag start.
- Window movement is constrained to the visible application/browser viewport.
- Existing T18B editable memory debugger and all prior T17/T16 functionality are preserved.

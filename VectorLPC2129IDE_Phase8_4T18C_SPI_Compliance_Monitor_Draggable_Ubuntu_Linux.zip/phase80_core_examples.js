/* VECTOR LPC2129 IDE — Phase 8.0D
   Editable/saveable example source windows + canonical HEX-driven circuit flow.
   RULE: source -> ARM GCC/GAS -> ELF/HEX -> ARM7TDMI-S -> LPC2129 GPIO -> canvas.
*/
(function(){
'use strict';

const EXAMPLES={
  c_led:{name:'Embedded C — LED Blink (P0.10)',sourceType:'c',file:'examples/phase80_c_led_blink.c',fileName:'phase80_c_led_blink.c',project:'P80_C_LED_BLINK',circuit:'led'},
  c_switch:{name:'Embedded C — Switch P0.14 → LED P0.10',sourceType:'c',file:'examples/phase80_c_switch_led.c',fileName:'phase80_c_switch_led.c',project:'P80_C_SWITCH_LED',circuit:'switch_led'},
  asm_led:{name:'GNU ARM Assembly — LED Blink (P0.10)',sourceType:'assembly',file:'examples/phase80_asm_led_blink.s',fileName:'phase80_asm_led_blink.s',project:'P80_ASM_LED_BLINK',circuit:'led'},
  asm_switch:{name:'GNU ARM Assembly — Switch P0.14 → LED P0.10',sourceType:'assembly',file:'examples/phase80_asm_switch_led.s',fileName:'phase80_asm_switch_led.s',project:'P80_ASM_SWITCH_LED',circuit:'switch_led'},
  c_uart0:{name:'Embedded C — UART0 TX/RX Echo',sourceType:'c',file:'examples/phase82_c_uart0_echo.c',fileName:'phase82_c_uart0_echo.c',project:'P82_C_UART0_ECHO',uart:0},
  c_uart1:{name:'Embedded C — UART1 TX/RX Echo',sourceType:'c',file:'examples/phase82_c_uart1_echo.c',fileName:'phase82_c_uart1_echo.c',project:'P82_C_UART1_ECHO',uart:1},
  asm_uart0:{name:'GNU ARM Assembly — UART0 TX/RX Echo',sourceType:'assembly',file:'examples/phase82_asm_uart0_echo.s',fileName:'phase82_asm_uart0_echo.s',project:'P82_ASM_UART0_ECHO',uart:0},
  asm_uart1:{name:'GNU ARM Assembly — UART1 TX/RX Echo',sourceType:'assembly',file:'examples/phase82_asm_uart1_echo.s',fileName:'phase82_asm_uart1_echo.s',project:'P82_ASM_UART1_ECHO',uart:1},
  c_uart0_irq:{name:'Embedded C — UART0 RX Interrupt Echo',sourceType:'c',file:'examples/phase83_c_uart0_irq_echo.c',fileName:'phase83_c_uart0_irq_echo.c',project:'P83_C_UART0_IRQ',uart:0},
  c_uart1_irq:{name:'Embedded C — UART1 RX Interrupt Echo',sourceType:'c',file:'examples/phase83_c_uart1_irq_echo.c',fileName:'phase83_c_uart1_irq_echo.c',project:'P83_C_UART1_IRQ',uart:1},
  asm_uart0_irq:{name:'GNU ARM Assembly — UART0 RX Interrupt Echo',sourceType:'assembly',file:'examples/phase83_asm_uart0_irq_echo.s',fileName:'phase83_asm_uart0_irq_echo.s',project:'P83_ASM_UART0_IRQ',uart:0},
  asm_uart1_irq:{name:'GNU ARM Assembly — UART1 RX Interrupt Echo',sourceType:'assembly',file:'examples/phase83_asm_uart1_irq_echo.s',fileName:'phase83_asm_uart1_irq_echo.s',project:'P83_ASM_UART1_IRQ',uart:1},
  c_p130al_p131al:{name:'Embedded C — P1.30 AL Switch → P1.31 AL LED',sourceType:'c',file:'examples/phase83e_c_swAL_ledAL.c',fileName:'phase83e_c_swAL_ledAL.c',project:'P83E_SWAL_LEDAL',boardCombo:'AL_AL'},
  c_p130al_p131ah:{name:'Embedded C — P1.30 AL Switch → P1.31 AH LED',sourceType:'c',file:'examples/phase83e_c_swAL_ledAH.c',fileName:'phase83e_c_swAL_ledAH.c',project:'P83E_SWAL_LEDAH',boardCombo:'AL_AH'},
  c_p130ah_p131al:{name:'Embedded C — P1.30 AH Switch → P1.31 AL LED',sourceType:'c',file:'examples/phase83e_c_swAH_ledAL.c',fileName:'phase83e_c_swAH_ledAL.c',project:'P83E_SWAH_LEDAL',boardCombo:'AH_AL'},
  c_p130ah_p131ah:{name:'Embedded C — P1.30 AH Switch → P1.31 AH LED',sourceType:'c',file:'examples/phase83e_c_swAH_ledAH.c',fileName:'phase83e_c_swAH_ledAH.c',project:'P83E_SWAH_LEDAH',boardCombo:'AH_AH'},
  c_adc0_uart0:{name:'Embedded C — ADC AIN0 + UART0',sourceType:'c',file:'examples/phase84_c_adc0_uart0.c',fileName:'phase84_c_adc0_uart0.c',project:'P84_ADC0_UART0',circuit:'adc4',uart:0},
  c_adc4_uart0:{name:'Embedded C — ADC 4-Channel Polling + UART0',sourceType:'c',file:'examples/phase84_c_adc4_uart0.c',fileName:'phase84_c_adc4_uart0.c',project:'P84_ADC4_UART0',circuit:'adc4',uart:0},
  c_adc4_burst_uart0:{name:'Embedded C — ADC 4-Channel Burst + UART0',sourceType:'c',file:'examples/phase84_c_adc4_burst_uart0.c',fileName:'phase84_c_adc4_burst_uart0.c',project:'P84_ADC4_BURST_UART0',circuit:'adc4',uart:0},
  c_timer0_adc_blink:{name:'Embedded C — Timer0 + AIN0 Variable Blink',sourceType:'c',file:'examples/phase84b_c_timer0_adc_blink.c',fileName:'phase84b_c_timer0_adc_blink.c',project:'P84B_TIMER0_ADC_BLINK',circuit:'timer_adc',uart:0},
  c_timer1_adc_blink:{name:'Embedded C — Timer1 + AIN0 Variable Blink',sourceType:'c',file:'examples/phase84b_c_timer1_adc_blink.c',fileName:'phase84b_c_timer1_adc_blink.c',project:'P84B_TIMER1_ADC_BLINK',circuit:'timer_adc',uart:0},
  c_pwm2_led_fade:{name:'Embedded C — AIN0 Trimpot → PWM2 LED Brightness',sourceType:'c',file:'examples/phase84p_c_adc0_pwm2_led.c',fileName:'phase84p_c_adc0_pwm2_led.c',project:'P84P_ADC0_PWM2_LED',circuit:'pwm_adc_led'},
  c_rtc_calendar:{name:'Embedded C — RTC Digital Calendar → UART0',sourceType:'c',file:'examples/phase84o_c_rtc_calendar_uart0.c',fileName:'phase84o_c_rtc_calendar_uart0.c',project:'P84O_RTC_CALENDAR',uart:0},
  c_i2c_24lc512:{name:'Embedded C — I2C + 24LC512 String EEPROM',sourceType:'c',file:'examples/phase84t4_c_i2c_24lc512.c',fileName:'phase84t4_c_i2c_24lc512.c',project:'P84T14_I2C_STRING_24LC512',i2cLab:'24lc512'},
  c_spi0_25lc512:{name:'Embedded C — SPI0 + 25LC512 String EEPROM',sourceType:'c',file:'examples/phase84t14_c_spi0_25lc512.c',fileName:'phase84t14_c_spi0_25lc512.c',project:'P84T15_SPI0_STRING_25LC512',spiLab:'25lc512'},
  c_can1_can2_loop:{name:'Embedded C — CAN1 ↔ CAN2 MCP2551 String Loop',sourceType:'c',file:'examples/phase84t15_c_can1_can2_mcp2551_string_loop.c',fileName:'phase84t15_c_can1_can2_mcp2551_string_loop.c',project:'P84T15_CAN1_CAN2_MCP2551_STRING_LOOP',canLab:'mcp2551loop'}
};
const sourceWindows={};
const sourceBuffers={};
let activeExampleKey=null, z=51000;
function safeLog(s){try{if(typeof log==='function')log(s);}catch(e){}}
function bring(p){if(p)p.style.zIndex=String(++z)}
function nodePortPin(node){const m=String(node||'').match(/^uno\.P([01])_(\d+)$/);return m?{port:+m[1],pin:+m[2]}:null}
function connected(node){const a=[];if(typeof project==='undefined'||!project||!Array.isArray(project.wires))return a;for(const w of project.wires){if(w.from===node)a.push(w.to);else if(w.to===node)a.push(w.from)}return a}
function connectedButtonsToGpio(port,pin){const gpio=`uno.P${port}_${pin}`,result=[];if(typeof project==='undefined'||!project||!Array.isArray(project.parts))return result;for(const n of connected(gpio)){const m=String(n).match(/^([^\.]+)\.S$/);if(!m)continue;const p=project.parts.find(x=>x.id===m[1]&&x.type==='button');if(p)result.push(p)}return result}


/* Phase 8.1B deterministic external-input latch.
   UI events enqueue physical input changes; the CPU-side sampler applies them
   at the next deterministic simulation boundary/read. */
const phase81PendingInputs=new Map();

function phase81QueueButtonInput(buttonPart){
  if(!buttonPart)return;
  phase81PendingInputs.set(buttonPart.id,!!buttonPart.state);
}

window.phase81FlushPendingInput=function(emu){
  if(!emu||!phase81PendingInputs.size)return false;
  const changed=window.phase80SampleExternalInputs(emu);
  if(changed && window.phase81SimClock){
    window.phase81SimClock.inputTransitions=(window.phase81SimClock.inputTransitions||0)+1;
  }
  phase81PendingInputs.clear();
  return changed;
};
window.phase80SampleExternalInputs=function(emu){
  if(!emu||!emu.gpio)return false;
  let changed=false;
  for(const port of [0,1]){
    const dir=port===0?(emu.gpio.IO0DIR>>>0):(emu.gpio.IO1DIR>>>0);
    const before=port===0?(emu.gpio.IO0PIN>>>0):(emu.gpio.IO1PIN>>>0);
    let pinv=before;
    const pins=port===0?[...Array(26).keys(),27,28,29,30]:Array.from({length:16},(_,i)=>i+16);
    for(const pin of pins){
      const bit=(2**pin)>>>0;
      if(dir&bit)continue;
      const btns=connectedButtonsToGpio(port,pin);
      if(!btns.length)continue;
      const pressed=btns.some(b=>!!b.state);
      pinv=pressed?((pinv&~bit)>>>0):((pinv|bit)>>>0);
    }
    if(pinv!==before){
      changed=true;
      if(port===0)emu.gpio.IO0PIN=pinv>>>0;else emu.gpio.IO1PIN=pinv>>>0;
    }
  }
  if(changed)emu.gpioPinChangeCount=(emu.gpioPinChangeCount||0)+1;
  return changed;
};
window.phase80OnButtonStateChange=function(buttonPart){
  try{
    phase81QueueButtonInput(buttonPart);
    try{
      if(typeof window.phase82bSetInput==='function'&&buttonPart){
        for(const port of [0,1]){
          const pins=port===0?[...Array(26).keys(),27,28,29,30]:Array.from({length:16},(_,i)=>i+16);
          for(const pin of pins){
            const btns=connectedButtonsToGpio(port,pin);
            if(btns.includes(buttonPart)){
              const pressed=btns.some(b=>!!b.state);
              window.phase82bSetInput(port,pin,!pressed); /* active-low classroom switch */
            }
          }
        }
      }
    }catch(e){}

    const emu=window.lpcArm7Emu;
    if(emu){
      const changed=window.phase81FlushPendingInput(emu);
      if(changed){
        window.lpcGpio=window.lpcGpio||{};
        const p0=window.lpcGpio.p0||(window.lpcGpio.p0={});
        const p1=window.lpcGpio.p1||(window.lpcGpio.p1={});
        p0.IOPIN=p0.pin=emu.gpio.IO0PIN>>>0;
        p1.IOPIN=p1.pin=emu.gpio.IO1PIN>>>0;
        if(window.phase81SimClock){
          const hz=Math.max(1,Number((window.LPC2129ClockConfig&&window.LPC2129ClockConfig.cclkHz)||60000000));
          window.phase81SimClock.lastInputTransitionUs=((emu.profiler.totalCycles||0)/hz)*1000000;
        }
        if(typeof renderLpcGpioMonitor==='function')renderLpcGpioMonitor();
      }
      if(typeof window.phase5RefreshDebug==='function')window.phase5RefreshDebug(emu,'external GPIO input changed');
    }
  }catch(e){}
};
function gpioLevel(node){
  if(node==='uno.5V'||node==='uno.3V3'||node==='VCC'||node==='+5V')return 1;
  if(node==='uno.GND'||node==='GND'||node==='gnd')return 0;
  const pp=nodePortPin(node);if(!pp)return null;const g=window.lpcGpio&&(pp.port===0?window.lpcGpio.p0:window.lpcGpio.p1);if(!g)return 0;return ((g.IOPIN>>>pp.pin)&1)?1:0;
}
function neighbors(node){const a=[node];if(typeof project==='undefined'||!project||!Array.isArray(project.wires))return a;for(const w of project.wires){if(w.from===node)a.push(w.to);if(w.to===node)a.push(w.from)}return a}
window.updateLpcExternalLoads=function(){
  if(typeof project==='undefined'||!project||!Array.isArray(project.parts))return;
  for(const p of project.parts){
    if(p.type==='led'){const an=neighbors(p.id+'.A').map(gpioLevel),ca=neighbors(p.id+'.K').map(gpioLevel);p.state=(an.includes(1)&&ca.includes(0))?HIGH:LOW}
    else if(p.type==='buzzer'){p.state=neighbors(p.id+'.SIG').map(gpioLevel).includes(1)?HIGH:LOW}
    else if(p.type==='relay'){p.state=neighbors(p.id+'.IN').map(gpioLevel).includes(1)?HIGH:LOW}
  }
};
window.phase81RefreshCanvasOutputs=function(){
  if(typeof project==='undefined'||!project||!Array.isArray(project.parts))return;
  for(const p of project.parts){
    if(p.type==='led'){
      const el=document.querySelector('#'+CSS.escape(p.id)+' .ledBulb');
      if(!el)continue;
      const shouldOn=!!p.state;
      const isOn=el.classList.contains('on');
      if(shouldOn!==isOn)el.classList.toggle('on',shouldOn);
    }
  }
};


function clearCircuit(){
  try{if(typeof stopSimulation==='function')stopSimulation()}catch(e){}
  try{if(window.lpcArm7Emu)window.lpcArm7Emu.running=false}catch(e){}
  try{nextId=1;selectedId=null;wiringSource=null;wiringMouse=null}catch(e){}
  if(typeof project==='undefined'||!project)return;project.parts=[];project.wires=[];document.querySelectorAll('.part').forEach(e=>e.remove());
}
function buildCircuit(kind){
  clearCircuit();if(typeof project==='undefined'||!project)return;project.canvasScale=0.82;
  if(kind==='adc4'){
    const xs=[82,270,458,646],vals=[128,384,640,896];
    for(let ch=0;ch<4;ch++){
      const pot=addPart('pot',{x:xs[ch],y:590,scale:0.92});pot.adcChannel=ch;pot.value=vals[ch];
      addWire('uno.3V3',pot.id+'.VCC');addWire(pot.id+'.GND','uno.GND');addWire('uno.P0_'+(27+ch),pot.id+'.OUT');
    }
    if(typeof render==='function')render();
    try{if(typeof window.phase84SyncAdcCanvas==='function')setTimeout(window.phase84SyncAdcCanvas,80)}catch(e){}
  }else if(kind==='pwm_adc_led'){
    const pot=addPart('pot',{x:270,y:590,scale:0.96});pot.adcChannel=0;pot.value=512;
    addWire('uno.3V3',pot.id+'.VCC');addWire(pot.id+'.GND','uno.GND');addWire('uno.P0_27',pot.id+'.OUT');
    addWire('uno.P0_7','p83e.LED');
    if(typeof render==='function')render();
    try{if(typeof window.phase83eSetLedMode==='function')window.phase83eSetLedMode('AH')}catch(e){}
    try{if(typeof window.phase84SyncAdcCanvas==='function')setTimeout(window.phase84SyncAdcCanvas,80)}catch(e){}
  }else if(kind==='timer_adc'){
    const pot=addPart('pot',{x:270,y:590,scale:0.96});pot.adcChannel=0;pot.value=512;
    addWire('uno.3V3',pot.id+'.VCC');addWire(pot.id+'.GND','uno.GND');addWire('uno.P0_27',pot.id+'.OUT');
    addWire('uno.P0_10','p83e.LED');
    if(typeof render==='function')render();
    try{if(typeof window.phase83eSetLedMode==='function')window.phase83eSetLedMode('AH')}catch(e){}
    try{if(typeof window.phase84SyncAdcCanvas==='function')setTimeout(window.phase84SyncAdcCanvas,80)}catch(e){}
  }else{
    const led=addPart('led',{x:890,y:105,scale:0.82});addWire('uno.P0_10',led.id+'.A');addWire('uno.GND',led.id+'.K');
    if(kind==='switch_led'){const btn=addPart('button',{x:900,y:310,scale:0.82});addWire('uno.P0_14',btn.id+'.S');addWire('uno.GND',btn.id+'.G')}
  }
  if(typeof applyCanvasZoom==='function')applyCanvasZoom();if(typeof render==='function')render();if(typeof drawWires==='function')setTimeout(drawWires,40);
}

function syncActiveSource(key){
  const ex=EXAMPLES[key];if(!ex)return;
  const w=sourceWindows[key];
  const code=w?w.ta.value:(sourceBuffers[key]||'');
  activeExampleKey=key;
  if(w) sourceBuffers[key]=w.ta.value;
  document.querySelectorAll('.p80-source-window').forEach(x=>x.classList.toggle('p80-active-source',w&&x===w.p));
  document.querySelectorAll('.ide-tree-file[data-phase80-example]').forEach(x=>x.classList.toggle('active',x.dataset.phase80Example===key));
  const ce=document.getElementById('code'),st=document.getElementById('sourceType'),pn=document.getElementById('projectName'),title=document.getElementById('codePanelTitle');
  if(ce){ce.readOnly=false;ce.value=code}
  if(st)st.value=ex.sourceType;
  if(pn)pn.value=ex.project;
  if(title)title.textContent=ex.sourceType==='assembly'?'LPC2129 GNU ARM Assembly Source':'LPC2129 Embedded C Source';
  window.phase70MainBuffer=code;
  window.phase70MainSourceType=ex.sourceType;
}
function makeDraggableResizable(p){
  const head=p.querySelector('.p80-source-head');
  head.addEventListener('mousedown',e=>{if(e.button!==0||e.target.closest('button,input,textarea'))return;bring(p);const r=p.getBoundingClientRect(),sx=e.clientX,sy=e.clientY,sl=r.left,st=r.top;function mv(ev){p.style.left=Math.max(4,Math.min(sl+ev.clientX-sx,window.innerWidth-p.offsetWidth-4))+'px';p.style.top=Math.max(58,Math.min(st+ev.clientY-sy,window.innerHeight-40))+'px'}function up(){removeEventListener('mousemove',mv,true);removeEventListener('mouseup',up,true)}addEventListener('mousemove',mv,true);addEventListener('mouseup',up,true);e.preventDefault()},true);
  p.addEventListener('mousedown',()=>bring(p),true);
}
async function saveSource(key){
  const w=sourceWindows[key],ex=EXAMPLES[key];if(!w||!ex)return false;
  sourceBuffers[key]=w.ta.value;
  syncActiveSource(key);
  w.save.textContent='Saving…';
  try{
    const r=await fetch('/api/save-source',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({fileName:ex.fileName,sourceType:ex.sourceType,code:w.ta.value})});
    const d=await r.json();
    w.save.textContent=d.ok?'Saved ✓':'Save Source';
    w.dirty=false;w.mark.textContent=d.ok?'Saved':'Modified';w.mark.className='p80-source-state '+(d.ok?'saved':'dirty');
    safeLog(d.output||'');
    setTimeout(()=>{if(w.save)w.save.textContent='Save Source'},1300);
    return !!d.ok;
  }catch(e){w.save.textContent='Save Source';safeLog('Save source backend error: '+e.message);return false}
}
async function openSourceWindow(key,code){
  const ex=EXAMPLES[key];if(!ex)return;
  let w=sourceWindows[key];
  if(w){w.p.style.display='flex';bring(w.p);syncActiveSource(key);return w}
  if(code===undefined || code===null){
    if(Object.prototype.hasOwnProperty.call(sourceBuffers,key)) code=sourceBuffers[key];
    else code=await fetch(ex.file).then(r=>{if(!r.ok)throw new Error(r.statusText);return r.text()});
  }
  sourceBuffers[key]=code;
  const p=document.createElement('div');p.className='p80-source-window';p.id='p80src_'+key;
  const offset=Object.keys(sourceWindows).length*28;
  Object.assign(p.style,{left:(260+offset)+'px',top:(112+offset)+'px',width:'760px',height:'570px'});
  p.innerHTML=`<div class="p80-source-head"><div class="p80-source-title"><b>${ex.fileName}</b><span class="p80-source-lang">${ex.sourceType==='assembly'?'GNU ARM Assembly':'Embedded C'}</span><span class="p80-source-state saved">Loaded</span></div><div class="p80-source-actions"><button class="p80-save">Save Source</button><button class="p80-close" title="Close">×</button></div></div><textarea class="p80-source-editor" spellcheck="false"></textarea>`;
  document.body.appendChild(p);
  const ta=p.querySelector('.p80-source-editor'),save=p.querySelector('.p80-save'),mark=p.querySelector('.p80-source-state');ta.value=code;
  w=sourceWindows[key]={p,ta,save,mark,dirty:false};
  p.querySelector('.p80-close').onclick=()=>p.style.display='none';
  save.onclick=()=>saveSource(key);
  ta.addEventListener('input',()=>{w.dirty=true;sourceBuffers[key]=ta.value;mark.textContent='Modified';mark.className='p80-source-state dirty';if(activeExampleKey===key)syncActiveSource(key);window.lastLpc2129Hex=''});
  ta.addEventListener('focus',()=>syncActiveSource(key));
  p.addEventListener('mousedown',()=>syncActiveSource(key),true);
  makeDraggableResizable(p);bring(p);syncActiveSource(key);return w;
}
window.phase80OpenExampleSource=async function(key){
  try{return await openSourceWindow(key);}catch(e){safeLog('Open source failed: '+e.message);return null}
};

function addExampleToProjectWorkspace(key){
  const ex=EXAMPLES[key];if(!ex)return;
  const explorer=document.getElementById('ideProjectExplorer');
  const tree=explorer&&explorer.querySelector('.ide-tree');
  if(!tree)return;
  let row=tree.querySelector(`[data-phase80-example="${key}"]`);
  if(!row){
    row=document.createElement('div');
    row.className='ide-tree-row ide-tree-file p80-project-source';
    row.dataset.phase80Example=key;
    row.dataset.fileName=ex.fileName;
    row.innerHTML=`<span class="ide-tree-icon">${ex.sourceType==='assembly'?'S':'C'}</span><span>${ex.fileName}</span>`;
    row.title='Double-click or click to open editable source';
    row.onclick=e=>{e.stopPropagation();window.phase80OpenExampleSource(key)};
    const debugFolder=[...tree.querySelectorAll('.ide-tree-folder')].find(x=>/Debug Views/i.test(x.textContent||''));
    if(debugFolder)tree.insertBefore(row,debugFolder);else tree.appendChild(row);
  }
  tree.querySelectorAll('.ide-tree-file').forEach(x=>x.classList.remove('active'));
  row.classList.add('active');
}
async function loadExample(key){
  const ex=EXAMPLES[key];if(!ex)return;
  try{
    let code;
    if(sourceWindows[key]) code=sourceWindows[key].ta.value;
    else if(Object.prototype.hasOwnProperty.call(sourceBuffers,key)) code=sourceBuffers[key];
    else code=await fetch(ex.file).then(r=>{if(!r.ok)throw new Error(r.statusText);return r.text()});
    sourceBuffers[key]=code;

    /* Selecting an example makes it the active project source, but does NOT
       automatically open another editor window. Open it explicitly from PROJECT. */
    syncActiveSource(key);
    addExampleToProjectWorkspace(key);
    /* Phase 8.4T: keep the dedicated I2C lab selection explicit.  Do not
       rely on a wrapper around window.phase80LoadExample: this local function
       is what the toolbar menu actually invokes. */
    try{if(!ex.i2cLab && typeof window.phase84tHideI2CEepromLab==='function')window.phase84tHideI2CEepromLab()}catch(e){}
    if(ex.i2cLab==='24lc512'){
      clearCircuit();
      try{if(typeof window.phase84tShowI2CEepromLab==='function')window.phase84tShowI2CEepromLab()}catch(e){}
    }else if(ex.spiLab==='25lc512'){
      clearCircuit();
      try{if(typeof window.phase84t14ShowSpiEepromLab==='function')window.phase84t14ShowSpiEepromLab()}catch(e){}
      try{if(typeof window.phase72ShowCanvas==='function')window.phase72ShowCanvas()}catch(e){}
    }else if(ex.canLab==='mcp2551loop'){
      clearCircuit();
      try{if(typeof window.phase84t15ShowCanLoopLab==='function')window.phase84t15ShowCanLoopLab()}catch(e){}
      try{if(typeof window.phase72ShowCanvas==='function')window.phase72ShowCanvas()}catch(e){}
      try{if(typeof window.phase84t15ShowCANMonitor==='function')window.phase84t15ShowCANMonitor()}catch(e){}
    }else if(ex.boardCombo){
      clearCircuit();
      try{if(typeof window.phase83eConfigureBoard==='function')window.phase83eConfigureBoard(ex.boardCombo)}catch(e){}
      try{if(typeof window.phase72ShowCanvas==='function')window.phase72ShowCanvas()}catch(e){}
    }else if(ex.circuit){
      buildCircuit(ex.circuit);
      try{if(typeof window.phase72ShowCanvas==='function')window.phase72ShowCanvas()}catch(e){}
      if(ex.uart===0||ex.uart===1){try{if(typeof window.phase82ShowTerminal==='function')window.phase82ShowTerminal(ex.uart)}catch(e){}}
    }else if(ex.uart===0||ex.uart===1){
      try{if(typeof window.phase82ShowTerminal==='function')window.phase82ShowTerminal(ex.uart)}catch(e){}
    }

    window.lastLpc2129Hex='';window.lastLpc2129DebugListing='';window.lastLpc2129DebugMap=null;window.lpcArm7Emu=null;
    safeLog('Example added to PROJECT workspace: '+ex.fileName);
    safeLog(ex.boardCombo?'Relevant on-board P1.30/P1.31 SMD circuit configured and Circuit Canvas opened. Click the project source file to edit/save it.':(ex.circuit?'Relevant Circuit Canvas opened. Click the project source file to edit/save it.':'Relevant UART'+ex.uart+' simulated serial terminal opened. Click the project source file to edit/save it.'));
    safeLog('Build HEX uses the currently selected project source.');
    safeLog('RULE ACTIVE: source -> ARM GCC/GAS -> HEX -> ARM7TDMI-S -> LPC2129 GPIO -> canvas.');
  }catch(e){safeLog('Example load failed: '+e.message)}
}
window.phase80LoadExample=loadExample;
window.phase80SaveActiveSource=function(){return activeExampleKey?saveSource(activeExampleKey):false};

function installExamplesToolbar(){
  const cBtn=document.getElementById('phase80CBtn'),aBtn=document.getElementById('phase80AsmBtn');if(!cBtn||!aBtn||cBtn.dataset.bound==='1')return;cBtn.dataset.bound='1';aBtn.dataset.bound='1';
  let menu=document.getElementById('phase80BodyMenu');if(!menu){menu=document.createElement('div');menu.id='phase80BodyMenu';menu.className='phase80-body-menu';document.body.appendChild(menu)}
  function closeMenu(){menu.classList.remove('show');menu.innerHTML=''}
  function openMenu(button,items){menu.innerHTML=items.map(x=>`<button type="button" data-example="${x[0]}">${x[1]}</button>`).join('');const r=button.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(r.left,window.innerWidth-300))+'px';menu.style.top=(r.bottom+4)+'px';menu.classList.add('show');menu.querySelectorAll('[data-example]').forEach(b=>b.onclick=async e=>{e.stopPropagation();const key=b.dataset.example;closeMenu();await loadExample(key)})}
  cBtn.onclick=e=>{e.stopPropagation();openMenu(cBtn,[['c_led','LED Blink — P0.10'],['c_switch','Switch P0.14 → LED P0.10'],['c_uart0','UART0 — TX/RX Echo'],['c_uart1','UART1 — TX/RX Echo'],['c_uart0_irq','UART0 — RX Interrupt Echo'],['c_uart1_irq','UART1 — RX Interrupt Echo'],['c_p130al_p131al','P1.30 AL SW → P1.31 AL LED'],['c_p130al_p131ah','P1.30 AL SW → P1.31 AH LED'],['c_p130ah_p131al','P1.30 AH SW → P1.31 AL LED'],['c_p130ah_p131ah','P1.30 AH SW → P1.31 AH LED'],['c_adc0_uart0','ADC AIN0 → UART0'],['c_adc4_uart0','ADC AIN0–AIN3 Polling → UART0'],['c_adc4_burst_uart0','ADC AIN0–AIN3 Burst → UART0'],['c_timer0_adc_blink','Timer0 + AIN0 Variable Blink'],['c_timer1_adc_blink','Timer1 + AIN0 Variable Blink'],['c_pwm2_led_fade','AIN0 Trimpot → PWM2 LED Brightness'],['c_rtc_calendar','RTC — Digital Calendar → UART0'],['c_i2c_24lc512','I2C — 24LC512 String Byte/Page Demo'],['c_spi0_25lc512','SPI0 — 25LC512 String Byte/Page Demo'],['c_can1_can2_loop','CAN1 ↔ CAN2 — MCP2551 String Loop']])};
  aBtn.onclick=e=>{e.stopPropagation();openMenu(aBtn,[['asm_led','LED Blink — P0.10'],['asm_switch','Switch P0.14 → LED P0.10'],['asm_uart0','UART0 — TX/RX Echo'],['asm_uart1','UART1 — TX/RX Echo'],['asm_uart0_irq','UART0 — RX Interrupt Echo'],['asm_uart1_irq','UART1 — RX Interrupt Echo']])};
  menu.onclick=e=>e.stopPropagation();document.addEventListener('click',closeMenu);window.addEventListener('resize',closeMenu);document.querySelector('.topbar.appToolbar')?.addEventListener('scroll',closeMenu);
}

/* Safety wrapper: Build HEX always synchronizes the active example window first. */
window.addEventListener('load',()=>setTimeout(()=>{
  installExamplesToolbar();
  const oldCompile=window.compileLpc2129Hex||window.unifiedCompile;
  if(oldCompile&&!window.__phase80dCompileWrapped){
    window.__phase80dCompileWrapped=true;
    const wrapped=async function(){if(activeExampleKey)syncActiveSource(activeExampleKey);return oldCompile()};
    window.compileLpc2129Hex=wrapped;window.unifiedCompile=wrapped;
  }
  safeLog('Phase 8.1B ready: deterministic fixed-step ARM7 timing + latched GPIO input + 60 FPS differential output refresh.');
},1550));

})();

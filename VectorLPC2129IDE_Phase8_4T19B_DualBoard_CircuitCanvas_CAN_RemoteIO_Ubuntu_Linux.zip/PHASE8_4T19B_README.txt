Phase 8.4T19B — Dual-board Circuit Canvas CAN Remote-I/O

Expected classroom workflow now implemented:
1. Open Communication > CAN > Multi-Node ARM7/LPC2129 CANLab.
2. Circuit Canvas shows two LPC2129 development boards.
3. Node A and Node B each have a separate ARM7/LPC2129 worker engine.
4. Each node is connected to its own MCP2551 visual transceiver.
5. The two MCP2551s share CANH/CANL with 120-ohm termination.
6. Node A onboard switch is P1.30 active-low.
7. Node A firmware sends CAN1 ID 0x101, DLC=1, DATA=01 when pressed and DATA=00 when released.
8. Node B firmware receives the CAN frame and drives onboard LED P1.31 active-low.
9. Node B LED visual is derived from Node B GPIO state, not directly from the UI event.
10. CAN bus lines pulse during traffic and CAN Bus Monitor logs direction, ID, DLC, data and ACK.

Debug windows:
- Node A CAN1 SFR
- Node B CAN1 SFR
- Node A CPU/GPIO
- Node B CPU/GPIO
CAN1 SFR includes RX registers and all three transmit-buffer TFI/TID/TDA/TDB sets.

MCP2551 visuals use 5V supply labeling and CAN1 TD1 is shown as dedicated.

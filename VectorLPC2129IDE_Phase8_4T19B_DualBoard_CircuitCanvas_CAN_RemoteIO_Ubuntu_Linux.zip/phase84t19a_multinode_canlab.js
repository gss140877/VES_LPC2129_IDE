(function(){
'use strict';
const node={A:{worker:null,hex:'',state:null,running:false},B:{worker:null,hex:'',state:null,running:false}};
let pending=[],arbTimer=null,seq=0,events=[],trafficPulse=0;

const sourceA=`/* T19B Node A: onboard switch P1.30 -> CAN1 ID 0x101 */
#define IO1PIN  (*(volatile unsigned long*)0xE0028010)
#define PINSEL1 (*(volatile unsigned long*)0xE002C004)
#define C1MOD   (*(volatile unsigned long*)0xE0044000)
#define C1CMR   (*(volatile unsigned long*)0xE0044004)
#define C1BTR   (*(volatile unsigned long*)0xE0044014)
#define C1SR    (*(volatile unsigned long*)0xE004401C)
#define C1TFI1  (*(volatile unsigned long*)0xE0044030)
#define C1TID1  (*(volatile unsigned long*)0xE0044034)
#define C1TDA1  (*(volatile unsigned long*)0xE0044038)
#define C1TDB1  (*(volatile unsigned long*)0xE004403C)
#define AFMR    (*(volatile unsigned long*)0xE003C000)
#define SW      (1UL<<30)
static void send_state(unsigned char v){
 while((C1SR&4UL)==0){}
 C1TFI1=(1UL<<16); C1TID1=0x101; C1TDA1=v; C1TDB1=0; C1CMR=0x21;
}
int main(void){
 unsigned long last=2,now;
 PINSEL1=(PINSEL1&~(3UL<<18))|(1UL<<18);
 C1MOD=1; C1BTR=0x001C001D; AFMR=2; C1MOD=0;
 while(1){ now=(IO1PIN&SW)?0:1; if(now!=last){last=now;send_state((unsigned char)now);} }
}`;

const sourceB=`/* T19B Node B: CAN1 ID 0x101 -> onboard active-low LED P1.31 */
#define IO1SET  (*(volatile unsigned long*)0xE0028014)
#define IO1DIR  (*(volatile unsigned long*)0xE0028018)
#define IO1CLR  (*(volatile unsigned long*)0xE002801C)
#define PINSEL1 (*(volatile unsigned long*)0xE002C004)
#define C1MOD   (*(volatile unsigned long*)0xE0044000)
#define C1CMR   (*(volatile unsigned long*)0xE0044004)
#define C1GSR   (*(volatile unsigned long*)0xE0044008)
#define C1BTR   (*(volatile unsigned long*)0xE0044014)
#define C1RID   (*(volatile unsigned long*)0xE0044024)
#define C1RDA   (*(volatile unsigned long*)0xE0044028)
#define AFMR    (*(volatile unsigned long*)0xE003C000)
#define LED     (1UL<<31)
int main(void){
 unsigned long d;
 IO1DIR|=LED; IO1SET=LED;
 PINSEL1=(PINSEL1&~(3UL<<18))|(1UL<<18);
 C1MOD=1; C1BTR=0x001C001D; AFMR=2; C1MOD=0;
 while(1){
  if(C1GSR&1UL){
   d=C1RDA;
   if((C1RID&0x7FFUL)==0x101){if(d&1UL)IO1CLR=LED;else IO1SET=LED;}
   C1CMR=0x04;
  }
 }
}`;

function log(s,kind='info'){events.push({n:++seq,t:new Date().toLocaleTimeString(),s,kind});if(events.length>250)events.shift();renderMonitor();}
async function compileOne(k){
 const ta=document.getElementById('t19src'+k),st=document.getElementById('t19status'+k);st.textContent='Compiling...';
 try{
  const r=await fetch('/api/build-hex',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:ta.value,sourceType:'c'})});
  const d=await r.json();
  if(!d.ok){st.textContent='Compile failed';log('Node '+k+' compile failed','err');return false;}
  node[k].hex=d.hex||'';st.textContent='Compiled';log('Node '+k+' compiled');return true;
 }catch(e){st.textContent='Backend error';log('Node '+k+' compile error: '+e.message,'err');return false;}
}
async function compileNodes(){const a=await compileOne('A'),b=await compileOne('B');return a&&b;}
function stopNode(k){const n=node[k];if(n.worker){try{n.worker.postMessage({type:'stop'});n.worker.terminate();}catch(e){}n.worker=null;}n.running=false;}
function startNode(k){
 stopNode(k);const n=node[k];if(!n.hex)return false;
 const w=new Worker('phase82b_arm7_worker.js');n.worker=w;w.onmessage=e=>handle(k,e.data||{});
 w.postMessage({type:'start',hex:n.hex,clock:{cclkHz:60000000,pclkHz:15000000}});
 w.postMessage({type:'can-external-config',enabled:true,nodeId:k});n.running=true;return true;
}
function runNodes(){if(!node.A.hex||!node.B.hex){log('Compile Nodes first.','warn');return;}pending=[];startNode('A');startNode('B');setTimeout(()=>setSwitch(false),150);log('Node A and Node B ARM7/LPC2129 engines running.');}
function stopNodes(){stopNode('A');stopNode('B');log('Both nodes stopped.');}
function setSwitch(pressed){
 const w=node.A.worker;if(w)w.postMessage({type:'gpio-input',port:1,pin:30,level:!pressed});
 const b=document.getElementById('nodeASwitch');if(b)b.classList.toggle('pressed',pressed);
 const t=document.getElementById('nodeASwText');if(t)t.textContent=pressed?'PRESSED':'RELEASED';
}
function handle(k,d){
 if(d.type==='snapshot'){node[k].state=d.state||null;renderNodes();return;}
 if(d.type==='started'){log('Node '+k+' ARM7/LPC2129 started.');return;}
 if(d.type==='can-external-tx'){pending.push({k,d});if(!arbTimer)arbTimer=setTimeout(resolveBus,2);return;}
 if(d.type==='error')log('Node '+k+' error: '+d.text,'err');
}
function bits(v,n){const a=[];for(let i=n-1;i>=0;i--)a.push((v>>>i)&1);return a;}
function arbBits(f){return f.extended?[0,...bits((f.id>>>18)&0x7ff,11),1,1,...bits(f.id&0x3ffff,18),f.rtr?1:0,0,0]:[0,...bits(f.id&0x7ff,11),f.rtr?1:0,0,0];}
function compare(x,y){const a=arbBits(x),b=arbBits(y),n=Math.min(a.length,b.length);for(let i=0;i<n;i++)if(a[i]!==b[i])return {winner:a[i]===0?0:1,bit:i};return {winner:0,bit:-1};}
function resolveBus(){
 arbTimer=null;if(!pending.length)return;const q=pending.splice(0);
 if(q.length===1){deliver(q[0]);return;}
 const x=q[0],y=q[1],r=compare(x.d.frame,y.d.frame),win=r.winner===0?x:y,lose=r.winner===0?y:x;
 log(`ARBITRATION: Node ${win.k} wins; Node ${lose.k} loses at bit ${r.bit}.`,'arb');
 const lw=node[lose.k].worker;if(lw)lw.postMessage({type:'can-external-arbitration-lost',controller:lose.d.controller,buf:lose.d.frame.buf,bit:r.bit});
 deliver(win);
}
function deliver(x){
 const peers=['A','B'].filter(k=>k!==x.k&&node[k].worker&&node[k].running),ack=peers.length>0;
 const w=node[x.k].worker;if(w)w.postMessage({type:'can-external-result',controller:x.d.controller,buf:x.d.frame.buf,ack});
 for(const k of peers)node[k].worker.postMessage({type:'can-external-rx',controller:1,frame:x.d.frame});
 const f=x.d.frame,data=(f.data||[]).slice(0,f.dlc||0).map(v=>Number(v).toString(16).toUpperCase().padStart(2,'0')).join(' ');
 log(`Node ${x.k} -> ${peers.join(',')||'-'} | ID 0x${f.id.toString(16).toUpperCase()} | DLC ${f.dlc} | DATA ${data||'--'} | ${ack?'ACK':'NO ACK'}`,'frame');
 pulseBus(x.k);
}
function pulseBus(k){
 trafficPulse++;const id=trafficPulse;document.querySelectorAll('.t19canH,.t19canL').forEach(e=>e.classList.add('active'));
 const t=document.getElementById('t19traffic');if(t){t.textContent='CAN TRAFFIC: NODE '+k;t.classList.add('active');}
 setTimeout(()=>{if(id!==trafficPulse)return;document.querySelectorAll('.t19canH,.t19canL').forEach(e=>e.classList.remove('active'));if(t){t.textContent='CAN BUS';t.classList.remove('active');}},220);
}
function renderNodes(){
 for(const k of ['A','B']){
  const s=node[k].state||{},c=s.can1||{},g=s.gpio||{},e=document.getElementById('t19state'+k);
  if(e)e.innerHTML=`ARM steps ${s.steps||0}<br>CAN1 ${(c.MOD&1)?'RESET':'NORMAL'} • TX ${c.txCount||0} • RX ${c.rxCount||0}<br>TEC ${c.txErr||0} • REC ${c.rxErr||0}`;
  if(k==='B'){
   const ledOn=!!((g.IO1DIR>>>31)&1)&&!((g.IO1PIN>>>31)&1);
   const led=document.getElementById('nodeBLed');if(led)led.classList.toggle('on',ledOn);
   const lt=document.getElementById('nodeBLedText');if(lt)lt.textContent=ledOn?'LED ON':'LED OFF';
  }
 }
 renderDebug();
}
function regRow(n,v){return `<div><b>${n}</b><span>0x${(Number(v||0)>>>0).toString(16).toUpperCase().padStart(8,'0')}</span></div>`;}
function canRegs(k){
 const c=((node[k].state||{}).can1)||{},tx=c.tx||[];
 let h=regRow('C1MOD',c.MOD)+regRow('C1GSR',c.GSR)+regRow('C1ICR',c.ICR)+regRow('C1IER',c.IER)+regRow('C1BTR',c.BTR)+regRow('C1EWL',c.EWL)+regRow('C1SR',c.SR)+regRow('C1RFS',c.RFS)+regRow('C1RID',c.RID)+regRow('C1RDA',c.RDA)+regRow('C1RDB',c.RDB);
 tx.forEach((x,i)=>{const n=i+1;h+=regRow('C1TFI'+n,x.TFI)+regRow('C1TID'+n,x.TID)+regRow('C1TDA'+n,x.TDA)+regRow('C1TDB'+n,x.TDB);});
 return h;
}
function showDebug(k,type){
 let p=document.getElementById('t19dbg'+k+type.replace(/\W/g,''));
 if(!p){
  p=document.createElement('div');p.id='t19dbg'+k+type.replace(/\W/g,'');p.className='t19dbg';p.dataset.node=k;p.dataset.type=type;
  p.innerHTML=`<div class="t19dbghead"><b>Node ${k} — ${type}</b><button>×</button></div><div class="t19dbgbody"></div>`;
  document.body.appendChild(p);p.querySelector('button').onclick=()=>p.style.display='none';drag(p,p.querySelector('.t19dbghead'));
 }
 p.style.display='block';renderDebug();
}
function renderDebug(){
 document.querySelectorAll('.t19dbg').forEach(p=>{
  if(p.style.display==='none')return;
  const k=p.dataset.node,type=p.dataset.type,s=node[k].state||{},b=p.querySelector('.t19dbgbody');
  if(type==='CAN1 SFR')b.innerHTML='<div class="regs">'+canRegs(k)+'</div>';
  else if(type==='CPU/GPIO')b.innerHTML='<div class="regs">'+regRow('PC',(s.r||[])[15])+regRow('SP',(s.r||[])[13])+regRow('IO0PIN',(s.gpio||{}).IO0PIN)+regRow('IO0DIR',(s.gpio||{}).IO0DIR)+regRow('IO1PIN',(s.gpio||{}).IO1PIN)+regRow('IO1DIR',(s.gpio||{}).IO1DIR)+'</div>';
 });
}
function clearMonitor(){events=[];seq=0;renderMonitor();}
function renderMonitor(){
 const e=document.getElementById('t19events');if(!e)return;
 e.innerHTML=events.slice().reverse().map(x=>`<div class="${x.kind}"><span>${x.t} #${x.n}</span>${x.s}</div>`).join('');
}
function circuitHtml(){return `<div class="t19circuit">
 <div class="t19node nodeA"><div class="nodeTitle">NODE A • ARM7TDMI-S + LPC2129</div><img src="assets/vector_lpc2129_board.png"><button id="nodeASwitch" class="boardSwitch" title="Onboard switch P1.30"><i></i></button><label id="nodeASwText" class="swText">RELEASED</label><div id="t19stateA" class="nodeState"></div><div class="nodePorts">CAN1 • RD1=P0.25 • TD1=dedicated</div></div>
 <div class="mcp mcpA"><b>VECTOR INDIA</b><strong>MCP2551</strong><small>NODE A TRANSCEIVER</small><div>TXD / RXD</div><div>CANH / CANL</div><em>VCC 5V</em></div>
 <div class="bus"><div class="t19canH"></div><div class="t19canL"></div><span class="h">CANH</span><span class="l">CANL</span><b id="t19traffic">CAN BUS</b><i class="term left">120Ω</i><i class="term right">120Ω</i></div>
 <div class="mcp mcpB"><b>VECTOR INDIA</b><strong>MCP2551</strong><small>NODE B TRANSCEIVER</small><div>TXD / RXD</div><div>CANH / CANL</div><em>VCC 5V</em></div>
 <div class="t19node nodeB"><div class="nodeTitle">NODE B • ARM7TDMI-S + LPC2129</div><img src="assets/vector_lpc2129_board.png"><i id="nodeBLed" class="boardLed"></i><label id="nodeBLedText" class="ledText">LED OFF</label><div id="t19stateB" class="nodeState"></div><div class="nodePorts">CAN1 • RD1=P0.25 • TD1=dedicated</div></div>
 <svg class="t19localwires" viewBox="0 0 1200 330" preserveAspectRatio="none"><path d="M325 138 C360 138 370 138 405 138"/><path d="M325 160 C360 160 370 160 405 160"/><path d="M795 138 C830 138 840 138 875 138"/><path d="M795 160 C830 160 840 160 875 160"/></svg>
 </div>`;}
function open(){
 let p=document.getElementById('t19canlab');
 if(!p){
  p=document.createElement('div');p.id='t19canlab';p.className='t19canlab';
  p.innerHTML=`<div class="t19head"><b>LPC2129 Multi-Node CANLab — Circuit Canvas</b><button data-close>×</button></div>
  <div class="t19toolbar"><button data-c>Compile Nodes</button><button data-r>Run Nodes</button><button data-s>Stop Nodes</button><button data-da>Node A CAN1 SFR</button><button data-db>Node B CAN1 SFR</button><button data-ca>Node A CPU/GPIO</button><button data-cb>Node B CPU/GPIO</button><button data-cl>Clear Monitor</button></div>
  ${circuitHtml()}
  <div class="t19lower"><section><h3>Node A Source — Switch → CAN</h3><textarea id="t19srcA"></textarea><span id="t19statusA">Not compiled</span></section><section><h3>Node B Source — CAN → LED</h3><textarea id="t19srcB"></textarea><span id="t19statusB">Not compiled</span></section><section><h3>CAN Bus Monitor</h3><div id="t19events"></div></section></div>`;
  document.body.appendChild(p);p.querySelector('#t19srcA').value=sourceA;p.querySelector('#t19srcB').value=sourceB;
  p.querySelector('[data-close]').onclick=()=>p.style.display='none';p.querySelector('[data-c]').onclick=compileNodes;p.querySelector('[data-r]').onclick=runNodes;p.querySelector('[data-s]').onclick=stopNodes;
  p.querySelector('[data-da]').onclick=()=>showDebug('A','CAN1 SFR');p.querySelector('[data-db]').onclick=()=>showDebug('B','CAN1 SFR');p.querySelector('[data-ca]').onclick=()=>showDebug('A','CPU/GPIO');p.querySelector('[data-cb]').onclick=()=>showDebug('B','CPU/GPIO');p.querySelector('[data-cl]').onclick=clearMonitor;
  const sw=p.querySelector('#nodeASwitch');sw.addEventListener('pointerdown',e=>{e.preventDefault();setSwitch(true);});sw.addEventListener('pointerup',e=>{e.preventDefault();setSwitch(false);});sw.addEventListener('pointercancel',()=>setSwitch(false));sw.addEventListener('lostpointercapture',()=>setSwitch(false));
  drag(p,p.querySelector('.t19head'));
 }
 p.style.display='block';renderNodes();renderMonitor();
}
function drag(p,h){let on=false,ox=0,oy=0;h.onmousedown=e=>{if(e.target.tagName==='BUTTON')return;on=true;ox=e.clientX-p.offsetLeft;oy=e.clientY-p.offsetTop;e.preventDefault();};addEventListener('mousemove',e=>{if(on){p.style.left=Math.max(0,e.clientX-ox)+'px';p.style.top=Math.max(50,e.clientY-oy)+'px';}});addEventListener('mouseup',()=>on=false);}
window.phase84t19aOpenMultiNodeCANLab=open;
})();
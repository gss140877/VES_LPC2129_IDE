/* VECTOR LPC2129 IDE — Phase 8.2B
   Dedicated ARM7TDMI-S runtime worker.
   The ARM core below is extracted from the canonical simulator.js engine
   so compiled HEX still executes through the same CPU decoder/executor.
*/
'use strict';
const window=self;
const IO0PIN=0xE0028000>>>0, IO0SET=0xE0028004>>>0, IO0DIR=0xE0028008>>>0, IO0CLR=0xE002800C>>>0;
const IO1PIN=0xE0028010>>>0, IO1SET=0xE0028014>>>0, IO1DIR=0xE0028018>>>0, IO1CLR=0xE002801C>>>0;
const RAM_BASE=0x40000000>>>0, RAM_SIZE=16*1024, FLASH_SIZE=256*1024;
const ARM_COND=['EQ','NE','CS','CC','MI','PL','VS','VC','HI','LS','GE','LT','GT','LE','AL','NV'];
const DP=['AND','EOR','SUB','RSB','ADD','ADC','SBC','RSC','TST','TEQ','CMP','CMN','ORR','MOV','BIC','MVN'];
function u32(x){return x>>>0}
function s32(x){return x|0}
function sx(v,b){const s=32-b;return(v<<s)>>s}
function h8(x){return '0x'+u32(x).toString(16).toUpperCase().padStart(8,'0')}
let quietTrace=true;
function safeLog(s){
  // Worker logs only significant errors; instruction/GPIO hot-path logging stays off.
  if(!quietTrace)postMessage({type:'log',text:String(s)});
}
let gpioEdgeSeq=0;
function syncGpioFromEmu(emu){
  // Phase 8.4F: physical GPIO transitions are real-time events, not debug snapshots.
  // This keeps canvas/on-board/off-board loads synchronized with the canonical pin state
  // without waiting for the ~30 Hz diagnostic snapshot path.
  if(!emu||!emu.gpio)return;
  postMessage({
    type:'gpio-edge',
    seq:++gpioEdgeSeq,
    cycles:(emu.profiler&&emu.profiler.totalCycles)||0,
    gpio:{
      IO0PIN:emu.gpio.IO0PIN>>>0, IO0DIR:emu.gpio.IO0DIR>>>0,
      IO0SET:emu.gpio.IO0SET>>>0, IO0CLR:emu.gpio.IO0CLR>>>0,
      IO1PIN:emu.gpio.IO1PIN>>>0, IO1DIR:emu.gpio.IO1DIR>>>0,
      IO1SET:emu.gpio.IO1SET>>>0, IO1CLR:emu.gpio.IO1CLR>>>0
    }
  });
}
window.phase5Trace=[];
  class LPC2129Arm7Emu{
    constructor(){ this.reset(); }
    reset(){
      this.r=new Uint32Array(16); this.cpsr={N:0,Z:0,C:0,V:0,I:1,F:1,T:0,mode:0x13}; this.spsr_irq=0; this.irqSavedR13=0; this.irqSavedR14=0;
      this.flash=new Uint8Array(FLASH_SIZE); this.ram=new Uint8Array(RAM_SIZE); this.flash.fill(0xFF); this.ram.fill(0);
      this.gpio={IO0PIN:0,IO0SET:0,IO0DIR:0,IO0CLR:0,IO1PIN:0,IO1SET:0,IO1DIR:0,IO1CLR:0};
      this.running=false; this.steps=0; this.loaded=false; this.disasm=''; this.lastError=''; this.decodeStats={ARM:{},THUMB:{}}; this.unsupportedCount=0; this.lastUnsupported=null;
      this.profiler={totalCycles:0,totalInstructions:0,armInstructions:0,thumbInstructions:0,lastMode:'ARM',lastPC:0,lastOpcode:'-',lastFamily:'-',families:{}};
      this.r[15]=0; this.r[13]=RAM_BASE+RAM_SIZE;
    }
    loadIntelHex(hex){
      this.reset(); let ext=0, bytes=0; const lines=String(hex||'').trim().split(/\r?\n/).filter(Boolean);
      for(const [idx,line0] of lines.entries()){
        const line=line0.trim(); if(!line.startsWith(':')) throw new Error('HEX line '+(idx+1)+' missing colon');
        const n=parseInt(line.substr(1,2),16), off=parseInt(line.substr(3,4),16), type=parseInt(line.substr(7,2),16);
        let sum=n+((off>>8)&255)+(off&255)+type; const data=[];
        for(let i=0;i<n;i++){ const b=parseInt(line.substr(9+i*2,2),16); data.push(b); sum+=b; }
        const chk=parseInt(line.substr(9+n*2,2),16); if(((sum+chk)&255)!==0) throw new Error('HEX checksum error at line '+(idx+1));
        if(type===0){ const a=(ext+off)>>>0; for(let i=0;i<data.length;i++){ this.writeByteRaw(a+i,data[i]); bytes++; } }
        else if(type===1) break; else if(type===4) ext=((data[0]<<24)|(data[1]<<16))>>>0; else if(type===2) ext=(((data[0]<<8)|data[1])<<4)>>>0;
        else if(type===5) this.r[15]=((data[0]<<24)|(data[1]<<16)|(data[2]<<8)|data[3])>>>0;
      }
      this.loaded=true; return bytes;
    }
    estimateCycles(mode,name){
      if(name==='MUL'||name==='MLA')return 3;
      if(['UMULL','UMLAL','SMULL','SMLAL'].includes(name))return 5;
      if(['LDR','STR','LDRB','STRB','SDT_LOAD','SDT_STORE','LDRH/S','STRH'].includes(name))return 3;
      if(['LDM','STM','BDT_LOAD','BDT_STORE','LDMIA','STMIA','PUSH','POP'].includes(name))return 4;
      if(['B','BL','BX','BLX_REG','B_COND','BL_PREFIX','BL_SUFFIX'].includes(name))return 3;
      if(String(name).includes('UNSUPPORTED'))return 1;
      return 1;
    }
    stat(mode,name){
      const m=this.decodeStats[mode]; m[name]=(m[name]||0)+1;
      const cycles=this.estimateCycles(mode,name);
      this.profiler.totalInstructions++;
      if(mode==='ARM')this.profiler.armInstructions++; else this.profiler.thumbInstructions++;
      this.profiler.totalCycles+=cycles;
      const key=mode+' '+name;
      const f=this.profiler.families[key]||(this.profiler.families[key]={decode:0,execute:0,cycles:0,lastPC:0,lastOpcode:'-'});
      f.decode++; f.execute++; f.cycles+=cycles; f.lastPC=this.currentPC>>>0; f.lastOpcode=this.currentOpcodeText||'-';
      this.profiler.lastMode=mode; this.profiler.lastPC=this.currentPC>>>0; this.profiler.lastOpcode=this.currentOpcodeText||'-'; this.profiler.lastFamily=name;
      try{
        window.phase5Trace=window.phase5Trace||[];
        if(window.phase5Trace.length<300 || (this.steps%1000)===0){
          window.phase5Trace.push({step:this.steps,mode,pc:this.currentPC>>>0,opcode:this.currentOpcodeText||'-',family:name,cycles:this.profiler.totalCycles});
          if(window.phase5Trace.length>300) window.phase5Trace.shift();
        }
      }catch(e){}
    }
    reportUnsupported(mode,addr,opcode,family,detail){
      this.unsupportedCount=(this.unsupportedCount||0)+1;
      const opText=mode==='THUMB'?('0x'+(opcode&0xFFFF).toString(16).toUpperCase().padStart(4,'0')):h8(opcode);
      this.lastUnsupported={mode,pc:u32(addr),opcode:opText,family:family||'UNKNOWN',detail:detail||'No executor implemented'};
      const msg='Unsupported instruction detected: Mode='+mode+' PC='+h8(addr)+' Opcode='+opText+' Family='+(family||'UNKNOWN')+' Detail='+(detail||'No executor implemented');
      this.disasm=msg;
      safeLog(msg);
      throw new Error(msg);
    }
    writeByteRaw(a,b){ a=u32(a); if(a<FLASH_SIZE)this.flash[a]=b&255; else if(a>=RAM_BASE&&a<RAM_BASE+RAM_SIZE)this.ram[a-RAM_BASE]=b&255; }
    read8(a){ a=u32(a); try{if(typeof window.phase82PeripheralRead==='function'&&window.phase82IsPeripheralAddress&&window.phase82IsPeripheralAddress(a))return window.phase82PeripheralRead(this,a,8)&0xFF;}catch(e){} if(a<FLASH_SIZE)return this.flash[a]; if(a>=RAM_BASE&&a<RAM_BASE+RAM_SIZE)return this.ram[a-RAM_BASE]; return 0; }
    write8(a,b){ a=u32(a); try{if(typeof window.phase82PeripheralWrite==='function'&&window.phase82IsPeripheralAddress&&window.phase82IsPeripheralAddress(a)){window.phase82PeripheralWrite(this,a,b&0xFF,8);return;}}catch(e){} if(a>=RAM_BASE&&a<RAM_BASE+RAM_SIZE)this.ram[a-RAM_BASE]=b&255; }
    read16(a){ a=u32(a&~1); try{if(typeof window.phase82PeripheralRead==='function'&&window.phase82IsPeripheralAddress&&window.phase82IsPeripheralAddress(a))return window.phase82PeripheralRead(this,a,16)&0xFFFF;}catch(e){} return this.read8(a)|(this.read8(a+1)<<8); }
    write16(a,v){ a=u32(a&~1); try{if(typeof window.phase82PeripheralWrite==='function'&&window.phase82IsPeripheralAddress&&window.phase82IsPeripheralAddress(a)){window.phase82PeripheralWrite(this,a,v&0xFFFF,16);return;}}catch(e){} this.write8(a,v); this.write8(a+1,v>>>8); }
    read32(a){ a=u32(a&~3); if(this.isGpio(a))return this.gpioRead(a); try{if(typeof window.phase82PeripheralRead==='function'&&window.phase82IsPeripheralAddress&&window.phase82IsPeripheralAddress(a))return u32(window.phase82PeripheralRead(this,a,32));}catch(e){} return u32(this.read8(a)|(this.read8(a+1)<<8)|(this.read8(a+2)<<16)|(this.read8(a+3)<<24)); }
    write32(a,v){ a=u32(a&~3); v=u32(v); if(this.isGpio(a))return this.gpioWrite(a,v); try{if(typeof window.phase82PeripheralWrite==='function'&&window.phase82IsPeripheralAddress&&window.phase82IsPeripheralAddress(a)){window.phase82PeripheralWrite(this,a,v,32);return;}}catch(e){} if(a>=RAM_BASE&&a<RAM_BASE+RAM_SIZE-3){ this.write8(a,v); this.write8(a+1,v>>>8); this.write8(a+2,v>>>16); this.write8(a+3,v>>>24); } }
    isGpio(a){ a=u32(a); return (a>=IO0PIN&&a<=IO0CLR&&((a-IO0PIN)&3)===0)||(a>=IO1PIN&&a<=IO1CLR&&((a-IO1PIN)&3)===0); }
    gpioRead(a){
      if((a>>>0)===IO0PIN || (a>>>0)===IO1PIN){
        try{ if(typeof window.phase80SampleExternalInputs==='function') window.phase80SampleExternalInputs(this); }catch(e){}
      }
      switch(a>>>0){case IO0PIN:return this.gpio.IO0PIN>>>0;case IO0SET:return this.gpio.IO0SET>>>0;case IO0DIR:return this.gpio.IO0DIR>>>0;case IO0CLR:return this.gpio.IO0CLR>>>0;case IO1PIN:return this.gpio.IO1PIN>>>0;case IO1SET:return this.gpio.IO1SET>>>0;case IO1DIR:return this.gpio.IO1DIR>>>0;case IO1CLR:return this.gpio.IO1CLR>>>0;} return 0;
    }
    gpioName(a){ switch(a>>>0){case IO0PIN:return'IO0PIN';case IO0SET:return'IO0SET';case IO0DIR:return'IO0DIR';case IO0CLR:return'IO0CLR';case IO1PIN:return'IO1PIN';case IO1SET:return'IO1SET';case IO1DIR:return'IO1DIR';case IO1CLR:return'IO1CLR';} return h8(a); }
    gpioWrite(a,v){
      a=u32(a); v=u32(v); const b0=this.gpio.IO0PIN>>>0,b1=this.gpio.IO1PIN>>>0;
      switch(a>>>0){
        case IO0DIR:this.gpio.IO0DIR=v;break; case IO0SET:this.gpio.IO0SET=v;this.gpio.IO0PIN=u32(this.gpio.IO0PIN|(v&this.gpio.IO0DIR));break; case IO0CLR:this.gpio.IO0CLR=v;this.gpio.IO0PIN=u32(this.gpio.IO0PIN&~(v&this.gpio.IO0DIR));break; case IO0PIN:this.gpio.IO0PIN=u32((this.gpio.IO0PIN&~this.gpio.IO0DIR)|(v&this.gpio.IO0DIR));break;
        case IO1DIR:this.gpio.IO1DIR=v;break; case IO1SET:this.gpio.IO1SET=v;this.gpio.IO1PIN=u32(this.gpio.IO1PIN|(v&this.gpio.IO1DIR));break; case IO1CLR:this.gpio.IO1CLR=v;this.gpio.IO1PIN=u32(this.gpio.IO1PIN&~(v&this.gpio.IO1DIR));break; case IO1PIN:this.gpio.IO1PIN=u32((this.gpio.IO1PIN&~this.gpio.IO1DIR)|(v&this.gpio.IO1DIR));break;
      }
      try{if(this.spiEngines)this.spiEngines[0].syncCS()}catch(e){}
      this.lastGpioWrite=this.gpioName(a)+' <= '+h8(v)+'  P0='+h8(this.gpio.IO0PIN)+' P1='+h8(this.gpio.IO1PIN); this.gpioWriteCount=(this.gpioWriteCount||0)+1;
      if(b0!==this.gpio.IO0PIN||b1!==this.gpio.IO1PIN){
        this.gpioPinChangeCount=(this.gpioPinChangeCount||0)+1;
        this.lastGpioTransitionCycles=this.profiler.totalCycles||0;
        this.lastGpioTransitionPort0=this.gpio.IO0PIN>>>0;
        this.lastGpioTransitionPort1=this.gpio.IO1PIN>>>0;
      }
      if((b0!==this.gpio.IO0PIN||b1!==this.gpio.IO1PIN||/DIR$/.test(this.gpioName(a)))&&(this.gpioWriteCount<=80||(this.gpioWriteCount%1000)===0)) safeLog('GPIO WRITE: '+this.lastGpioWrite);
      const physicalChanged=(b0!==(this.gpio.IO0PIN>>>0))||(b1!==(this.gpio.IO1PIN>>>0));
      const dirChanged=(a===IO0DIR)||(a===IO1DIR);
      if(physicalChanged||dirChanged) syncGpioFromEmu(this);
    }
    condOK(c){ const {N,Z,C,V}=this.cpsr; return [Z===1,Z===0,C===1,C===0,N===1,N===0,V===1,V===0,C===1&&Z===0,C===0||Z===1,N===V,N!==V,Z===0&&N===V,Z===1||N!==V,true,false][c]; }
    getReg(i,addr){ return i===15?u32(addr+(this.cpsr.T?4:8)):this.r[i]>>>0; }
    setNZ(v){ v=u32(v); this.cpsr.N=(v>>>31)&1; this.cpsr.Z=v===0?1:0; }
    setAddFlags(a,b,r){ this.cpsr.C=((a>>>0)+(b>>>0))>0xFFFFFFFF?1:0; this.cpsr.V=(((~(a^b))&(a^r))>>>31)&1; }
    setSubFlags(a,b,r){ this.cpsr.C=(a>>>0)>=(b>>>0)?1:0; this.cpsr.V=(((a^b)&(a^r))>>>31)&1; }
    ror(v,n){ n&=31; return n?u32((v>>>n)|(v<<(32-n))):u32(v); }
    shifterOperand(ins,addr){
      if((ins>>>25)&1){ const imm=ins&255, rot=((ins>>>8)&15)*2; const val=this.ror(imm,rot); return {val,carry:rot?((val>>>31)&1):this.cpsr.C}; }
      const rm=ins&15; let val=this.getReg(rm,addr); const type=(ins>>>5)&3; let amount=((ins>>>4)&1)?(this.r[(ins>>>8)&15]&255):((ins>>>7)&31); let carry=this.cpsr.C;
      if(amount===0){ if(type===3){carry=val&1; val=u32((carry?0x80000000:0)|(val>>>1));} return {val:u32(val),carry}; }
      if(type===0){ carry=amount>32?0:((val>>>(32-amount))&1); val=amount>=32?0:u32(val<<amount); }
      else if(type===1){ carry=amount>32?0:((val>>>(amount-1))&1); val=amount>=32?0:u32(val>>>amount); }
      else if(type===2){ carry=amount>32?(val>>>31):((val>>>(amount-1))&1); val=amount>=32?(val&0x80000000?0xFFFFFFFF:0):u32(s32(val)>>amount); }
      else { amount&=31; carry=(val>>>(amount?amount-1:31))&1; val=this.ror(val,amount); }
      return {val:u32(val),carry};
    }
    cpsrValue(){ return ((this.cpsr.N<<31)|(this.cpsr.Z<<30)|(this.cpsr.C<<29)|(this.cpsr.V<<28)|((this.cpsr.I||0)<<7)|((this.cpsr.F||0)<<6)|(this.cpsr.T<<5)|(this.cpsr.mode&31))>>>0; }
    setCpsrValue(v){ this.cpsr.N=(v>>>31)&1; this.cpsr.Z=(v>>>30)&1; this.cpsr.C=(v>>>29)&1; this.cpsr.V=(v>>>28)&1; this.cpsr.I=(v>>>7)&1; this.cpsr.F=(v>>>6)&1; this.cpsr.T=(v>>>5)&1; this.cpsr.mode=v&31; }
    step(){ return this.cpsr.T?this.stepThumb():this.stepArm(); }
    stepArm(){
      const addr=this.r[15]>>>0, ins=this.read32(addr); this.currentPC=addr; this.currentOpcodeText=h8(ins); this.r[15]=u32(addr+4); this.steps++;
      if(this.steps<=120) safeLog('TRACE '+this.steps+': ARM PC='+h8(addr)+' INS='+h8(ins));
      const cond=ins>>>28; if(!this.condOK(cond)){ this.stat('ARM','COND_SKIP'); this.disasm='ARM '+ARM_COND[cond]+' skipped'; return true; }
      // Branch / BL
      if((ins&0x0E000000)===0x0A000000){ const L=(ins>>>24)&1; const off=sx(ins&0x00FFFFFF,24)<<2; if(L)this.r[14]=u32(addr+4); this.r[15]=u32(addr+8+off); this.stat('ARM',L?'BL':'B'); this.disasm=(L?'BL':'B')+' '+h8(this.r[15]); return true; }
      // BX / BLX register (ARMv4T has BX; BLX is safely decoded)
      if((ins&0x0FFFFFF0)===0x012FFF10 || (ins&0x0FFFFFF0)===0x012FFF30){ const rm=ins&15,t=this.r[rm]>>>0; this.cpsr.T=t&1; this.r[15]=t&~1; this.stat('ARM',(ins&0x20)?'BLX_REG':'BX'); this.disasm='BX/BLX R'+rm; return true; }
      // SWP/SWPB
      if((ins&0x0FB00FF0)===0x01000090){ const B=(ins>>>22)&1,rn=(ins>>>16)&15,rd=(ins>>>12)&15,rm=ins&15,a=this.r[rn]>>>0; const old=B?this.read8(a):this.read32(a); if(B)this.write8(a,this.r[rm]); else this.write32(a,this.r[rm]); this.r[rd]=old>>>0; this.stat('ARM',B?'SWPB':'SWP'); this.disasm=(B?'SWPB':'SWP')+' R'+rd; return true; }
      // Multiply / multiply long
      if((ins&0x0FC000F0)===0x00000090){ const A=(ins>>>21)&1,S=(ins>>>20)&1,rd=(ins>>>16)&15,rn=(ins>>>12)&15,rs=(ins>>>8)&15,rm=ins&15; let res=Math.imul(this.r[rm],this.r[rs])>>>0; if(A)res=u32(res+this.r[rn]); this.r[rd]=res; if(S)this.setNZ(res); this.stat('ARM',A?'MLA':'MUL'); this.disasm=(A?'MLA':'MUL')+' R'+rd; return true; }
      if((ins&0x0F8000F0)===0x00800090){ const U=(ins>>>22)&1,A=(ins>>>21)&1,S=(ins>>>20)&1,rdHi=(ins>>>16)&15,rdLo=(ins>>>12)&15,rs=(ins>>>8)&15,rm=ins&15; let prod;
        if(U) prod=BigInt(this.r[rm]>>>0)*BigInt(this.r[rs]>>>0); else prod=BigInt(s32(this.r[rm]))*BigInt(s32(this.r[rs]));
        if(A) prod += (BigInt(this.r[rdHi]>>>0)<<32n)+BigInt(this.r[rdLo]>>>0);
        this.r[rdLo]=Number(prod&0xFFFFFFFFn)>>>0; this.r[rdHi]=Number((prod>>32n)&0xFFFFFFFFn)>>>0; if(S){this.cpsr.N=(this.r[rdHi]>>>31)&1;this.cpsr.Z=(this.r[rdHi]===0&&this.r[rdLo]===0)?1:0;} this.stat('ARM',(U?'U':'S')+(A?'MLAL':'MULL')); this.disasm='MULL'; return true; }
      // MRS/MSR
      if((ins&0x0FBF0FFF)===0x010F0000){ const rd=(ins>>>12)&15; this.r[rd]=this.cpsrValue(); this.stat('ARM','MRS'); this.disasm='MRS R'+rd; return true; }
      if((ins&0x0DB0F000)===0x0120F000 || (ins&0x0DB0F000)===0x0320F000){ const rm=ins&15; const val=((ins>>>25)&1)?this.shifterOperand(ins,addr).val:this.r[rm]; this.setCpsrValue(val); this.stat('ARM','MSR'); this.disasm='MSR CPSR'; return true; }
      // Halfword/signed transfer LDRH/STRH/LDRSB/LDRSH
      if((ins&0x0E000090)===0x00000090 && (ins&0x60)!==0){ const P=(ins>>>24)&1,U=(ins>>>23)&1,I=(ins>>>22)&1,W=(ins>>>21)&1,L=(ins>>>20)&1,rn=(ins>>>16)&15,rd=(ins>>>12)&15; const sh=(ins>>>5)&3; let off=I?(((ins>>>4)&0xF0)|(ins&0xF)):(this.r[ins&15]>>>0); let base=this.getReg(rn,addr), ea=P?(U?u32(base+off):u32(base-off)):base; if(L){ let v; if(sh===1)v=this.read16(ea); else if(sh===2)v=sx(this.read8(ea),8); else v=sx(this.read16(ea),16); this.r[rd]=u32(v); } else { if(sh===1)this.write16(ea,this.r[rd]); else this.write8(ea,this.r[rd]); } if(!P||W)this.r[rn]=U?u32(base+off):u32(base-off); this.stat('ARM',L?'LDRH/S':'STRH'); this.disasm='HWT '+h8(ea); return true; }
      // Data processing
      if((ins&0x0C000000)===0x00000000){ const op=(ins>>>21)&15,S=(ins>>>20)&1,rn=(ins>>>16)&15,rd=(ins>>>12)&15; const op2=this.shifterOperand(ins,addr), a=this.getReg(rn,addr); let r=0,write=true;
        switch(op){ case 0:r=a&op2.val;break;case 1:r=a^op2.val;break;case 2:r=u32(a-op2.val);if(S)this.setSubFlags(a,op2.val,r);break;case 3:r=u32(op2.val-a);if(S)this.setSubFlags(op2.val,a,r);break;case 4:r=u32(a+op2.val);if(S)this.setAddFlags(a,op2.val,r);break;case 5:r=u32(a+op2.val+this.cpsr.C);if(S)this.setAddFlags(a,op2.val+this.cpsr.C,r);break;case 6:r=u32(a-op2.val-(1-this.cpsr.C));if(S)this.setSubFlags(a,op2.val+(1-this.cpsr.C),r);break;case 7:r=u32(op2.val-a-(1-this.cpsr.C));if(S)this.setSubFlags(op2.val,a+(1-this.cpsr.C),r);break;case 8:r=a&op2.val;write=false;break;case 9:r=a^op2.val;write=false;break;case 10:r=u32(a-op2.val);write=false;this.setSubFlags(a,op2.val,r);break;case 11:r=u32(a+op2.val);write=false;this.setAddFlags(a,op2.val,r);break;case 12:r=a|op2.val;break;case 13:r=op2.val;break;case 14:r=a&(~op2.val);break;case 15:r=~op2.val;break; }
        if(write){
          if(rd===15 && S && this.cpsr.mode===0x12 && this.spsr_irq!==undefined){
            this.r[15]=u32(r);
            const saved=this.spsr_irq>>>0;
            this.r[13]=this.irqSavedR13>>>0;
            this.r[14]=this.irqSavedR14>>>0;
            this.setCpsrValue(saved);
          }else this.r[rd]=u32(r);
        } if(S||!write){this.setNZ(r); if([0,1,8,9,12,13,14,15].includes(op))this.cpsr.C=op2.carry;} this.stat('ARM',DP[op]); this.disasm='ARM '+DP[op]+' R'+rd; return true; }
      // Single data transfer
      if((ins&0x0C000000)===0x04000000){ const I=(ins>>>25)&1,P=(ins>>>24)&1,U=(ins>>>23)&1,B=(ins>>>22)&1,W=(ins>>>21)&1,L=(ins>>>20)&1,rn=(ins>>>16)&15,rd=(ins>>>12)&15; const off=I?this.shifterOperand(ins,addr).val:(ins&0xFFF); let base=this.getReg(rn,addr),ea=P?(U?u32(base+off):u32(base-off)):base; if(L)this.r[rd]=B?this.read8(ea):this.read32(ea); else { const v=this.getReg(rd,addr); if(B)this.write8(ea,v); else this.write32(ea,v); } if(!P||W)this.r[rn]=U?u32(base+off):u32(base-off); this.stat('ARM',(L?'LDR':'STR')+(B?'B':'')); this.disasm=(L?'LDR':'STR')+' '+h8(ea); return true; }
      // Block transfer
      if((ins&0x0E000000)===0x08000000){ const P=(ins>>>24)&1,U=(ins>>>23)&1,W=(ins>>>21)&1,L=(ins>>>20)&1,rn=(ins>>>16)&15,list=ins&0xFFFF; let regs=[]; for(let i=0;i<16;i++)if((list>>>i)&1)regs.push(i); let base=this.r[rn]>>>0, a=U?(P?u32(base+4):base):(P?u32(base-4*regs.length):u32(base-4*(regs.length-1))); for(const reg of regs){ if(L)this.r[reg]=this.read32(a); else this.write32(a,this.getReg(reg,addr)); a=u32(a+4); } if(W)this.r[rn]=U?u32(base+4*regs.length):u32(base-4*regs.length); this.stat('ARM',L?'LDM':'STM'); this.disasm=(L?'LDM':'STM')+' R'+rn; return true; }
      if((ins&0x0F000000)===0x0F000000){ this.stat('ARM','SWI'); this.disasm='SWI '+h8(ins&0xFFFFFF); return true; }
      if((ins&0x0E000000)===0x0C000000){ this.stat('ARM','COPROCESSOR_UNSUPPORTED'); return this.reportUnsupported('ARM',addr,ins,'Coprocessor','ARM7TDMI-S has no usable coprocessor model in this simulator'); }
      this.stat('ARM','UNDEFINED_UNSUPPORTED'); return this.reportUnsupported('ARM',addr,ins,'Undefined/Unclassified ARM','Opcode is not yet handled by the ARM decoder/executor');
    }
    stepThumb(){
      const addr=this.r[15]>>>0, ins=this.read16(addr); this.currentPC=addr; this.currentOpcodeText='0x'+(ins&0xFFFF).toString(16).toUpperCase().padStart(4,'0'); this.r[15]=u32(addr+2); this.steps++; if(this.steps<=120)safeLog('TRACE '+this.steps+': THUMB PC='+h8(addr)+' INS=0x'+ins.toString(16).toUpperCase().padStart(4,'0'));
      const rd=ins&7, rs=(ins>>>3)&7, rn=(ins>>>6)&7;
      // Format 1 shift by immediate
      if((ins&0xE000)===0x0000){ const op=(ins>>>11)&3, imm=(ins>>>6)&31; let v=this.r[rs]>>>0,r=v; if(op===0)r=u32(v<<imm); else if(op===1)r=imm?u32(v>>>imm):v; else r=imm?u32(s32(v)>>imm):v; this.r[rd]=r; this.setNZ(r); this.stat('THUMB','SHIFT'); this.disasm='THUMB SHIFT'; return true; }
      // add/sub register/immediate
      if((ins&0xF800)===0x1800){ const I=(ins>>>10)&1,sub=(ins>>>9)&1,op2=I?rn:(this.r[rn]>>>0),a=this.r[rs]>>>0; const r=sub?u32(a-op2):u32(a+op2); this.r[rd]=r; this.setNZ(r); if(sub)this.setSubFlags(a,op2,r); else this.setAddFlags(a,op2,r); this.stat('THUMB',sub?'SUB':'ADD'); return true; }
      // mov/cmp/add/sub immediate
      if((ins&0xE000)===0x2000){ const op=(ins>>>11)&3,d=(ins>>>8)&7,imm=ins&255,a=this.r[d]>>>0; let r=imm; if(op===0){this.r[d]=r;this.setNZ(r);this.stat('THUMB','MOVI');} else if(op===1){r=u32(a-imm);this.setNZ(r);this.setSubFlags(a,imm,r);this.stat('THUMB','CMPI');} else if(op===2){r=u32(a+imm);this.r[d]=r;this.setNZ(r);this.setAddFlags(a,imm,r);this.stat('THUMB','ADDI');} else {r=u32(a-imm);this.r[d]=r;this.setNZ(r);this.setSubFlags(a,imm,r);this.stat('THUMB','SUBI');} return true; }
      // ALU ops
      if((ins&0xFC00)===0x4000){ const op=(ins>>>6)&15; let a=this.r[rd]>>>0,b=this.r[rs]>>>0,r=a; switch(op){case 0:r=a&b;break;case 1:r=a^b;break;case 2:r=u32(a<< (b&255));break;case 3:r=u32(a>>> (b&255));break;case 4:r=u32(s32(a)>> (b&255));break;case 5:r=u32(a+b+this.cpsr.C);break;case 6:r=u32(a-b-(1-this.cpsr.C));break;case 7:r=u32(b-a-(1-this.cpsr.C));break;case 8:r=a&b;this.setNZ(r);this.stat('THUMB','TST');return true;case 9:r=u32(-b);break;case 10:r=u32(a-b);this.setNZ(r);this.setSubFlags(a,b,r);this.stat('THUMB','CMP');return true;case 11:r=u32(a+b);this.setNZ(r);this.setAddFlags(a,b,r);this.stat('THUMB','CMN');return true;case 12:r=a|b;break;case 13:r=Math.imul(a,b)>>>0;break;case 14:r=a&~b;break;case 15:r=~b;break;} this.r[rd]=r; this.setNZ(r); this.stat('THUMB','ALU'); return true; }
      // hi-register ops / BX
      if((ins&0xFC00)===0x4400){ const op=(ins>>>8)&3,h1=(ins>>>7)&1,h2=(ins>>>6)&1,d=(h1<<3)|(ins&7),s=(h2<<3)|((ins>>>3)&7); if(op===0){this.r[d]=u32(this.r[d]+this.r[s]);this.stat('THUMB','ADD_HI');} else if(op===1){const r=u32(this.r[d]-this.r[s]);this.setNZ(r);this.setSubFlags(this.r[d],this.r[s],r);this.stat('THUMB','CMP_HI');} else if(op===2){this.r[d]=this.r[s];this.stat('THUMB','MOV_HI');} else {const t=this.r[s]>>>0;this.cpsr.T=t&1;this.r[15]=t&~1;this.stat('THUMB','BX');} return true; }
      // PC-relative LDR
      if((ins&0xF800)===0x4800){ const d=(ins>>>8)&7; this.r[d]=this.read32(((addr+4)&~3)+((ins&255)<<2)); this.stat('THUMB','LDR_LITERAL'); return true; }
      // load/store register offset, sign/halfword register offset, immediate offset, sp-relative
      if((ins&0xF000)===0x5000){ const L=(ins>>>11)&1,B=(ins>>>10)&1,ro=(ins>>>6)&7,base=this.r[rs]>>>0,ea=u32(base+this.r[ro]); if(L)this.r[rd]=B?this.read8(ea):this.read32(ea); else {if(B)this.write8(ea,this.r[rd]);else this.write32(ea,this.r[rd]);} this.stat('THUMB',L?'LDR_REG':'STR_REG'); return true; }
      if((ins&0xF000)===0x6000 || (ins&0xF000)===0x7000){ const L=(ins>>>11)&1,B=(ins>>>12)&1,off=((ins>>>6)&31)<<(B?0:2),ea=u32(this.r[rs]+off); if(L)this.r[rd]=B?this.read8(ea):this.read32(ea); else {if(B)this.write8(ea,this.r[rd]);else this.write32(ea,this.r[rd]);} this.stat('THUMB',L?'LDR_IMM':'STR_IMM'); return true; }
      if((ins&0xF000)===0x8000){ const L=(ins>>>11)&1,off=((ins>>>6)&31)<<1,ea=u32(this.r[rs]+off); if(L)this.r[rd]=this.read16(ea); else this.write16(ea,this.r[rd]); this.stat('THUMB',L?'LDRH':'STRH'); return true; }
      if((ins&0xF000)===0x9000){ const L=(ins>>>11)&1,d=(ins>>>8)&7,ea=u32(this.r[13]+((ins&255)<<2)); if(L)this.r[d]=this.read32(ea); else this.write32(ea,this.r[d]); this.stat('THUMB',L?'LDR_SP':'STR_SP'); return true; }
      // load address / add sp
      if((ins&0xF000)===0xA000){ const d=(ins>>>8)&7; this.r[d]=u32(((ins>>>11)&1?this.r[13]:((addr+4)&~3))+((ins&255)<<2)); this.stat('THUMB','ADD_ADDR'); return true; }
      if((ins&0xFF00)===0xB000){ const sub=(ins>>>7)&1,imm=(ins&0x7F)<<2; this.r[13]=sub?u32(this.r[13]-imm):u32(this.r[13]+imm); this.stat('THUMB','ADD_SP'); return true; }
      // push/pop
      if((ins&0xF600)===0xB400){ const L=(ins>>>11)&1,R=(ins>>>8)&1,list=ins&255; if(!L){ if(R){this.r[13]=u32(this.r[13]-4);this.write32(this.r[13],this.r[14]);} for(let i=7;i>=0;i--)if((list>>>i)&1){this.r[13]=u32(this.r[13]-4);this.write32(this.r[13],this.r[i]);} this.stat('THUMB','PUSH'); } else { for(let i=0;i<8;i++)if((list>>>i)&1){this.r[i]=this.read32(this.r[13]);this.r[13]=u32(this.r[13]+4);} if(R){const t=this.read32(this.r[13]);this.r[13]=u32(this.r[13]+4);this.cpsr.T=t&1;this.r[15]=t&~1;} this.stat('THUMB','POP'); } return true; }
      // multiple load/store
      if((ins&0xF000)===0xC000){ const L=(ins>>>11)&1,base=(ins>>>8)&7,list=ins&255; let a=this.r[base]>>>0; for(let i=0;i<8;i++)if((list>>>i)&1){ if(L)this.r[i]=this.read32(a); else this.write32(a,this.r[i]); a=u32(a+4); } this.r[base]=a; this.stat('THUMB',L?'LDMIA':'STMIA'); return true; }
      // conditional branch / SWI
      if((ins&0xF000)===0xD000){ const cond=(ins>>>8)&15; if(cond===15){this.stat('THUMB','SWI');this.disasm='THUMB SWI';return true;} if(this.condOK(cond))this.r[15]=u32(addr+4+(sx(ins&255,8)<<1)); this.stat('THUMB','B_COND'); return true; }
      if((ins&0xF800)===0xE000){ this.r[15]=u32(addr+4+(sx(ins&0x7FF,11)<<1)); this.stat('THUMB','B'); return true; }
      if((ins&0xF800)===0xF000){ this.r[14]=u32(addr+4+(sx(ins&0x7FF,11)<<12)); this.stat('THUMB','BL_PREFIX'); return true; }
      if((ins&0xF800)===0xF800){ const target=u32(this.r[14]+((ins&0x7FF)<<1)); this.r[14]=u32((addr+2)|1); this.r[15]=target; this.stat('THUMB','BL_SUFFIX'); return true; }
      this.stat('THUMB','UNDEFINED_UNSUPPORTED'); return this.reportUnsupported('THUMB',addr,ins,'Undefined/Unclassified THUMB','Opcode is not yet handled by the THUMB decoder/executor');
    }
  }

const VIC_BASE=0xFFFFF000>>>0;
const VICIRQStatus=0xFFFFF000>>>0,VICFIQStatus=0xFFFFF004>>>0,VICRawIntr=0xFFFFF008>>>0;
const VICIntSelect=0xFFFFF00C>>>0,VICIntEnable=0xFFFFF010>>>0,VICIntEnClr=0xFFFFF014>>>0;
const VICSoftInt=0xFFFFF018>>>0,VICSoftIntClear=0xFFFFF01C>>>0,VICProtection=0xFFFFF020>>>0;
const VICVectAddr=0xFFFFF030>>>0,VICDefVectAddr=0xFFFFF034>>>0;
const VICVectAddr0=0xFFFFFF00>>>0,VICVectAddr15=0xFFFFFF3C>>>0;
const VICVectCntl0=0xFFFFF200>>>0,VICVectCntl15=0xFFFFF23C>>>0;
const TIMER0_VIC_SOURCE=4,TIMER1_VIC_SOURCE=5,UART0_VIC_SOURCE=6,UART1_VIC_SOURCE=7,ADC_VIC_SOURCE=18;

class WorkerVIC{
  constructor(emu){this.emu=emu;this.reset()}
  reset(){
    this.intSelect=0;this.intEnable=0;this.softInt=0;this.protection=0;this.defVectAddr=0;
    this.vectAddr=new Uint32Array(16);this.vectCntl=new Uint32Array(16);
    this.currentVector=0;this.irqEntries=0;this.lastSource=-1;
  }
  raw(){
    let r=this.softInt>>>0;
    const us=this.emu.uartEngines;
    if(us){
      if((us[0].iir()&1)===0)r|=(1<<UART0_VIC_SOURCE);
      if((us[1].iir()&1)===0)r|=(1<<UART1_VIC_SOURCE);
    }
    if(this.emu.timerEngines){
      if(this.emu.timerEngines[0].interruptPending())r|=(1<<TIMER0_VIC_SOURCE);
      if(this.emu.timerEngines[1].interruptPending())r|=(1<<TIMER1_VIC_SOURCE);
    }
    if(this.emu.adcEngine && this.emu.adcEngine.interruptPending()) r|=(1<<ADC_VIC_SOURCE);
    return r>>>0;
  }
  irqStatus(){return (this.raw()&this.intEnable&~this.intSelect)>>>0}
  fiqStatus(){return (this.raw()&this.intEnable&this.intSelect)>>>0}
  vectorForIRQ(){
    const pending=this.irqStatus();
    for(let i=0;i<16;i++){
      const c=this.vectCntl[i]>>>0,src=c&31;
      if((c&0x20)&&(pending&(1<<src))){
        this.currentVector=this.vectAddr[i]>>>0;this.lastSource=src;return this.currentVector;
      }
    }
    this.currentVector=this.defVectAddr>>>0;this.lastSource=-1;return this.currentVector;
  }
  read(a){
    a>>>=0;
    if(a===VICIRQStatus)return this.irqStatus();
    if(a===VICFIQStatus)return this.fiqStatus();
    if(a===VICRawIntr)return this.raw();
    if(a===VICIntSelect)return this.intSelect>>>0;
    if(a===VICIntEnable)return this.intEnable>>>0;
    if(a===VICSoftInt)return this.softInt>>>0;
    if(a===VICProtection)return this.protection>>>0;
    if(a===VICVectAddr)return this.vectorForIRQ();
    if(a===VICDefVectAddr)return this.defVectAddr>>>0;
    if(a>=VICVectAddr0&&a<=VICVectAddr15&&((a-VICVectAddr0)&3)===0)return this.vectAddr[(a-VICVectAddr0)>>>2]>>>0;
    if(a>=VICVectCntl0&&a<=VICVectCntl15&&((a-VICVectCntl0)&3)===0)return this.vectCntl[(a-VICVectCntl0)>>>2]>>>0;
    return 0;
  }
  write(a,v){
    a>>>=0;v>>>=0;
    if(a===VICIntSelect)this.intSelect=v;
    else if(a===VICIntEnable)this.intEnable=u32(this.intEnable|v);
    else if(a===VICIntEnClr)this.intEnable=u32(this.intEnable&~v);
    else if(a===VICSoftInt)this.softInt=u32(this.softInt|v);
    else if(a===VICSoftIntClear)this.softInt=u32(this.softInt&~v);
    else if(a===VICProtection)this.protection=v&1;
    else if(a===VICVectAddr){this.currentVector=0;} /* write is EOI */
    else if(a===VICDefVectAddr)this.defVectAddr=v;
    else if(a>=VICVectAddr0&&a<=VICVectAddr15&&((a-VICVectAddr0)&3)===0)this.vectAddr[(a-VICVectAddr0)>>>2]=v;
    else if(a>=VICVectCntl0&&a<=VICVectCntl15&&((a-VICVectCntl0)&3)===0)this.vectCntl[(a-VICVectCntl0)>>>2]=v&0x3F;
  }
  snapshot(){return {raw:this.raw(),irqStatus:this.irqStatus(),fiqStatus:this.fiqStatus(),intSelect:this.intSelect>>>0,intEnable:this.intEnable>>>0,currentVector:this.currentVector>>>0,lastSource:this.lastSource,irqEntries:this.irqEntries}}
}
function ensureVIC(emu){if(!emu.vic)emu.vic=new WorkerVIC(emu);return emu.vic}
function isVicAddress(a){
  a>>>=0;
  return ((a>=VIC_BASE&&a<=VIC_BASE+0x23C) || (a>=VICVectAddr0&&a<=VICVectAddr15));
}
function enterIRQIfPending(emu){
  const vic=ensureVIC(emu);
  if((emu.cpsr.I||0)!==0 || !vic.irqStatus())return false;
  const old=emu.cpsrValue();
  emu.spsr_irq=old>>>0;
  emu.irqSavedR13=emu.r[13]>>>0;
  emu.irqSavedR14=emu.r[14]>>>0;
  const nextPC=emu.r[15]>>>0;
  emu.r[13]=(RAM_BASE+RAM_SIZE-0x400)>>>0;
  emu.r[14]=u32(nextPC+4);
  emu.cpsr.mode=0x12;emu.cpsr.I=1;emu.cpsr.T=0;
  emu.r[15]=0x18;
  vic.irqEntries++;
  return true;
}

let clockCfg={cclkHz:60000000,pclkHz:15000000};
let lpcClockCycles=0;
function lpcNowCycles(){return Number(lpcClockCycles)||0;}


/* VECTOR Phase 8.4O — LPC2129 on-chip PWM + RTC engines.
   RTC external-clock path is driven by an exact 32.768 kHz crystal domain. */

/* VECTOR Phase 8.4T — LPC2129 I2C + 24LC512 EEPROM.
   Additive peripheral engine: no GPIO/UART/Timer/ADC/PWM/RTC timing paths are changed. */
const I2C_BASE=0xE001C000>>>0;
/* Phase 8.4T16 — clocked LPC2129 I2C + 24LC512 compliance-oriented engine.
   The engine deliberately preserves the LPC2129 SI-driven software contract:
   firmware advances the state machine by clearing SI.  Each resulting bus phase
   is timestamped from SCLH/SCLL and PCLK instead of being an un-timed shortcut. */
class Worker24LC512{
  constructor(){
    this.mem=new Uint8Array(65536);this.mem.fill(0xff);
    this.present=true;this.address=0x50;this.wp=false;
    this.ptr=0;this.addrBytes=[];this.writeCount=0;this.readCount=0;
    this.txnWrite=[];this.txnStart=0;this.busyUntilUs=0;this.writeCycleUs=5000;
    this.pageSize=128;this.events=[];this.lastAckPolls=0;
  }
  now(){return Number(lpcSimTimeUs)||0}
  event(kind,data=0){this.events.push({t:this.now(),kind,data:Number(data)>>>0});if(this.events.length>96)this.events.shift()}
  busy(){return this.now()<this.busyUntilUs}
  addressAck(addr){return this.present&&!this.busy()&&((addr&0x7f)===(this.address&0x7f))}
  begin(read){
    if(!read){this.addrBytes=[];this.txnWrite=[];this.txnStart=this.ptr}
    this.event(read?'BEGIN_READ':'BEGIN_WRITE',this.ptr);
  }
  writeByte(b){
    b&=255;
    if(this.addrBytes.length<2){
      this.addrBytes.push(b);
      if(this.addrBytes.length===2){this.ptr=((this.addrBytes[0]<<8)|this.addrBytes[1])&0xffff;this.txnStart=this.ptr;this.event('WORD_ADDR',this.ptr)}
      return true;
    }
    /* Buffer bytes until STOP. 24LC512 programs the page after STOP. */
    this.txnWrite.push(b);this.event('PAGE_BUFFER',b);return true;
  }
  commitStop(){
    if(!this.txnWrite.length)return;
    const base=this.txnStart&~(this.pageSize-1),startOff=this.txnStart&(this.pageSize-1);
    if(!this.wp){
      for(let i=0;i<this.txnWrite.length;i++){
        const a=(base|((startOff+i)&(this.pageSize-1)))&0xffff;
        this.mem[a]=this.txnWrite[i]&255;this.ptr=(a+1)&0xffff;this.writeCount++;
      }
      this.busyUntilUs=this.now()+this.writeCycleUs;this.event('WRITE_CYCLE_START',this.txnWrite.length);
    }else this.event('WP_BLOCKED',this.txnWrite.length);
    this.txnWrite=[];
  }
  readByte(){const b=this.mem[this.ptr]&255;this.event('READ_BYTE',(this.ptr<<8)|b);this.ptr=(this.ptr+1)&0xffff;this.readCount++;return b}
  snapshot(){
    const start=this.ptr&0xffc0;
    return {present:!!this.present,address:this.address&0x7f,pointer:this.ptr,writeCount:this.writeCount,readCount:this.readCount,
      busy:this.busy(),busyRemainingUs:Math.max(0,this.busyUntilUs-this.now()),writeCycleUs:this.writeCycleUs,pageSize:this.pageSize,wp:this.wp,
      pendingPageBytes:this.txnWrite.length,windowBase:start,window:Array.from(this.mem.slice(start,start+64)),events:this.events.slice(-48)};
  }
}
class WorkerI2C{
  constructor(emu){
    this.emu=emu;this.CONSET=0;this.STAT=0xF8;this.DAT=0;this.ADR=0;this.SCLH=60;this.SCLL=60;
    this.eeprom=new Worker24LC512();this.active=false;this.readMode=false;this.address=0;
    this.events=[];this.phaseCount=0;this.nextEventUs=0;this.busError=false;this.arbitrationLost=false;
    this.clockStretchUs=0;this.externalSdaLow=false;this.externalSclLow=false;
  }
  now(){return Number(lpcSimTimeUs)||0}
  pclkHz(){
    /* LPC2129 baseline is configured around PCLK=15 MHz. Clock panel may expose a live value. */
    const c=this.emu&&this.emu.clock;return Number(c&&((c.pclkHz)||(c.PCLK)))||15000000;
  }
  pinsConfigured(){return (this.emu.pinConnect.PINSEL0&0xF0)===0x50}
  enabled(){return !!(this.CONSET&0x40)}
  byteTimeUs(){const hz=this.pclkHz(),ticks=Math.max(4,(this.SCLH&0xffff)+(this.SCLL&0xffff));return 9*ticks*1e6/hz}
  phaseDelayUs(bits=9){const hz=this.pclkHz(),ticks=Math.max(4,(this.SCLH&0xffff)+(this.SCLL&0xffff));return bits*ticks*1e6/hz+this.clockStretchUs}
  event(kind,data=0){this.events.push({t:this.now(),kind,data:Number(data)>>>0,stat:this.STAT&0xf8});if(this.events.length>128)this.events.shift()}
  setSI(stat,kind){
    this.STAT=stat&0xF8;this.CONSET|=0x08;this.phaseCount++;this.nextEventUs=this.now();
    this.event(kind||'STAT',this.STAT);
  }
  failBus(){
    this.busError=true;this.active=false;this.setSI(0x00,'BUS_ERROR');
  }
  start(repeated){
    if(!this.enabled()||!this.pinsConfigured()||this.externalSclLow){this.failBus();return}
    this.active=true;this.readMode=false;this.nextEventUs=this.now()+this.phaseDelayUs(1);
    this.setSI(repeated?0x10:0x08,repeated?'REPEATED_START':'START');
  }
  stop(){
    if(this.active)this.eeprom.commitStop();
    this.active=false;this.readMode=false;this.CONSET&=~0x10;this.STAT=0xF8;
    this.nextEventUs=this.now()+this.phaseDelayUs(1);this.event('STOP',0);
  }
  loseArbitration(){
    this.arbitrationLost=true;this.active=false;this.CONSET&=~0x20;this.setSI(0x38,'ARBITRATION_LOST');
  }
  advance(){
    if(!this.enabled()){this.STAT=0xF8;return}
    if(this.externalSdaLow&&!this.active&&(this.CONSET&0x20)){this.failBus();return}
    if(this.CONSET&0x20){this.CONSET&=~0x20;this.start(this.active);return}
    const st=this.STAT&0xF8;
    if(st===0x08||st===0x10){
      this.address=(this.DAT>>>1)&0x7f;this.readMode=!!(this.DAT&1);
      const ack=this.pinsConfigured()&&this.eeprom.addressAck(this.address);
      this.nextEventUs=this.now()+this.phaseDelayUs();
      if(ack){this.eeprom.begin(this.readMode);this.setSI(this.readMode?0x40:0x18,'SLA_ACK');this.event('ADDR',this.DAT&255)}
      else {if(this.eeprom.busy())this.eeprom.lastAckPolls++;this.setSI(this.readMode?0x48:0x20,'SLA_NACK');}
      return;
    }
    if(st===0x18||st===0x28){
      const ack=this.eeprom.present&&!this.eeprom.busy()&&this.address===(this.eeprom.address&0x7f)&&this.eeprom.writeByte(this.DAT);
      this.nextEventUs=this.now()+this.phaseDelayUs();this.event('WRITE',this.DAT&255);this.setSI(ack?0x28:0x30,ack?'DATA_ACK':'DATA_NACK');return;
    }
    if(st===0x40||st===0x50){
      this.DAT=this.eeprom.readByte();this.nextEventUs=this.now()+this.phaseDelayUs();this.event('READ',this.DAT&255);
      this.setSI((this.CONSET&0x04)?0x50:0x58,(this.CONSET&0x04)?'DATA_RX_ACK':'DATA_RX_NACK');return;
    }
    if(st===0x38){this.STAT=0xF8;return}
    if(st===0x00){this.STAT=0xF8;this.busError=false;return}
  }
  read(a){
    const o=(a-I2C_BASE)>>>0;
    if(o===0)return this.CONSET>>>0;if(o===4)return this.STAT>>>0;if(o===8)return this.DAT>>>0;
    if(o===0x0c)return this.ADR>>>0;if(o===0x10)return this.SCLH>>>0;if(o===0x14)return this.SCLL>>>0;return 0;
  }
  write(a,v){
    const o=(a-I2C_BASE)>>>0;v>>>=0;
    if(o===0){
      if(v&0x04)this.CONSET|=0x04;
      if(v&0x10){this.CONSET|=0x10;this.stop()}
      if(v&0x20)this.CONSET|=0x20;
      if(v&0x40)this.CONSET|=0x40;
      return;
    }
    if(o===8){this.DAT=v&255;return}
    if(o===0x0c){this.ADR=v&0xff;return}
    if(o===0x10){this.SCLH=v&0xffff;return}
    if(o===0x14){this.SCLL=v&0xffff;return}
    if(o===0x18){
      if(v&0x04)this.CONSET&=~0x04;
      if(v&0x08){this.CONSET&=~0x08;this.advance()}
      if(v&0x20)this.CONSET&=~0x20;
      if(v&0x40){this.CONSET&=~0x40;this.active=false;this.STAT=0xF8}
      return;
    }
  }
  snapshot(){
    const scl=this.pclkHz()/Math.max(4,(this.SCLH&0xffff)+(this.SCLL&0xffff));
    return {CONSET:this.CONSET>>>0,STAT:this.STAT>>>0,DAT:this.DAT>>>0,ADR:this.ADR>>>0,SCLH:this.SCLH>>>0,SCLL:this.SCLL>>>0,
      pinsConfigured:this.pinsConfigured(),enabled:this.enabled(),active:this.active,readMode:this.readMode,address:this.address,
      sclHz:scl,byteTimeUs:this.byteTimeUs(),phaseCount:this.phaseCount,nextEventUs:this.nextEventUs,busError:this.busError,
      arbitrationLost:this.arbitrationLost,clockStretchUs:this.clockStretchUs,externalSdaLow:this.externalSdaLow,externalSclLow:this.externalSclLow,
      eeprom:this.eeprom.snapshot(),events:this.events.slice(-64)};
  }
}
function ensureI2C(emu){if(!emu.i2cEngine)emu.i2cEngine=new WorkerI2C(emu);return emu.i2cEngine}
function isI2CAddress(a){a>>>=0;return a>=I2C_BASE&&a<=I2C_BASE+0x18}


/* Phase 8.4T14 — LPC2129 SPI0/SPI1 + 25LC512 engine.
   LPC2129 exposes two programmer-visible SPI blocks. 25LC512 is attached to SPI0.
   SPI0 master uses P0.7 GPIO as active-low CS; SSEL0 remains available for slave mode. */
const SPI_BASES=[0xE0020000>>>0,0xE0030000>>>0];
class Worker25LC512{
  constructor(){this.mem=new Uint8Array(65536);this.mem.fill(0xff);this.present=true;this.selected=false;this.cmd=null;this.addrBytes=[];this.ptr=0;this.wel=false;this.wip=false;this.status=0;this.writeCount=0;this.readCount=0;this.events=[];this.wrote=false;this.pageBuf=[];this.pageStart=0;this.pageSize=128;this.writeCycleUs=5000;this.busyUntilUs=0;this.wp=false;this.hold=false;}
  event(kind,data){this.events.push({t:lpcSimTimeUs,kind,data:Number(data)>>>0});if(this.events.length>96)this.events.shift();}
  updateBusy(){if(this.wip&&Number(lpcSimTimeUs)>=this.busyUntilUs){this.wip=false;this.event('WIP_CLEAR',0)}}
  select(){this.updateBusy();if(!this.selected){this.selected=true;this.cmd=null;this.addrBytes=[];this.pageBuf=[];this.wrote=false;this.event('CS_LOW',0);}}
  deselect(){if(this.selected){if(this.cmd===0x02&&this.pageBuf.length&&this.wel&&!this.wip){if(!this.wp){const base=this.pageStart&0xff80,off=this.pageStart&0x7f;for(let i=0;i<this.pageBuf.length;i++){this.mem[base|((off+i)&0x7f)]=this.pageBuf[i]&255;this.writeCount++;}this.wip=true;this.busyUntilUs=Number(lpcSimTimeUs)+this.writeCycleUs;this.event('WRITE_CYCLE_START',this.pageBuf.length);}else this.event('WP_BLOCKED',this.pageBuf.length);this.wel=false;}this.selected=false;this.pageBuf=[];this.event('CS_HIGH',0);}}
  sr(){this.updateBusy();return (this.status&0xFC)|(this.wel?0x02:0)|(this.wip?0x01:0);}
  xfer(b){
    b&=255;this.updateBusy();if(!this.present||!this.selected||this.hold)return 0xff;
    if(this.cmd===null){
      this.cmd=b;this.addrBytes=[];this.event('CMD',b);
      if(b===0x06&&!this.wip)this.wel=true;
      else if(b===0x04)this.wel=false;
      return 0xff;
    }
    if(this.cmd===0x05)return this.sr();
    if(this.wip)return 0xff;
    if(this.cmd===0x01){if(this.wel&&!this.wp){this.status=b&0x8C;this.wel=false;this.wip=true;this.busyUntilUs=Number(lpcSimTimeUs)+this.writeCycleUs;}return 0xff;}
    if(this.cmd===0x03||this.cmd===0x02){
      if(this.addrBytes.length<2){
        this.addrBytes.push(b);
        if(this.addrBytes.length===2){this.ptr=((this.addrBytes[0]<<8)|this.addrBytes[1])&0xffff;this.pageStart=this.ptr;this.event('ADDR',this.ptr);}
        return 0xff;
      }
      if(this.cmd===0x03){const v=this.mem[this.ptr]&255;this.event('READ',(this.ptr<<8)|v);this.ptr=(this.ptr+1)&0xffff;this.readCount++;return v;}
      if(this.cmd===0x02){
        if(this.wel){
          this.pageBuf.push(b);this.event('PAGE_BUFFER',b);const pageBase=this.pageStart&0xff80,off=((this.pageStart&0x7f)+this.pageBuf.length)&0x7f;this.ptr=pageBase|off;this.wrote=true;
        }
        return 0xff;
      }
    }
    return 0xff;
  }
  snapshot(){this.updateBusy();const base=this.ptr&0xffc0;return {present:this.present,selected:this.selected,pointer:this.ptr,wel:this.wel,wip:this.wip,status:this.sr(),wp:this.wp,hold:this.hold,pageSize:this.pageSize,writeCycleUs:this.writeCycleUs,busyRemainingUs:Math.max(0,this.busyUntilUs-Number(lpcSimTimeUs)),writeCount:this.writeCount,readCount:this.readCount,windowBase:base,window:Array.from(this.mem.slice(base,base+64)),events:this.events.slice(-48)};}
}
class WorkerSPI{
  constructor(index,emu,eeprom){this.index=index;this.emu=emu;this.base=SPI_BASES[index];this.eeprom=eeprom||null;this.SPCR=0;this.SPSR=0;this.SPDR=0;this.SPCCR=8;this.SPINT=0;this.transfers=0;this.events=[];this.wave=[];this.lastCS=true;this.rxUnread=false;this.completeAtUs=0;}
  pinsConfigured(){
    if(this.index===0)return ((this.emu.pinConnect.PINSEL0&0x3f00)===0x1500);
    return ((this.emu.pinConnect.PINSEL1&0xfc)===0xa8); /* P0.17/18/19 function 10 */
  }
  master(){return !!(this.SPCR&0x20)}
  cpol(){return !!(this.SPCR&0x10)}
  cpha(){return !!(this.SPCR&0x08)}
  lsb(){return !!(this.SPCR&0x40)}
  pclkHz(){const c=this.emu&&this.emu.clock;return Number(c&&((c.pclkHz)||(c.PCLK)))||15000000}
  sckHz(){return this.pclkHz()/Math.max(8,this.SPCCR&0xff)}
  transferUs(){return 8*1e6/Math.max(1,this.sckHz())}
  waveform(tx,rx){const idle=this.cpol()?1:0,dt=1e6/(2*Math.max(1,this.sckHz())),lsb=this.lsb();let clk=idle,t=Number(lpcSimTimeUs);for(let bit=0;bit<8;bit++){const bi=lsb?bit:7-bit,mo=(tx>>bi)&1,mi=(rx>>bi)&1;clk=1-clk;t+=dt;this.wave.push({t,edge:'leading',sck:clk,mosi:mo,miso:mi,bit,sample:this.cpha()?0:1});clk=1-clk;t+=dt;this.wave.push({t,edge:'trailing',sck:clk,mosi:mo,miso:mi,bit,sample:this.cpha()?1:0});}if(this.wave.length>192)this.wave.splice(0,this.wave.length-192)}
  csHigh(){return !!(this.emu.gpio.IO0PIN&(1<<7))}
  syncCS(){if(this.index!==0||!this.eeprom)return;const h=this.csHigh();if(h!==this.lastCS){this.lastCS=h;if(h)this.eeprom.deselect();else this.eeprom.select();}}
  event(kind,data){this.events.push({t:lpcSimTimeUs,kind,data:Number(data)>>>0});if(this.events.length>48)this.events.shift();}
  transfer(v){
    this.syncCS();v&=255;this.SPSR&=~0x80;if(this.rxUnread){this.SPSR|=0x20;this.event('ROVR',this.SPDR);}
    let rx=0xff;
    if(!this.master()){this.SPSR|=0x10;this.event('MODF',v);}
    else if(!this.pinsConfigured()){this.SPSR|=0x08;this.event('ABRT',v);}
    else if(this.index===0&&this.eeprom)rx=this.eeprom.xfer(v);
    this.waveform(v,rx);this.completeAtUs=Number(lpcSimTimeUs)+this.transferUs();this.SPDR=rx&255;this.SPSR|=0x80;this.rxUnread=true;this.transfers++;this.event('XFER',(v<<8)|rx);this.event('SPIF_AT',Math.round(this.completeAtUs));
    if(this.SPCR&0x80)this.SPINT|=1;
  }
  read(a){const o=(a-this.base)>>>0;this.syncCS();if(o===0)return this.SPCR>>>0;if(o===4)return this.SPSR>>>0;if(o===8){const v=this.SPDR>>>0;this.SPSR&=~0x80;this.rxUnread=false;return v}if(o===0x0c)return this.SPCCR>>>0;if(o===0x1c)return this.SPINT>>>0;return 0;}
  write(a,v){const o=(a-this.base)>>>0;v>>>=0;this.syncCS();if(o===0){this.SPCR=v&0xF8;return}if(o===8){this.transfer(v);return}if(o===0x0c){this.SPCCR=v&0xff;if(this.SPCCR<8||(this.SPCCR&1))this.SPSR|=0x08;return}if(o===0x1c){if(v&1)this.SPINT&=~1;return}}
  snapshot(){this.syncCS();return {index:this.index,SPCR:this.SPCR>>>0,SPSR:this.SPSR>>>0,SPDR:this.SPDR>>>0,SPCCR:this.SPCCR>>>0,SPINT:this.SPINT>>>0,master:this.master(),cpol:this.cpol(),cpha:this.cpha(),lsb:this.lsb(),pinsConfigured:this.pinsConfigured(),sckHz:this.sckHz(),transferUs:this.transferUs(),completeAtUs:this.completeAtUs,transfers:this.transfers,wave:this.wave.slice(-96),events:this.events.slice(-32),eeprom:this.eeprom?this.eeprom.snapshot():null};}
}
function ensureSPIs(emu){
  if(!emu.spiEeprom25)emu.spiEeprom25=new Worker25LC512();
  if(!emu.spiEngines)emu.spiEngines={0:new WorkerSPI(0,emu,emu.spiEeprom25),1:new WorkerSPI(1,emu,null)};
  return emu.spiEngines;
}
function spiForAddress(a){a>>>=0;for(let i=0;i<2;i++){const b=SPI_BASES[i];if(a===b||a===b+4||a===b+8||a===b+0x0c||a===b+0x1c)return i}return -1}


/* Phase 8.4T15 — LPC2129 CAN1/CAN2 programmer-visible controller + AF + bus engine.
   Controller bases: CAN1 0xE0044000, CAN2 0xE0048000.
   Acceptance filter: 0xE003C000, AF RAM 0xE0038000.
   Central status: 0xE0040000.
*/
const CAN_BASES=[0,0xE0044000>>>0,0xE0048000>>>0];
const CAN_AF_BASE=0xE003C000>>>0,CAN_AF_RAM=0xE0038000>>>0,CAN_CENTRAL=0xE0040000>>>0;
class WorkerCANAF{
 constructor(){this.AFMR=1;this.SFF_sa=0;this.SFF_GRP_sa=0;this.EFF_sa=0;this.EFF_GRP_sa=0;this.ENDofTable=0;this.LUTerrAd=0;this.LUTerr=0;this.ram=new Uint32Array(512);}
 read(a){const o=(a-CAN_AF_BASE)>>>0;return [this.AFMR,this.SFF_sa,this.SFF_GRP_sa,this.EFF_sa,this.EFF_GRP_sa,this.ENDofTable,this.LUTerrAd,this.LUTerr][o>>>2]>>>0}
 write(a,v){const o=(a-CAN_AF_BASE)>>>0;v>>>=0;if(o===0)this.AFMR=v&3;else if(o===4)this.SFF_sa=v;else if(o===8)this.SFF_GRP_sa=v;else if(o===12)this.EFF_sa=v;else if(o===16)this.EFF_GRP_sa=v;else if(o===20)this.ENDofTable=v}
 accept(ctrl,frame){
   const mode=this.AFMR&3;
   if(mode===2)return true;          /* bypass: all messages accepted */
   if(mode===1)return false;         /* filter off */
   /* Standard individual entries: two 16-bit entries per word.
      entry bits 15:13 controller number, 10:0 identifier. */
   if(!frame.extended){
     let begin=(this.SFF_sa>>>2),end=(this.SFF_GRP_sa>>>2);
     for(let i=begin;i<end&&i<this.ram.length;i++){
       const q=this.ram[i]>>>0,es=[(q>>>16)&0xffff,q&0xffff];
       for(const e of es){if(((e>>>13)&7)===ctrl.index&&(e&0x7ff)===(frame.id&0x7ff))return true}
     }
   }
   /* Empty table in classroom builds: reject unless bypass mode is used. */
   return false;
 }
 snapshot(){return {AFMR:this.AFMR,SFF_sa:this.SFF_sa,SFF_GRP_sa:this.SFF_GRP_sa,EFF_sa:this.EFF_sa,EFF_GRP_sa:this.EFF_GRP_sa,ENDofTable:this.ENDofTable,LUTerrAd:this.LUTerrAd,LUTerr:this.LUTerr}}
}
class WorkerCANController{
 constructor(index,emu,bus){this.index=index;this.emu=emu;this.bus=bus;this.base=CAN_BASES[index];this.MOD=1;this.GSR=0x0c;this.ICR=0;this.IER=0;this.BTR=0x001c0000;this.EWL=0x60;this.RFS=0;this.RID=0;this.RDA=0;this.RDB=0;this.tx=[null,{TFI:0,TID:0,TDA:0,TDB:0},{TFI:0,TID:0,TDA:0,TDB:0},{TFI:0,TID:0,TDA:0,TDB:0}];this.txErr=0;this.rxErr=0;this.rxPending=false;this.txReady=[false,true,true,true];this.transfers=0;this.rxCount=0;this.events=[]}
 event(kind,data){this.events.push({t:lpcSimTimeUs,kind,data});if(this.events.length>64)this.events.shift()}
 normal(){return !(this.MOD&1)}
 pinsConfigured(){
   const ps=this.emu.pinConnect.PINSEL1>>>0;
   if(this.index===1)return ((ps>>>18)&3)===1; /* RD1=P0.25; TD1 dedicated */
   return (((ps>>>14)&3)===1)&&(((ps>>>16)&3)===1); /* RD2/TD2 */
 }
 sr(){
   let v=0;
   /* each transmit buffer group exposes TBS/TCS/TS bits; idle buffers are available */
   for(let i=1;i<=3;i++){const sh=(i-1)*8;if(this.txReady[i])v|=(1<<(sh+2));}
   if(this.rxPending)v|=1;
   return v>>>0;
 }
 gsr(){
   let v=this.sr()&0xff;
   v|=(this.rxErr&255)<<16;v|=(this.txErr&255)<<24;
   return v>>>0;
 }
 txFrame(i){
   const t=this.tx[i],dlc=Math.min(8,(t.TFI>>>16)&15),ext=!!(t.TFI&(1<<31)),rtr=!!(t.TFI&(1<<30));
   const data=[];for(let k=0;k<4&&k<dlc;k++)data.push((t.TDA>>>(8*k))&255);for(let k=4;k<dlc;k++)data.push((t.TDB>>>(8*(k-4)))&255);
   return {src:this.index,buf:i,id:ext?(t.TID&0x1fffffff):(t.TID&0x7ff),extended:ext,rtr,dlc,data};
 }
 command(v){
   if(v&0x04){this.rxPending=false;this.RFS=this.RID=this.RDA=this.RDB=0;this.ICR&=~1;this.event('RRB',0)}
   if(v&0x08){this.GSR&=~2;this.ICR&=~8}
   if(v&0x02){for(let i=1;i<=3;i++)this.txReady[i]=true;this.event('AT',0)}
   if(v&0x01){
     let b=(v&0x20)?1:(v&0x40)?2:(v&0x80)?3:1;
     if(this.normal()){this.txReady[b]=false;this.bus.transmit(this,this.txFrame(b));}
   }
 }
 receive(frame){
   if(!this.normal()||this.rxPending)return false;
   if(!this.emu.canAF.accept(this,frame))return false;
   this.RFS=((frame.extended?1:0)<<31)|((frame.rtr?1:0)<<30)|((frame.dlc&15)<<16);
   this.RID=frame.id>>>0;this.RDA=0;this.RDB=0;
   for(let i=0;i<Math.min(4,frame.data.length);i++)this.RDA|=(frame.data[i]&255)<<(8*i);
   for(let i=4;i<Math.min(8,frame.data.length);i++)this.RDB|=(frame.data[i]&255)<<(8*(i-4));
   this.rxPending=true;this.rxCount++;this.ICR|=1;this.event('RX',{id:frame.id,dlc:frame.dlc,data:frame.data.slice()});return true;
 }
 txDone(buf,acked){
   this.txReady[buf]=true;this.transfers++;if(acked){this.ICR|=(buf===1?2:buf===2?0x200:0x400);this.event('TX_OK',buf)}else{this.txErr=Math.min(255,this.txErr+8);this.ICR|=0x80;this.event('TX_NO_ACK',buf)}
 }
 externalArbitrationLost(buf,bit){this.ICR|=0x40;this.event('ARBITRATION_LOST',{buf:buf,bit:bit});}
 externalReceive(frame){return this.receive(frame)}

 read(a){const o=(a-this.base)>>>0;
   if(o===0)return this.MOD>>>0;if(o===8)return this.gsr();if(o===12){const v=this.ICR>>>0;this.ICR=0;return v}if(o===16)return this.IER>>>0;if(o===20)return this.BTR>>>0;if(o===24)return this.EWL>>>0;if(o===28)return this.sr();if(o===32)return this.RFS>>>0;if(o===36)return this.RID>>>0;if(o===40)return this.RDA>>>0;if(o===44)return this.RDB>>>0;
   for(let b=1;b<=3;b++){const q=0x30+(b-1)*0x10;if(o===q)return this.tx[b].TFI>>>0;if(o===q+4)return this.tx[b].TID>>>0;if(o===q+8)return this.tx[b].TDA>>>0;if(o===q+12)return this.tx[b].TDB>>>0}return 0;
 }
 write(a,v){const o=(a-this.base)>>>0;v>>>=0;
   if(o===0){this.MOD=v&0x7f;return}if(o===4){this.command(v);return}if(o===8){if(this.MOD&1){this.txErr=(v>>>24)&255;this.rxErr=(v>>>16)&255}return}if(o===16){this.IER=v&0x7ff;return}if(o===20){if(this.MOD&1)this.BTR=v;return}if(o===24){this.EWL=v&255;return}
   for(let b=1;b<=3;b++){const q=0x30+(b-1)*0x10;if(o===q){this.tx[b].TFI=v;return}if(o===q+4){this.tx[b].TID=v;return}if(o===q+8){this.tx[b].TDA=v;return}if(o===q+12){this.tx[b].TDB=v;return}}
 }
 snapshot(){return {index:this.index,MOD:this.MOD,GSR:this.gsr(),ICR:this.ICR,IER:this.IER,BTR:this.BTR,EWL:this.EWL,SR:this.sr(),RFS:this.RFS,RID:this.RID,RDA:this.RDA,RDB:this.RDB,tx:this.tx.slice(1).map(x=>({...x})),txErr:this.txErr,rxErr:this.rxErr,rxPending:this.rxPending,txCount:this.transfers,rxCount:this.rxCount,pinsConfigured:this.pinsConfigured(),events:this.events.slice(-32)}}
}
class WorkerCANBus{
 constructor(emu){this.emu=emu;this.externalMode=false;this.nodeId='';this.connected=true;this.term1=true;this.term2=true;this.mcp1=true;this.mcp2=true;this.frames=[];this.seq=0}
 healthy(){return this.connected&&this.term1&&this.term2&&this.mcp1&&this.mcp2}
 transmit(src,frame){
   if(this.externalMode){
     postMessage({type:'can-external-tx',nodeId:this.nodeId,controller:src.index,frame:{...frame,data:frame.data.slice()},t:lpcSimTimeUs});
     this.frames.push({seq:++this.seq,t:lpcSimTimeUs,src:src.index,dst:0,id:frame.id,extended:frame.extended,rtr:frame.rtr,dlc:frame.dlc,data:frame.data.slice(),ack:false,external:true});
     if(this.frames.length>128)this.frames.shift();
     return;
   }
   const dst=this.emu.canControllers[src.index===1?2:1];let ack=false;
   if(this.healthy()&&src.pinsConfigured()&&dst&&dst.pinsConfigured()&&dst.normal()){
     ack=true; dst.receive(frame);
   }
   src.txDone(frame.buf,ack);
   this.frames.push({seq:++this.seq,t:lpcSimTimeUs,src:src.index,dst:src.index===1?2:1,id:frame.id,extended:frame.extended,rtr:frame.rtr,dlc:frame.dlc,data:frame.data.slice(),ack});
   if(this.frames.length>128)this.frames.shift();
 }
 snapshot(){return {connected:this.connected,term1:this.term1,term2:this.term2,mcp1:this.mcp1,mcp2:this.mcp2,healthy:this.healthy(),frames:this.frames.slice(-64)}}
}
function ensureCAN(emu){
 if(!emu.canAF)emu.canAF=new WorkerCANAF();
 if(!emu.canBus)emu.canBus=new WorkerCANBus(emu);
 if(!emu.canControllers)emu.canControllers={1:new WorkerCANController(1,emu,emu.canBus),2:new WorkerCANController(2,emu,emu.canBus)};
 return emu.canControllers;
}
function canControllerForAddress(a){a>>>=0;if(a>=0xE0044000&&a<=0xE004405f)return 1;if(a>=0xE0048000&&a<=0xE004805f)return 2;return 0}
function isCANAFAddress(a){a>>>=0;return a>=0xE003C000&&a<=0xE003C01f}
function isCANAFRam(a){a>>>=0;return a>=0xE0038000&&a<0xE0038800}
function isCANCentral(a){a>>>=0;return a>=0xE0040000&&a<=0xE0040008}
function canCentralRead(emu,a){const c=ensureCAN(emu),o=(a-CAN_CENTRAL)>>>0;
 if(o===0){return ((c[1].sr()&0x000c0c0c)|((c[2].sr()&0x000c0c0c)<<16))>>>0}
 if(o===4){return ((c[1].rxPending?1:0)|((c[2].rxPending?1:0)<<8))>>>0}
 if(o===8){return (((c[1].txErr||c[1].rxErr)?1:0)|(((c[2].txErr||c[2].rxErr)?1:0)<<8))>>>0}
 return 0;
}

const PWM_BASE=0xE0014000>>>0;
const RTC_BASE=0xE0024000>>>0;
const RTC_XTAL_HZ=32768;
class WorkerPWM{
 constructor(emu){this.emu=emu;this.reset()}
 reset(){this.IR=0;this.TCR=0;this.TC=0;this.PR=0;this.PC=0;this.MCR=0;this.MR=new Uint32Array(7);this.PCR=0;this.LER=0;this.pending=new Uint32Array(7);this.pclkTicks=0;}
 enabled(){return !!(this.TCR&1)&&!(this.TCR&2)&&!!(this.TCR&8)}
 write(a,v){const o=(a-PWM_BASE)>>>0;v>>>=0;if(o===0){this.IR&=~v;return}if(o===4){this.TCR=v&0x0b;if(v&2){this.TC=0;this.PC=0}return}if(o===8){this.TC=v;return}if(o===0x0c){this.PR=v;return}if(o===0x10){this.PC=v;return}if(o===0x14){this.MCR=v;return}const mo={0x18:0,0x1c:1,0x20:2,0x24:3,0x40:4,0x44:5,0x48:6}[o];if(mo!==undefined){this.pending[mo]=v;return}if(o===0x4c){this.PCR=v&0x7e7c;return}if(o===0x50){this.LER|=v&0x7f;for(let i=0;i<7;i++)if(v&(1<<i))this.MR[i]=this.pending[i]>>>0;this.LER=0;return}}
 read(a){const o=(a-PWM_BASE)>>>0;if(o===0)return this.IR>>>0;if(o===4)return this.TCR>>>0;if(o===8)return this.TC>>>0;if(o===0x0c)return this.PR>>>0;if(o===0x10)return this.PC>>>0;if(o===0x14)return this.MCR>>>0;const mo={0x18:0,0x1c:1,0x20:2,0x24:3,0x40:4,0x44:5,0x48:6}[o];if(mo!==undefined)return this.MR[mo]>>>0;if(o===0x4c)return this.PCR>>>0;if(o===0x50)return this.LER>>>0;return 0}
 tickPclk(pt){if(!this.enabled())return;this.pclkTicks+=pt;const div=(this.PR>>>0)+1,total=this.PC+pt,inc=Math.floor(total/div);this.PC=total%div;if(!inc)return;let period=this.MR[0]>>>0;if(!period){this.TC=(this.TC+inc)>>>0;return}let t=this.TC+inc;while(t>=period){t-=period;this.IR|=1;if(this.MCR&2)t=0;if(this.MCR&4){this.TCR&=~1;break}}this.TC=t>>>0}
 duty(ch){if(ch<1||ch>6||!(this.PCR&(1<<(8+ch)))||!this.enabled())return 0;const p=this.MR[0]>>>0;if(!p)return 0;return Math.max(0,Math.min(1,(this.MR[ch]>>>0)/p))}
 snapshot(){return {IR:this.IR>>>0,TCR:this.TCR>>>0,TC:this.TC>>>0,PR:this.PR>>>0,PC:this.PC>>>0,MCR:this.MCR>>>0,MR:Array.from(this.MR),PCR:this.PCR>>>0,LER:this.LER>>>0,duty:[0,1,2,3,4,5,6].map(i=>this.duty(i)),pclkTicks:this.pclkTicks}}
}
function leap(y){return (y%4===0&&y%100!==0)||y%400===0}
function dim(y,m){return [31,leap(y)?29:28,31,30,31,30,31,31,30,31,30,31][Math.max(1,Math.min(12,m))-1]}
class WorkerRTC{
 constructor(emu){this.emu=emu;this.reset()}
 reset(){this.ILR=0;this.CCR=0;this.CIIR=0;this.AMR=0xff;this.CTC=0;this.SEC=0;this.MIN=0;this.HOUR=0;this.DOM=1;this.DOW=0;this.DOY=1;this.MONTH=1;this.YEAR=2000;this.ALSEC=0;this.ALMIN=0;this.ALHOUR=0;this.ALDOM=1;this.ALDOW=0;this.ALDOY=1;this.ALMON=1;this.ALYEAR=2000;this.PREINT=0;this.PREFRAC=0;this.frac=0;this.seconds=0}
 tickCrystal(ticks){if(!(this.CCR&1))return;if(this.CCR&2){this.CTC=0;return}this.frac+=ticks;while(this.frac>=RTC_XTAL_HZ){this.frac-=RTC_XTAL_HZ;this.incSecond()}this.CTC=Math.floor(this.frac)&0x7fff}
 incSecond(){this.SEC++;this.seconds++;let changed=1;if(this.SEC>=60){this.SEC=0;this.MIN++;changed|=2;if(this.MIN>=60){this.MIN=0;this.HOUR++;changed|=4;if(this.HOUR>=24){this.HOUR=0;this.DOM++;this.DOW=(this.DOW+1)%7;this.DOY++;changed|=8|16|32;if(this.DOM>dim(this.YEAR,this.MONTH)){this.DOM=1;this.MONTH++;changed|=64;if(this.MONTH>12){this.MONTH=1;this.YEAR++;this.DOY=1;changed|=128}}}}}if(this.CIIR&changed)this.ILR|=1;if(this.alarmMatch())this.ILR|=2}
 alarmMatch(){const vals=[this.SEC,this.MIN,this.HOUR,this.DOM,this.DOW,this.DOY,this.MONTH,this.YEAR],als=[this.ALSEC,this.ALMIN,this.ALHOUR,this.ALDOM,this.ALDOW,this.ALDOY,this.ALMON,this.ALYEAR];for(let i=0;i<8;i++)if(!(this.AMR&(1<<i))&&vals[i]!==als[i])return false;return this.AMR!==0xff}
 ctime0(){return (this.SEC&63)|((this.MIN&63)<<8)|((this.HOUR&31)<<16)|((this.DOW&7)<<24)}
 ctime1(){return (this.DOM&31)|((this.MONTH&15)<<8)|((this.YEAR&0xfff)<<16)}
 ctime2(){return this.DOY&0xfff}
 read(a){const o=(a-RTC_BASE)>>>0;const map={0:this.ILR,4:this.CTC,8:this.CCR,12:this.CIIR,16:this.AMR,20:this.ctime0(),24:this.ctime1(),28:this.ctime2(),32:this.SEC,36:this.MIN,40:this.HOUR,44:this.DOM,48:this.DOW,52:this.DOY,56:this.MONTH,60:this.YEAR,96:this.ALSEC,100:this.ALMIN,104:this.ALHOUR,108:this.ALDOM,112:this.ALDOW,116:this.ALDOY,120:this.ALMON,124:this.ALYEAR,128:this.PREINT,132:this.PREFRAC};return (map[o]??0)>>>0}
 write(a,v){const o=(a-RTC_BASE)>>>0;v>>>=0;if(o===0){this.ILR&=~(v&3);return}if(o===8){this.CCR=v&0x13;if(v&2){this.frac=0;this.CTC=0}return}if(o===12){this.CIIR=v&0xff;return}if(o===16){this.AMR=v&0xff;return}const names={32:'SEC',36:'MIN',40:'HOUR',44:'DOM',48:'DOW',52:'DOY',56:'MONTH',60:'YEAR',96:'ALSEC',100:'ALMIN',104:'ALHOUR',108:'ALDOM',112:'ALDOW',116:'ALDOY',120:'ALMON',124:'ALYEAR',128:'PREINT',132:'PREFRAC'};if(names[o])this[names[o]]=v}
 snapshot(){return {ILR:this.ILR>>>0,CTC:this.CTC>>>0,CCR:this.CCR>>>0,CIIR:this.CIIR>>>0,AMR:this.AMR>>>0,SEC:this.SEC,MIN:this.MIN,HOUR:this.HOUR,DOM:this.DOM,DOW:this.DOW,DOY:this.DOY,MONTH:this.MONTH,YEAR:this.YEAR,CTIME0:this.ctime0()>>>0,CTIME1:this.ctime1()>>>0,CTIME2:this.ctime2()>>>0,crystalHz:RTC_XTAL_HZ,clockSource:(this.CCR&16)?'32.768 kHz external crystal':'PCLK divider',seconds:this.seconds}}
}
function ensurePWM(emu){if(!emu.pwmEngine)emu.pwmEngine=new WorkerPWM(emu);return emu.pwmEngine}
function ensureRTC(emu){if(!emu.rtcEngine)emu.rtcEngine=new WorkerRTC(emu);return emu.rtcEngine}
function isPWMAddress(a){a>>>=0;return a>=PWM_BASE&&a<=PWM_BASE+0x70}
function isRTCAddress(a){a>>>=0;return a>=RTC_BASE&&a<=RTC_BASE+0x84}

const UART0_BASE=0xE000C000>>>0, UART1_BASE=0xE0010000>>>0;
const PINSEL0=0xE002C000>>>0,PINSEL1=0xE002C004>>>0,PINSEL2=0xE002C014>>>0;
const externalInputs={0:new Map(),1:new Map()};
let pendingTx={0:[],1:[]};


const ADC_BASE=0xE0034000>>>0;
const ADCR_ADDR=ADC_BASE, ADGDR_ADDR=(ADC_BASE+0x04)>>>0, ADINTEN_ADDR=(ADC_BASE+0x0C)>>>0;
const ADDR0_ADDR=(ADC_BASE+0x10)>>>0, ADSTAT_ADDR=(ADC_BASE+0x30)>>>0;
const ADC_ANALOG_PINS=[27,28,29,30];
let adcAnalogRaw=[0,0,0,0]; /* canonical physical AIN0..AIN3, 10-bit */

class WorkerADC{
  constructor(emu){this.emu=emu;this.reset()}
  reset(){
    this.ADCR=0x00000001;this.ADGDR=0;this.ADINTEN=0x00000100;
    this.addr=new Uint32Array(8);this.done=new Uint8Array(8);this.overrun=new Uint8Array(8);
    this.busy=false;this.channel=0;this.dueCycle=0;this.burstIndex=0;this.conversions=0;
    this.lastResult=0;this.lastChannel=0;this.lastStart=0;this.triggerCount=0;
  }
  operational(){return !!(this.ADCR&(1<<21))}
  burst(){return !!(this.ADCR&(1<<16))}
  selectedMask(){const m=this.ADCR&0xff;return m?m:1}
  adcClockHz(){const div=((this.ADCR>>>8)&0xff)+1;return clockCfg.pclkHz/div}
  clocksPerConversion(){return this.burst()?(11-((this.ADCR>>>17)&7)):11}
  conversionCycles(){
    const hz=Math.max(1,this.adcClockHz());
    return Math.max(1,Math.ceil(this.clocksPerConversion()*clockCfg.cclkHz/hz));
  }
  pinAnalogSelected(ch){
    if(ch<0||ch>3)return false;
    const ps=(this.emu.pinConnect&&this.emu.pinConnect.PINSEL1)>>>0;
    const shift=22+ch*2;
    return ((ps>>>shift)&3)===1;
  }
  nextSelected(after=-1){
    const m=this.selectedMask()&0x0f; /* LPC2129 64-pin: AIN0..AIN3 only */
    if(!m)return 0;
    for(let n=1;n<=4;n++){const ch=(after+n)&3;if(m&(1<<ch))return ch}
    return 0;
  }
  start(ch,now){
    if(!this.operational())return;
    this.channel=ch&3;this.busy=true;this.dueCycle=Number(now||0)+this.conversionCycles();
  }
  commandStart(now){
    const start=(this.ADCR>>>24)&7;this.lastStart=start;
    if(this.burst()){
      if(start===0&&!this.busy){this.burstIndex=this.nextSelected(-1);this.start(this.burstIndex,now)}
      return;
    }
    if(start===1){this.start(this.nextSelected(-1),now)}
    /* START 2..7 are armed hardware-trigger modes; phase84Trigger() supplies the edge. */
  }
  externalTrigger(source,falling,now){
    if(this.burst()||!this.operational())return false;
    const st=(this.ADCR>>>24)&7;if(st<2||st>7)return false;
    const edge=!!(this.ADCR&(1<<27));if(edge!==!!falling)return false;
    const expected={2:'P0.16',3:'P0.22',4:'MAT0.1',5:'MAT0.3',6:'MAT1.0',7:'MAT1.1'}[st];
    if(source!==expected)return false;
    this.triggerCount++;this.start(this.nextSelected(-1),now);return true;
  }
  sampleRaw(ch){
    ch&=3;
    /* ADC inputs are physical AIN pins. Canvas/wiring updates adcAnalogRaw. */
    let raw=Number(adcAnalogRaw[ch]);if(!Number.isFinite(raw))raw=0;
    raw=Math.max(0,Math.min(1023,Math.round(raw)));
    /* CLKS reduces result accuracy in burst mode: lower bits are zeroed. */
    const bits=this.burst()?Math.max(3,10-((this.ADCR>>>17)&7)):10;
    if(bits<10) raw=(raw>>>(10-bits))<<(10-bits);
    return raw;
  }
  complete(ch,now){
    const raw=this.sampleRaw(ch);
    if(this.done[ch])this.overrun[ch]=1;
    this.done[ch]=1;this.lastResult=raw;this.lastChannel=ch;this.conversions++;
    this.addr[ch]=u32((raw<<6)|((ch&7)<<24)|(this.overrun[ch]?0x40000000:0)|0x80000000);
    const gdOver=(this.ADGDR&0x80000000)?0x40000000:0;
    this.ADGDR=u32((raw<<6)|((ch&7)<<24)|gdOver|0x80000000);
    this.busy=false;
    if(this.burst()&&this.operational()&&(((this.ADCR>>>24)&7)===0)){
      this.burstIndex=this.nextSelected(ch);this.start(this.burstIndex,now);
    }
  }
  tick(cycles){if(this.busy&&Number(cycles||0)>=this.dueCycle)this.complete(this.channel,this.dueCycle)}
  status(){
    let v=0;for(let i=0;i<8;i++){if(this.done[i])v|=(1<<i);if(this.overrun[i])v|=(1<<(8+i))}
    if(this.interruptPending())v|=(1<<16);return v>>>0;
  }
  interruptPending(){
    for(let i=0;i<8;i++)if(this.done[i]&&(this.ADINTEN&(1<<i)))return true;
    if(this.ADINTEN&(1<<8)){for(let i=0;i<8;i++)if(this.done[i])return true}
    return false;
  }
  read(a){
    a>>>=0;this.tick(lpcNowCycles());
    if(a===ADCR_ADDR)return this.ADCR>>>0;
    if(a===ADGDR_ADDR){const v=this.ADGDR>>>0;this.ADGDR&=~0xC0000000;return v}
    if(a===ADINTEN_ADDR)return this.ADINTEN>>>0;
    if(a===ADSTAT_ADDR)return this.status();
    if(a>=ADDR0_ADDR&&a<=ADDR0_ADDR+0x1c&&((a-ADDR0_ADDR)&3)===0){
      const ch=(a-ADDR0_ADDR)>>>2,v=this.addr[ch]>>>0;this.done[ch]=0;this.overrun[ch]=0;this.addr[ch]&=~0xC0000000;return v;
    }
    return 0;
  }
  write(a,v){
    a>>>=0;v>>>=0;
    if(a===ADCR_ADDR){
      /* Implement defined fields, ignore reserved/test bits. */
      this.ADCR=v&0x0F2FFFFF;
      this.ADGDR&=~0x80000000;
      this.commandStart(lpcNowCycles());return;
    }
    if(a===ADINTEN_ADDR){this.ADINTEN=v&0x1ff;return}
    if(a===ADGDR_ADDR){this.ADGDR=v>>>0;return}
  }
  snapshot(){return {ADCR:this.ADCR>>>0,ADGDR:this.ADGDR>>>0,ADSTAT:this.status(),ADINTEN:this.ADINTEN>>>0,
    ADDR:Array.from(this.addr),done:Array.from(this.done),overrun:Array.from(this.overrun),busy:this.busy,channel:this.channel,
    adcClockHz:this.adcClockHz(),clocksPerConversion:this.clocksPerConversion(),conversions:this.conversions,lastResult:this.lastResult,
    lastChannel:this.lastChannel,analogRaw:adcAnalogRaw.slice(),analogVolts:adcAnalogRaw.map(v=>Number((Math.max(0,Math.min(1023,v))*3.3/1023).toFixed(4))),
    pinAnalogSelected:[0,1,2,3].map(ch=>this.pinAnalogSelected(ch)),triggerCount:this.triggerCount};}
}

function ensureADC(emu){if(!emu.adcEngine)emu.adcEngine=new WorkerADC(emu);return emu.adcEngine}
function isAdcAddress(a){a>>>=0;return a===ADCR_ADDR||a===ADGDR_ADDR||a===ADINTEN_ADDR||a===ADSTAT_ADDR||(a>=ADDR0_ADDR&&a<=ADDR0_ADDR+0x1c&&((a-ADDR0_ADDR)&3)===0)}


/* VECTOR LPC2129 Phase 8.4B — Timer/Counter0 + Timer/Counter1 engine.
   Implements IR/TCR/TC/PR/PC/MCR/MR0..3/CCR/CR0..3/EMR/CTCR,
   PCLK timer mode, CAP edge counter mode, capture latching, match IRQ/reset/stop,
   external-match actions and VIC sources 4/5. */
const TIMER_BASES=[0xE0004000>>>0,0xE0008000>>>0];
const TIMER_REG_OFFSETS=new Set([0x00,0x04,0x08,0x0c,0x10,0x14,0x18,0x1c,0x20,0x24,0x28,0x2c,0x30,0x34,0x38,0x3c,0x70]);
class WorkerTimer{
  constructor(index,emu){this.index=index;this.emu=emu;this.base=TIMER_BASES[index];this.reset()}
  reset(){this.IR=0;this.TCR=0;this.TC=0;this.PR=0;this.PC=0;this.MCR=0;this.MR=new Uint32Array(4);this.CCR=0;this.CR=new Uint32Array(4);this.EMR=0;this.CTCR=0;this.lastCpuCycles=0;this.pclkFrac=0;this.matchCount=0;this.captureCount=0;this.counterEdges=0;this.pclkTicks=0;}
  enabled(){return !!(this.TCR&1) && !(this.TCR&2)}
  interruptPending(){return !!(this.IR&0xff)}
  counterMode(){return this.CTCR&3}
  counterChannel(){return (this.CTCR>>>2)&3}
  processMatch(){
    const tc=this.TC>>>0;let doReset=false,doStop=false;
    for(let ch=0;ch<4;ch++)if((this.MR[ch]>>>0)===tc){
      this.matchCount++;const m=(this.MCR>>>(ch*3))&7;if(m&1)this.IR|=(1<<ch);if(m&2)doReset=true;if(m&4)doStop=true;
      const ctl=(this.EMR>>>(4+ch*2))&3;let bit=(this.EMR>>>ch)&1,nb=bit;if(ctl===1)nb=0;else if(ctl===2)nb=1;else if(ctl===3)nb=bit^1;
      if(nb!==bit){if(nb)this.EMR|=(1<<ch);else this.EMR&=~(1<<ch);try{ensureADC(this.emu).externalTrigger('MAT'+this.index+'.'+ch,!nb,lpcNowCycles())}catch(e){}}
    }
    if(doReset){this.TC=0;this.PC=0}
    if(doStop)this.TCR&=~1;
  }
  advanceTC(incs){
    incs=Math.floor(Number(incs)||0);if(incs<=0)return;
    const MOD=4294967296;let remaining=incs;let guard=0;
    while(remaining>0&&this.enabled()&&guard++<64){
      const tc=this.TC>>>0;let best=MOD;
      for(let ch=0;ch<4;ch++){let d=(Number(this.MR[ch]>>>0)-tc+MOD)%MOD;if(d===0)d=MOD;if(d<best)best=d}
      if(best>remaining||best>=MOD){this.TC=(tc+remaining)>>>0;remaining=0;break}
      this.TC=(tc+best)>>>0;remaining-=best;this.processMatch();
    }
    if(remaining>0&&this.enabled())this.TC=(this.TC+remaining)>>>0;
  }
  /* Phase 8.4G: Timer clocking belongs to the LPC2129 VPB/PCLK domain. */
  tickPclk(pt){
    pt=Math.floor(Number(pt)||0);if(pt<=0||!this.enabled()||this.counterMode()!==0)return;
    this.pclkTicks+=pt;
    const div=(this.PR>>>0)+1,total=(this.PC>>>0)+pt,incs=Math.floor(total/div);this.PC=(total%div)>>>0;if(incs)this.advanceTC(incs);
  }
  tick(cpuCycles){this.lastCpuCycles=Number(cpuCycles)||this.lastCpuCycles;}
  externalEdge(channel,rising){
    channel&=3;const mode=this.counterMode();if(this.enabled()&&mode){const selected=this.counterChannel();if(channel===selected&&((mode===1&&rising)||(mode===2&&!rising)||mode===3)){this.counterEdges++;this.advanceTC(1)}}
    const c=(this.CCR>>>(channel*3))&7;if((rising&&(c&1))||(!rising&&(c&2))){this.CR[channel]=this.TC>>>0;this.captureCount++;if(c&4)this.IR|=(1<<(4+channel))}
  }
  read(a){const o=(a-this.base)>>>0;if(o===0x00)return this.IR>>>0;if(o===0x04)return this.TCR>>>0;if(o===0x08)return this.TC>>>0;if(o===0x0c)return this.PR>>>0;if(o===0x10)return this.PC>>>0;if(o===0x14)return this.MCR>>>0;if(o>=0x18&&o<=0x24)return this.MR[(o-0x18)>>>2]>>>0;if(o===0x28)return this.CCR>>>0;if(o>=0x2c&&o<=0x38)return this.CR[(o-0x2c)>>>2]>>>0;if(o===0x3c)return this.EMR>>>0;if(o===0x70)return this.CTCR>>>0;return 0}
  write(a,v){v>>>=0;const o=(a-this.base)>>>0;if(o===0x00){this.IR&=~(v&0xff);return}if(o===0x04){this.TCR=v&3;if(this.TCR&2){this.TC=0;this.PC=0}return}if(o===0x08){this.TC=v;return}if(o===0x0c){this.PR=v;return}if(o===0x10){this.PC=v;return}if(o===0x14){this.MCR=v&0xfff;return}if(o>=0x18&&o<=0x24){this.MR[(o-0x18)>>>2]=v;return}if(o===0x28){this.CCR=v&0xfff;return}if(o===0x3c){this.EMR=v&0xfff;return}if(o===0x70){this.CTCR=v&0xf;return}}
  snapshot(){return {index:this.index,pclkTicks:this.pclkTicks,IR:this.IR>>>0,TCR:this.TCR>>>0,TC:this.TC>>>0,PR:this.PR>>>0,PC:this.PC>>>0,MCR:this.MCR>>>0,MR:Array.from(this.MR),CCR:this.CCR>>>0,CR:Array.from(this.CR),EMR:this.EMR>>>0,CTCR:this.CTCR>>>0,matchCount:this.matchCount,captureCount:this.captureCount,counterEdges:this.counterEdges,interruptPending:this.interruptPending()}}
}
function ensureTimers(emu){if(!emu.timerEngines)emu.timerEngines={0:new WorkerTimer(0,emu),1:new WorkerTimer(1,emu)};return emu.timerEngines}
function timerForAddress(a){a>>>=0;for(let i=0;i<2;i++){const b=TIMER_BASES[i];if(a>=b&&a<=b+0x70&&TIMER_REG_OFFSETS.has((a-b)>>>0))return i}return -1}

class WorkerUART{
  constructor(port,emu){this.port=port;this.emu=emu;this.base=port?UART1_BASE:UART0_BASE;this.reset()}
  reset(){
    this.DLL=1;this.DLM=0;this.IER=0;this.FCR=0;this.LCR=0;this.LSR=0x60;
    this.SCR=0;this.ACR=0;this.FDR=0x10;this.TER=0x80;this.MCR=0;this.MSR=0;
    this.rx=[];this.rxErrors=[];this.tx=[];this.activeTx=null;this.txDueCycles=0;
    this.txCount=0;this.rxCount=0;this.overrunCount=0;this.lastTxCycle=0;this.lastRxCycle=0;
  }
  dlab(){return !!(this.LCR&0x80)}
  fifoEnabled(){return !!(this.FCR&1)}
  fifoCapacity(){return this.fifoEnabled()?16:1}
  rxTrigger(){return [1,4,8,14][(this.FCR>>>6)&3]}
  wordBits(){return 5+(this.LCR&3)}
  frameBits(){const stop=(this.LCR&4)?(this.wordBits()===5?1.5:2):1;return 1+this.wordBits()+((this.LCR&8)?1:0)+stop}
  divisor(){return (((this.DLM<<8)|this.DLL)&0xffff)||1}
  baud(){
    const mul=((this.FDR>>>4)&15)||1, add=this.FDR&15;
    return clockCfg.pclkHz/(16*this.divisor()*(1+add/mul));
  }
  frameCycles(){return Math.max(1,Math.round((this.frameBits()/Math.max(1,this.baud()))*clockCfg.cclkHz))}
  pinsConfigured(){
    const ps=(this.emu.pinConnect&&this.emu.pinConnect.PINSEL0)>>>0;
    return this.port===0?((ps&0xf)===0x5):(((ps>>>16)&0xf)===0x5);
  }
  updateLSR(){
    if(this.rx.length)this.LSR|=1;else this.LSR&=~1;
    if(this.tx.length===0)this.LSR|=0x20;else this.LSR&=~0x20;
    if(this.tx.length===0&&this.activeTx===null)this.LSR|=0x40;else this.LSR&=~0x40;
    if(this.rxErrors.length)this.LSR|=0x80;else this.LSR&=~0x80;
  }
  iir(){
    const f=this.fifoEnabled()?0xc0:0;
    if((this.IER&4)&&(this.LSR&0x1e))return f|0x06;
    if((this.IER&1)&&this.rx.length>=this.rxTrigger())return f|0x04;
    if((this.IER&2)&&(this.LSR&0x20))return f|0x02;
    if(this.port===1&&(this.IER&8)&&(this.MSR&0x0f))return f;
    return f|1;
  }
  read(off){
    off&=0xfc;this.tick(lpcNowCycles());
    switch(off){
      case 0x00:
        if(this.dlab())return this.DLL;
        if(!this.rx.length){this.updateLSR();return 0}
        {const b=this.rx.shift()&255,er=this.rxErrors.shift()||0;this.LSR=(this.LSR&~0x1e)|(er&0x1e);this.rxCount++;this.lastRxCycle=lpcNowCycles();this.updateLSR();return b}
      case 0x04:return this.dlab()?this.DLM:this.IER;
      case 0x08:return this.iir();
      case 0x0c:return this.LCR;
      case 0x10:return this.port?this.MCR:0;
      case 0x14:{this.updateLSR();const v=this.LSR&255;this.LSR&=~0x1e;this.updateLSR();return v}
      case 0x18:{if(!this.port)return 0;const v=this.MSR&255;this.MSR&=0xf0;return v}
      case 0x1c:return this.SCR;
      case 0x20:return this.ACR;
      case 0x28:return this.FDR;
      case 0x30:return this.TER;
      default:return 0;
    }
  }
  write(off,val){
    off&=0xfc;val>>>=0;
    switch(off){
      case 0x00: if(this.dlab())this.DLL=val&255; else this.writeTHR(val&255);break;
      case 0x04: if(this.dlab())this.DLM=val&255; else this.IER=val&(this.port?0x30f:0x307);break;
      case 0x08:
        this.FCR=val&0xc7;
        if(val&2){this.rx=[];this.rxErrors=[];this.LSR&=~0x1f}
        if(val&4){this.tx=[];this.activeTx=null;this.LSR|=0x60}
        break;
      case 0x0c:this.LCR=val&255;break;
      case 0x10:if(this.port){this.MCR=val&0xf3;this.loopbackModem()}break;
      case 0x1c:this.SCR=val&255;break;
      case 0x20:this.ACR=val&7;if(val&0x300)this.ACR&=~1;break;
      case 0x28:this.FDR=val&255;break;
      case 0x30:this.TER=val&0x80;break;
    }
    this.updateLSR();
  }
  writeTHR(b){
    if(!(this.TER&0x80))return;
    if(this.tx.length>=this.fifoCapacity())return;
    this.tx.push(b&255);this.LSR&=~0x60;this.startNext(lpcNowCycles());
  }
  startNext(now){
    if(this.activeTx!==null||!this.tx.length||!(this.TER&0x80))return;
    this.activeTx=this.tx.shift()&255;
    this.txDueCycles=Number(now)+this.frameCycles();
    this.updateLSR();
  }
  tick(cycles){
    cycles=Number(cycles||0);this.startNext(cycles);
    let guard=0;
    while(this.activeTx!==null&&cycles>=this.txDueCycles&&guard++<64){
      const b=this.activeTx&255,doneAt=this.txDueCycles;
      this.activeTx=null;this.txCount++;this.lastTxCycle=doneAt;
      if(this.pinsConfigured()){
        if(this.port===1&&(this.MCR&0x10))this.injectRx(b,0,true);
        else pendingTx[this.port].push(b);
      }
      this.startNext(doneAt);
    }
    this.updateLSR();
  }
  injectRx(b,err=0,internal=false){
    if(!internal&&!this.pinsConfigured())return false;
    if(this.rx.length>=this.fifoCapacity()){this.LSR|=2;this.overrunCount++;return false}
    const mask=(1<<this.wordBits())-1;
    this.rx.push((b&mask)&255);this.rxErrors.push(err&0x1e);this.LSR|=1;if(err&0x1e)this.LSR|=(err&0x1e)|0x80;return true;
  }
  loopbackModem(){
    if(!this.port||!(this.MCR&0x10))return;
    const old=(this.MSR>>>4)&15;
    const now=((this.MCR&2)?1:0)|((this.MCR&1)?2:0)|((this.MCR&4)?4:0)|((this.MCR&8)?8:0);
    this.MSR=((now&15)<<4)|((old^now)&15);
  }
  snapshot(){
    this.updateLSR();
    return {DLL:this.DLL,DLM:this.DLM,IER:this.IER,FCR:this.FCR,LCR:this.LCR,LSR:this.LSR,SCR:this.SCR,
      ACR:this.ACR,FDR:this.FDR,TER:this.TER,MCR:this.MCR,MSR:this.MSR,IIR:this.iir(),baud:this.baud(),
      fifo:this.fifoEnabled(),rxDepth:this.rx.length,txDepth:this.tx.length+(this.activeTx!==null?1:0),
      txCount:this.txCount,rxCount:this.rxCount,overrunCount:this.overrunCount,pinsConfigured:this.pinsConfigured(),
      wordBits:this.wordBits()};
  }
}

function ensurePeripherals(emu){
  ensureVIC(emu);
  if(!emu.pinConnect)emu.pinConnect={PINSEL0:0,PINSEL1:0,PINSEL2:0x0000000c};
  if(!emu.uartEngines)emu.uartEngines={0:new WorkerUART(0,emu),1:new WorkerUART(1,emu)};
  ensureADC(emu);
  ensureTimers(emu); ensurePWM(emu); ensureRTC(emu); ensureI2C(emu); ensureSPIs(emu); ensureCAN(emu);
  return emu.uartEngines;
}
window.phase82IsPeripheralAddress=function(a){
  a>>>=0;
  return isVicAddress(a)||isAdcAddress(a)||isPWMAddress(a)||isRTCAddress(a)||isI2CAddress(a)||spiForAddress(a)>=0||canControllerForAddress(a)>0||isCANAFAddress(a)||isCANAFRam(a)||isCANCentral(a)||timerForAddress(a)>=0||(a>=UART0_BASE&&a<=UART0_BASE+0x30)||(a>=UART1_BASE&&a<=UART1_BASE+0x30)||a===PINSEL0||a===PINSEL1||a===PINSEL2;
};
window.phase82PeripheralRead=function(emu,a,width){
  a>>>=0;ensurePeripherals(emu);ensureVIC(emu);
  if(isVicAddress(a))return emu.vic.read(a)>>>0;
  if(isAdcAddress(a))return ensureADC(emu).read(a)>>>0;
  if(isPWMAddress(a))return ensurePWM(emu).read(a)>>>0;
  if(isRTCAddress(a))return ensureRTC(emu).read(a)>>>0;
  if(isI2CAddress(a))return ensureI2C(emu).read(a)>>>0;
  {const ci=canControllerForAddress(a);if(ci)return ensureCAN(emu)[ci].read(a)>>>0;}
  if(isCANAFAddress(a)){ensureCAN(emu);return emu.canAF.read(a)>>>0;}
  if(isCANAFRam(a)){ensureCAN(emu);return emu.canAF.ram[((a-CAN_AF_RAM)>>>2)&511]>>>0;}
  if(isCANCentral(a))return canCentralRead(emu,a)>>>0;
  {const si=spiForAddress(a);if(si>=0)return ensureSPIs(emu)[si].read(a)>>>0;}
  {const ti=timerForAddress(a);if(ti>=0)return ensureTimers(emu)[ti].read(a)>>>0;}
  if(a===PINSEL0)return emu.pinConnect.PINSEL0>>>0;
  if(a===PINSEL1)return emu.pinConnect.PINSEL1>>>0;
  if(a===PINSEL2)return emu.pinConnect.PINSEL2>>>0;
  const p=a>=UART1_BASE?1:0,b=p?UART1_BASE:UART0_BASE;
  return emu.uartEngines[p].read((a-b)>>>0)>>>0;
};
window.phase82PeripheralWrite=function(emu,a,v,width){
  a>>>=0;v>>>=0;ensurePeripherals(emu);ensureVIC(emu);
  if(isVicAddress(a)){emu.vic.write(a,v);return}
  if(isAdcAddress(a)){ensureADC(emu).write(a,v);return}
  if(isPWMAddress(a)){ensurePWM(emu).write(a,v);return}
  if(isRTCAddress(a)){ensureRTC(emu).write(a,v);return}
  if(isI2CAddress(a)){ensureI2C(emu).write(a,v);return}
  {const ci=canControllerForAddress(a);if(ci){ensureCAN(emu)[ci].write(a,v);return}}
  if(isCANAFAddress(a)){ensureCAN(emu);emu.canAF.write(a,v);return}
  if(isCANAFRam(a)){ensureCAN(emu);emu.canAF.ram[((a-CAN_AF_RAM)>>>2)&511]=v>>>0;return}
  if(isCANCentral(a))return;
  {const si=spiForAddress(a);if(si>=0){ensureSPIs(emu)[si].write(a,v);return}}
  {const ti=timerForAddress(a);if(ti>=0){ensureTimers(emu)[ti].write(a,v);return}}
  if(a===PINSEL0){emu.pinConnect.PINSEL0=v;return}
  if(a===PINSEL1){emu.pinConnect.PINSEL1=v;return}
  if(a===PINSEL2){emu.pinConnect.PINSEL2=v;return}
  const p=a>=UART1_BASE?1:0,b=p?UART1_BASE:UART0_BASE;
  emu.uartEngines[p].write((a-b)>>>0,v);
};
window.phase80SampleExternalInputs=function(emu){
  let changed=false;
  for(const port of [0,1]){
    const dir=port===0?emu.gpio.IO0DIR>>>0:emu.gpio.IO1DIR>>>0;
    const before=port===0?emu.gpio.IO0PIN>>>0:emu.gpio.IO1PIN>>>0;
    let v=before;
    for(const [pin,level] of externalInputs[port]){
      const bit=(2**pin)>>>0;if(dir&bit)continue;
      v=level?u32(v|bit):u32(v&~bit);
    }
    if(v!==before){changed=true;if(port===0)emu.gpio.IO0PIN=v;else emu.gpio.IO1PIN=v}
  }
  if(changed)emu.gpioPinChangeCount=(emu.gpioPinChangeCount||0)+1;
  return changed;
};

let emu=null,running=false,resetAsserted=false;
let wallPrev=0,wallAccumulatorMs=0,lastSnapshotWall=0,lastTxFlushWall=0;
const QUANTUM_US=1000,MAX_CATCHUP_MS=20;
/* Phase 8.4H: the LPC2129 clock tree owns time. The ARM interpreter is a functional
   executor attached to that clock domain; it must never stall Timer/VIC wall timing.
   2000 real decoded instructions per 1 ms hardware quantum is ample for startup,
   polling loops and IRQ service without making host throughput define PCLK. */
const CPU_STEPS_PER_QUANTUM=2000,MAX_CPU_STEPS_PER_SLICE=40000;
let lpcSimTimeUs=0,pclkFracTicks=0;
const SNAPSHOT_MS=33,TX_FLUSH_MS=16;

function makeSnapshot(){
  if(!emu)return null;
  const us=ensurePeripherals(emu);
  return {
    running,
    lpcSimTimeUs,
    lpcClockCycles,
    steps:emu.steps,
    r:Array.from(emu.r),
    cpsr:{...emu.cpsr},
    gpio:{...emu.gpio},
    gpioPinChangeCount:emu.gpioPinChangeCount||0,
    lastGpioTransitionCycles:emu.lastGpioTransitionCycles||0,
    lastError:emu.lastError||'',
    disasm:emu.disasm||'',
    unsupportedCount:emu.unsupportedCount||0,
    lastUnsupported:emu.lastUnsupported||null,
    profiler:JSON.parse(JSON.stringify(emu.profiler)),
    decodeStats:JSON.parse(JSON.stringify(emu.decodeStats)),
    uart0:us[0].snapshot(),
    uart1:us[1].snapshot(),
    adc:ensureADC(emu).snapshot(),
    timer0:ensureTimers(emu)[0].snapshot(),
    timer1:ensureTimers(emu)[1].snapshot(),
    pwm:ensurePWM(emu).snapshot(),
    rtc:ensureRTC(emu).snapshot(),
    i2c:ensureI2C(emu).snapshot(),
    spi0:ensureSPIs(emu)[0].snapshot(),
    spi1:ensureSPIs(emu)[1].snapshot(),
    can1:ensureCAN(emu)[1].snapshot(),
    can2:ensureCAN(emu)[2].snapshot(),
    canAF:emu.canAF.snapshot(),
    canBus:emu.canBus.snapshot(),
    vic:ensureVIC(emu).snapshot(),
    pinConnect:{...emu.pinConnect}
  };
}
function flushTx(force=false){
  const now=performance.now();
  if(!force&&now-lastTxFlushWall<TX_FLUSH_MS)return;
  lastTxFlushWall=now;
  for(const p of [0,1]){
    if(pendingTx[p].length){
      const bytes=pendingTx[p].splice(0,pendingTx[p].length);
      postMessage({type:'uart-tx',port:p,bytes});
      postMessage({type:'activity',kind:'tx',port:p,count:bytes.length});
    }
  }
}
function sendSnapshot(force=false){
  const now=performance.now();
  if(!force&&now-lastSnapshotWall<SNAPSHOT_MS)return;
  lastSnapshotWall=now;postMessage({type:'snapshot',state:makeSnapshot()});
}
function runSlice(){
  if(!running||!emu)return;
  if(resetAsserted){setTimeout(runSlice,1);return}
  const now=performance.now();
  let dt=now-wallPrev;wallPrev=now;
  if(dt<0)dt=0;if(dt>MAX_CATCHUP_MS)dt=MAX_CATCHUP_MS;
  wallAccumulatorMs+=dt;
  let count=0;
  try{
    const quantumMs=QUANTUM_US/1000;
    while(running&&wallAccumulatorMs>=quantumMs&&count<MAX_CPU_STEPS_PER_SLICE){
      /* Phase 8.4H canonical hardware-time commit.
         One LPC2129 millisecond advances the oscillator/PLL/CCLK/PCLK domains first.
         Timer/ADC/UART therefore observe the same hardware timestamp independent of
         how quickly the host can decode the ARM polling loop. */
      lpcSimTimeUs+=QUANTUM_US;
      const qcycles=Math.max(1,Math.floor(clockCfg.cclkHz*QUANTUM_US/1000000));
      lpcClockCycles+=qcycles;
      const pExact=clockCfg.pclkHz*QUANTUM_US/1000000+pclkFracTicks;
      const pTicks=Math.floor(pExact);pclkFracTicks=pExact-pTicks;
      const us=ensurePeripherals(emu),timers=ensureTimers(emu);
      timers[0].tickPclk(pTicks);timers[1].tickPclk(pTicks);ensurePWM(emu).tickPclk(pTicks);
      /* RTC CLKSRC=1 uses its dedicated 32.768 kHz crystal, independent of PCLK. */
      ensureRTC(emu).tickCrystal(RTC_XTAL_HZ*QUANTUM_US/1000000);
      us[0].tick(lpcNowCycles());us[1].tick(lpcNowCycles());ensureADC(emu).tick(lpcNowCycles());

      /* Execute the actual compiled ARM/THUMB firmware. A pending LPC2129 IRQ is
         sampled before every instruction, so a Timer match enters the genuine VIC
         path and the compiled ISR performs the GPIO write. No Timer->LED shortcut. */
      let qsteps=0;
      while(running&&qsteps<CPU_STEPS_PER_QUANTUM&&count<MAX_CPU_STEPS_PER_SLICE){
        enterIRQIfPending(emu);emu.step();qsteps++;count++;
      }
      wallAccumulatorMs-=quantumMs;
    }
    flushTx();sendSnapshot();
  }catch(e){
    running=false;emu.running=false;emu.lastError=e&&e.message?e.message:String(e);
    flushTx(true);sendSnapshot(true);postMessage({type:'error',text:emu.lastError});return;
  }
  setTimeout(runSlice,0);
}
onmessage=function(ev){
  const m=ev.data||{};
  if(m.type==='start'){
    clockCfg={cclkHz:Math.max(1,Number(m.clock&&m.clock.cclkHz)||60000000),pclkHz:Math.max(1,Number(m.clock&&m.clock.pclkHz)||15000000)};lpcSimTimeUs=0;pclkFracTicks=0;lpcClockCycles=0;
    emu=new LPC2129Arm7Emu();
    const n=emu.loadIntelHex(m.hex||'');
    ensurePeripherals(emu);
    running=true;emu.running=true;wallPrev=performance.now();wallAccumulatorMs=0;lastSnapshotWall=0;lastTxFlushWall=0;
    postMessage({type:'started',bytes:n});
    sendSnapshot(true);setTimeout(runSlice,0);
  }else if(m.type==='stop'){
    running=false;if(emu)emu.running=false;flushTx(true);sendSnapshot(true);postMessage({type:'stopped'});
  }else if(m.type==='rx'){
    if(!emu)return;const p=Number(m.port)?1:0,u=ensurePeripherals(emu)[p];
    let accepted=0;
    for(const b of (m.bytes||[]))if(u.injectRx(Number(b)&255,0,false))accepted++;
    if(accepted)postMessage({type:'activity',kind:'rx',port:p,count:accepted});
    sendSnapshot(true);
  }else if(m.type==='reset-assert'){
    resetAsserted=true;
    pendingTx={0:[],1:[]};
    postMessage({type:'reset-state',asserted:true});
    sendSnapshot(true);
  }else if(m.type==='reset-release'){
    if(emu){
      const flash=emu.flash.slice();
      emu.reset();
      emu.flash.set(flash);
      emu.loaded=true;emu.running=true;
      /* Hardware reset also resets the modeled LPC2129 peripheral blocks. */
      emu.uartEngines=null;emu.adcEngine=null;emu.timerEngines=null;emu.vic=null;emu.pinConnect=null;
      ensurePeripherals(emu);
      pendingTx={0:[],1:[]};
      wallPrev=performance.now();wallAccumulatorMs=0;
    }
    resetAsserted=false;
    postMessage({type:'reset-state',asserted:false});
    sendSnapshot(true);
  }else if(m.type==='gpio-input'){
    const p=Number(m.port)?1:0,pin=Number(m.pin);
    if(Number.isFinite(pin))externalInputs[p].set(pin,!!m.level);
  }else if(m.type==='gpio-input-release'){
    const p=Number(m.port)?1:0,pin=Number(m.pin);
    if(Number.isFinite(pin))externalInputs[p].delete(pin);
  }else if(m.type==='adc-input'){
    const ch=Number(m.channel),raw=Number(m.raw);
    if(Number.isFinite(ch)&&ch>=0&&ch<4&&Number.isFinite(raw))adcAnalogRaw[ch]=Math.max(0,Math.min(1023,Math.round(raw)));
  }else if(m.type==='adc-trigger'){
    if(emu)ensureADC(emu).externalTrigger(String(m.source||''),!!m.falling,lpcNowCycles());
  }else if(m.type==='timer-edge'){
    if(emu){const ti=Number(m.timer)?1:0;ensureTimers(emu)[ti].externalEdge(Number(m.channel)||0,!!m.rising);}
  }else if(m.type==='clock'){
    clockCfg={cclkHz:Math.max(1,Number(m.cclkHz)||clockCfg.cclkHz),pclkHz:Math.max(1,Number(m.pclkHz)||clockCfg.pclkHz)};
  }else if(m.type==='eeprom-config'){
    if(emu){const dev=ensureI2C(emu).eeprom;dev.present=(m.present!==false);dev.address=(0x50|(Number(m.a0)||0)|((Number(m.a1)||0)<<1)|((Number(m.a2)||0)<<2))&0x7f;if('wp' in m)dev.wp=!!m.wp;if('writeCycleUs' in m)dev.writeCycleUs=Math.max(0,Number(m.writeCycleUs)||0);sendSnapshot(true);}
    }else if(m.type==='i2c-fault-config'){
    if(emu){const q=ensureI2C(emu);if('clockStretchUs' in m)q.clockStretchUs=Math.max(0,Number(m.clockStretchUs)||0);if('sdaLow' in m)q.externalSdaLow=!!m.sdaLow;if('sclLow' in m)q.externalSclLow=!!m.sclLow;if(m.arbitrationLost)q.loseArbitration();sendSnapshot(true);}
    }else if(m.type==='spi-eeprom-config'){
    if(emu){const d=ensureSPIs(emu)[0].eeprom;d.present=(m.present!==false);if('wp' in m)d.wp=!!m.wp;if('hold' in m)d.hold=!!m.hold;if('writeCycleUs' in m)d.writeCycleUs=Math.max(0,Number(m.writeCycleUs)||0);sendSnapshot(true);}
    }else if(m.type==='can-external-config'){
    if(emu){ensureCAN(emu);emu.canBus.externalMode=!!m.enabled;emu.canBus.nodeId=String(m.nodeId||'');sendSnapshot(true);}
  }else if(m.type==='can-external-result'){
    if(emu){const c=ensureCAN(emu)[Number(m.controller)||1];if(c)c.txDone(Number(m.buf)||1,!!m.ack);sendSnapshot(true);}
  }else if(m.type==='can-external-rx'){
    if(emu){const c=ensureCAN(emu)[Number(m.controller)||1];if(c)c.externalReceive(m.frame||{});sendSnapshot(true);}
  }else if(m.type==='can-external-arbitration-lost'){
    if(emu){const c=ensureCAN(emu)[Number(m.controller)||1];if(c){const b=Number(m.buf)||1;c.externalArbitrationLost(b,Number(m.bit)||0);setTimeout(()=>{try{c.bus.transmit(c,c.txFrame(b))}catch(e){}},1);}sendSnapshot(true);}
  }else if(m.type==='can-bus-config'){
    if(emu){ensureCAN(emu);const b=emu.canBus;if('connected' in m)b.connected=!!m.connected;if('term1' in m)b.term1=!!m.term1;if('term2' in m)b.term2=!!m.term2;if('mcp1' in m)b.mcp1=!!m.mcp1;if('mcp2' in m)b.mcp2=!!m.mcp2;sendSnapshot(true);}
  }else if(m.type==='debug-clear'){
    if(emu){const s=String(m.scope||'all');
      if(s==='all'||s==='i2c'){const q=ensureI2C(emu);q.events=[];q.phaseCount=0;q.arbitrationLost=false;q.busError=false;q.eeprom.events=[];q.eeprom.writeCount=0;q.eeprom.readCount=0;q.eeprom.lastAckPolls=0;}
      if(s==='all'||s==='spi'){const sp=ensureSPIs(emu);for(const k of [0,1]){sp[k].events=[];sp[k].wave=[];sp[k].transfers=0;}const d=sp[0].eeprom;if(d){d.events=[];d.writeCount=0;d.readCount=0;}}
      if(s==='all'||s==='can'){ensureCAN(emu);for(const k of [1,2]){const c=emu.canControllers[k];c.events=[];c.transfers=0;c.rxCount=0;}emu.canBus.frames=[];emu.canBus.seq=0;}
      sendSnapshot(true);
    }
  }else if(m.type==='memory-write'){
    const reqId=Number(m.reqId)||0;
    const kind=String(m.kind||'');
    let base=Number(m.base)>>>0;
    const data=Array.isArray(m.bytes)?m.bytes:[];
    let written=0;
    if(emu){
      if(kind==='flash'){
        if(base<0x00040000){written=Math.min(data.length,0x00040000-base);for(let i=0;i<written;i++)emu.flash[base+i]=Number(data[i])&255;}
      }else if(kind==='ram'){
        if(base>=0x40000000&&base<0x40004000){const off=base-0x40000000;written=Math.min(data.length,0x4000-off);for(let i=0;i<written;i++)emu.ram[off+i]=Number(data[i])&255;}
      }else if(kind==='eeprom'){
        const dev=ensureI2C(emu).eeprom;base&=0xFFFF;written=Math.min(data.length,0x10000-base);for(let i=0;i<written;i++)dev.mem[base+i]=Number(data[i])&255;
      }else if(kind==='spieeprom'){
        const dev=ensureSPIs(emu)[0].eeprom;base&=0xFFFF;written=Math.min(data.length,0x10000-base);for(let i=0;i<written;i++)dev.mem[base+i]=Number(data[i])&255;
      }
      sendSnapshot(true);
    }
    postMessage({type:'memory-op-response',reqId,op:'write',kind,base,written});
  }else if(m.type==='memory-fill'){
    const reqId=Number(m.reqId)||0;
    const kind=String(m.kind||'');
    let start=Number(m.start)>>>0,end=Number(m.end)>>>0,value=Number(m.value)&255,filled=0;
    if(end<start){const t=start;start=end;end=t;}
    if(emu){
      if(kind==='flash'){
        start=Math.min(start,0x0003FFFF);end=Math.min(end,0x0003FFFF);if(end>=start){emu.flash.fill(value,start,end+1);filled=end-start+1;}
      }else if(kind==='ram'){
        start=Math.max(start,0x40000000);end=Math.min(end,0x40003FFF);if(end>=start){emu.ram.fill(value,start-0x40000000,end-0x40000000+1);filled=end-start+1;}
      }else if(kind==='eeprom'){
        const dev=ensureI2C(emu).eeprom;start&=0xFFFF;end=Math.min(end&0xFFFF,0xFFFF);if(end>=start){dev.mem.fill(value,start,end+1);filled=end-start+1;}
      }else if(kind==='spieeprom'){
        const dev=ensureSPIs(emu)[0].eeprom;start&=0xFFFF;end=Math.min(end&0xFFFF,0xFFFF);if(end>=start){dev.mem.fill(value,start,end+1);filled=end-start+1;}
      }
      sendSnapshot(true);
    }
    postMessage({type:'memory-op-response',reqId,op:'fill',kind,start,end,value,filled});
  }else if(m.type==='memory-read'){
    const reqId=Number(m.reqId)||0;
    const kind=String(m.kind||'');
    let base=Number(m.base)>>>0;
    let length=Math.max(1,Math.min(1024,Number(m.length)||256));
    let bytes=[];
    if(emu){
      if(kind==='flash'){
        if(base>=0x00000000&&base<0x00040000){
          length=Math.min(length,0x00040000-base);
          bytes=Array.from(emu.flash.slice(base,base+length));
        }
      }else if(kind==='ram'){
        if(base>=0x40000000&&base<0x40004000){
          const off=base-0x40000000;
          length=Math.min(length,0x4000-off);
          bytes=Array.from(emu.ram.slice(off,off+length));
        }
      }else if(kind==='eeprom'){
        const dev=ensureI2C(emu).eeprom;
        base=base&0xFFFF;
        length=Math.min(length,0x10000-base);
        bytes=Array.from(dev.mem.slice(base,base+length));
      }else if(kind==='spieeprom'){
        const dev=ensureSPIs(emu)[0].eeprom;
        base=base&0xFFFF;
        length=Math.min(length,0x10000-base);
        bytes=Array.from(dev.mem.slice(base,base+length));
      }
    }
    postMessage({type:'memory-response',reqId,kind,base,bytes});
  }else if(m.type==='snapshot'){
    sendSnapshot(true);
  }
};
